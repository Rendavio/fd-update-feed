export function installAutoThemeRefresh({ win, doc, getThemeMode, refresh }) {
  const refreshIfAuto = (reason) => {
    if (getThemeMode() === 'auto') refresh(new Date(), reason);
  };

  refreshIfAuto('startup');
  win.setInterval(() => refreshIfAuto('timer'), 60_000);
  doc.addEventListener('visibilitychange', () => {
    if (doc.visibilityState === 'visible') refreshIfAuto('visibilitychange');
  });
}

