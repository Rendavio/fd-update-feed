// Only this closed schema can enter the private audit transport.
const enums = {
  kind: ['websocket', 'message', 'decision', 'overlay', 'audio', 'test'],
  source: ['p2p', 'maintenance_click', 'maintenance_unattended', 'development'],
  websocket: ['connected', 'disconnected', 'reconnecting', 'connecting'],
  reconnectResult: ['pending', 'connected', 'failed'],
  overlay: ['requested', 'shown', 'cleared', 'not_shown'],
  audioResult: ['played', 'blocked', 'failed', 'cancelled', 'timeout', 'unsupported'],
  audioError: ['none', 'timeout', 'blocked', 'cancelled', 'unsupported', 'failed', 'stale'],
  contextBefore: ['running', 'suspended', 'closed', 'interrupted', 'unknown'],
  contextAfter: ['running', 'suspended', 'closed', 'interrupted', 'unknown'],
};
const flags = ['cancelled', 'tokyo23Matched', 'duplicateSuppressed', 'audioRequested', 'userActivation'];
export function safeEewRow(row) {
  if (!row || !enums.kind.includes(row.kind) || !enums.source.includes(row.source)) return null;
  const safe = {};
  for (const [key, values] of Object.entries(enums)) if (values.includes(row[key])) safe[key] = row[key];
  for (const key of flags) if (typeof row[key] === 'boolean') safe[key] = row[key];
  if (typeof row.eventId === 'string' && /^(?:[0-9]{14}|TEST-[A-Z0-9_-]{1,75})$/.test(row.eventId)) safe.eventId = row.eventId;
  if (typeof row.serial === 'string' && /^[0-9]{1,6}$/.test(row.serial)) safe.serial = row.serial;
  if (Number.isInteger(row.reconnectAttempt) && row.reconnectAttempt >= 0 && row.reconnectAttempt <= 10000) safe.reconnectAttempt = row.reconnectAttempt;
  return safe;
}
export async function requestEew(path, body, fetchImpl = globalThis.fetch.bind(globalThis)) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 3000);
  try {
    const response = await fetchImpl(path, {
      method: body === undefined ? 'GET' : 'POST', cache: 'no-store', signal: controller.signal,
      ...(body === undefined ? {} : { headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }),
    });
    if (!response.ok) throw new Error('eew_local_unavailable');
    return await response.json();
  } finally { clearTimeout(timer); }
}
export function createEewAuditClient({ fetchImpl = globalThis.fetch.bind(globalThis), setTimeoutImpl = globalThis.setTimeout.bind(globalThis) } = {}) {
  const queue = []; let scheduled = false, flushing = false;
  async function flush() {
    if (flushing) return;
    flushing = true; scheduled = false;
    try {
      while (queue.length) {
        const rows = queue.splice(0, 32);
        // Failure drops a bounded batch; telemetry must never stop the warning path.
        try { await requestEew('/api/eew/audit', { rows }, fetchImpl); } catch { /* safe failure, no raw exception */ }
      }
    } finally { flushing = false; }
  }
  function record(row) {
    const safe = safeEewRow(row); if (!safe) return;
    if (queue.length >= 64) queue.shift(); queue.push(safe);
    if (!scheduled && !flushing) { scheduled = true; setTimeoutImpl(() => { void flush(); }, 150); }
  }
  return { record, flush };
}
export async function consumeUnattendedTest({ request = path => requestEew(path, {}), schedule = globalThis.setTimeout.bind(globalThis), run, record, activation = () => globalThis.navigator?.userActivation?.hasBeenActive === true } = {}) {
  let state;
  try { state = await request('/api/eew/unattended/consume'); } catch { return false; }
  if (state?.armed !== true) return false;
  // Server deletes the one-shot before returning it; never trust a remotely supplied delay.
  schedule(() => {
    record({ kind: 'test', source: 'maintenance_unattended', userActivation: activation() });
    run();
  }, 45_000);
  return true;
}
export function describeEewSummary(summary) {
  const entries = Array.isArray(summary?.entries) ? summary.entries : [];
  const latest = summary?.latest || {};
  const ws = latest.websocket || entries.find(row => row.kind === 'websocket');
  const lines = [`WebSocket: ${(ws?.websocket || 'UNKNOWN').toUpperCase()}`];
  if (latest.connected) lines.push(`Last connected: ${latest.connected.receivedAtJst || '--'}`);
  for (const [source, label] of [['p2p', 'REAL'], ['maintenance_click', 'TEST click'], ['maintenance_unattended', 'TEST unattended']]) {
    const stream = summary?.bySource?.[source];
    const rows = stream ? Object.values(stream).filter(row => row && typeof row === 'object') : entries.filter(row => row.source === source);
    rows.sort((a, b) => String(b.receivedAtUtc || '').localeCompare(String(a.receivedAtUtc || '')));
    const message = stream?.message || rows.find(row => row.kind === 'message');
    const audio = stream?.audio || rows.find(row => row.audioResult);
    const overlay = stream?.overlay || rows.find(row => row.kind === 'overlay');
    const decision = stream?.target || rows.find(row => row.cancelled !== true && typeof row.tokyo23Matched === 'boolean');
    lines.push(`${label}: ${message?.receivedAtJst || '--'} / ${message?.eventId || '--'} / ${message?.serial || '--'}${message?.cancelled ? ' / CANCELLED' : ''}`);
    lines.push(`Tokyo23: ${decision ? (decision.tokyo23Matched ? 'MATCH' : 'NO MATCH') : 'UNKNOWN'} / Overlay: ${(overlay?.overlay || 'UNKNOWN').toUpperCase()} / Audio: ${audio?.audioResult === 'played' ? 'SCHEDULED' : (audio?.audioResult || 'NOT REQUESTED').toUpperCase()}`);
    const activation = rows.find(row => typeof row.userActivation === 'boolean');
    if (activation) lines.push(`User activation: ${activation.userActivation ? 'YES — 無操作テストとして無効' : 'NO'}`);
  }
  lines.push('音の聞こえ方・Windows音量は未確認。SCHEDULEDはWeb Audioへの予約です。');
  return lines.join('\n');
}
