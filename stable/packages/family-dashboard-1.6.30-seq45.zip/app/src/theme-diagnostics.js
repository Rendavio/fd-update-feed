import { getTokyoDateParts, resolveAutomaticTheme } from './sun-times.js';

const themeValue = (value) => ['auto', 'light', 'dark'].includes(value) ? value : '(none)';
const themeClasses = (values = []) => values.filter(
  (value) => /^(?:(?:theme|color-scheme)[-_])?(?:auto|light|dark)$/.test(value),
).join(' ') || '(none)';

export function describeThemeDiagnostics({
  now = new Date(), requestedTheme, themeMode, documentTheme,
  dashboardClasses, rootClasses, bodyClasses, rootTheme, bodyTheme, visibility,
  lastApplication = null,
}) {
  const solar = resolveAutomaticTheme(now);
  const parts = getTokyoDateParts(now);
  const midnight = Date.UTC(parts.year, parts.month - 1, parts.day, -9);
  const sunrise = midnight + solar.sunriseMinutes * 60_000;
  const sunset = midnight + solar.sunsetMinutes * 60_000;
  return {
    'Requested theme (URL)': themeValue(requestedTheme),
    'Current mode (state)': themeValue(themeMode),
    'Current local datetime': now.toLocaleString('sv-SE'),
    'Date.toString()': now.toString(),
    'Date.toISOString()': now.toISOString(),
    'getTimezoneOffset()': String(now.getTimezoneOffset()),
    'Browser timezone': Intl.DateTimeFormat().resolvedOptions().timeZone,
    'Solar basis': 'Asia/Tokyo / seasonal constants (no coordinates)',
    'Sunrise (device local)': new Date(sunrise).toString(),
    'Sunset (device local)': new Date(sunset).toString(),
    'Sunrise epoch ms (derived JST)': String(sunrise),
    'Sunset epoch ms (derived JST)': String(sunset),
    'Current epoch ms': String(now.getTime()),
    'resolveAutomaticTheme()': solar.theme,
    'Dashboard data-theme': themeValue(documentTheme),
    'Dashboard theme classes': themeClasses(dashboardClasses),
    'Root data-theme': themeValue(rootTheme),
    'Root theme classes': themeClasses(rootClasses),
    'Body data-theme': themeValue(bodyTheme),
    'Body theme classes': themeClasses(bodyClasses),
    'Last theme applied (ISO)': lastApplication?.at || '(none)',
    'Last apply reason': ['startup', 'timer', 'visibilitychange', 'manual'].includes(lastApplication?.reason)
      ? lastApplication.reason : '(none)',
    'Last DOM writer': ['updateTheme', 'renderDashboard'].includes(lastApplication?.source)
      ? lastApplication.source : '(none)',
    'document.visibilityState': ['visible', 'hidden'].includes(visibility) ? visibility : '(unknown)',
  };
}

