let sharedAudioContext = null;
let latestPlayRequest = 0;
const AUDIO_RESUME_TIMEOUT_MS = 3000;
const CONTEXT_STATES = new Set(['running', 'suspended', 'closed', 'interrupted']);

export const EEW_TONE_PATTERN = Object.freeze([
  { frequency: 880, start: 0.00, duration: 0.16 },
  { frequency: 660, start: 0.20, duration: 0.16 },
  { frequency: 880, start: 0.40, duration: 0.16 },
  { frequency: 660, start: 0.60, duration: 0.16 },
  { frequency: 990, start: 0.88, duration: 0.24 },
  { frequency: 740, start: 1.16, duration: 0.24 },
]);

function getAudioContext() {
  if (sharedAudioContext) return sharedAudioContext;
  const AudioContextImpl = globalThis.AudioContext || globalThis.webkitAudioContext;
  if (!AudioContextImpl) return null;
  sharedAudioContext = new AudioContextImpl();
  return sharedAudioContext;
}

function contextState(context) {
  const state = context?.state;
  return CONTEXT_STATES.has(state) ? state : 'unknown';
}

function resumeContext(context, signal) {
  if (signal?.aborted) return Promise.resolve({ ready: false, reason: 'cancelled' });
  if (context.state === 'running') return Promise.resolve({ ready: true, reason: 'running' });
  if (!['suspended', 'interrupted'].includes(context.state)) return Promise.resolve({ ready: false, reason: 'failed' });
  return new Promise((resolve) => {
    let settled = false;
    const finish = (reason) => {
      if (settled) return;
      settled = true;
      globalThis.clearTimeout(timer);
      signal?.removeEventListener('abort', abort);
      resolve({ ready: reason === 'running', reason });
    };
    const abort = () => finish('cancelled');
    const timer = globalThis.setTimeout(() => finish('timeout'), AUDIO_RESUME_TIMEOUT_MS);
    signal?.addEventListener('abort', abort, { once: true });
    if (signal?.aborted) { abort(); return; }
    try {
      Promise.resolve(context.resume()).then(
        () => finish(signal?.aborted ? 'cancelled' : context.state === 'running' ? 'running' : 'blocked'),
        () => finish('blocked'),
      );
    } catch {
      finish('blocked');
    }
  });
}

export async function armEewAudio({ signal } = {}) {
  if (signal?.aborted) return { ready: false, reason: 'cancelled' };
  try {
    const context = getAudioContext();
    if (!context) return { ready: false, reason: 'unsupported' };
    return await resumeContext(context, signal);
  } catch {
    return { ready: false, reason: 'failed' };
  }
}

export async function playEewWarningTone({ developmentTest = false, signal, onAudit = () => {} } = {}) {
  const request = ++latestPlayRequest;
  let context = sharedAudioContext;
  let before = contextState(context);
  const report = (audioResult, audioError = audioResult === 'played' ? 'none' : audioResult) => {
    try {
      onAudit({ kind: 'audio', contextBefore: before, contextAfter: contextState(context), audioRequested: true, audioResult, audioError });
    } catch { /* Diagnostics must not interrupt warnings. */ }
    return audioResult === 'played' ? { played: true, developmentTest } : { played: false, reason: audioResult };
  };
  if (signal?.aborted) return report('cancelled');

  const nodes = [];
  const oscillators = [];
  let cleanupTimer;
  let cleaned = false;
  const cleanup = () => {
    if (cleaned) return;
    cleaned = true;
    globalThis.clearTimeout(cleanupTimer);
    signal?.removeEventListener('abort', cleanup);
    for (const oscillator of oscillators) {
      try { oscillator.stop(context.currentTime); } catch { /* Already stopped or never started. */ }
    }
    for (const node of nodes) {
      try { node.disconnect(); } catch { /* Best-effort cleanup after partial setup. */ }
    }
  };
  try {
    context = getAudioContext();
    before = contextState(context);
    if (!context) return report('unsupported');
    const armed = await resumeContext(context, signal);
    if (signal?.aborted) return report('cancelled');
    if (request !== latestPlayRequest) return report('cancelled', 'stale');
    if (!armed.ready) return report(armed.reason);
    if (context.state !== 'running') return report('blocked');
    // No asynchronous work between the stale check and scheduling the nodes.
    const master = context.createGain();
    nodes.push(master);
    master.gain.value = developmentTest ? 0.08 : 0.34;
    master.connect(context.destination);
    signal?.addEventListener('abort', cleanup, { once: true });
    const baseTime = context.currentTime + 0.02;

    EEW_TONE_PATTERN.forEach(({ frequency, start, duration }) => {
      const oscillator = context.createOscillator();
      oscillators.push(oscillator);
      nodes.push(oscillator);
      const envelope = context.createGain();
      nodes.push(envelope);
      oscillator.type = 'square';
      oscillator.frequency.value = frequency;
      envelope.gain.setValueAtTime(0.0001, baseTime + start);
      envelope.gain.exponentialRampToValueAtTime(0.7, baseTime + start + 0.015);
      envelope.gain.exponentialRampToValueAtTime(0.0001, baseTime + start + duration);
      oscillator.connect(envelope);
      envelope.connect(master);
      oscillator.start(baseTime + start);
      oscillator.stop(baseTime + start + duration + 0.02);
    });

    const totalDuration = Math.max(...EEW_TONE_PATTERN.map((tone) => tone.start + tone.duration));
    cleanupTimer = globalThis.setTimeout(cleanup, Math.ceil((totalDuration + 0.2) * 1000));
    // 'played' confirms WebAudio scheduling, never hardware audibility.
    return report('played');
  } catch {
    cleanup();
    return report('failed');
  }
}

export function installEewAudioArming() {
  const arm = () => void armEewAudio();
  globalThis.addEventListener?.('pointerdown', arm, { once: true, passive: true });
  globalThis.addEventListener?.('keydown', arm, { once: true });
}

