@echo off
setlocal
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-Edge-Translate-MachinePolicy.ps1"
set "policyExitCode=%ERRORLEVEL%"
echo.
if "%policyExitCode%"=="0" (
  echo Family Dashboard Edge Translate Machine Policy: PASS
) else (
  echo Family Dashboard Edge Translate Machine Policy: FAIL
)
echo.
pause
exit /b %policyExitCode%
