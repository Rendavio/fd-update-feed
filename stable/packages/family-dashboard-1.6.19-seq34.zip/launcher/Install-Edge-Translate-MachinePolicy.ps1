#requires -Version 5.1
Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"

function Test-IsAdministrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

if ([Environment]::UserName -ine "DashboardAdmin") {
    exit 10
}

if (-not (Test-IsAdministrator)) {
    $powershell = Join-Path $env:SystemRoot "System32\WindowsPowerShell\v1.0\powershell.exe"
    $scriptPath = [IO.Path]::GetFullPath($PSCommandPath)
    try {
        $child = Start-Process -FilePath $powershell -Verb RunAs -WindowStyle Hidden `
            -PassThru -Wait -ArgumentList @(
                "-NoLogo", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
                "-File", ('"{0}"' -f $scriptPath)
            )
    } catch {
        exit 20
    }
    if ($null -eq $child) {
        exit 21
    }
    exit [int]$child.ExitCode
}

$policyPath = "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Edge"
$valueName = "TranslateEnabled"
try {
    New-Item -Path $policyPath -Force | Out-Null
    New-ItemProperty -Path $policyPath -Name $valueName -PropertyType DWord -Value 0 -Force | Out-Null

    $key = Get-Item -LiteralPath $policyPath -ErrorAction Stop
    if (-not (@($key.GetValueNames()) -ccontains $valueName)) {
        exit 30
    }
    if ($key.GetValueKind($valueName) -ne [Microsoft.Win32.RegistryValueKind]::DWord) {
        exit 31
    }
    if ([int]$key.GetValue($valueName) -ne 0) {
        exit 32
    }
} catch {
    exit 33
}

exit 0
