"""Read-only Dropbox App Folder consumer for the two headache reports."""
from __future__ import annotations

import copy
import json
import os
import re
import threading
import time
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import HTTPRedirectHandler, ProxyHandler, Request, build_opener
from zoneinfo import ZoneInfo

from switchbot_control import _event_occurs_on, _normalize_description

JST = ZoneInfo("Asia/Tokyo")
SETUP_SUMMARY = "FD-DROPBOX-SETUP"
SCOPES = ("files.metadata.read", "files.content.read")
DOCUMENTS = {
    "12month": ("/headache-12month.pdf", "headache-12month.pdf"),
    "visit-interval": ("/headache-visit-interval.pdf", "headache-visit-interval.pdf"),
}
MAX_PDF_BYTES = 20 * 1024 * 1024
MAX_SETUP_LENGTH = 4096
MAX_CREDENTIAL_LENGTH = 2048
CHECK_INTERVAL = timedelta(hours=6)


def is_setup_event(item: Any) -> bool:
    return isinstance(item, dict) and item.get("summary") == SETUP_SUMMARY


def parse_setup_credentials(items: list[dict[str, Any]], fetched_at: datetime) -> tuple[str, str] | None:
    today = fetched_at.astimezone(JST).date()
    matches = [item for item in items if is_setup_event(item) and _event_occurs_on(item, today)]
    if len(matches) != 1:
        return None
    description = matches[0].get("description")
    if not isinstance(description, str) or not 1 <= len(description) <= MAX_SETUP_LENGTH:
        return None
    normalized = _normalize_description(description)
    if normalized is None:
        return None
    lines = [line.strip() for line in normalized.replace("\r\n", "\n").replace("\r", "\n").split("\n") if line.strip()]
    if len(lines) != 2:
        return None
    values = {}
    for line, key in zip(lines, ("APP_KEY", "REFRESH_TOKEN")):
        if not line.startswith(key + "="):
            return None
        value = line[len(key) + 1:]
        if not 1 <= len(value) <= MAX_CREDENTIAL_LENGTH or any(not 0x21 <= ord(c) <= 0x7e for c in value):
            return None
        values[key] = value
    return values["APP_KEY"], values["REFRESH_TOKEN"]


def validate_pdf(data: Any) -> bool:
    return isinstance(data, bytes) and 5 <= len(data) <= MAX_PDF_BYTES and data.startswith(b"%PDF-")


def _cached_pdf_ready(path: Path) -> bool:
    try:
        size = path.stat().st_size
        if not 5 <= size <= MAX_PDF_BYTES:
            return False
        with path.open("rb") as stream:
            return stream.read(5) == b"%PDF-"
    except OSError:
        return False


def _read_cached_pdf(path: Path) -> bytes | None:
    try:
        with path.open("rb") as stream:
            data = stream.read(MAX_PDF_BYTES + 1)
        return data if validate_pdf(data) else None
    except OSError:
        return None


def _write_atomic(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name("." + path.name + "." + uuid.uuid4().hex + ".tmp")
    try:
        with temporary.open("xb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(temporary, 0o600)
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def _write_json(path: Path, value: dict[str, Any]) -> None:
    _write_atomic(path, json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("ascii"))


class _NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise OSError("Dropbox redirect rejected")


class DropboxApi:
    """Fixed Dropbox API endpoints and fixed App Folder paths only."""

    def __init__(self) -> None:
        self._opener = build_opener(ProxyHandler({}), _NoRedirect())
        self._access_token = None
        self._access_until = 0.0

    def _request(self, url: str, data: bytes, headers: dict[str, str], limit: int) -> tuple[bytes, Any]:
        request = Request(url, data=data, headers=headers, method="POST")
        try:
            with self._opener.open(request, timeout=15) as response:
                if response.geturl() != url or response.status != 200:
                    raise OSError("Dropbox response rejected")
                content = response.read(limit + 1)
                if len(content) > limit:
                    raise OSError("Dropbox response too large")
                return content, response.headers
        except (HTTPError, URLError, TimeoutError, OSError) as exc:
            raise OSError("Dropbox request failed") from exc

    def _token(self, credentials: tuple[str, str]) -> str:
        if self._access_token and time.monotonic() < self._access_until:
            return self._access_token
        key, refresh = credentials
        body = urlencode({"grant_type": "refresh_token", "refresh_token": refresh, "client_id": key}).encode("ascii")
        data, _ = self._request(
            "https://api.dropboxapi.com/oauth2/token", body,
            {"Content-Type": "application/x-www-form-urlencoded"}, 8192)
        try:
            value = json.loads(data)
            token = value["access_token"]
            expires = value["expires_in"]
            if not isinstance(token, str) or not token or isinstance(expires, bool):
                raise ValueError
            if not isinstance(expires, (str, int)) or not str(expires).isdigit() or int(expires) < 60:
                raise ValueError
            expires = int(expires)
            scopes = value.get("scope")
            if scopes is not None and (not isinstance(scopes, str)
                    or set(scopes.split()) != set(SCOPES) or len(scopes.split()) != len(SCOPES)):
                raise ValueError
        except (ValueError, KeyError, TypeError) as exc:
            raise OSError("Dropbox token response invalid") from exc
        self._access_token = token
        self._access_until = time.monotonic() + min(expires - 30, 3500)
        return token

    def metadata(self, credentials: tuple[str, str]) -> dict[str, str]:
        token = self._token(credentials)
        revs = {}
        for document_id, (remote_path, _) in DOCUMENTS.items():
            body = json.dumps({"path": remote_path}, separators=(",", ":")).encode("ascii")
            data, _ = self._request(
                "https://api.dropboxapi.com/2/files/get_metadata", body,
                {"Authorization": "Bearer " + token, "Content-Type": "application/json"}, 16384)
            try:
                value = json.loads(data)
                rev = value["rev"]
                if (value.get(".tag") != "file" or value.get("path_lower") != remote_path
                        or not isinstance(rev, str) or not 1 <= len(rev) <= 128
                        or not isinstance(value.get("size"), int) or not 1 <= value["size"] <= MAX_PDF_BYTES):
                    raise ValueError
            except (ValueError, KeyError, TypeError) as exc:
                raise OSError("Dropbox metadata invalid") from exc
            revs[document_id] = rev
        return revs

    def download(self, credentials: tuple[str, str], document_id: str, expected_rev: str | None = None) -> bytes:
        if document_id not in DOCUMENTS:
            raise ValueError("Unknown document")
        token = self._token(credentials)
        remote_path = DOCUMENTS[document_id][0]
        data, headers = self._request(
            "https://content.dropboxapi.com/2/files/download", b"",
            {"Authorization": "Bearer " + token, "Dropbox-API-Arg": json.dumps({"path": remote_path})},
            MAX_PDF_BYTES)
        try:
            metadata = json.loads(headers["Dropbox-API-Result"])
            if (metadata.get("path_lower") != remote_path
                    or (expected_rev is not None and metadata.get("rev") != expected_rev)):
                raise ValueError
        except (KeyError, ValueError, TypeError) as exc:
            raise OSError("Dropbox download metadata invalid") from exc
        if not validate_pdf(data):
            raise OSError("Dropbox PDF invalid")
        return data


class DropboxConsumer:
    def __init__(self, app_data_root: Path, api: Any = None,
                 now_factory: Callable[[], datetime] | None = None) -> None:
        self.root = app_data_root
        self.config_path = app_data_root / "dropbox-consumer.json"
        self.documents_root = app_data_root / "documents" / "headache"
        self.state_path = self.documents_root / "state.json"
        self.api = api or DropboxApi()
        self.now_factory = now_factory or (lambda: datetime.now(timezone.utc))
        self._lock = threading.RLock()
        self._sync_lock = threading.Lock()
        self._wake = threading.Event()
        self._stop = threading.Event()
        self._thread = None
        self._pending = None
        self._last_attempt = None
        self._config = self._load_config()
        self._state = self._load_state()
        self._last_check = "UNKNOWN"

    def _load_config(self):
        try:
            if self.config_path.stat().st_size > 8192:
                return None
            value = json.loads(self.config_path.read_text(encoding="ascii"))
            if set(value) != {"app_key", "refresh_token", "granted_scopes", "configured_at"}:
                return None
            pair = parse_setup_credentials([{"summary": SETUP_SUMMARY, "start": {"date": "2026-09-18"},
                "description": "APP_KEY=" + value["app_key"] + "\nREFRESH_TOKEN=" + value["refresh_token"]}],
                datetime(2026, 9, 18, tzinfo=timezone.utc))
            return pair if pair and value["granted_scopes"] == list(SCOPES) else None
        except (OSError, ValueError, TypeError, KeyError):
            return None

    def _load_state(self) -> dict[str, Any]:
        try:
            if self.state_path.stat().st_size > 4096:
                return {}
            state = json.loads(self.state_path.read_text(encoding="ascii"))
            generation = state.get("generation")
            revs = state.get("revs")
            if (not isinstance(generation, str) or not re.fullmatch("[0-9a-f]{32}", generation)
                    or not isinstance(revs, dict) or set(revs) != set(DOCUMENTS)
                    or not all(isinstance(r, str) and 1 <= len(r) <= 128 for r in revs.values())):
                return {}
            if not all(_cached_pdf_ready(self.documents_root / "generations" / generation / filename)
                       for _, filename in DOCUMENTS.values()):
                return {}
            return state
        except (OSError, ValueError, TypeError):
            return {}

    def _commit_pair(self, revs: dict[str, str], pdfs: dict[str, bytes]) -> None:
        generation = uuid.uuid4().hex
        folder = self.documents_root / "generations" / generation
        folder.mkdir(parents=True, exist_ok=False)
        for document_id, (_, filename) in DOCUMENTS.items():
            _write_atomic(folder / filename, pdfs[document_id])
        now = self.now_factory().astimezone(timezone.utc).isoformat()
        state = {"generation": generation, "revs": revs, "lastMetadataCheck": now, "lastSync": now}
        _write_json(self.state_path, state)
        with self._lock:
            self._state = state

    def consume_calendar_items(self, items: list[dict[str, Any]], fetched_at: datetime) -> bool:
        with self._lock:
            if self._config is not None or self._pending is not None:
                return False
            if self._last_attempt is not None and self.now_factory() - self._last_attempt < CHECK_INTERVAL:
                return False
        credentials = parse_setup_credentials(items, fetched_at)
        if credentials is None:
            return False
        with self._lock:
            if self._config is not None or self._pending is not None:
                return False
            self._pending = credentials
        self._wake.set()
        return True

    def process_pending_setup(self) -> bool:
        with self._lock:
            credentials, self._pending = self._pending, None
            if self._config is not None or credentials is None:
                return False
        with self._sync_lock:
            try:
                revs = self.api.metadata(credentials)
                if set(revs) != set(DOCUMENTS):
                    raise OSError("Dropbox metadata incomplete")
                pdfs = self._download_pair(credentials, revs)
                config = {"app_key": credentials[0], "refresh_token": credentials[1],
                          "granted_scopes": list(SCOPES),
                          "configured_at": self.now_factory().astimezone(timezone.utc).isoformat()}
                _write_json(self.config_path, config)
                with self._lock:
                    self._config = credentials
                self._commit_pair(revs, pdfs)
                self._last_check = "PASS"
                self._last_attempt = self.now_factory()
                return True
            except Exception:
                self._last_check = "FAIL"
                self._last_attempt = self.now_factory()
                return False

    def _download_pair(self, credentials, revs):
        pdfs = {}
        for document_id in DOCUMENTS:
            try:
                data = self.api.download(credentials, document_id, revs[document_id])
            except TypeError:
                # Test adapters may expose the simpler two-argument contract.
                data = self.api.download(credentials, document_id)
            if not validate_pdf(data):
                raise OSError("Invalid PDF")
            pdfs[document_id] = data
        return pdfs

    def check_now(self) -> str:
        with self._sync_lock:
            with self._lock:
                credentials = self._config
                state = copy.deepcopy(self._state)
            if credentials is None:
                return "UNCONFIGURED"
            self._last_attempt = self.now_factory()
            try:
                revs = self.api.metadata(credentials)
                if set(revs) != set(DOCUMENTS) or not all(isinstance(r, str) and r for r in revs.values()):
                    raise OSError("Dropbox metadata invalid")
                old_revs = state.get("revs")
                if old_revs:
                    changed = [revs[key] != old_revs[key] for key in DOCUMENTS]
                    if not any(changed):
                        result = "UNCHANGED"
                    elif not all(changed):
                        result = "PAIR_INCOMPLETE"
                    else:
                        result = "PASS"
                else:
                    result = "PASS"
                if result == "PASS":
                    pdfs = self._download_pair(credentials, revs)
                    self._commit_pair(revs, pdfs)
                else:
                    state["lastMetadataCheck"] = self.now_factory().astimezone(timezone.utc).isoformat()
                    _write_json(self.state_path, state)
                    with self._lock:
                        self._state = state
                self._last_check = result
                return result
            except Exception:
                self._last_check = "FAIL"
                return "FAIL"

    def get_document(self, document_id: str) -> bytes | None:
        if document_id not in DOCUMENTS:
            return None
        with self._lock:
            generation = self._state.get("generation")
        if not isinstance(generation, str) or not re.fullmatch("[0-9a-f]{32}", generation):
            return None
        path = self.documents_root / "generations" / generation / DOCUMENTS[document_id][1]
        return _read_cached_pdf(path)

    def get_status(self) -> dict[str, Any]:
        with self._lock:
            state = self._state.copy()
            configured = self._config is not None
        generation = state.get("generation")
        ready = 0
        if isinstance(generation, str) and re.fullmatch("[0-9a-f]{32}", generation):
            ready = sum(_cached_pdf_ready(self.documents_root / "generations" / generation / filename)
                        for _, filename in DOCUMENTS.values())
        return {"configured": configured, "ready": ready, "lastCheck": self._last_check,
                "lastSync": state.get("lastSync")}

    def request_check_if_due(self) -> None:
        with self._lock:
            if self._config is None:
                return
            now = self.now_factory()
            last_success = self._state.get("lastMetadataCheck")
            try:
                recent_success = last_success and now - datetime.fromisoformat(last_success) < CHECK_INTERVAL
            except (ValueError, TypeError):
                recent_success = False
            recent_attempt = self._last_attempt and now - self._last_attempt < CHECK_INTERVAL
            if not recent_success and not recent_attempt:
                self._wake.set()

    def _run(self) -> None:
        self.request_check_if_due()
        while not self._stop.is_set():
            now = self.now_factory().astimezone(JST)
            next_check = now.replace(hour=4, minute=0, second=0, microsecond=0)
            if next_check <= now:
                next_check += timedelta(days=1)
            woke = self._wake.wait(max(1, (next_check - now).total_seconds()))
            self._wake.clear()
            if self._stop.is_set():
                break
            self.process_pending_setup()
            if self._config is not None and self._check_due():
                self.check_now()

    def _check_due(self):
        now = self.now_factory()
        return self._last_attempt is None or now - self._last_attempt >= CHECK_INTERVAL

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._thread = threading.Thread(target=self._run, name="dropbox-headache-reports", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        self._wake.set()
        if self._thread:
            self._thread.join(timeout=2)

