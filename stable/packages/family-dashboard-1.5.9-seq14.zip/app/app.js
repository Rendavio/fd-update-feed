import { createProviders, MOCK_CALENDAR_ID } from './src/providers.js';
import { formatMinutes, getTokyoDateParts, resolveAutomaticTheme } from './src/sun-times.js';
import { makeWeatherIcon } from './src/weather-icons.js';
import { P2PEarthquakeProvider } from './src/earthquake-provider.js';
import { installEewAudioArming, playEewWarningTone } from './src/eew-audio.js';
import {
  DASHBOARD_DESIGN_HEIGHT,
  DASHBOARD_DESIGN_WIDTH,
  calculateDashboardScale,
  createLongPressController,
  targetBrightnessForTheme,
} from './src/display-mode.js';
import {
  buildFutureMultiDayLayout,
  calculateEventCapacity,
  isFutureLaneEvent,
} from './src/calendar-layout.js';
import {
  describeUpdateStatus,
  pollForDashboardRecovery,
  requestUpdateApply,
} from './src/update-client.js';
import { describeMaintenanceDiagnostics } from './src/maintenance-diagnostics.js';

const resolutions = {
  100: { width: 1920, height: 1200 },
  125: { width: 1536, height: 960 },
  150: { width: 1280, height: 800 },
};

const weekdayLong = ['日曜日', '月曜日', '火曜日', '水曜日', '木曜日', '金曜日', '土曜日'];
const weekdayShort = ['日', '月', '火', '水', '木', '金', '土'];
const providers = createProviders();
const params = new URLSearchParams(window.location.search);
const requestedTheme = ['auto', 'light', 'dark'].includes(params.get('theme')) ? params.get('theme') : 'auto';
const requestedCalendar = params.get('calendar') === 'google' ? 'google' : 'mock';
const requestedEewEndpoint = params.get('eew') === 'sandbox' ? 'sandbox' : 'production';
const requestedEewPreview = /^(?:[A-G]|MISSING)$/i.test(params.get('eewPreview') || '')
  ? params.get('eewPreview').toUpperCase()
  : null;
const layoutFixtures = new Set([
  'today0', 'today3', 'today6', 'today8', 'today12',
  'future1', 'future3', 'future5', 'future8', 'future12',
  'multi1', 'multi2', 'multi3', 'multiClipStart', 'multiClipEnd',
  'multiTwo', 'multiDense',
]);
const requestedLayoutFixture = layoutFixtures.has(params.get('fixture')) ? params.get('fixture') : null;

const state = {
  resolution: Object.hasOwn(resolutions, params.get('resolution')) ? params.get('resolution') : '100',
  themeMode: requestedTheme,
  resolvedTheme: 'light',
  scenario: ['normal', 'many', 'long', 'joint'].includes(params.get('scenario')) ? params.get('scenario') : 'normal',
  headerLayout: ['a', 'b', 'c', 'd', 'e'].includes(params.get('header')) ? params.get('header') : 'a',
  displayOnly: params.get('display') === '1',
  calendarMode: params.get('display') === '1'
    ? (requestedLayoutFixture ? 'mock' : 'google')
    : requestedCalendar,
  calendarLoadedMode: null,
  weather: makePlaceholderWeather(),
  calendarDays: Array.from({ length: 7 }, () => []),
  headacheHistory: makeEmptyHistory(),
  aerobicHistory: makeEmptyHistory(),
  strengthHistory: makeEmptyHistory(),
  calendarLastSuccessAt: null,
  calendarStale: false,
  calendarError: null,
  earthquake: null,
  earthquakeStatus: { state: 'idle', endpointKind: 'production', retryInMs: null },
  earthquakeTestResult: null,
  earthquakeAudioResult: null,
  runtimeMode: 'development',
  weatherError: null,
  dashboardScale: 1,
  brightnessAvailable: false,
  currentBrightness: null,
  displaySettings: {
    autoBrightness: true,
    dayBrightness: 65,
    nightBrightness: 30,
  },
  lastAutoBrightnessTarget: null,
  appVersion: '--',
  updateStatus: null,
  updateStatusAvailable: false,
  maintenanceRuntime: null,
  updateRequestActive: false,
};

let earthquakeProvider = null;

const previewApp = document.getElementById('previewApp');
const previewCanvas = document.getElementById('previewCanvas');
const deviceFrame = document.getElementById('deviceFrame');
const dashboardShell = document.getElementById('dashboardShell');
const dashboard = document.getElementById('dashboard');
const scenarioSelect = document.getElementById('scenarioSelect');
const calendarProviderSelect = document.getElementById('calendarProviderSelect');
const headerLayoutSelect = document.getElementById('headerLayoutSelect');
const previewStatus = document.getElementById('previewStatus');
const eewScenarioSelect = document.getElementById('eewScenarioSelect');
const displayControlLayer = document.getElementById('displayControlLayer');
const displayHotspot = document.getElementById('displayHotspot');
const displayPanel = document.getElementById('displayPanel');
const autoBrightnessOn = document.getElementById('autoBrightnessOn');
const autoBrightnessOff = document.getElementById('autoBrightnessOff');
const autoBrightnessControls = document.getElementById('autoBrightnessControls');
const manualBrightnessControls = document.getElementById('manualBrightnessControls');
const brightnessUnavailable = document.getElementById('brightnessUnavailable');
const dayBrightness = document.getElementById('dayBrightness');
const nightBrightness = document.getElementById('nightBrightness');
const currentBrightness = document.getElementById('currentBrightness');
const dayBrightnessValue = document.getElementById('dayBrightnessValue');
const nightBrightnessValue = document.getElementById('nightBrightnessValue');
const currentBrightnessValue = document.getElementById('currentBrightnessValue');
const closeDisplayPanelButton = document.getElementById('closeDisplayPanel');
const currentUpdateVersion = document.getElementById('currentUpdateVersion');
const updateStatusText = document.getElementById('updateStatusText');
const applyUpdateButton = document.getElementById('applyUpdate');
const updateConfirmation = document.getElementById('updateConfirmation');
const updateConfirmationText = document.getElementById('updateConfirmationText');
const confirmApplyUpdateButton = document.getElementById('confirmApplyUpdate');
const cancelApplyUpdateButton = document.getElementById('cancelApplyUpdate');
const updateOverlay = document.getElementById('updateOverlay');
const updateProgressText = document.getElementById('updateProgressText');
const reloadDashboardButton = document.getElementById('reloadDashboard');
const openWindowsExitButton = document.getElementById('openWindowsExit');
const pinDialog = document.getElementById('pinDialog');
const maintenancePin = document.getElementById('maintenancePin');
const pinStatus = document.getElementById('pinStatus');
const confirmWindowsExitButton = document.getElementById('confirmWindowsExit');
const cancelWindowsExitButton = document.getElementById('cancelWindowsExit');
const diagnosticDashboard = document.getElementById('diagnosticDashboard');
const diagnosticSequence = document.getElementById('diagnosticSequence');
const diagnosticUpdater = document.getElementById('diagnosticUpdater');
const diagnosticServer = document.getElementById('diagnosticServer');
const diagnosticIntegrity = document.getElementById('diagnosticIntegrity');
const diagnosticUpdate = document.getElementById('diagnosticUpdate');
const diagnosticLastUpdate = document.getElementById('diagnosticLastUpdate');
const diagnosticLastApplyPhase = document.getElementById('diagnosticLastApplyPhase');
const diagnosticLastApplyResult = document.getElementById('diagnosticLastApplyResult');
const diagnosticLastApplyError = document.getElementById('diagnosticLastApplyError');
const PIN_DIALOG_TIMEOUT_MS = 30_000;
let pinDialogTimer = null;

function createElement(tag, className, text) {
  const element = document.createElement(tag);
  if (className) element.className = className;
  if (text !== undefined) element.textContent = text;
  return element;
}

function tokyoIsoDate(offset = 0) {
  const parts = getTokyoDateParts();
  const date = new Date(Date.UTC(parts.year, parts.month - 1, parts.day + offset));
  return date.toISOString().slice(0, 10);
}

function addIsoDays(isoDate, offset) {
  const [year, month, day] = isoDate.split('-').map(Number);
  const date = new Date(Date.UTC(year, month - 1, day + offset));
  return date.toISOString().slice(0, 10);
}

function makeEmptyHistory(startDate = tokyoIsoDate()) {
  return [
    [-4, '4日前'],
    [-3, '3日前'],
    [-2, '2日前'],
    [-1, '昨日'],
    [0, '本日'],
  ].map(([offset, label]) => ({ date: addIsoDays(startDate, offset), label, occurred: false }));
}

function makePlaceholderWeather() {
  return {
    schemaVersion: 1,
    fetchedAt: null,
    lastSuccessAt: null,
    observationTime: null,
    stale: true,
    cacheState: 'empty',
    currentTemperature: null,
    days: Array.from({ length: 7 }, (_, index) => ({
      date: tokyoIsoDate(index),
      weatherCode: null,
      icon: '--',
      condition: '--',
      high: null,
      low: null,
      rain: null,
    })),
  };
}

function parseIsoDate(isoDate) {
  const [year, month, day] = isoDate.split('-').map(Number);
  const weekday = new Date(Date.UTC(year, month - 1, day)).getUTCDay();
  return { year, month, day, weekday };
}

function formatMetric(value, suffix) {
  return value === null || value === undefined ? '--' : `${value}${suffix}`;
}

function makeEventCard(event) {
  const card = createElement('div', `event-card event-${event.owner}`);
  const ownerBar = createElement('span', 'owner-bar');
  ownerBar.setAttribute('aria-hidden', 'true');
  ownerBar.appendChild(createElement('span'));
  if (event.owner === 'joint') ownerBar.appendChild(createElement('span'));

  const copy = createElement('div', 'event-copy');
  const time = createElement('span', `event-time${event.allDay ? ' is-all-day' : ''}`, event.time);
  const title = createElement('span', 'event-title', event.summary);
  copy.append(time, title);
  card.append(ownerBar, copy);
  return card;
}

function makeEventsList(events, role, { showEmpty = true } = {}) {
  const list = createElement('div', 'events-list');
  list.dataset.eventListRole = role;
  list.dataset.totalEvents = String(events.length);
  if (role === 'primary' && events.length > 6) list.classList.add('is-density-limited');
  if (!events.length) {
    list.dataset.visibleEvents = '0';
    list.dataset.hiddenEvents = '0';
    if (showEmpty) list.appendChild(createElement('p', 'empty-events', '予定はありません'));
    return list;
  }
  events.forEach((event) => list.appendChild(makeEventCard(event)));
  const more = createElement('p', 'more-events', '');
  more.hidden = true;
  list.appendChild(more);
  return list;
}

function fitEventsList(list) {
  const cards = [...list.querySelectorAll(':scope > .event-card')];
  const more = list.querySelector(':scope > .more-events');
  if (!cards.length || !more) return;

  cards.forEach((card) => { card.hidden = false; });
  more.hidden = false;
  more.textContent = `ほか${cards.length}件`;

  const styles = window.getComputedStyle(list);
  const result = calculateEventCapacity({
    availableHeight: Math.max(
      0,
      list.clientHeight
        - (Number.parseFloat(styles.paddingTop) || 0)
        - (Number.parseFloat(styles.paddingBottom) || 0),
    ),
    cardHeights: cards.map((card) => card.offsetHeight),
    gap: Number.parseFloat(styles.rowGap) || 0,
    moreHeight: more.offsetHeight,
  });

  cards.forEach((card, index) => { card.hidden = index >= result.visibleCount; });
  more.hidden = !result.showMore;
  if (result.showMore) more.textContent = `ほか${result.hiddenCount}件`;
  list.dataset.visibleEvents = String(result.visibleCount);
  list.dataset.hiddenEvents = String(result.hiddenCount);
}

let eventFittingFrame = null;

function fitAllEventLists() {
  layoutFutureScheduleGrid();
  dashboard.querySelectorAll('.events-list').forEach(fitEventsList);
}

function scheduleEventFitting() {
  if (eventFittingFrame !== null) window.cancelAnimationFrame(eventFittingFrame);
  eventFittingFrame = window.requestAnimationFrame(() => {
    eventFittingFrame = null;
    fitAllEventLists();
  });
}

function makeSectionHeading(count) {
  const heading = createElement('div', 'section-heading');
  heading.append(createElement('span', '', '予定'), createElement('b', '', `${count}件`));
  return heading;
}

function makeActivityHistories(histories) {
  const definitions = [
    { key: 'headache', title: '頭痛', activeText: '頭痛', activeClass: 'is-headache' },
    { key: 'aerobic', title: '有酸素', activeText: '有酸素', activeClass: 'is-aerobic' },
    { key: 'strength', title: '筋トレ', activeText: '筋トレ', activeClass: 'is-strength' },
  ];
  const section = createElement('section', 'activity-histories');
  section.setAttribute('aria-label', '過去5日履歴');
  const grid = createElement('div', 'activity-history-grid');
  grid.appendChild(createElement('span', 'history-corner', ''));
  histories.headache.forEach((item) => grid.appendChild(createElement('span', 'history-day-label', item.label)));

  definitions.forEach((definition) => {
    grid.appendChild(createElement('h2', 'history-row-title', definition.title));
    histories[definition.key].forEach((item) => {
      const className = `history-value${item.occurred ? ` ${definition.activeClass}` : ''}`;
      grid.appendChild(createElement('strong', className, item.occurred ? definition.activeText : '-'));
    });
  });
  section.appendChild(grid);
  return section;
}

function makePrimaryDay(day, events, histories) {
  const date = parseIsoDate(day.date);
  const card = createElement('article', 'day-card primary-day');
  const header = createElement('header', 'primary-header');
  const dateGroup = createElement('div');
  const dateTitle = createElement('h1', 'primary-date');
  dateTitle.append(
    createElement('span', 'date-month', `${date.month}月`),
    createElement('span', 'date-day', `${date.day}日`),
  );
  dateGroup.append(dateTitle, createElement('p', '', weekdayLong[date.weekday]));
  const time = createElement('time', '', '--:--');
  header.append(dateGroup, time);

  const currentWeather = createElement('div', 'primary-weather');
  const icon = makeWeatherIcon(day.weatherCode, { primary: true });
  const temperatureBlock = createElement('div', 'temperature-block');
  const currentValue = state.weather.currentTemperature;
  const currentTemp = createElement('p', 'current-temp', currentValue === null ? '--' : String(currentValue));
  if (currentValue !== null && currentValue !== undefined) currentTemp.appendChild(createElement('span', '', '°'));
  temperatureBlock.append(currentTemp, createElement('p', 'weather-label', day.condition || '--'));
  currentWeather.append(icon, temperatureBlock);

  const stats = createElement('div', 'weather-stats');
  [
    ['最高気温', formatMetric(day.high, '°'), 'temp-high'],
    ['最低気温', formatMetric(day.low, '°'), 'temp-low'],
    ['降水確率', formatMetric(day.rain, '%'), 'rain-stat'],
  ].forEach((item) => {
    const block = createElement('div');
    block.setAttribute('aria-label', `${item[0]} ${item[1]}`);
    block.appendChild(createElement('strong', item[2], item[1]));
    stats.appendChild(block);
  });

  const schedule = createElement('div', 'schedule-section primary-schedule');
  schedule.append(makeSectionHeading(events.length), makeEventsList(events, 'primary'));
  card.append(header, currentWeather, stats, makeActivityHistories(histories), schedule);
  return card;
}

function makeFutureDay(day, events, futureDayIndex, totalEventCount, hasMultiDayEvent) {
  const date = parseIsoDate(day.date);
  const card = createElement('article', 'day-card future-day');
  const header = createElement('header', 'future-header');
  header.append(createElement('strong', '', `${date.month}/${date.day}`), createElement('span', '', weekdayShort[date.weekday]));

  const futureWeather = createElement('div', 'future-weather');
  const icon = makeWeatherIcon(day.weatherCode);
  const temperatures = createElement('div', 'future-temperatures');
  temperatures.append(
    createElement('strong', 'temp-high', formatMetric(day.high, '°')),
    createElement('span', '', '/'),
    createElement('strong', 'temp-low', formatMetric(day.low, '°')),
  );
  const rain = createElement('p', 'rain-chance', formatMetric(day.rain, '%'));
  rain.setAttribute('aria-label', `降水確率 ${formatMetric(day.rain, '%')}`);
  futureWeather.append(icon, createElement('p', '', day.condition || '--'), temperatures, rain);

  const schedule = createElement('div', 'schedule-section');
  schedule.append(
    makeSectionHeading(totalEventCount),
    makeEventsList(events, 'future', { showEmpty: !hasMultiDayEvent }),
  );
  card.append(header, futureWeather, schedule);
  card.style.gridColumn = String(futureDayIndex + 1);
  return card;
}

function makeMultiDayLane(layout) {
  const lane = createElement('section', 'future-schedule-grid multiday-lane');
  lane.setAttribute('aria-label', '複数日にまたがる終日予定');
  lane.dataset.laneCount = String(layout.laneCount);
  lane.style.setProperty('--multiday-lane-count', String(layout.laneCount));
  layout.items.forEach((item) => {
    const owner = item.event.owner || 'neutral';
    const card = createElement('div', `event-card multiday-event event-${owner}`);
    const ownerBar = createElement('span', 'owner-bar');
    ownerBar.setAttribute('aria-hidden', 'true');
    ownerBar.appendChild(createElement('span'));
    if (owner === 'joint') ownerBar.appendChild(createElement('span'));
    const title = createElement('span', 'multiday-title', item.event.summary);
    card.append(ownerBar, title);
    card.style.gridColumn = `${item.startDayIndex} / ${item.endDayIndexExclusive}`;
    card.style.gridRow = String(item.lane + 1);
    card.dataset.startDayIndex = String(item.startDayIndex);
    card.dataset.endDayIndexExclusive = String(item.endDayIndexExclusive);
    card.dataset.laneIndex = String(item.lane);
    lane.appendChild(card);
  });
  return lane;
}

function localTopWithin(element, ancestor) {
  let current = element;
  let top = 0;
  while (current && current !== ancestor) {
    top += current.offsetTop;
    current = current.offsetParent;
  }
  return current === ancestor ? top : null;
}

function layoutFutureScheduleGrid() {
  const futureGrid = dashboard.querySelector('.future-days-grid');
  if (!futureGrid) return;
  const lane = futureGrid.querySelector(':scope > .future-schedule-grid');
  const eventLists = [...futureGrid.querySelectorAll('.future-day .events-list')];
  eventLists.forEach((list) => { list.style.paddingTop = ''; });
  if (!lane || !eventLists.length) return;

  const positions = eventLists.map((list) => localTopWithin(list, futureGrid));
  if (positions.some((value) => value === null)) return;
  const laneTop = Math.max(...positions);
  lane.style.top = `${laneTop}px`;
  const styles = window.getComputedStyle(lane);
  const reserveGap = Number.parseFloat(styles.getPropertyValue('--multiday-reserve-gap')) || 0;
  const laneHeight = lane.offsetHeight;
  eventLists.forEach((list, index) => {
    list.style.paddingTop = `${laneTop - positions[index] + laneHeight + reserveGap}px`;
  });
  futureGrid.dataset.multidayTop = String(laneTop);
  futureGrid.dataset.multidayHeight = String(laneHeight);
}

function renderEarthquakeOverlay() {
  if (!state.earthquake) return;
  const overlay = createElement('section', 'earthquake-overlay');
  overlay.setAttribute('role', 'alertdialog');
  overlay.setAttribute('aria-modal', 'true');
  const copy = createElement('div', 'earthquake-copy');
  if (state.earthquake.developmentTest) {
    copy.appendChild(createElement(
      'p',
      'earthquake-kicker',
      state.earthquake.sandbox ? '開発用テスト・P2P Sandbox' : '開発用テスト',
    ));
  }
  copy.append(
    createElement('h2', '', state.earthquake.headline),
    createElement('p', 'earthquake-region', state.earthquake.region),
  );
  const metrics = createElement('div', 'earthquake-metrics');
  [
    ['予想震度', state.earthquake.predictedIntensity || '--'],
    ['M', state.earthquake.magnitude || '--'],
    ['深さ', state.earthquake.depth || '--'],
  ].forEach(([label, value]) => {
    const metric = createElement('div', 'earthquake-metric');
    metric.append(
      createElement('span', 'earthquake-metric-label', label),
      createElement('b', 'earthquake-metric-value', value),
    );
    metrics.appendChild(metric);
  });
  copy.appendChild(metrics);
  const hypocenter = createElement('div', 'earthquake-hypocenter');
  hypocenter.append(
    createElement('span', 'earthquake-hypocenter-label', '震源'),
    createElement('p', 'earthquake-hypocenter-name', state.earthquake.hypocenter || '--'),
  );
  copy.appendChild(hypocenter);
  const metadata = createElement('p', 'earthquake-meta');
  const issued = createElement('span');
  issued.append(createElement('b', '', '発表時刻'), document.createTextNode(formatTokyoTimestamp(state.earthquake.issuedAt)));
  metadata.appendChild(issued);
  copy.appendChild(metadata);
  overlay.appendChild(copy);
  if (state.earthquake.developmentTest) {
    const close = createElement('button', 'earthquake-close', 'テスト表示を閉じる');
    close.type = 'button';
    close.addEventListener('click', () => earthquakeProvider?.clearDevelopmentAlert());
    overlay.appendChild(close);
  }
  dashboard.appendChild(overlay);
}

function renderDashboard() {
  const grid = createElement('div', 'week-grid');
  const futureGrid = createElement('div', 'future-days-grid');
  const multiDayLayout = buildFutureMultiDayLayout(
    state.calendarDays.flat(),
    state.weather.days[0].date,
  );
  const histories = {
    headache: state.headacheHistory,
    aerobic: state.aerobicHistory,
    strength: state.strengthHistory,
  };
  grid.appendChild(makePrimaryDay(state.weather.days[0], state.calendarDays[0] ?? [], histories));
  state.weather.days.slice(1).forEach((day, index) => {
    const allEvents = state.calendarDays[index + 1] ?? [];
    const dailyEvents = allEvents.filter((event) => !isFutureLaneEvent(event, multiDayLayout.eventKeys));
    const visibleDayIndex = index + 1;
    const hasMultiDayEvent = multiDayLayout.items.some((item) => (
      item.startDayIndex <= visibleDayIndex && visibleDayIndex < item.endDayIndexExclusive
    ));
    futureGrid.appendChild(makeFutureDay(
      day,
      dailyEvents,
      index,
      allEvents.length,
      hasMultiDayEvent,
    ));
  });
  if (multiDayLayout.items.length) futureGrid.appendChild(makeMultiDayLane(multiDayLayout));
  grid.appendChild(futureGrid);
  dashboard.replaceChildren(grid);
  dashboard.dataset.theme = state.resolvedTheme;
  dashboard.dataset.headerLayout = state.headerLayout;
  renderEarthquakeOverlay();
  displayControlLayer.classList.toggle('eew-blocked', Boolean(state.earthquake));
  if (state.earthquake) displayPanel.hidden = true;
  if (state.earthquake) hideUpdateConfirmation();
  if (state.earthquake) hidePinDialog();
  updateClock();
  scheduleEventFitting();
}

function updateScale() {
  const resolution = state.displayOnly
    ? { width: DASHBOARD_DESIGN_WIDTH, height: DASHBOARD_DESIGN_HEIGHT }
    : resolutions[state.resolution];
  const scale = state.displayOnly
    ? calculateDashboardScale(window.innerWidth, window.innerHeight)
    : Math.min((window.innerWidth - 48) / resolution.width, (window.innerHeight - 188) / resolution.height, 1);

  state.dashboardScale = scale;
  dashboardShell.style.width = `${resolution.width}px`;
  dashboardShell.style.height = `${resolution.height}px`;
  dashboardShell.style.transform = `scale(${scale})`;
  dashboard.style.setProperty('--u', `${resolution.width / 100}px`);
  deviceFrame.style.width = `${resolution.width * scale}px`;
  deviceFrame.style.height = `${resolution.height * scale}px`;
  scheduleEventFitting();
}

function renderDisplayControls() {
  const settings = state.displaySettings;
  const available = state.brightnessAvailable;
  autoBrightnessOn.classList.toggle('is-active', settings.autoBrightness);
  autoBrightnessOff.classList.toggle('is-active', !settings.autoBrightness);
  autoBrightnessOn.disabled = !available;
  autoBrightnessOff.disabled = !available;
  brightnessUnavailable.hidden = available;
  autoBrightnessControls.hidden = !available || !settings.autoBrightness;
  manualBrightnessControls.hidden = !available || settings.autoBrightness;

  dayBrightness.value = String(settings.dayBrightness);
  nightBrightness.value = String(settings.nightBrightness);
  dayBrightnessValue.textContent = `${settings.dayBrightness}%`;
  nightBrightnessValue.textContent = `${settings.nightBrightness}%`;
  const manualValue = Number.isInteger(state.currentBrightness) ? state.currentBrightness : 50;
  currentBrightness.value = String(manualValue);
  currentBrightnessValue.textContent = Number.isInteger(state.currentBrightness)
    ? `${state.currentBrightness}%`
    : '--';
}

function renderUpdateControls() {
  const view = describeUpdateStatus(state.updateStatus || {
    updaterInstalled: false,
    currentVersion: state.appVersion,
    state: 'UNAVAILABLE',
  });
  currentUpdateVersion.textContent = view.currentVersion;
  updateStatusText.textContent = view.statusText;
  applyUpdateButton.disabled = state.updateRequestActive || !view.canApply;
  if (!view.canApply) updateConfirmation.hidden = true;
  return view;
}

async function loadUpdateStatus() {
  if (state.updateRequestActive) return renderUpdateControls();
  try {
    const response = await fetch('/api/update/status', { cache: 'no-store' });
    if (!response.ok) throw new Error(`update status failed: ${response.status}`);
    state.updateStatus = await response.json();
    state.updateStatusAvailable = true;
  } catch {
    state.updateStatusAvailable = false;
    state.updateStatus = {
      updaterInstalled: false,
      currentVersion: state.appVersion,
      state: 'UNAVAILABLE',
    };
  }
  return renderUpdateControls();
}

function renderMaintenanceDiagnostics() {
  const diagnostics = describeMaintenanceDiagnostics({
    runtime: state.maintenanceRuntime,
    updateStatus: state.updateStatusAvailable ? state.updateStatus : null,
  });
  diagnosticDashboard.textContent = diagnostics.dashboard;
  diagnosticSequence.textContent = diagnostics.sequence;
  diagnosticUpdater.textContent = diagnostics.updater;
  diagnosticServer.textContent = diagnostics.server;
  diagnosticIntegrity.textContent = diagnostics.integrity;
  diagnosticUpdate.textContent = diagnostics.update;
  diagnosticLastUpdate.textContent = diagnostics.lastUpdate;
  diagnosticLastApplyPhase.textContent = diagnostics.lastApplyPhase;
  diagnosticLastApplyResult.textContent = diagnostics.lastApplyResult;
  diagnosticLastApplyError.textContent = diagnostics.lastApplyError;
}

async function loadMaintenanceRuntime() {
  try {
    const response = await fetch('/api/runtime', { cache: 'no-store' });
    if (!response.ok) throw new Error(`runtime status failed: ${response.status}`);
    state.maintenanceRuntime = await response.json();
  } catch {
    state.maintenanceRuntime = null;
  }
}

function showUpdateConfirmation() {
  const view = renderUpdateControls();
  if (!view.canApply || !view.stagedVersion) return;
  updateConfirmationText.textContent = `Apply update ${view.stagedVersion}?`;
  updateConfirmation.hidden = false;
  confirmApplyUpdateButton.focus();
}

function hideUpdateConfirmation() {
  updateConfirmation.hidden = true;
}

function setUpdateProgress(phase) {
  const messages = {
    preparing: 'Preparing the signed update...',
    waiting_for_shutdown: 'Waiting for Dashboard to stop safely...',
    server_offline: 'Applying and verifying the signed update...',
    server_restored_waiting: 'Dashboard is restarting...',
  };
  updateProgressText.textContent = messages[phase] || 'Applying the signed update...';
}

async function beginUpdateApply() {
  if (state.updateRequestActive) return;
  const view = renderUpdateControls();
  if (!view.canApply || !view.stagedVersion) {
    hideUpdateConfirmation();
    return;
  }

  state.updateRequestActive = true;
  hideUpdateConfirmation();
  renderUpdateControls();
  displayPanel.hidden = true;
  reloadDashboardButton.hidden = true;
  updateProgressText.textContent = 'Requesting UAC confirmation for Updater V1...';
  updateOverlay.hidden = false;

  try {
    await requestUpdateApply();
  } catch (error) {
    if (error?.code === 'uac_cancelled') {
      state.updateRequestActive = false;
      updateOverlay.hidden = true;
      displayPanel.hidden = false;
      renderUpdateControls();
      updateStatusText.textContent = 'Update cancelled.';
      return;
    }
    // A successful local task request can close the server before Fetch receives
    // its 202. Probe after the shutdown grace period before treating it as rejected.
    await new Promise((resolve) => window.setTimeout(resolve, 600));
    try {
      const health = await fetch(`/api/health?applyProbe=${Date.now()}`, { cache: 'no-store' });
      if (health.ok) {
        state.updateRequestActive = false;
        updateOverlay.hidden = true;
        displayPanel.hidden = false;
        renderUpdateControls();
        updateStatusText.textContent = 'Apply request was not accepted.';
        return;
      }
    } catch {
      // Server outage makes the request outcome uncertain; recovery polling is safe.
    }
  }

  setUpdateProgress('preparing');
  const result = await pollForDashboardRecovery({
    expectedVersion: view.stagedVersion,
    previousVersion: view.currentVersion,
    onPhase: setUpdateProgress,
  });
  if (result.outcome === 'updated') {
    updateProgressText.textContent = 'Update complete. Reloading Dashboard...';
    window.setTimeout(() => window.location.reload(), 750);
    return;
  }
  if (result.outcome === 'rolled_back') {
    updateProgressText.textContent = 'Update failed; previous version restored.';
  } else if (result.outcome === 'failed') {
    updateProgressText.textContent = 'Update failed. Dashboard has been restored.';
  } else if (result.outcome === 'shutdown_timeout') {
    state.updateRequestActive = false;
    updateOverlay.hidden = true;
    displayPanel.hidden = false;
    renderUpdateControls();
    updateStatusText.textContent = 'Dashboard did not stop; update was not started.';
    return;
  } else {
    updateProgressText.textContent = 'Dashboard did not return in the expected time.';
  }
  reloadDashboardButton.hidden = false;
}

async function loadDisplayStatus() {
  try {
    const response = await fetch('/api/display/status', { cache: 'no-store' });
    if (!response.ok) throw new Error(`display status failed: ${response.status}`);
    const result = await response.json();
    state.brightnessAvailable = result.available === true;
    state.currentBrightness = Number.isInteger(result.currentBrightness)
      ? result.currentBrightness
      : null;
    if (result.settings) state.displaySettings = result.settings;
  } catch {
    state.brightnessAvailable = false;
    state.currentBrightness = null;
  }
  renderDisplayControls();
}

async function setHardwareBrightness(value) {
  const response = await fetch('/api/display/brightness', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ value }),
  });
  const result = await response.json();
  state.brightnessAvailable = result.available === true;
  state.currentBrightness = Number.isInteger(result.currentBrightness)
    ? result.currentBrightness
    : null;
  renderDisplayControls();
  if (!response.ok) throw new Error('Brightness control unavailable');
}

async function persistDisplaySettings() {
  const response = await fetch('/api/display/settings', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(state.displaySettings),
  });
  if (!response.ok) throw new Error(`display settings failed: ${response.status}`);
  const result = await response.json();
  state.displaySettings = result.settings;
  renderDisplayControls();
}

async function applyAutoBrightness({ force = false } = {}) {
  const target = targetBrightnessForTheme(state.displaySettings, state.resolvedTheme);
  if (!state.displayOnly || !state.brightnessAvailable || target === null) return;
  if (!force && state.lastAutoBrightnessTarget === target) return;
  state.lastAutoBrightnessTarget = target;
  if (state.currentBrightness === target) return;
  try {
    await setHardwareBrightness(target);
  } catch {
    state.lastAutoBrightnessTarget = null;
  }
}

function closeDisplayPanel() {
  hideUpdateConfirmation();
  hidePinDialog();
  displayPanel.hidden = true;
}

function hidePinDialog() {
  if (pinDialogTimer !== null) window.clearTimeout(pinDialogTimer);
  pinDialogTimer = null;
  maintenancePin.value = '';
  confirmWindowsExitButton.disabled = false;
  pinDialog.hidden = true;
}

function showPinDialog() {
  hideUpdateConfirmation();
  maintenancePin.value = '';
  pinStatus.textContent = 'PINを入力してください。';
  pinDialog.hidden = false;
  maintenancePin.focus();
  pinDialogTimer = window.setTimeout(hidePinDialog, PIN_DIALOG_TIMEOUT_MS);
}

async function requestWindowsExit() {
  const pin = maintenancePin.value;
  if (!/^[0-9]{4}$/.test(pin)) {
    pinStatus.textContent = '4桁の数字を入力してください。';
    maintenancePin.value = '';
    maintenancePin.focus();
    return;
  }
  confirmWindowsExitButton.disabled = true;
  try {
    const response = await fetch('/api/maintenance/exit', {
      method: 'POST',
      cache: 'no-store',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ pin }),
    });
    maintenancePin.value = '';
    const result = await response.json();
    if (response.status === 429) {
      pinStatus.textContent = 'しばらく待ってから再試行してください。';
      return;
    }
    if (!response.ok || result?.accepted !== true) {
      pinStatus.textContent = response.status === 403
        ? 'PINが違います。'
        : 'Windowsへ戻る操作を利用できません。';
      return;
    }
    pinStatus.textContent = 'Windowsへ戻ります。';
  } catch {
    maintenancePin.value = '';
    pinStatus.textContent = 'Windowsへ戻る操作を利用できません。';
  } finally {
    confirmWindowsExitButton.disabled = false;
    if (!pinDialog.hidden) maintenancePin.focus();
  }
}

async function openDisplayPanel() {
  if (!state.displayOnly || state.earthquake) return;
  displayPanel.hidden = false;
  renderDisplayControls();
  renderUpdateControls();
  renderMaintenanceDiagnostics();
  await Promise.all([loadDisplayStatus(), loadUpdateStatus(), loadMaintenanceRuntime()]);
  renderMaintenanceDiagnostics();
}

async function setAutoBrightness(enabled) {
  if (!state.brightnessAvailable || state.displaySettings.autoBrightness === enabled) return;
  state.displaySettings = { ...state.displaySettings, autoBrightness: enabled };
  state.lastAutoBrightnessTarget = null;
  try {
    await persistDisplaySettings();
    if (enabled) await applyAutoBrightness({ force: true });
  } catch {
    await loadDisplayStatus();
  }
}

const displayHold = createLongPressController({
  onComplete: () => { void openDisplayPanel(); },
});

function hotspotContains(event) {
  const bounds = displayHotspot.getBoundingClientRect();
  return (
    event.clientX >= bounds.left
    && event.clientX <= bounds.right
    && event.clientY >= bounds.top
    && event.clientY <= bounds.bottom
  );
}

displayHotspot.addEventListener('pointerdown', (event) => {
  if (!state.displayOnly || state.earthquake) return;
  event.preventDefault();
  displayHold.start(event.pointerId, hotspotContains(event), event.isPrimary);
  if (displayHold.isActive()) displayHotspot.setPointerCapture(event.pointerId);
});
displayHotspot.addEventListener('pointermove', (event) => {
  displayHold.move(event.pointerId, hotspotContains(event));
});
['pointerup', 'pointercancel', 'lostpointercapture'].forEach((name) => {
  displayHotspot.addEventListener(name, (event) => displayHold.end(event.pointerId));
});
document.addEventListener('pointerdown', (event) => {
  if (state.displayOnly && displayHold.isActive() && event.target !== displayHotspot) {
    displayHold.cancel();
  }
}, true);

function blockProductionGesture(event) {
  if (
    state.displayOnly
    && !displayPanel.contains(event.target)
    && event.target !== displayHotspot
  ) {
    event.preventDefault();
  }
}
['contextmenu', 'dragstart', 'selectstart'].forEach((name) => {
  document.addEventListener(name, blockProductionGesture);
});
document.addEventListener('wheel', blockProductionGesture, { passive: false });

autoBrightnessOn.addEventListener('click', () => { void setAutoBrightness(true); });
autoBrightnessOff.addEventListener('click', () => { void setAutoBrightness(false); });
closeDisplayPanelButton.addEventListener('click', closeDisplayPanel);
openWindowsExitButton.addEventListener('click', showPinDialog);
cancelWindowsExitButton.addEventListener('click', hidePinDialog);
confirmWindowsExitButton.addEventListener('click', () => { void requestWindowsExit(); });
maintenancePin.addEventListener('input', () => {
  maintenancePin.value = maintenancePin.value.replace(/[^0-9]/g, '').slice(0, 4);
});
applyUpdateButton.addEventListener('click', showUpdateConfirmation);
cancelApplyUpdateButton.addEventListener('click', hideUpdateConfirmation);
confirmApplyUpdateButton.addEventListener('click', () => { void beginUpdateApply(); });
reloadDashboardButton.addEventListener('click', () => window.location.reload());

dayBrightness.addEventListener('input', () => {
  state.displaySettings = {
    ...state.displaySettings,
    dayBrightness: Number(dayBrightness.value),
  };
  renderDisplayControls();
});
nightBrightness.addEventListener('input', () => {
  state.displaySettings = {
    ...state.displaySettings,
    nightBrightness: Number(nightBrightness.value),
  };
  renderDisplayControls();
});

async function commitAutomaticTargets() {
  state.lastAutoBrightnessTarget = null;
  try {
    await persistDisplaySettings();
    await applyAutoBrightness({ force: true });
  } catch {
    await loadDisplayStatus();
  }
}

dayBrightness.addEventListener('change', () => { void commitAutomaticTargets(); });
nightBrightness.addEventListener('change', () => { void commitAutomaticTargets(); });
currentBrightness.addEventListener('input', () => {
  currentBrightnessValue.textContent = `${currentBrightness.value}%`;
});
currentBrightness.addEventListener('change', () => {
  void setHardwareBrightness(Number(currentBrightness.value)).catch(() => {});
});

async function initializeDisplayControls() {
  if (!state.displayOnly) return;
  displayControlLayer.hidden = false;
  renderUpdateControls();
  await Promise.all([loadDisplayStatus(), loadUpdateStatus()]);
  await applyAutoBrightness({ force: true });
}

function updateControls() {
  document.querySelectorAll('[data-resolution]').forEach((button) => {
    button.classList.toggle('is-active', button.dataset.resolution === state.resolution);
  });
  document.querySelectorAll('[data-theme]').forEach((button) => {
    button.classList.toggle('is-active', button.dataset.theme === state.themeMode);
  });
  scenarioSelect.value = state.scenario;
  calendarProviderSelect.value = state.calendarMode;
  scenarioSelect.disabled = state.calendarMode === 'google';
  headerLayoutSelect.value = state.headerLayout;
  eewScenarioSelect.disabled = state.runtimeMode !== 'development';
}

function updateClock() {
  const time = dashboard.querySelector('.primary-header time');
  if (!time) return;
  const now = new Date();
  time.textContent = new Intl.DateTimeFormat('ja-JP', {
    timeZone: 'Asia/Tokyo',
    hour: '2-digit',
    minute: '2-digit',
    hourCycle: 'h23',
  }).format(now);
  time.dateTime = now.toISOString();
}

function formatTokyoTimestamp(value) {
  if (!value) return '--';
  return new Intl.DateTimeFormat('ja-JP', {
    timeZone: 'Asia/Tokyo',
    month: 'numeric',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hourCycle: 'h23',
  }).format(new Date(value));
}

function updateTheme(now = new Date()) {
  const previousTheme = state.resolvedTheme;
  const automatic = resolveAutomaticTheme(now);
  state.resolvedTheme = state.themeMode === 'auto' ? automatic.theme : state.themeMode;
  dashboard.dataset.theme = state.resolvedTheme;
  updateControls();
  updateDevelopmentStatus(automatic);
  if (previousTheme !== state.resolvedTheme) void applyAutoBrightness();
}

function updateDevelopmentStatus(automatic = resolveAutomaticTheme()) {
  if (!previewStatus) return;
  const fetched = state.weather.lastSuccessAt
    ? formatTokyoTimestamp(state.weather.lastSuccessAt)
    : '未取得';
  const weatherState = state.weather.stale || state.weatherError
    ? `気象更新待ち・最終取得 ${fetched}`
    : `気象取得 ${fetched}`;
  const autoState = `Auto 日の出 ${formatMinutes(automatic.sunriseMinutes)} / 日没 ${formatMinutes(automatic.sunsetMinutes)}`;
  let calendarState = '予定 Mock';
  if (state.calendarMode === 'google') {
    if (state.calendarError) {
      const labels = {
        configuration: '設定待ち',
        authentication: '認証エラー',
        permission: '共有権限エラー',
        network: '更新待ち',
      };
      calendarState = `予定 Google ${labels[state.calendarError] || '取得エラー'}`;
    } else {
      const calendarFetched = state.calendarLastSuccessAt
        ? formatTokyoTimestamp(state.calendarLastSuccessAt)
        : '未取得';
      calendarState = `予定 Google${state.calendarStale ? ' 更新待ち' : ''} ${calendarFetched}`;
    }
  }
  const eewLabels = {
    idle: '待機',
    connecting: '接続中',
    connected: '接続済み',
    reconnecting: `再接続待ち ${Math.ceil((state.earthquakeStatus.retryInMs || 0) / 1000)}秒`,
    connection_error: '接続エラー',
    stopped: '停止',
  };
  const endpointLabel = state.earthquakeStatus.endpointKind === 'sandbox' ? 'Sandbox' : '本番556';
  const testState = state.earthquakeTestResult ? `・テスト${state.earthquakeTestResult}` : '';
  const audioState = state.earthquakeAudioResult === 'autoplay_blocked' ? '・音声許可待ち' : '';
  const earthquakeState = `地震速報 ${endpointLabel} ${eewLabels[state.earthquakeStatus.state] || state.earthquakeStatus.state}${testState}${audioState}`;
  previewStatus.textContent = `${weatherState}｜${calendarState}｜${autoState}｜${earthquakeState}`;
}

async function loadCalendar() {
  const provider = providers.calendars[state.calendarMode];
  const options = state.calendarMode === 'mock'
    ? {
        calendarId: MOCK_CALENDAR_ID,
        startDate: state.weather.days[0].date,
        days: 7,
        scenario: state.scenario,
        fixture: requestedLayoutFixture,
      }
    : {};
  const result = await provider.getEvents(options);
  state.calendarDays = state.weather.days.map((weatherDay) => (
    result.days.find((calendarDay) => calendarDay.date === weatherDay.date)?.events ?? []
  ));
  state.headacheHistory = result.headacheHistory ?? makeEmptyHistory(state.weather.days[0].date);
  state.aerobicHistory = result.aerobicHistory ?? makeEmptyHistory(state.weather.days[0].date);
  state.strengthHistory = result.strengthHistory ?? makeEmptyHistory(state.weather.days[0].date);
  state.calendarLastSuccessAt = result.lastSuccessAt ?? null;
  state.calendarStale = Boolean(result.stale);
  state.calendarError = result.errorType ?? null;
  state.calendarLoadedMode = state.calendarMode;
}

async function refreshCalendar() {
  try {
    await loadCalendar();
  } catch (error) {
    state.calendarError = error?.kind || 'unknown';
  }
  renderDashboard();
  updateDevelopmentStatus();
}

async function refreshWeather() {
  try {
    const weather = await providers.weather.getWeather();
    state.weather = weather;
    state.weatherError = null;
    renderDashboard();
    updateDevelopmentStatus();
    if (weather.cacheState === 'empty') window.setTimeout(refreshWeather, 5000);
  } catch (error) {
    state.weatherError = error instanceof Error ? error.message : 'Weather refresh failed';
    updateDevelopmentStatus();
  }
}

document.querySelectorAll('[data-resolution]').forEach((button) => {
  button.addEventListener('click', () => {
    state.resolution = button.dataset.resolution;
    updateControls();
    updateScale();
  });
});

document.querySelectorAll('[data-theme]').forEach((button) => {
  button.addEventListener('click', () => {
    state.themeMode = button.dataset.theme;
    updateTheme();
  });
});

scenarioSelect.addEventListener('change', async () => {
  state.scenario = scenarioSelect.value;
  await refreshCalendar();
});

calendarProviderSelect.addEventListener('change', async () => {
  state.calendarMode = calendarProviderSelect.value;
  state.calendarError = null;
  if (state.calendarLoadedMode !== state.calendarMode) {
    state.calendarDays = Array.from({ length: 7 }, () => []);
    state.headacheHistory = makeEmptyHistory(state.weather.days[0].date);
    state.aerobicHistory = makeEmptyHistory(state.weather.days[0].date);
    state.strengthHistory = makeEmptyHistory(state.weather.days[0].date);
    state.calendarLastSuccessAt = null;
    state.calendarStale = false;
  }
  updateControls();
  await refreshCalendar();
});

headerLayoutSelect.addEventListener('change', () => {
  state.headerLayout = headerLayoutSelect.value;
  dashboard.dataset.headerLayout = state.headerLayout;
});

eewScenarioSelect.addEventListener('change', () => {
  const scenario = eewScenarioSelect.value;
  eewScenarioSelect.value = '';
  if (!scenario || !earthquakeProvider || state.runtimeMode !== 'development') return;
  const results = earthquakeProvider.runDevelopmentScenario(scenario);
  state.earthquakeTestResult = `${scenario}:${results.map((result) => result.status).join('→')}`;
  updateDevelopmentStatus();
});

if (state.displayOnly) {
  previewApp.classList.add('display-only');
  previewCanvas.setAttribute('aria-label', '全画面表示');
}

window.addEventListener('resize', updateScale);
window.setInterval(refreshWeather, 60 * 1000);
window.setInterval(refreshCalendar, 60 * 1000);
window.setInterval(() => {
  if (state.displayOnly && !displayPanel.hidden && !state.updateRequestActive) {
    void loadUpdateStatus();
  }
}, 15 * 1000);
window.setInterval(() => {
  updateClock();
  updateTheme();
}, 30 * 1000);

async function initialize() {
  try {
    const response = await fetch('/api/runtime', { cache: 'no-store' });
    const runtime = await response.json();
    if (typeof runtime?.appVersion === 'string') state.appVersion = runtime.appVersion;
    if (runtime?.mode === 'production') {
      state.runtimeMode = 'production';
      state.themeMode = 'auto';
      state.calendarMode = 'google';
      state.displayOnly = true;
      previewApp.classList.add('display-only');
      previewCanvas.setAttribute('aria-label', '全画面表示');
    }
  } catch {
    // Development defaults remain active if the local runtime status is unavailable.
  }
  const endpointKind = state.runtimeMode === 'development' ? requestedEewEndpoint : 'production';
  earthquakeProvider = new P2PEarthquakeProvider({
    endpointKind,
    environment: state.runtimeMode,
    onSound: (alert) => {
      void playEewWarningTone({ developmentTest: alert.developmentTest }).then((result) => {
        state.earthquakeAudioResult = result.played ? 'played' : result.reason;
        updateDevelopmentStatus();
      });
    },
  });
  earthquakeProvider.subscribe((event) => {
    state.earthquake = event;
    renderDashboard();
  });
  earthquakeProvider.subscribeStatus((status) => {
    state.earthquakeStatus = status;
    updateDevelopmentStatus();
  });
  installEewAudioArming();
  earthquakeProvider.connect();
  updateTheme();
  updateControls();
  renderDashboard();
  updateScale();
  void initializeDisplayControls();
  Promise.all([providers.battery.getBattery(), providers.powerPlug.getState()]).catch(() => {});
  refreshWeather();
  refreshCalendar();
  if (requestedEewPreview && state.runtimeMode === 'development') {
    const results = earthquakeProvider.runDevelopmentScenario(requestedEewPreview, { suppressSound: true });
    state.earthquakeTestResult = `${requestedEewPreview}:${results.map((result) => result.status).join('→')}・音なしプレビュー`;
    updateDevelopmentStatus();
  }
}

initialize();
