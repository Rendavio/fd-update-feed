"""Small, sanitized state shared by the Dashboard Apply coordinator and UI."""

from __future__ import annotations

import json
import os
import threading
from pathlib import Path
from typing import Any

APPLY_PHASES = {
    "UNKNOWN", "REQUEST_ACCEPTED", "UAC_APPROVED", "COORDINATOR_STARTED",
    "SHUTDOWN_REQUESTED", "SERVER_EXITED", "PORT_CLOSED", "UPDATER_STARTED",
    "UPDATER_FINISHED", "WATCHER_RESTARTED", "HEALTH_OK",
}
APPLY_RESULTS = {"UNKNOWN", "RUNNING", "PASS", "FAIL", "TIMEOUT"}
APPLY_ERRORS = {
    "NONE", "UAC_CANCELLED", "COORDINATOR_NOT_STARTED",
    "SERVER_EXIT_TIMEOUT", "PORT_CLOSE_TIMEOUT", "UPDATER_NOT_STARTED",
    "UPDATER_EXIT_NONZERO", "UPDATER_TIMEOUT", "RESTART_TIMEOUT",
}
MAX_APPLY_STATE_BYTES = 256
_write_lock = threading.Lock()


def default_apply_state_path() -> Path:
    root = os.environ.get("LOCALAPPDATA")
    if not root:
        return Path(r"C:\ProgramData\FamilyDashboardUpdater\unavailable\apply-phase.json")
    return Path(root) / "FamilyDashboard" / "apply-phase.json"


def unknown_apply_state() -> dict[str, Any]:
    return {"schemaVersion": 1, "phase": "UNKNOWN", "result": "UNKNOWN", "error": "NONE"}


def _validate(phase: str, result: str, error: str) -> dict[str, Any]:
    if phase not in APPLY_PHASES or result not in APPLY_RESULTS or error not in APPLY_ERRORS:
        raise ValueError("Apply phase state must use approved enums")
    return {"schemaVersion": 1, "phase": phase, "result": result, "error": error}


def write_apply_state(
    phase: str,
    result: str,
    error: str,
    *,
    path: Path | None = None,
) -> None:
    target = path or default_apply_state_path()
    value = _validate(phase, result, error)
    raw = (json.dumps(value, ensure_ascii=True, separators=(",", ":")) + "\n").encode("utf-8")
    if len(raw) > MAX_APPLY_STATE_BYTES:
        raise ValueError("Apply phase state exceeds its fixed size bound")
    temporary = Path(str(target) + ".tmp")
    with _write_lock:
        target.parent.mkdir(parents=True, exist_ok=True)
        try:
            with temporary.open("wb") as stream:
                stream.write(raw)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, target)
        finally:
            temporary.unlink(missing_ok=True)


def read_apply_state(*, path: Path | None = None) -> dict[str, Any]:
    target = path or default_apply_state_path()
    try:
        metadata = target.stat()
        if not 1 <= metadata.st_size <= MAX_APPLY_STATE_BYTES:
            raise ValueError("Apply phase state size is invalid")
        raw = target.read_bytes()
        if len(raw) != metadata.st_size or raw.startswith(b"\xef\xbb\xbf"):
            raise ValueError("Apply phase state changed or has a BOM")
        pairs = json.loads(raw.decode("utf-8", errors="strict"), object_pairs_hook=list)
        if not isinstance(pairs, list) or any(not isinstance(item, tuple) or len(item) != 2 for item in pairs):
            raise ValueError("Apply phase state is not an object")
        value: dict[str, Any] = {}
        for key, item in pairs:
            if key in value:
                raise ValueError("Duplicate Apply phase state key")
            value[key] = item
        if set(value) != {"schemaVersion", "phase", "result", "error"} or value["schemaVersion"] != 1:
            raise ValueError("Apply phase state schema is invalid")
        return _validate(value["phase"], value["result"], value["error"])
    except (OSError, ValueError, TypeError, json.JSONDecodeError, UnicodeError):
        return unknown_apply_state()
