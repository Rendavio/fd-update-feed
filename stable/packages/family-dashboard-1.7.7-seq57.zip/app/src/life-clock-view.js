import { calculateLife, tokyoDay } from './life-clock.js';
import { PRIVACY_MODE_STORAGE_KEY } from './display-mode.js';
const el=(tag,cls,text)=>{const n=document.createElement(tag);n.className=cls;if(text!==undefined)n.textContent=text;return n;};
const duration=(months,unit)=>`${Math.floor(months/12)}${unit}${months%12 ? ` ${months%12}か月`:''}`;
export function bindLifeClock({dashboard,isPrivate,isEmergency,refresh,beforeShow=()=>{}}) {
 let open=false, people=[], generation=0, mode='view', message='', day='';
 const blocked=()=>{
  if(isPrivate()) return true;
  try {return localStorage.getItem(PRIVACY_MODE_STORAGE_KEY)==='on';} catch {return true;}
 };
 const clear=()=>{generation++;open=false;people=[];dashboard.querySelector('.life-clock')?.remove();};
 async function request(action,body) {
  if(blocked()) throw Error('privacy');
  const response=await fetch(`/api/life-clock/${action}`,{method:'POST',cache:'no-store',headers:{'Content-Type':'application/json','X-Life-Clock-Privacy':'off'},body:JSON.stringify(body)});
  const result=await response.json();
  if(!response.ok) throw Error(result.error || 'unavailable');
  return result;
 }
 function render() {
  if(!open||blocked()) {clear();return;}
  dashboard.querySelector('.life-clock')?.remove();
  const panel=el('section','life-clock');panel.setAttribute('role','dialog');panel.setAttribute('aria-label','いのちの時計');
  const head=el('header','life-clock-header');head.append(el('h1','','いのちの時計'));
  const back=el('button','','Dashboardへ戻る');back.type='button';back.onclick=()=>{clear();refresh();};head.append(back);panel.append(head);
  if(mode==='register') {renderForm(panel);dashboard.append(panel);return;}
  day=tokyoDay();
  if(!people.length) panel.append(el('p','life-clock-empty',message||'未設定です。Maintenanceから初回登録してください。'));
  people.forEach((person,index)=>{
   const card=el('article',`life-clock-card life-clock-person-${index}`);
   card.append(el('h2','',person.name));
   try {
    const data=calculateLife(person,day);
    const metrics=el('div','life-clock-metrics');
    for(const [label,value] of [['現在の年齢',duration(data.ageMonths,'歳')],['あと',duration(data.remainingMonths,'年')],['平均寿命の目安',duration(data.targetMonths,'歳')]]) {
     const item=el('div','');item.append(el('p','life-clock-label',label),el('strong','',value));metrics.append(item);
    }
    card.append(metrics);
    const bar=el('div','life-clock-bar');bar.setAttribute('role','progressbar');bar.setAttribute('aria-label','人生の進捗率');bar.setAttribute('aria-valuemin','0');bar.setAttribute('aria-valuemax','100');bar.setAttribute('aria-valuenow',data.percent.toFixed(1));
    const fill=el('div','life-clock-fill',`${data.percent.toFixed(1)}%`);fill.style.width=`${data.percent}%`;bar.append(fill);card.append(bar);
    const dates=el('div','life-clock-dates');dates.append(el('span','',person.birthDate.slice(0,7).replace('-','.')),el('span','',data.targetDate.slice(0,7).replace('-','.')));card.append(dates);
   } catch {card.append(el('p','','生命表の対象年齢外のため計算できません。'));}
   panel.append(card);
  });
  panel.append(el('p','life-clock-note','厚生労働省 2025年簡易生命表。現在年齢の平均余命から求めた統計上の平均到達年齢です。個人の死亡時期を予測するものではありません。年月は満年月で表示。'));
  dashboard.append(panel);
 }
 function renderForm(panel) {
  const form=el('form','life-clock-form');form.autocomplete='off';
  form.append(el('p','','2人分の初回登録のみ。保存先は端末内のprivate領域です。登録済みの内容は上書きしません。'));
  for(let i=0;i<2;i++) {
   const row=el('fieldset','');row.append(el('legend','',i===0?'上段（青）':'下段（ピンク）'));
   for(const [key,label,type] of [['name','表示名','text'],['birthDate','生年月日','date']]) {
    const wrap=el('label','',label), input=el('input','');input.name=`${key}${i}`;input.type=type;input.required=true;input.autocomplete='off';if(key==='name')input.maxLength=32;wrap.append(input);row.append(wrap);
   }
   const wrap=el('label','','生命表'),select=el('select','');select.name=`sex${i}`;
   for(const [value,label] of [['male','男性'],['female','女性']]) {const o=el('option','',label);o.value=value;select.append(o);}select.value=i===0?'male':'female';wrap.append(select);row.append(wrap);form.append(row);
  }
  const label=el('label','','Maintenance PIN'),pin=el('input','');pin.type='password';pin.name='pin';pin.inputMode='numeric';pin.pattern='[0-9]{4}';pin.maxLength=4;pin.required=true;pin.autocomplete='off';label.append(pin);form.append(label);
  const save=el('button','','初回登録する');save.type='submit';const status=el('p','');status.setAttribute('role','status');form.append(save,status);
  form.onsubmit=async event=>{
   event.preventDefault();if(blocked()||isEmergency())return;
   save.disabled=true;const id=generation;const data=new FormData(form);
   const values=[0,1].map(i=>({name:data.get(`name${i}`),birthDate:data.get(`birthDate${i}`),sex:data.get(`sex${i}`)}));
   const body={pin:data.get('pin'),people:values};pin.value='';
   try {await request('register',body);form.reset();if(id===generation&&!blocked())status.textContent='登録しました。Dashboardから開いて確認できます。';}
   catch(error) {if(id===generation&&!blocked())status.textContent=error.message==='already_registered'?'登録済みです。既存設定を保持しました。':'登録できませんでした。PIN・入力・private領域を確認してください。';}
   finally {body.pin='';body.people=[];save.disabled=false;}
  };
  panel.append(form);
 }
 async function show(setup=false) {
  if(blocked()||isEmergency())return;
  beforeShow();clear();open=true;mode=setup?'register':'view';message=setup?'':'読み込み中…';refresh();
  if(setup)return;
  const id=generation;
  try {const result=await request('view',{});if(id!==generation||!open||blocked())return;people=result.people;message='';}
  catch {if(id!==generation)return;people=[];message='設定を読み込めません。Maintenanceで確認してください。';}
  if(id===generation&&open&&!blocked())render();
 }
 window.addEventListener('pagehide',clear);
 document.addEventListener('visibilitychange',()=>{if(document.hidden){clear();}else if(open){render();}});
 document.getElementById('registerLifeClock')?.addEventListener('click',()=>show(true));
 return {show,render,clear,isOpen:()=>open,tick:()=>{if(blocked()){if(open)clear();}else if(open&&mode==='view'&&day!==tokyoDay())render();}};
}
