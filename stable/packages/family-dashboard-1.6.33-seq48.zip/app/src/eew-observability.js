// Only this closed schema can enter the private audit transport.
const enums = {
  soundRole: ['production', 'training', 'development'],
  audioBackend: ['private_asset', 'existing_tone'],
  audioPhase: ['requested', 'asset', 'fallback', 'resume', 'scheduled', 'cancelled', 'completed'],
  assetError: ['none', 'missing', 'unreadable', 'invalid', 'unsafe_path', 'fetch_failed', 'decode_failed', 'asset_timeout'],
  cancelReason: ['eew_cancel', 'stop_test', 'auto_cancel', 'superseded', 'unattended_cancel', 'stale'],
  kind: ['websocket', 'message', 'decision', 'overlay', 'audio', 'test'],
  source: ['p2p', 'maintenance_click', 'maintenance_unattended', 'development'],
  websocket: ['connected', 'disconnected', 'reconnecting', 'connecting'],
  reconnectResult: ['pending', 'connected', 'failed'],
  overlay: ['requested', 'shown', 'cleared', 'not_shown'],
  audioResult: ['played', 'blocked', 'failed', 'cancelled', 'timeout', 'unsupported'],
  audioError: ['none', 'timeout', 'blocked', 'cancelled', 'unsupported', 'failed', 'stale'],
  contextBefore: ['running', 'suspended', 'closed', 'interrupted', 'unknown'],
  contextAfter: ['running', 'suspended', 'closed', 'interrupted', 'unknown'],
};
const flags = ['cancelled', 'tokyo23Matched', 'duplicateSuppressed', 'audioRequested', 'userActivation'];
export function safeEewRow(row) {
  if (!row || !enums.kind.includes(row.kind) || !enums.source.includes(row.source)) return null;
  const safe = {};
  for (const [key, values] of Object.entries(enums)) if (values.includes(row[key])) safe[key] = row[key];
  for (const key of flags) if (typeof row[key] === 'boolean') safe[key] = row[key];
  if (typeof row.eventId === 'string' && /^(?:[0-9]{14}|TEST-[A-Z0-9_-]{1,75})$/.test(row.eventId)) safe.eventId = row.eventId;
  if (typeof row.serial === 'string' && /^[0-9]{1,6}$/.test(row.serial)) safe.serial = row.serial;
  if (Number.isInteger(row.reconnectAttempt) && row.reconnectAttempt >= 0 && row.reconnectAttempt <= 10000) safe.reconnectAttempt = row.reconnectAttempt;
  return safe;
}
export async function requestEew(path, body, fetchImpl = globalThis.fetch.bind(globalThis)) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 3000);
  try {
    const response = await fetchImpl(path, {
      method: body === undefined ? 'GET' : 'POST', cache: 'no-store', signal: controller.signal,
      ...(body === undefined ? {} : { headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }),
    });
    if (!response.ok) throw new Error('eew_local_unavailable');
    return await response.json();
  } finally { clearTimeout(timer); }
}
export function createEewAuditClient({ fetchImpl = globalThis.fetch.bind(globalThis), setTimeoutImpl = globalThis.setTimeout.bind(globalThis) } = {}) {
  const queue = []; let scheduled = false, flushing = false;
  async function flush() {
    if (flushing) return;
    flushing = true; scheduled = false;
    try {
      while (queue.length) {
        const rows = queue.splice(0, 32);
        // Failure drops a bounded batch; telemetry must never stop the warning path.
        try { await requestEew('/api/eew/audit', { rows }, fetchImpl); } catch { /* safe failure, no raw exception */ }
      }
    } finally { flushing = false; }
  }
  function record(row) {
    const safe = safeEewRow(row); if (!safe) return;
    if (queue.length >= 64) queue.shift(); queue.push(safe);
    if (!scheduled && !flushing) { scheduled = true; setTimeoutImpl(() => { void flush(); }, 150); }
  }
  return { record, flush };
}
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
const TEST_ID = /^TEST-[A-Z0-9_-]{1,75}$/;
export function createEewTestControl({
  request = (path, body = {}) => requestEew(path, body),
  schedule = globalThis.setTimeout.bind(globalThis), cancelTimer = globalThis.clearTimeout.bind(globalThis),
  activation = () => globalThis.navigator?.userActivation?.hasBeenActive === true,
  run = () => {}, record = () => {}, onStop = () => {}, onState = () => {},
  storage = globalThis.sessionStorage, channel,
} = {}) {
  let generation = 0, timer = null, pending = false, pendingId = null, activeId = null;
  const cancelled = new Set();
  const valid = id => typeof id === 'string' && (UUID.test(id) || TEST_ID.test(id));
  const notify = (error = null) => { try { onState({ pending, active: !!activeId, error }); } catch {} };
  const remember = id => {
    if (!valid(id)) return;
    if (cancelled.size >= 64) cancelled.delete(cancelled.values().next().value);
    cancelled.add(id);
  };
  const forgetStorage = () => { try { storage?.removeItem('eew-test-id'); } catch {} };
  const broadcast = id => { try { channel?.postMessage({ type: 'cancel', testId: id }); } catch {} };
  const cancelServer = id => {
    if (!UUID.test(id || '')) return;
    void request('/api/eew/unattended/cancel', { testId: id }).catch(() => notify('cancel_unavailable'));
  };
  function stop({ expectedId, announce = true, reason = 'stop_test' } = {}) {
    if (expectedId) {
      remember(expectedId);
      if (expectedId !== pendingId && expectedId !== activeId) return;
      if (expectedId === pendingId) {
        ++generation;
        if (timer !== null) cancelTimer(timer);
        timer = null; pending = false; pendingId = null;
        try { if (storage?.getItem('eew-test-id') === expectedId) forgetStorage(); } catch {}
      }
      if (expectedId === activeId) {
        try { onStop(reason, expectedId); } catch {}
        activeId = null;
      }
      cancelServer(expectedId);
      if (announce) broadcast(expectedId);
      notify(); return;
    }
    ++generation;
    if (timer !== null) cancelTimer(timer);
    timer = null;
    const ids = [...new Set([pendingId, activeId].filter(valid))];
    if (!expectedId) { try { const id = storage?.getItem('eew-test-id'); if (UUID.test(id || '')) ids.push(id); } catch {} }
    pending = false; pendingId = null;
    // Synchronous local STOP precedes network or diagnostics.
    try { onStop(reason, expectedId); } catch {}
    activeId = null; forgetStorage();
    for (const id of ids) { remember(id); cancelServer(id); if (announce) broadcast(id); }
    notify();
  }
  const receive = event => {
    const row = event?.data;
    if (row?.type === 'cancel' && valid(row.testId)) stop({ expectedId: row.testId, announce: false, reason: 'unattended_cancel' });
  };
  channel?.addEventListener('message', receive);
  async function consume() {
    const version = generation;
    pending = true;
    try { const id = storage?.getItem('eew-test-id'); if (UUID.test(id || '')) pendingId = id; } catch {}
    notify();
    let state;
    try { state = await request('/api/eew/unattended/consume', {}); }
    catch { if (version === generation) { pending = false; notify('consume_unavailable'); } return false; }
    if (state?.armed !== true || !UUID.test(state.testId || '')) {
      if (version === generation) { pending = false; pendingId = null; forgetStorage(); notify(); }
      return false;
    }
    const id = state.testId;
    if (version !== generation || cancelled.has(id)) { remember(id); cancelServer(id); broadcast(id); return false; }
    pendingId = id;
    timer = schedule(() => {
      timer = null;
      if (version !== generation || cancelled.has(id)) return;
      pending = false; pendingId = null; activeId = id; forgetStorage(); notify();
      record({ kind: 'test', source: 'maintenance_unattended', userActivation: activation() });
      run({ source: 'maintenance_unattended', testId: id });
    }, 45_000);
    notify(); return true;
  }
  async function armAndReload(reload) {
    const version = ++generation;
    pending = true; notify();
    try {
      const state = await request('/api/eew/unattended/arm', {});
      if (!UUID.test(state?.testId || '')) throw new Error('invalid');
      if (version !== generation || cancelled.has(state.testId)) { cancelServer(state.testId); broadcast(state.testId); return false; }
      pendingId = state.testId;
      try { storage?.setItem('eew-test-id', state.testId); } catch {}
      reload(); return true;
    } catch { if (version === generation) { pending = false; notify('arm_unavailable'); } return false; }
  }
  return {
    consume, armAndReload, stop,
    setActive(id) { if (valid(id)) activeId = id; notify(); },
    done(id) { if (activeId === id) activeId = null; notify(); },
    observe(state) { if (state?.armed === true && UUID.test(state.testId || '') && !pendingId && !activeId) { pendingId = state.testId; pending = true; notify(); } },
    dispose() { stop(); channel?.removeEventListener('message', receive); channel?.close?.(); },
  };
}
export function describeEewSummary(summary) {
  const entries = Array.isArray(summary?.entries) ? summary.entries : [];
  const latest = summary?.latest || {};
  const ws = latest.websocket || entries.find(row => row.kind === 'websocket');
  const soundState = role => ['READY', 'MISSING', 'INVALID'].includes(summary?.sounds?.[role]) ? summary.sounds[role] : 'unavailable';
  const last = latest.audio;
  const result = last?.audioResult === 'played' ? 'SCHEDULED' : enums.audioResult.includes(last?.audioResult) ? last.audioResult.toUpperCase() : 'NOT REQUESTED';
  const lines = [
    'Production sound: ' + soundState('production'),
    'Training sound: ' + soundState('training'),
    'Last audio result: ' + (last?.audioBackend === 'existing_tone' ? 'FALLBACK / ' : last?.audioBackend === 'private_asset' ? 'PRIVATE ASSET / ' : '') + result,
    'WebSocket: ' + (ws?.websocket || 'UNKNOWN').toUpperCase(),
  ];
  if (latest.connected) lines.push(`Last connected: ${latest.connected.receivedAtJst || '--'}`);
  for (const [source, label] of [['p2p', 'REAL'], ['maintenance_click', 'TEST click'], ['maintenance_unattended', 'TEST unattended']]) {
    const stream = summary?.bySource?.[source];
    const rows = stream ? Object.values(stream).filter(row => row && typeof row === 'object') : entries.filter(row => row.source === source);
    rows.sort((a, b) => String(b.receivedAtUtc || '').localeCompare(String(a.receivedAtUtc || '')));
    const message = stream?.message || rows.find(row => row.kind === 'message');
    const audio = stream?.audio || rows.find(row => row.audioResult);
    const overlay = stream?.overlay || rows.find(row => row.kind === 'overlay');
    const decision = stream?.target || rows.find(row => row.cancelled !== true && typeof row.tokyo23Matched === 'boolean');
    lines.push(`${label}: ${message?.receivedAtJst || '--'} / ${message?.eventId || '--'} / ${message?.serial || '--'}${message?.cancelled ? ' / CANCELLED' : ''}`);
    lines.push(`Tokyo23: ${decision ? (decision.tokyo23Matched ? 'MATCH' : 'NO MATCH') : 'UNKNOWN'} / Overlay: ${(overlay?.overlay || 'UNKNOWN').toUpperCase()} / Audio: ${audio?.audioResult === 'played' ? 'SCHEDULED' : (audio?.audioResult || 'NOT REQUESTED').toUpperCase()}`);
    if (stream?.fallback) lines.push('Fallback: ' + (enums.assetError.includes(stream.fallback.assetError) ? stream.fallback.assetError.toUpperCase() : 'FAILED'));
    const activation = rows.find(row => typeof row.userActivation === 'boolean');
    if (activation) lines.push(`User activation: ${activation.userActivation ? 'YES — 無操作テストとして無効' : 'NO'}`);
  }
  lines.push('音の聞こえ方・Windows音量は未確認。SCHEDULEDはWeb Audioへの予約です。');
  return lines.join('\n');
}


// Cancel on the initial gesture, before the global AudioContext arming listener.
export function installEewTestStop(button, isCurrent, stop) {
  const cancel = () => { if (isCurrent()) stop(); };
  button.addEventListener('pointerdown', cancel);
  button.addEventListener('keydown', event => {
    if (event.key === 'Enter' || event.key === ' ') cancel();
  });
  button.addEventListener('click', cancel);
}
