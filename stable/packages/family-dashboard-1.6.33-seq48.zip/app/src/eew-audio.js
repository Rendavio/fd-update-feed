let sharedAudioContext = null;
let latestPlayRequest = 0;
const AUDIO_RESUME_TIMEOUT_MS = 3000;
const CONTEXT_STATES = new Set(['running', 'suspended', 'closed', 'interrupted']);

export const EEW_TONE_PATTERN = Object.freeze([
  { frequency: 880, start: 0.00, duration: 0.16 },
  { frequency: 660, start: 0.20, duration: 0.16 },
  { frequency: 880, start: 0.40, duration: 0.16 },
  { frequency: 660, start: 0.60, duration: 0.16 },
  { frequency: 990, start: 0.88, duration: 0.24 },
  { frequency: 740, start: 1.16, duration: 0.24 },
]);

function getAudioContext() {
  if (sharedAudioContext) return sharedAudioContext;
  const AudioContextImpl = globalThis.AudioContext || globalThis.webkitAudioContext;
  if (!AudioContextImpl) return null;
  sharedAudioContext = new AudioContextImpl();
  return sharedAudioContext;
}

function contextState(context) {
  const state = context?.state;
  return CONTEXT_STATES.has(state) ? state : 'unknown';
}

function resumeContext(context, signal) {
  if (signal?.aborted) return Promise.resolve({ ready: false, reason: 'cancelled' });
  if (context.state === 'running') return Promise.resolve({ ready: true, reason: 'running' });
  if (!['suspended', 'interrupted'].includes(context.state)) return Promise.resolve({ ready: false, reason: 'failed' });
  return new Promise((resolve) => {
    let settled = false;
    const finish = (reason) => {
      if (settled) return;
      settled = true;
      globalThis.clearTimeout(timer);
      signal?.removeEventListener('abort', abort);
      resolve({ ready: reason === 'running', reason });
    };
    const abort = () => finish('cancelled');
    const timer = globalThis.setTimeout(() => finish('timeout'), AUDIO_RESUME_TIMEOUT_MS);
    signal?.addEventListener('abort', abort, { once: true });
    if (signal?.aborted) { abort(); return; }
    try {
      Promise.resolve(context.resume()).then(
        () => finish(signal?.aborted ? 'cancelled' : context.state === 'running' ? 'running' : 'blocked'),
        () => finish('blocked'),
      );
    } catch {
      finish('blocked');
    }
  });
}

export async function armEewAudio({ signal } = {}) {
  if (signal?.aborted) return { ready: false, reason: 'cancelled' };
  try {
    const context = getAudioContext();
    if (!context) return { ready: false, reason: 'unsupported' };
    return await resumeContext(context, signal);
  } catch {
    return { ready: false, reason: 'failed' };
  }
}

export async function playEewWarningTone({ developmentTest = false, signal, onAudit = () => {} } = {}) {
  const request = ++latestPlayRequest;
  let context = sharedAudioContext;
  let before = contextState(context);
  const report = (audioResult, audioError = audioResult === 'played' ? 'none' : audioResult) => {
    try {
      onAudit({ kind: 'audio', contextBefore: before, contextAfter: contextState(context), audioRequested: true, audioResult, audioError });
    } catch { /* Diagnostics must not interrupt warnings. */ }
    return audioResult === 'played' ? { played: true, developmentTest } : { played: false, reason: audioResult };
  };
  if (signal?.aborted) return report('cancelled');

  const nodes = [];
  const oscillators = [];
  let cleanupTimer;
  let cleaned = false;
  const cleanup = () => {
    if (cleaned) return;
    cleaned = true;
    globalThis.clearTimeout(cleanupTimer);
    signal?.removeEventListener('abort', cleanup);
    for (const oscillator of oscillators) {
      try { oscillator.stop(context.currentTime); } catch { /* Already stopped or never started. */ }
    }
    for (const node of nodes) {
      try { node.disconnect(); } catch { /* Best-effort cleanup after partial setup. */ }
    }
  };
  try {
    context = getAudioContext();
    before = contextState(context);
    if (!context) return report('unsupported');
    const armed = await resumeContext(context, signal);
    if (signal?.aborted) return report('cancelled');
    if (request !== latestPlayRequest) return report('cancelled', 'stale');
    if (!armed.ready) return report(armed.reason);
    if (context.state !== 'running') return report('blocked');
    // No asynchronous work between the stale check and scheduling the nodes.
    const master = context.createGain();
    nodes.push(master);
    master.gain.value = developmentTest ? 0.08 : 0.34;
    master.connect(context.destination);
    signal?.addEventListener('abort', cleanup, { once: true });
    const baseTime = context.currentTime + 0.02;

    EEW_TONE_PATTERN.forEach(({ frequency, start, duration }) => {
      const oscillator = context.createOscillator();
      oscillators.push(oscillator);
      nodes.push(oscillator);
      const envelope = context.createGain();
      nodes.push(envelope);
      oscillator.type = 'square';
      oscillator.frequency.value = frequency;
      envelope.gain.setValueAtTime(0.0001, baseTime + start);
      envelope.gain.exponentialRampToValueAtTime(0.7, baseTime + start + 0.015);
      envelope.gain.exponentialRampToValueAtTime(0.0001, baseTime + start + duration);
      oscillator.connect(envelope);
      envelope.connect(master);
      oscillator.start(baseTime + start);
      oscillator.stop(baseTime + start + duration + 0.02);
    });

    const totalDuration = Math.max(...EEW_TONE_PATTERN.map((tone) => tone.start + tone.duration));
    cleanupTimer = globalThis.setTimeout(cleanup, Math.ceil((totalDuration + 0.2) * 1000));
    // 'played' confirms WebAudio scheduling, never hardware audibility.
    return report('played');
  } catch {
    cleanup();
    return report('failed');
  }
}

export function installEewAudioArming() {
  const arm = () => void armEewAudio();
  globalThis.addEventListener?.('pointerdown', arm, { once: true, passive: true });
  globalThis.addEventListener?.('keydown', arm, { once: true });
}


export const EEW_FILE_GAIN = 0.20;
const ASSET_TIMEOUT_MS = 1500;
const ASSET_ERRORS = new Set(['missing', 'unreadable', 'invalid', 'unsafe_path']);

function preparePrivateSound(context, role, signal, fetchImpl) {
  return new Promise(resolve => {
    const controller = new AbortController();
    let settled = false;
    const finish = result => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      signal?.removeEventListener('abort', abort);
      controller.abort();
      resolve(result);
    };
    const abort = () => finish({ error: 'cancelled' });
    const timer = setTimeout(() => finish({ error: 'asset_timeout' }), ASSET_TIMEOUT_MS);
    signal?.addEventListener('abort', abort, { once: true });
    if (signal?.aborted) { abort(); return; }
    void (async () => {
      let response;
      try {
        response = await fetchImpl('/api/eew/sound/' + role, {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: '{}', cache: 'no-store', signal: controller.signal,
        });
        if (settled) return;
        if (!response.ok) {
          let error;
          try { error = (await response.json())?.error; } catch {}
          finish({ error: ASSET_ERRORS.has(error) ? error : 'fetch_failed' });
          return;
        }
        if (Number(response.headers?.get('Content-Length')) > 8 * 1024 * 1024) {
          finish({ error: 'invalid' }); return;
        }
        const raw = await response.arrayBuffer();
        if (settled) return;
        if (!raw.byteLength || raw.byteLength > 8 * 1024 * 1024) {
          finish({ error: 'invalid' }); return;
        }
        try {
          const buffer = await context.decodeAudioData(raw);
          if (!(buffer.duration > 0 && buffer.duration <= 30)
            || ![1, 2].includes(buffer.numberOfChannels)
            || !Number.isFinite(buffer.sampleRate) || buffer.sampleRate <= 0) {
            finish({ error: 'invalid' }); return;
          }
          finish({ buffer });
        } catch { finish({ error: 'decode_failed' }); }
      } catch { finish({ error: 'fetch_failed' }); }
    })();
  });
}

// The role is supplied by the local production/maintenance caller, never a P2P field.
export async function playEewAlertSound({
  soundRole, developmentTest = false, signal, onAudit = () => {},
  fetchImpl = (...args) => globalThis.fetch(...args),
} = {}) {
  if (soundRole === 'development') return playEewWarningTone({ developmentTest: true, signal, onAudit });
  if (!['production', 'training'].includes(soundRole)) return { played: false, reason: 'failed' };
  let context, before = 'unknown', backend = 'private_asset', nodes = [], source;
  let stopped = false, timer, terminal = false;
  const emit = (audioPhase, fields = {}) => {
    try { onAudit({ kind: 'audio', soundRole, audioBackend: backend, audioPhase,
      audioRequested: true, contextBefore: before, contextAfter: contextState(context), ...fields }); } catch {}
  };
  const clearNodes = () => {
    if (source) { try { source.stop(); } catch {} source.onended = null; }
    for (const node of nodes) {
      try { if (node.gain) node.gain.value = 0; node.disconnect(); } catch {}
    }
    nodes = []; source = null;
  };
  const dispose = () => {
    clearTimeout(timer); signal?.removeEventListener('abort', cancel); clearNodes();
  };
  const cancel = () => {
    if (terminal) return;
    stopped = true; terminal = true; dispose();
    emit('cancelled', { audioResult: 'cancelled', audioError: 'cancelled',
      cancelReason: ['eew_cancel', 'stop_test', 'auto_cancel', 'superseded', 'unattended_cancel'].includes(signal?.reason) ? signal.reason : 'stale' });
  };
  const failed = reason => {
    if (stopped || signal?.aborted) return { played: false, reason: 'cancelled' };
    terminal = true; dispose();
    emit('resume', { audioResult: reason, audioError: reason });
    return { played: false, reason };
  };
  if (signal?.aborted) { cancel(); return { played: false, reason: 'cancelled' }; }
  signal?.addEventListener('abort', cancel, { once: true });
  try {
    context = getAudioContext(); before = contextState(context);
    emit('requested');
    if (!context) return failed('unsupported');
    // Start within the click call stack; asset I/O must never precede this.
    const arming = resumeContext(context, signal);
    const preparing = preparePrivateSound(context, soundRole, signal, fetchImpl);
    const [armed, asset] = await Promise.all([arming, preparing]);
    if (stopped || signal?.aborted || asset.error === 'cancelled') return { played: false, reason: 'cancelled' };
    let error = asset.error;
    if (error) {
      backend = 'existing_tone';
      emit('fallback', { assetError: error });
    }
    if (!armed.ready) return failed(armed.reason);
    if (context.state !== 'running') return failed('blocked');
    if (!error) {
      try {
        const gain = context.createGain(); nodes.push(gain);
        gain.gain.value = EEW_FILE_GAIN;
        source = context.createBufferSource(); nodes.push(source);
        source.buffer = asset.buffer; source.loop = false;
        source.connect(gain); gain.connect(context.destination);
        if (stopped || signal?.aborted || context.state !== 'running') return failed('cancelled');
        source.onended = () => {
          if (terminal) return;
          terminal = true; dispose(); emit('completed', { audioResult: 'played', audioError: 'none' });
        };
        source.start(context.currentTime + 0.02);
        emit('scheduled', { audioResult: 'played', audioError: 'none' });
        timer = setTimeout(() => {
          if (!terminal) { terminal = true; dispose(); emit('completed', { audioResult: 'played', audioError: 'none' }); }
        }, Math.ceil((asset.buffer.duration + 0.1) * 1000));
        return { played: true, developmentTest: false };
      } catch {
        clearNodes();
        backend = 'existing_tone';
        emit('fallback', { assetError: 'decode_failed' });
      }
    }
    if (stopped || signal?.aborted) return { played: false, reason: 'cancelled' };
    // Context is already running; do not restart/extend a failed resume deadline.
    const result = await playEewWarningTone({ signal, developmentTest: false, onAudit: row => {
      if (!stopped) emit(row.audioResult === 'played' ? 'scheduled' : 'resume', row);
    } });
    if (stopped || signal?.aborted) return { played: false, reason: 'cancelled' };
    if (!result.played) { terminal = true; dispose(); }
    else timer = setTimeout(() => {
      if (!terminal) { terminal = true; dispose(); emit('completed', { audioResult: 'played', audioError: 'none' }); }
    }, 1700);
    return result;
  } catch { return failed('failed'); }
}


// Alert metadata is made by the local provider options, not copied from payload role fields.
export function selectEewSoundRole(alert) {
  if (alert?.maintenanceTest === true && ['maintenance_click', 'maintenance_unattended'].includes(alert.source)) return 'training';
  if (!alert?.developmentTest && !alert?.maintenanceTest && !alert?.sandbox && ['p2p', 'p2pquake'].includes(alert?.source)) return 'production';
  return 'development';
}
