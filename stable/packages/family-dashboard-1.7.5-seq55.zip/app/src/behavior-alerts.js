/** Positive display projection only; no detector, collection or commands. */
const SCHEMA={"enum":{"BASELINE_DELTA":["ABSOLUTE_FACT","ADDED","CONTEXT_ONLY","INITIAL_OBSERVATION","MODIFIED","REMOVED","UNKNOWN"],"EXECUTABLE_TRUST":["INVALID_SIGNATURE","NO_EMBEDDED_SIGNATURE","UNKNOWN","UNTRUSTED_CHAIN","VALID_CACHE_ONLY"],"EXECUTABLE_PATH_CLASS":["APP_CODE","OTHER_LOCAL","PROGRAM_FILES","SYSTEM","UNKNOWN","USER_PROFILE","USER_TEMP"],"NETWORK_DESTINATION_CLASS":["GATEWAY","GLOBAL","LINK_LOCAL","LOOPBACK","MULTICAST","PRIVATE","RESERVED","UNKNOWN","UNSPECIFIED"],"CONNECTION_STATE":["Bound","CloseWait","Closed","Closing","DeleteTCB","Established","FinWait1","FinWait2","LastAck","Listen","SynReceived","SynSent","TimeWait","UNKNOWN"],"CONNECTION_DIRECTION":["NOT_VERIFIED","OUTBOUND_ATTEMPT","OUTBOUND_ATTEMPT_THEN_ESTABLISHED"],"REACHABILITY":["ATTEMPT_ONLY","NOT_VERIFIED","TCP_ESTABLISHED_AT_SAMPLE"],"PROCESS_NETWORK_CORRELATION":["IDENTITY_MISMATCH","NOT_AVAILABLE","PID_SNAPSHOT_ONLY","VERIFIED_INSTANCE_AND_TIME"],"CONFIDENCE":["IDENTITY_UNVERIFIED","MULTI_SOURCE_IDENTITY_LINKED","OBSERVED_FACTS_ONLY"],"BASELINE_TRUST":["INTEGRITY_FAILED","NOT_AVAILABLE","OBSERVED_UNREVIEWED"],"UPDATE_CONTEXT":["LOCAL_RELEASE_MAP_AND_REPORT","NOT_AVAILABLE","REPORT_ONLY"]},"list":{"ANOMALY_TYPE":["BASELINE_REVIEW","CASE_OVERFLOW","CONNECTION_SURGE","EXPECTED_APP_UPDATE","IMAGE_HASH_CHANGED","INTEGRITY_MISMATCH","MASQUERADE_CANDIDATE","NEW_IMAGE","NEW_PEER","OS_VERSION_CHANGED","PERSISTENCE_ACROSS_BOOT","PERSISTENCE_CHANGED","RISKY_EXECUTABLE","SECURITY_CONFIG_CHANGED","SOURCE_DEGRADED","STATE_INTEGRITY_FAILED","STATE_RECOVERED","STATE_WRITE_FAILED","UNUSUAL_PARENT_CHILD","UNUSUAL_PORT"],"PERSISTENCE_CHANGE":["ADDED","MODIFIED","REMOVED"],"SECURITY_CONFIG_CHANGE":["ADDED","MODIFIED","REMOVED"],"CORRELATED_SIGNALS":["BASELINE_REVIEW","CASE_OVERFLOW","CONNECTION_SURGE","EXPECTED_APP_UPDATE","IMAGE_HASH_CHANGED","INTEGRITY_MISMATCH","MASQUERADE_CANDIDATE","NEW_IMAGE","NEW_PEER","OS_VERSION_CHANGED","OUTBOUND_ATTEMPT","PERSISTENCE_ACROSS_BOOT","PERSISTENCE_CHANGED","RISKY_EXECUTABLE","SAME_IMAGE_PERSISTENCE","SECURITY_CONFIG_CHANGED","SOURCE_DEGRADED","STATE_INTEGRITY_FAILED","STATE_RECOVERED","STATE_WRITE_FAILED","TCP_ESTABLISHED","UNUSUAL_PARENT_CHILD","UNUSUAL_PORT","VERIFIED_PARENT_CHILD"],"LIMITATIONS":["ACTOR_UNKNOWN","BASELINE_UNREVIEWED","CACHE_ONLY_REVOCATION_UNKNOWN","CATALOG_SIGNATURE_NOT_CHECKED","DIRECTION_UNKNOWN","DISK_IMAGE_NOT_MEMORY","EVIDENCE_NOT_SAVED","IDENTITY_CAPACITY_REACHED","IDENTITY_UNVERIFIED","INSPECTION_BUDGET_EXHAUSTED","INTEGRITY_UNAVAILABLE","INVALID_SNAPSHOT","LOCAL_MAP_NOT_RUNTIME_VERIFICATION","NETWORK_UNAVAILABLE","NO_ROLE_ATTRIBUTION","OPAQUE_PERSISTENCE_TARGET","PERSISTENCE_UNAVAILABLE","PID_REUSE_POSSIBLE","PROCESS_RACE","SAME_USER_SECRET_NOT_TAMPER_PROOF","SECURITY_UNAVAILABLE","SHORT_AND_UDP_TRAFFIC_MAY_BE_MISSED","SIGNATURE_UNKNOWN","SOURCE_ACCESS_DENIED","SOURCE_FUTURE","SOURCE_NOT_COLLECTED","SOURCE_PARTIAL","SOURCE_STALE","SOURCE_UNAVAILABLE","STATE_INTEGRITY_FAILED","STATE_RECOVERED","TCP_CONTENT_UNKNOWN","TIME_WINDOW_ONLY","TRUNCATED"],"RECOMMENDED_INVESTIGATION":["CHECK_MONITOR_HEALTH","REVIEW_BASELINE","REVIEW_EXECUTABLE","REVIEW_NETWORK","REVIEW_PERSISTENCE","REVIEW_PRIVATE_EVIDENCE","REVIEW_SECURITY_CONFIGURATION","VERIFY_RELEASE_FILES"],"MISSING_EVIDENCE":["ACTOR_IDENTITY","BASELINE_REVIEW","COMPLETE_COVERAGE","CONNECTION_CREATION_TIME","CURRENT_SOURCE_CLOCK","EVIDENCE_NOT_SAVED","EXPECTED_RELEASE_HASH","FRESH_FILE_INSPECTION","ORIGINAL_RAW_EVIDENCE","PERSISTENCE_TARGET","PROCESS_IMAGE","PROCESS_START","VERIFIED_PROCESS_INSTANCE"],"OBSERVATION_SOURCE":["LOCAL_FILE_HASH","NETTCPIP","PERSISTENCE_SNAPSHOT","SECURITY_CONFIG_SNAPSHOT","WIN32_PROCESS"]}};
const U='UNKNOWN',NV='NOT_VERIFIED';
const obj=v=>v!==null&&typeof v==='object'&&!Array.isArray(v);
const iso=v=>typeof v==='string'&&/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d{1,6})?(?:Z|[+-]\d\d:\d\d)$/.test(v)&&Number.isFinite(Date.parse(v))?v:U;
const photoTime=v=>iso(v)===U?U:new Date(v).toISOString().replace(/\.\d{3}Z$/,'Z');
const uuid=v=>typeof v==='string'&&/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/.test(v)?v:U;
const en=(v,values,fallback=U)=>typeof v==='string'&&values.includes(v)?v:fallback;
const number=(v,max,fallback=U)=>Number.isSafeInteger(v)&&v>=0&&v<=max?v:fallback;
/** An incident can be health-only only when every raw/public fact is absent. */
export function isPureBehaviorTelemetryCase(value){
 if(!obj(value)||value.EVENT_SOURCE!=='BEHAVIOR_MONITOR'||value.ALERT_LEVEL!=='WARNING'||value.MONITOR_HEALTH_ONLY===false)return false;
 if(!Array.isArray(value.ANOMALY_TYPE)||value.ANOMALY_TYPE.length!==1||value.ANOMALY_TYPE[0]!=='SOURCE_DEGRADED')return false;
 if(!Array.isArray(value.CORRELATED_SIGNALS)||value.CORRELATED_SIGNALS.some(v=>v!=='SOURCE_DEGRADED'))return false;
 for(const key of ['FACT_TIMELINE','OBSERVATION_SOURCE','PERSISTENCE_CHANGE','SECURITY_CONFIG_CHANGE','RELATED_EVENTS','REASON_CODES','RESOURCE_HASHES','RESOURCE_TYPES'])if(!Array.isArray(value[key])||value[key].length)return false;
 for(const key of ['PROCESS_IDENTITY','IMAGE_IDENTITY','BINARY_SHA256','BASELINE_ID','DESTINATION_PORT','NEW_PEER_COUNT','EXECUTABLE_TRUST','EXECUTABLE_PATH_CLASS','NETWORK_DESTINATION_CLASS','CONNECTION_STATE','DEFENDER_CASE_ID','THREAT_ID','THREAT_NAME','THREAT_CATEGORY','DEFENDER_SEVERITY','DETECTION_SOURCE','DETECTION_METHOD','ACTION_ATTEMPTED','ACTION_RESULT','ERROR_CODE','EVENT_ID','RECORD_ID','SIGNATURE_VERSION','SIGNATURE_AGE'])if(value[key]!=null && value[key]!==U)return false;
 const defaults={BASELINE_DELTA:'ABSOLUTE_FACT',CONNECTION_DIRECTION:'NOT_VERIFIED',REACHABILITY:'NOT_VERIFIED',PROCESS_NETWORK_CORRELATION:'NOT_AVAILABLE',CONFIDENCE:'OBSERVED_FACTS_ONLY',UPDATE_CONTEXT:'NOT_AVAILABLE',BASELINE_TRUST:'NOT_AVAILABLE'};
 for(const [key,expected] of Object.entries(defaults))if(value[key]!==expected)return false;
 if(value.DEFENDER_REFERENCE!=null && value.DEFENDER_REFERENCE!=='NOT_LINKED')return false;
 if(value.RESOURCE_CLASS!==undefined && (!Array.isArray(value.RESOURCE_CLASS)||value.RESOURCE_CLASS.length>1||value.RESOURCE_CLASS.some(v=>v!==U)))return false;
 if(value.DEFENDER_PROTECTION_STATE!==undefined && (!obj(value.DEFENDER_PROTECTION_STATE)||Object.values(value.DEFENDER_PROTECTION_STATE).some(v=>v!==U)))return false;
 return true;
}
export function projectBehaviorCase(raw){
 if(!obj(raw))throw new TypeError('Invalid behavior case');
 const c={CASE_ID:uuid(raw.CASE_ID),DETECTED_AT:iso(raw.DETECTED_AT),OBSERVED_AT:iso(raw.OBSERVED_AT),ALERT_LEVEL:'WARNING',EVENT_SOURCE:'BEHAVIOR_MONITOR',HUMAN_REVIEW_REQUIRED:raw.ACKNOWLEDGED!==true,ACKNOWLEDGED:raw.ACKNOWLEDGED===true,WIFI_STATE:U,ISOLATION_RESULT:'DISABLED',REASON_CODES:[],RESOURCE_CLASS:[U],RESOURCE_TYPES:[],RESOURCE_HASHES:[],RELATED_EVENTS:[],DEFENDER_PROTECTION_STATE:{}};
 for(const [key,values] of Object.entries(SCHEMA.enum))c[key]=en(raw[key],values);
 for(const [key,values] of Object.entries(SCHEMA.list))c[key]=Array.isArray(raw[key])?[...new Set(raw[key].slice(0,32).filter(v=>typeof v==='string'&&values.includes(v)))]:[];
 for(const key of ['PROCESS_IDENTITY','IMAGE_IDENTITY'])c[key]=typeof raw[key]==='string'&&new RegExp(`^${key==='PROCESS_IDENTITY'?'P':'I'}-[a-f0-9]{16}$`).test(raw[key])?raw[key]:U;
 c.MONITOR_HEALTH_ONLY=isPureBehaviorTelemetryCase(raw);
 if(Array.isArray(raw.ANOMALY_TYPE) && raw.ANOMALY_TYPE.some(v=>!SCHEMA.list.ANOMALY_TYPE.includes(v)))c.ANOMALY_TYPE.push(U);
 if(Array.isArray(raw.CORRELATED_SIGNALS) && raw.CORRELATED_SIGNALS.some(v=>!SCHEMA.list.CORRELATED_SIGNALS.includes(v)))c.CORRELATED_SIGNALS.push(U);
 c.BASELINE_ID=uuid(raw.BASELINE_ID);c.BINARY_SHA256=typeof raw.BINARY_SHA256==='string'&&/^[a-f0-9]{64}$/.test(raw.BINARY_SHA256)?raw.BINARY_SHA256:U;
 c.DESTINATION_PORT=number(raw.DESTINATION_PORT,65535);c.SAMPLE_COUNT=number(raw.SAMPLE_COUNT,65535,1);c.NEW_PEER_COUNT=number(raw.NEW_PEER_COUNT,1024);
 c.DEFENDER_REFERENCE=en(raw.DEFENDER_REFERENCE,['NOT_LINKED','SAME_SHA256_TIME_WINDOW'],'NOT_LINKED');c.DEFENDER_CASE_ID=uuid(raw.DEFENDER_CASE_ID);
 c.FACT_TIMELINE=Array.isArray(raw.FACT_TIMELINE)?raw.FACT_TIMELINE.slice(0,16).filter(f=>obj(f)&&iso(f.AT)!==U&&SCHEMA.list.OBSERVATION_SOURCE.includes(f.SOURCE)&&SCHEMA.list.CORRELATED_SIGNALS.includes(f.SIGNAL)&&typeof f.TARGET==='string'&&/^[PI]-[a-f0-9]{16}$/.test(f.TARGET)).map(f=>({AT:iso(f.AT),SOURCE:f.SOURCE,SIGNAL:f.SIGNAL,TARGET:f.TARGET})):[];
 c.MONITOR_HEALTH_ONLY=c.MONITOR_HEALTH_ONLY && isPureBehaviorTelemetryCase(c);
 if(c.MONITOR_HEALTH_ONLY){c.MONITOR_INCIDENT_STATUS=raw.MONITOR_INCIDENT_STATUS==='RECOVERED'?'RECOVERED':'ACTIVE';c.MONITOR_RECOVERED_AT=iso(raw.MONITOR_RECOVERED_AT);if(c.MONITOR_INCIDENT_STATUS==='RECOVERED')c.HUMAN_REVIEW_REQUIRED=false;}
 return c;
}
export function projectBehaviorMetadata(raw){
 if(!obj(raw))return null;
 const coverage={},sectionObservedAt={};
 for(const key of ['processes','network','persistence','security','integrity']){coverage[key]=en(raw.coverage?.[key],['OK','PARTIAL','UNAVAILABLE','NOT_COLLECTED']);sectionObservedAt[key]=iso(raw.sectionObservedAt?.[key]);}
 return {monitorState:en(raw.monitorState,['OK','DEGRADED','STARTING','NOT_AVAILABLE','STOPPED']),lastCheckedAt:iso(raw.lastCheckedAt),baselineTrust:en(raw.baselineTrust,SCHEMA.enum.BASELINE_TRUST),baselineObservedAt:iso(raw.baselineObservedAt),coverage,sectionObservedAt};
}
export function buildBehaviorPages(raw,snapshot,{nowMs=Date.now(),transportUnavailable=false}={}){
 const c=projectBehaviorCase(raw),b=projectBehaviorMetadata(snapshot.behavior),p=[],detail=[];
 const add=(label,value,group='behaviorLine',out=p)=>out.push({label,value:String(value),group});
 const join=v=>v.length?v.join(','):'NONE_REPORTED';
 const clipped=(values,n)=>join(values.slice(0,n))+(values.length>n?` +${values.length-n}_DETAILS`:'');
 const time=iso(b?.lastCheckedAt??snapshot.lastCheckedAt),age=time===U?null:Math.floor((nowMs-Date.parse(time))/1000);
 const freshness=transportUnavailable?'UNAVAILABLE':age===null?'UNKNOWN':age<0?'CLOCK_SKEW':age>300?'STALE':'RECENT';
 add('CASE_ID',c.CASE_ID);add('ALERT_LEVEL',`WARNING; DETECTED_AT=${photoTime(c.DETECTED_AT)}; HUMAN_REVIEW_REQUIRED=${String(c.HUMAN_REVIEW_REQUIRED).toUpperCase()}`);
 add('INCIDENT_STATUS',`${c.ACKNOWLEDGED?'ACKNOWLEDGED':'UNACKNOWLEDGED'}; EVENT_SOURCE=BEHAVIOR_MONITOR; OBSERVED_AT=${photoTime(c.OBSERVED_AT)}`);
 add('ANOMALY_TYPE',clipped(c.ANOMALY_TYPE,2));
 add('BASELINE_DELTA',`${c.BASELINE_DELTA}; BASELINE_TRUST=${c.BASELINE_TRUST}`);
 add('PROCESS_IDENTITY',`${c.PROCESS_IDENTITY}; IMAGE_IDENTITY=${c.IMAGE_IDENTITY}`);
 add('EXECUTABLE_TRUST',`${c.EXECUTABLE_TRUST}; PATH_CLASS=${c.EXECUTABLE_PATH_CLASS}`);
 if(c.BINARY_SHA256!==U)add('BINARY_SHA256',c.BINARY_SHA256);
 add('NETWORK_DESTINATION_CLASS',`${c.NETWORK_DESTINATION_CLASS}; DESTINATION_PORT=${c.DESTINATION_PORT}`);
 add('PROCESS_NETWORK_CORRELATION',c.PROCESS_NETWORK_CORRELATION);
 add('CONNECTION_STATE',`${c.CONNECTION_STATE}; DIRECTION=${c.CONNECTION_DIRECTION}`);
 add('REACHABILITY',`${c.REACHABILITY}; SAMPLES=${c.SAMPLE_COUNT}; NEW_PEERS=${c.NEW_PEER_COUNT}`);
 add('PERSISTENCE_CHANGE',`${clipped(c.PERSISTENCE_CHANGE,2)}; SECURITY_CONFIG_CHANGE=${clipped(c.SECURITY_CONFIG_CHANGE,2)}`);
 add('CORRELATED_SIGNALS',clipped(c.CORRELATED_SIGNALS,3));
 add('CONFIDENCE',`${c.CONFIDENCE}; DEFENDER_REFERENCE=${c.DEFENDER_REFERENCE}`);
 add('MONITOR_STATUS',`${transportUnavailable?'UNAVAILABLE':b?.monitorState??snapshot.monitorState??U}; LAST_CHECKED_AT=${photoTime(time)}`);
 const cov=b?.coverage;add('COVERAGE',cov?Object.entries(cov).map(([k,v])=>`${k.toUpperCase()}=${v}`).join(' '):U);
 add('SECTION_AGE_SEC',b?Object.entries(b.sectionObservedAt).map(([k,v])=>`${k.toUpperCase()}=${iso(v)===U?U:Math.floor((nowMs-Date.parse(v))/1000)}`).join(' '):U);
 add('WIFI_STATE',`${en(snapshot.wifiState,['ON','OFF','UNKNOWN','NOT_AVAILABLE'])}; AUTO_ISOLATION=OFF; ISOLATION_RESULT=DISABLED`);
 add('MISSING_EVIDENCE',clipped(c.MISSING_EVIDENCE,2));
 const basic=['BASELINE_UNREVIEWED','SAME_USER_SECRET_NOT_TAMPER_PROOF','DISK_IMAGE_NOT_MEMORY','CATALOG_SIGNATURE_NOT_CHECKED','CACHE_ONLY_REVOCATION_UNKNOWN','SHORT_AND_UDP_TRAFFIC_MAY_BE_MISSED','TCP_CONTENT_UNKNOWN','NO_ROLE_ATTRIBUTION'];
 const extra=c.LIMITATIONS.filter(v=>!basic.includes(v));
 add('LIMITATIONS',`DISK_ONLY; TRUST=CACHE_ONLY/NO_CATALOG; TCP=SAMPLED/NO_CONTENT/UDP; OS_CAN_BLIND`);
 if(extra.length)add('CASE_LIMITATIONS',clipped(extra,2));
 add('RECOMMENDED_INVESTIGATION',clipped(c.RECOMMENDED_INVESTIGATION,2));
 add('EVIDENCE_SAVED',`${c.MISSING_EVIDENCE.includes('EVIDENCE_NOT_SAVED')?'NO':NV}; DATA_FRESHNESS=${freshness}; AGE_SEC=${age??U}`);
 add('INFECTION_STATUS',`${NV}; RECONNECT_SAFETY=${NV}; BASELINE_IS_NOT_SAFETY_CERTIFICATION`);
 const facts=c.FACT_TIMELINE.slice(-2);add('TIMELINE',`${facts.length}/${c.FACT_TIMELINE.length}_PUBLIC; SOURCE=${clipped(c.OBSERVATION_SOURCE,2)}; RAW=LOCAL_ONLY`);
 for(const [i,f] of facts.entries())add(`T${i+1}`,`${photoTime(f.AT)} ${f.SOURCE} ${f.SIGNAL} ${f.TARGET}`);
 const needsDetail=c.FACT_TIMELINE.length>2||c.ANOMALY_TYPE.length>2||c.CORRELATED_SIGNALS.length>3||c.MISSING_EVIDENCE.length>2||extra.length>2||c.RECOMMENDED_INVESTIGATION.length>2||c.PERSISTENCE_CHANGE.length>2||c.SECURITY_CONFIG_CHANGE.length>2||c.DEFENDER_REFERENCE!=='NOT_LINKED';
 add('SUPPLEMENT',needsDetail?'PAGE_2; EXTRA_PUBLIC_FACTS; RAW_EVIDENCE=LOCAL_ONLY':'NONE; RAW_EVIDENCE=LOCAL_ONLY');
 if(needsDetail){
  for(const key of ['BASELINE_ID','BASELINE_TRUST','BINARY_SHA256','DEFENDER_CASE_ID'])add(key,c[key],'behaviorLine',detail);
  add('BASELINE_OBSERVED_AT',b?.baselineObservedAt??U,'behaviorLine',detail);
  for(const key of ['ANOMALY_TYPE','CORRELATED_SIGNALS','LIMITATIONS','MISSING_EVIDENCE','RECOMMENDED_INVESTIGATION','PERSISTENCE_CHANGE','SECURITY_CONFIG_CHANGE'])add(key,clipped(c[key],3)+(c[key].length>3?'; REST=LOCAL_ONLY':''),'behaviorLine',detail);
  add('SECTION_OBSERVED_AT',b?Object.entries(b.sectionObservedAt).map(([k,v])=>`${k.toUpperCase()}=${photoTime(v)}`).join(' '):U,'behaviorLine',detail);
  add('REFERENCE_SCOPE','SAME_SHA256_TIME_WINDOW=CONTENT_HASH_ONLY; INSTANCE/ACTOR/INFECTION=NOT_VERIFIED','behaviorLine',detail);
  const latest=c.FACT_TIMELINE.slice(-4);add('DETAIL_TIMELINE',`${latest.length}/${c.FACT_TIMELINE.length}; REMAINDER=LOCAL_ONLY`,'behaviorLine',detail);
  for(const [i,f] of latest.entries())add(`D${i+1}`,`${photoTime(f.AT)} ${f.SOURCE} ${f.SIGNAL} ${f.TARGET}`,'behaviorLine',detail);
 }
 return needsDetail?[p,detail]:[p];
}
