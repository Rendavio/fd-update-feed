"""Fixed read-only OS collector and bounded offline file worker; no probes."""
from __future__ import annotations
from collections import OrderedDict
from datetime import datetime,timezone
import copy,json,ntpath,os,re,subprocess,sys
from pathlib import Path
import eew_private_audio as private
from behavior_native import CRITICAL_ARCHIVE_FILES,MAX_SIGNATURE_INSPECTIONS,MAX_INSPECTION_REQUESTS
from behavior_events import canonical_path,instant,TRUST,LIMITATION_CODES
POWERSHELL=r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe'
COLLECTOR=r'C:\FamilyDashboard\launcher\Read-BehaviorSecuritySnapshot.ps1'
WORKER=r'C:\FamilyDashboard\app\behavior_native.py'
SECTIONS=('processes','network','persistence','security','integrity')
def _json(raw,limit):
 if not isinstance(raw,bytes) or not 1<=len(raw)<=limit:raise ValueError()
 def pairs(rows):
  out={}
  for k,v in rows:
   if k in out:raise ValueError()
   out[k]=v
  return out
 return json.loads(raw.decode('utf-8-sig'),object_pairs_hook=pairs,parse_constant=lambda _: (_ for _ in ()).throw(ValueError()))
def _run_environment():
 env=dict(os.environ);env['PSModulePath']=r'C:\Windows\System32\WindowsPowerShell\v1.0\Modules;C:\Program Files\WindowsPowerShell\Modules';env['PATH']=r'C:\Windows\System32;C:\Windows';return env
def _digest(v):return v.lower() if isinstance(v,str) and re.fullmatch('[a-fA-F0-9]{64}',v) else 'UNKNOWN'
class NativeBatchInspector:
 def __init__(self,*,runner=None):self.run=runner or subprocess.run
 def __call__(self,requests):
  if not isinstance(requests,list) or len(requests)>MAX_INSPECTION_REQUESTS:return []
  try:
   raw=json.dumps(requests,separators=(',',':')).encode()
   if len(raw)>32768:return []
   cp=self.run([sys.executable,'-I','-s','-B',WORKER,'--inspect'],input=raw,stdout=subprocess.PIPE,stderr=subprocess.PIPE,shell=False,timeout=10,env=_run_environment(),creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
   if cp.returncode:return []
   rows=_json(cp.stdout,32768)
   if not isinstance(rows,list) or len(rows)>MAX_INSPECTION_REQUESTS:return []
   result=[];seen=set()
   for row in rows:
    if not isinstance(row,dict):continue
    i=row.get('index')
    if type(i) is not int or not 0<=i<len(requests) or i in seen:continue
    seen.add(i);at=instant(row.get('inspectedAt'))
    result.append({'index':i,'trust':row.get('trust') if row.get('trust') in TRUST else 'UNKNOWN','sha256':_digest(row.get('sha256')),'inspectedAt':at.isoformat() if at else None,'error':row.get('error') if row.get('error') in {'NONE','UNSAFE_PATH','OVERSIZED','BYTE_BUDGET','UNREADABLE','UNKNOWN'} else 'UNKNOWN'})
   return result
  except (OSError,ValueError,TypeError,AttributeError,subprocess.TimeoutExpired):return []
class BehaviorWindowsSource:
 def __init__(self,*,app_version,app_sequence=None,update_provider=None,runner=None,inspector=None,platform=None,clock=None,map_loader=None):
  self.version=app_version;self.sequence=app_sequence;self.update_provider=update_provider;self.run=runner or subprocess.run;self.inspect=inspector or NativeBatchInspector();self._platform=sys.platform if platform is None else platform;self.clock=clock or (lambda:datetime.now(timezone.utc));self.cache=OrderedDict();self.map_loader=map_loader or self._read_map;self.slow_cache=None;self.slow_boot=None;self.release_cache={};self.attempts={}
 def _read_map(self):
  with private.secure_file(Path(r'C:\FamilyDashboard\app\behavior_release.json')) as stream:return _json(stream.read(20001),20000)
 def _failure(self,now,code='SOURCE_UNAVAILABLE'):
  return {'schemaVersion':1,'observedAt':now.isoformat(),'os':{},'app':{'version':self.version,'sequence':self.sequence},'coverage':{s:'UNAVAILABLE' for s in SECTIONS},'observed':{s:None for s in SECTIONS},'processes':[],'connections':[],'persistence':[],'security':[],'integrity':[],'gateways':[],'update':{},'limitations':[code]}
 def collect(self,*,full=False):
  now=self.clock()
  if self._platform!='win32':return self._failure(now)
  argv=[POWERSHELL,'-NoLogo','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',COLLECTOR]
  if full:argv.append('-Full')
  try:
   cp=self.run(argv,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,shell=False,timeout=20,env=_run_environment(),creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
   if cp.returncode:return self._failure(now,'SOURCE_ACCESS_DENIED' if cp.returncode==5 else 'SOURCE_UNAVAILABLE')
   v=_json(cp.stdout,1048576);now=self.clock()
   if not isinstance(v,dict) or v.get('schemaVersion')!=1 or not isinstance(v.get('coverage'),dict) or not instant(v.get('observedAt')):raise ValueError()
   for field in ['processes','processesAfter','connections','persistence','security','gateways']:
    if not isinstance(v.get(field),list):raise ValueError()
   if not isinstance(v.get('observed'),dict):raise ValueError()
   v['coverage']={s:v['coverage'].get(s) if v['coverage'].get(s) in {'OK','PARTIAL','UNAVAILABLE','NOT_COLLECTED'} else 'UNAVAILABLE' for s in SECTIONS}
   for name,section,cap in [('processes','processes',384),('connections','network',512),('persistence','persistence',512),('security','security',2048)]:
    if len(v[name])>cap or any(not isinstance(x,dict) for x in v[name]):v['coverage'][section]='PARTIAL'
    v[name]=[x for x in v[name][:cap] if isinstance(x,dict)]
   v['gateways']=[x for x in v['gateways'][:16] if isinstance(x,str) and len(x)<=64]
   v['app']={'version':self.version,'sequence':self.sequence};v['integrity']=[]
   boot=v.get('os',{}).get('bootAt')
   if boot!=self.slow_boot:self.slow_cache=None;self.release_cache={}
   if not full and self.slow_cache:
    for section in ('persistence','security','integrity'):
     v[section]=copy.deepcopy(self.slow_cache[section]);v['coverage'][section]=self.slow_cache['coverage'][section];v['observed'][section]=self.slow_cache['observed'][section]
   limits=[x for x in v.get('limitations',[])[:32] if isinstance(x,str) and x in LIMITATION_CODES]
   limits+=['DISK_IMAGE_NOT_MEMORY','CATALOG_SIGNATURE_NOT_CHECKED','CACHE_ONLY_REVOCATION_UNKNOWN','SHORT_AND_UDP_TRAFFIC_MAY_BE_MISSED']
   after={p.get('pid'):p for p in v.pop('processesAfter')[:384] if isinstance(p,dict) and type(p.get('pid')) is int}
   before={};requests=[];paths=[];candidates={};current_images=set()
   for p in v['processes']:
    pid=p.get('pid');path=canonical_path(p.get('path'));start=instant(p.get('start'));post=after.get(pid,{}) if type(pid) is int else {}
    p['identityVerified']=bool(path and start and canonical_path(post.get('path'))==path and instant(post.get('start'))==start)
    p['pathClass']=self._path_class(path);p.update(sha256='UNKNOWN',trust='UNKNOWN',inspectedAt=None)
    if type(pid) is int:before[pid]=p
    if path:current_images.add(path)
    cached=self.cache.get(path)
    if cached and start and (instant(cached['inspectedAt']) or datetime.min.replace(tzinfo=timezone.utc))>=start and 0<=(now-instant(cached['inspectedAt'])).total_seconds()<900:
     p.update(cached);self.cache.move_to_end(path)
    elif path and ntpath.splitext(path)[1] in {'.exe','.com','.dll'}:candidates[path]=p['pathClass']
   # A bounded deferred queue: new paths first, then least-recently attempted.
   # Failed/expired early images must not permanently starve the tail.
   self.attempts={path:at for path,at in self.attempts.items() if path in current_images}
   floor=datetime.min.replace(tzinfo=timezone.utc)
   paths=sorted(candidates,key=lambda path:(path in self.attempts, self.attempts.get(path,floor),candidates[path] not in {'USER_TEMP','USER_PROFILE','OTHER_LOCAL'},path))[:MAX_SIGNATURE_INSPECTIONS]
   if len(candidates)>MAX_SIGNATURE_INSPECTIONS:limits.append('INSPECTION_BUDGET_EXHAUSTED')
   for path in paths:self.attempts[path]=now;requests.append({'path':path,'signature':True})
   network_at=instant(v['observed'].get('network'))
   for flow in v['connections']:
    p=before.get(flow.get('pid'),{}) if type(flow.get('pid')) is int else {};created=instant(flow.get('createdAt'));start=instant(p.get('start'))
    flow.update(processStart=p.get('start'),processPath=p.get('path'),identityVerified=bool(p.get('identityVerified') and start and created and network_at and start<=created<=network_at<=now))
   release={} if full else self.release_cache
   if full:
    try:
     m=self.map_loader()
     if isinstance(m,dict) and m.get('schemaVersion')==1 and isinstance(m.get('files'),dict) and len(m['files'])<=16 and all(k in CRITICAL_ARCHIVE_FILES[:-1] and _digest(h)!='UNKNOWN' for k,h in m['files'].items()):release=m
    except Exception:pass
    for name in CRITICAL_ARCHIVE_FILES:
     requests.append({'path':ntpath.join(r'C:\FamilyDashboard',name.replace('/','\\')),'signature':False})
   results={r['index']:r for r in (self.inspect(requests) if requests else []) if isinstance(r,dict) and type(r.get('index')) is int}
   for i,path in enumerate(paths):
    r=results.get(i,{})
    if instant(r.get('inspectedAt')):
     self.cache[path]={'sha256':_digest(r.get('sha256')),'trust':r.get('trust') if r.get('trust') in TRUST else 'UNKNOWN','inspectedAt':r['inspectedAt']};self.cache.move_to_end(path)
     for p in v['processes']:
      if canonical_path(p.get('path'))==path:p.update(self.cache[path])
   while len(self.cache)>256:self.cache.popitem(last=False)
   if full:
    for offset,name in enumerate(CRITICAL_ARCHIVE_FILES):
     r=results.get(len(paths)+offset,{});actual=_digest(r.get('sha256'));expected=_digest(release.get('files',{}).get(name))
     v['integrity'].append({'path':ntpath.join(r'C:\FamilyDashboard',name.replace('/','\\')),'sha256':actual,'expectedSha256':expected,'expectedMatch':actual==expected if 'UNKNOWN' not in (actual,expected) else None,'checkedAt':r.get('inspectedAt')})
    # Self hash has no recursive expectation; all fixed release files must be covered.
    v['coverage']['integrity']='OK' if all(x['sha256']!='UNKNOWN' and x['expectedSha256']!='UNKNOWN' for x in v['integrity'][:-1]) else 'PARTIAL';v['observed']['integrity']=self.clock().isoformat()
   elif not self.slow_cache:v['coverage']['integrity']='NOT_COLLECTED';v['observed']['integrity']=None
   if full:
    self.slow_cache={section:copy.deepcopy(v[section]) for section in ('persistence','security','integrity')};self.slow_cache['coverage']=copy.deepcopy(v['coverage']);self.slow_cache['observed']=copy.deepcopy(v['observed']);self.slow_boot=boot;self.release_cache=copy.deepcopy(release)
   update={}
   if self.update_provider:
    try:update=self.update_provider()
    except Exception:pass
   v['update']={'source':'UPDATER_V1_REPORT' if update else 'NOT_AVAILABLE','version':update.get('currentVersion'),'sequence':update.get('currentSequence'),'state':update.get('state','UNKNOWN'),'lastResult':update.get('lastResult','UNKNOWN'),'verification':'REPORT_ONLY' if update else 'NOT_AVAILABLE','releaseMapVersion':release.get('version'),'releaseMapSequence':release.get('sequence')}
   v['observedAt']=self.clock().isoformat()
   v['limitations']=list(dict.fromkeys(limits))[:32];return v
  except (OSError,ValueError,TypeError,AttributeError,subprocess.TimeoutExpired):return self._failure(now)
 @staticmethod
 def _path_class(path):
  if not path:return 'UNKNOWN'
  if path.startswith(ntpath.normcase(ntpath.join('C:/FamilyDashboard/app',''))):return 'APP_CODE'
  if path.startswith((ntpath.normcase(ntpath.join('C:/Windows/System32','')),ntpath.normcase(ntpath.join('C:/Windows/SysWOW64','')),ntpath.normcase(ntpath.join('C:/Windows/WinSxS','')))):return 'SYSTEM'
  if path.startswith(('c:\\program files\\','c:\\program files (x86)\\')):return 'PROGRAM_FILES'
  if ntpath.sep+ntpath.normcase(ntpath.join('AppData/Local/Temp','')) in path or path.startswith(ntpath.normcase(ntpath.join('C:/Windows/Temp',''))):return 'USER_TEMP'
  if path.startswith(ntpath.normcase(ntpath.join('C:/Users',''))):return 'USER_PROFILE'
  return 'OTHER_LOCAL'
