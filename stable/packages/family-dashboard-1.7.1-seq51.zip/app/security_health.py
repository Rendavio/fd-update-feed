"""Positive projections for monitor health. No commands or personal data."""
from datetime import datetime, timezone

MONITOR_REASONS = frozenset({
    'NONE','UNKNOWN','MONITOR_WORKER_NOT_RUNNING','DEFENDER_STATUS_QUERY_TIMEOUT',
    'DEFENDER_STATUS_QUERY_FAILED','DEFENDER_SERVICE_QUERY_FAILED','DEFENDER_SERVICE_STOPPED',
    'REALTIME_PROTECTION_OFF','DEFENDER_EVENT_LOG_UNAVAILABLE','DEFENDER_EVENT_LOG_DISABLED',
    'DEFENDER_EVENT_LOG_ACCESS_DENIED','EVENT_LOG_RESET_OR_ROLLOVER','CHECKPOINT_INVALID',
    'POLL_TIMEOUT','INVALID_SNAPSHOT','SOURCE_PARTIAL','STATE_WRITE_FAILED'})
HEALTH_BOOLEAN_FIELDS=('serviceRunning','realtimeProtection','eventLogExists','eventLogEnabled','eventLogReadable')
LEGACY_MONITOR_CODES=frozenset({'MONITOR_UNAVAILABLE','PROTECTION_UNHEALTHY','PROTECTION_UNKNOWN','SOURCE_PARTIAL','STATE_CORRUPT','STATE_WRITE_FAILED','LOG_RESET','INVALID_SNAPSHOT'})

def safe_reason(value):
    return value if isinstance(value,str) and value in MONITOR_REASONS else 'UNKNOWN'

def safe_time(value):
    if not isinstance(value,str) or len(value)>64:return None
    try:
        at=datetime.fromisoformat(value.replace('Z','+00:00'))
        return at.astimezone(timezone.utc).isoformat() if at.tzinfo else None
    except (ValueError,OverflowError):return None

def safe_record(value):
    return value if type(value) is int and 0<=value<2**63 else None

def public_monitor_health(value):
    value=value if isinstance(value,dict) else {}
    result={
        'status':value.get('status') if value.get('status') in ('MONITOR_OK','MONITOR_UNAVAILABLE','STARTING') else 'STARTING',
        'reason':safe_reason(value.get('reason','NONE')),
        'lastReason':safe_reason(value.get('lastReason','NONE')),
        'workerAlive':value.get('workerAlive') is True,
        'retryCount':1 if type(value.get('retryCount')) is int and value['retryCount']==1 else 0,
        'lastRecovery':value.get('lastRecovery') if value.get('lastRecovery') in ('NONE','AUTOMATIC') else 'NONE',
        'recoveryResult':value.get('recoveryResult') if value.get('recoveryResult') in ('NONE','RECOVERED_AUTOMATICALLY','STILL_UNAVAILABLE') else 'NONE',
    }
    for key in ('lastSuccessfulPollAt','lastRecoveryAt'):result[key]=safe_time(value.get(key))
    for key in HEALTH_BOOLEAN_FIELDS:result[key]=value.get(key) if type(value.get(key)) is bool else None
    for key in ('oldestRecordId','newestRecordId','checkpoint'):result[key]=safe_record(value.get(key))
    return result

def source_reason(snapshot):
    if not isinstance(snapshot,dict):return 'INVALID_SNAPSHOT'
    h=snapshot.get('health');h=h if isinstance(h,dict) else {}
    reason=safe_reason(h.get('reason','NONE'))
    if reason!='NONE':return reason
    if not snapshot.get('available'):
        return {'TIMEOUT':'POLL_TIMEOUT','ACCESS_DENIED':'DEFENDER_EVENT_LOG_ACCESS_DENIED','INVALID_SNAPSHOT':'INVALID_SNAPSHOT'}.get(snapshot.get('error'),'DEFENDER_EVENT_LOG_UNAVAILABLE')
    p=snapshot.get('protection');p=p if isinstance(p,dict) else {}
    if p.get('serviceStatus')=='STOPPED' or p.get('AMServiceEnabled') is False:return 'DEFENDER_SERVICE_STOPPED'
    if p.get('RealTimeProtectionEnabled') is False:return 'REALTIME_PROTECTION_OFF'
    errors=snapshot.get('sourceErrors',[])
    if 'EVENT_LOG_UNAVAILABLE' in errors or snapshot.get('watermark') is None:return 'DEFENDER_EVENT_LOG_UNAVAILABLE'
    if 'STATUS_UNAVAILABLE' in errors or type(p.get('RealTimeProtectionEnabled')) is not bool:return 'DEFENDER_STATUS_QUERY_FAILED'
    if 'SERVICE_UNAVAILABLE' in errors or p.get('serviceStatus') not in ('RUNNING','STOPPED'):return 'DEFENDER_SERVICE_QUERY_FAILED'
    if snapshot.get('logReset') is True or 'LOG_RESET' in errors:return 'EVENT_LOG_RESET_OR_ROLLOVER'
    return 'SOURCE_PARTIAL' if errors else 'NONE'

def monitor_case(case):
    return case.get('EVENT_SOURCE')=='SECURITY_MONITOR' and case.get('ALERT_LEVEL')!='CRITICAL' and 'CASE_OVERFLOW' not in case.get('REASON_CODES',[]) and bool(set(case.get('REASON_CODES',[])) & LEGACY_MONITOR_CODES)

def recovered_case(case):
    return monitor_case(case) and case.get('MONITOR_INCIDENT_STATUS')=='RECOVERED'
