Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"

$script:InstallRoot = Split-Path -Parent $PSScriptRoot
$script:AppRoot = Join-Path $script:InstallRoot "app"
$script:RuntimeRoot = Join-Path $script:InstallRoot "runtime"
$script:PythonPath = Join-Path $script:RuntimeRoot "python.exe"
$script:ServerPath = Join-Path $script:AppRoot "server.py"
$script:HealthUrl = "http://127.0.0.1:3000/api/health"
$script:DiagnosticsUrl = "http://127.0.0.1:3000/diagnostics.html"
$script:ProductionUrl = "http://127.0.0.1:3000/?display=1&theme=auto&calendar=google&eew=production"
$script:MaintenanceUrl = "http://127.0.0.1:3000/?theme=auto&calendar=mock&eew=production"

function Test-FamilyDashboardAdministrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Get-FamilyDashboardEdgePath {
    $candidates = @()
    try {
        $appPath = (Get-ItemProperty -LiteralPath "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe" -ErrorAction Stop)."(default)"
        if ($appPath) { $candidates += $appPath }
    } catch {}
    try {
        $appPath32 = (Get-ItemProperty -LiteralPath "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe" -ErrorAction Stop)."(default)"
        if ($appPath32) { $candidates += $appPath32 }
    } catch {}
    if ($env:ProgramFiles) {
        $candidates += (Join-Path $env:ProgramFiles "Microsoft\Edge\Application\msedge.exe")
    }
    $programFilesX86 = [Environment]::GetEnvironmentVariable("ProgramFiles(x86)")
    if ($programFilesX86) {
        $candidates += (Join-Path $programFilesX86 "Microsoft\Edge\Application\msedge.exe")
    }
    foreach ($candidate in ($candidates | Select-Object -Unique)) {
        if ($candidate -and (Test-Path -LiteralPath $candidate -PathType Leaf)) {
            return (Resolve-Path -LiteralPath $candidate).Path
        }
    }
    return $null
}

function Get-FamilyDashboardHealth {
    try {
        return Invoke-RestMethod -Uri $script:HealthUrl -Method Get -TimeoutSec 3
    } catch {
        return $null
    }
}

function Test-Port3000Listening {
    try {
        return [bool](Get-NetTCPConnection -State Listen -LocalPort 3000 -ErrorAction Stop)
    } catch {
        $client = New-Object System.Net.Sockets.TcpClient
        try {
            $async = $client.BeginConnect("127.0.0.1", 3000, $null, $null)
            return $async.AsyncWaitHandle.WaitOne(500)
        } catch {
            return $false
        } finally {
            $client.Dispose()
        }
    }
}

function Test-FamilyDashboardProductionEdge {
    $existing = @(Get-CimInstance Win32_Process -Filter "Name='msedge.exe'" -ErrorAction SilentlyContinue |
        Where-Object {
            $_.CommandLine -and
            $_.CommandLine.Contains($script:ProductionUrl) -and
            $_.CommandLine -match '(?i)(?:^|\s)--kiosk(?:\s|=)'
        })
    return ($existing.Count -gt 0)
}

function Open-FamilyDashboardEdge {
    param(
        [Parameter(Mandatory = $true)]
        [ValidateSet("Production", "Maintenance", "Diagnostics")]
        [string]$Mode
    )
    $edgePath = Get-FamilyDashboardEdgePath
    if (-not $edgePath) {
        throw "Microsoft Edge Chromium was not found. No fallback browser will be installed or used."
    }
    $edgePolicyPath = "Registry::HKEY_CURRENT_USER\SOFTWARE\Policies\Microsoft\Edge"
    New-Item -Path $edgePolicyPath -Force | Out-Null
    New-ItemProperty -Path $edgePolicyPath -Name "TranslateEnabled" -PropertyType DWord -Value 0 -Force | Out-Null
    if ((Get-ItemPropertyValue -Path $edgePolicyPath -Name "TranslateEnabled") -ne 0) {
        throw "Microsoft Edge TranslateEnabled policy could not be applied."
    }
    if ($Mode -eq "Production") {
        if (Test-FamilyDashboardProductionEdge) { return }
    }
    $arguments = switch ($Mode) {
        "Production" {
            @(
                "--kiosk",
                $script:ProductionUrl,
                "--edge-kiosk-type=fullscreen",
                "--no-first-run"
            )
        }
        "Maintenance" { @("--new-window", $script:MaintenanceUrl) }
        "Diagnostics" { @("--new-window", $script:DiagnosticsUrl) }
    }
    Start-Process -FilePath $edgePath -ArgumentList $arguments | Out-Null
}

function Set-ChildEnvironment {
    param(
        [Parameter(Mandatory = $true)][string]$Mode,
        [Parameter(Mandatory = $true)][string]$DataRoot
    )
    $env:FAMILY_DASHBOARD_MODE = $Mode
    $env:FAMILY_DASHBOARD_HOME = $DataRoot
    $env:PYTHONUTF8 = "1"
    $env:PYTHONDONTWRITEBYTECODE = "1"
}
