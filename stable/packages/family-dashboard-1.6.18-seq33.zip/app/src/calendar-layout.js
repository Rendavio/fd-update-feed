const DAY_MS = 24 * 60 * 60 * 1000;
const DISPLAY_END_EXCLUSIVE = 7;
const FIRST_FUTURE_DAY_INDEX = 1;

function parseDateOnly(value) {
  if (typeof value !== 'string') return null;
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
  if (!match) return null;

  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  const timestamp = Date.UTC(year, month - 1, day);
  const parsed = new Date(timestamp);
  if (
    parsed.getUTCFullYear() !== year
    || parsed.getUTCMonth() !== month - 1
    || parsed.getUTCDate() !== day
  ) {
    return null;
  }
  return timestamp;
}

function finiteNonNegative(value, fallback = 0) {
  const number = Number(value);
  return Number.isFinite(number) && number >= 0 ? number : fallback;
}

export function weekendClassForWeekday(weekday) {
  if (weekday === 6) return 'weekend-saturday';
  if (weekday === 0) return 'weekend-sunday';
  return '';
}

/**
 * Return the stable identity used for expanded copies of a multi-day all-day event.
 * Google Calendar all-day `end` dates are exclusive, so a one-day event has a
 * duration of exactly one day and is intentionally not eligible for the lane.
 */
export function multiDayAllDayKey(event) {
  if (!event || event.allDay !== true || typeof event.id !== 'string' || !event.id) return null;
  const startTimestamp = parseDateOnly(event.start);
  const endTimestamp = parseDateOnly(event.end);
  if (startTimestamp === null || endTimestamp === null) return null;
  if ((endTimestamp - startTimestamp) / DAY_MS <= 1) return null;
  return JSON.stringify([event.id, event.start, event.end]);
}

/**
 * Build a deterministic layout for multi-day all-day events in future columns
 * 1..6 of a seven-day Dashboard. `events` may contain the same expanded event
 * once per day; copies are deduplicated by id + start + end.
 */
export function buildFutureMultiDayLayout(events, displayStartDate) {
  const displayStartTimestamp = parseDateOnly(displayStartDate);
  if (displayStartTimestamp === null) {
    throw new TypeError('displayStartDate must be a valid YYYY-MM-DD date');
  }

  const unique = new Map();
  for (const event of Array.isArray(events) ? events : []) {
    const key = multiDayAllDayKey(event);
    if (key !== null && !unique.has(key)) unique.set(key, event);
  }

  const items = [];
  for (const [key, event] of unique) {
    const rawStartIndex = (parseDateOnly(event.start) - displayStartTimestamp) / DAY_MS;
    const rawEndIndex = (parseDateOnly(event.end) - displayStartTimestamp) / DAY_MS;
    const startDayIndex = Math.max(FIRST_FUTURE_DAY_INDEX, rawStartIndex);
    const endDayIndexExclusive = Math.min(DISPLAY_END_EXCLUSIVE, rawEndIndex);
    if (startDayIndex >= endDayIndexExclusive) continue;
    items.push({
      key,
      event,
      startDayIndex,
      endDayIndexExclusive,
      lane: -1,
    });
  }

  items.sort((left, right) => (
    left.startDayIndex - right.startDayIndex
    || left.endDayIndexExclusive - right.endDayIndexExclusive
    || left.key.localeCompare(right.key)
  ));

  const laneEnds = [];
  for (const item of items) {
    let lane = laneEnds.findIndex((endDayIndexExclusive) => endDayIndexExclusive <= item.startDayIndex);
    if (lane === -1) lane = laneEnds.length;
    item.lane = lane;
    laneEnds[lane] = item.endDayIndexExclusive;
  }

  return {
    items,
    eventKeys: new Set(items.map((item) => item.key)),
    laneCount: laneEnds.length,
  };
}

export function isFutureLaneEvent(event, eventKeys) {
  const key = multiDayAllDayKey(event);
  return key !== null && eventKeys instanceof Set && eventKeys.has(key);
}

function usedHeightForCount(cardHeights, visibleCount, gap, moreHeight, showMore) {
  const cardsHeight = cardHeights.slice(0, visibleCount).reduce((total, height) => total + height, 0);
  const cardGaps = Math.max(0, visibleCount - 1) * gap;
  const moreGap = showMore && visibleCount > 0 ? gap : 0;
  return cardsHeight + cardGaps + (showMore ? moreHeight + moreGap : 0);
}

/**
 * Calculate how many leading event cards fit without using a fixed cap.
 * When cards are omitted, room for the "more" indicator is reserved.
 */
export function calculateEventCapacity({
  availableHeight,
  cardHeights,
  gap = 0,
  moreHeight = 0,
} = {}) {
  const available = finiteNonNegative(availableHeight);
  const heights = Array.isArray(cardHeights)
    ? cardHeights.map((height) => finiteNonNegative(height))
    : [];
  const safeGap = finiteNonNegative(gap);
  const safeMoreHeight = finiteNonNegative(moreHeight);

  const allHeight = usedHeightForCount(heights, heights.length, safeGap, safeMoreHeight, false);
  if (allHeight <= available) {
    return {
      visibleCount: heights.length,
      hiddenCount: 0,
      showMore: false,
      usedHeight: allHeight,
    };
  }

  for (let visibleCount = heights.length - 1; visibleCount >= 0; visibleCount -= 1) {
    const usedHeight = usedHeightForCount(heights, visibleCount, safeGap, safeMoreHeight, true);
    if (usedHeight <= available) {
      return {
        visibleCount,
        hiddenCount: heights.length - visibleCount,
        showMore: true,
        usedHeight,
      };
    }
  }

  return {
    visibleCount: 0,
    hiddenCount: heights.length,
    showMore: false,
    usedHeight: 0,
  };
}
