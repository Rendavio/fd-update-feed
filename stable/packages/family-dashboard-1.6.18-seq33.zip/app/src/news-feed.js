export const NEWS_REFRESH_MS = 20 * 60 * 1000;

export function normalizeNewsTitle(value) {
  if (typeof value !== 'string') return '';
  return value.replace(/[\u0000-\u001f\u007f-\u009f\u200b-\u200f\u202a-\u202e\u2060-\u206f\ufeff]/gu, ' ')
    .replace(/\s+/gu, ' ')
    .trim()
    .slice(0, 500);
}

export function sanitizeNewsPayload(payload) {
  const sanitizeList = (value) => {
    if (!Array.isArray(value)) return [];
    return value.slice(0, 3).map(normalizeNewsTitle).filter(Boolean);
  };
  return {
    yahoo: sanitizeList(payload?.yahoo),
    bbc: sanitizeList(payload?.bbc),
    refreshedAt: typeof payload?.refreshedAt === 'string' ? payload.refreshedAt : null,
  };
}

export function selectNewsDensity(availableHeight, threeItemHeight, twoItemHeight) {
  if (![availableHeight, threeItemHeight, twoItemHeight].every(Number.isFinite)) return 0;
  if (availableHeight >= threeItemHeight) return 3;
  if (availableHeight >= twoItemHeight) return 2;
  return 0;
}

export function selectBoardDensity(availableHeight, twoItemHeight, oneItemHeight, itemCount) {
  if (![availableHeight, twoItemHeight, oneItemHeight, itemCount].every(Number.isFinite)) return 0;
  if (itemCount >= 2 && availableHeight >= twoItemHeight) return 2;
  if (itemCount >= 1 && availableHeight >= oneItemHeight) return 1;
  return 0;
}

export function selectAuxiliaryDensities({
  availableHeight,
  boardItemCount,
  boardTwoHeight,
  boardOneHeight,
  boardNewsGap,
  hasNews,
  newsThreeHeight,
  newsTwoHeight,
}) {
  const boardDensity = selectBoardDensity(
    availableHeight,
    boardTwoHeight,
    boardOneHeight,
    boardItemCount,
  );
  const boardHeight = boardDensity === 2 ? boardTwoHeight : boardDensity === 1 ? boardOneHeight : 0;
  const remaining = Math.max(
    0,
    availableHeight - boardHeight - (boardDensity && hasNews ? boardNewsGap : 0),
  );
  return {
    boardDensity,
    newsDensity: hasNews ? selectNewsDensity(remaining, newsThreeHeight, newsTwoHeight) : 0,
  };
}

export function calculateAuxiliaryPositions({
  containerHeight,
  contentBottom,
  safeGap,
  bottomInset,
  boardHeight,
  newsHeight,
  boardNewsGap,
}) {
  const values = [containerHeight, contentBottom, safeGap, bottomInset, boardHeight, newsHeight, boardNewsGap];
  if (!values.every(Number.isFinite) || boardHeight <= 0 || newsHeight < 0) return null;
  const bottom = containerHeight - bottomInset;
  const newsTop = newsHeight > 0 ? bottom - newsHeight : null;
  const boardBottom = newsTop === null ? bottom : newsTop - boardNewsGap;
  const boardTop = boardBottom - boardHeight;
  if (boardTop < contentBottom + safeGap) return null;
  return { boardTop, newsTop };
}

export async function fetchNews(fetchImpl = fetch) {
  const response = await fetchImpl('/api/news', { cache: 'no-store' });
  if (!response.ok) throw new Error('News unavailable');
  return sanitizeNewsPayload(await response.json());
}
