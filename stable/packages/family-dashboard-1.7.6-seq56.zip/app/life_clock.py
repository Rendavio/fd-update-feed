"""Two-person private life-clock settings; no logging or external communication."""
import json
import os
import re
import tempfile
import threading
from datetime import date
from pathlib import Path
from eew_private_audio import locked_chain, secure_file, _set_private_acl, PrivateAudioError

_LOCK = threading.Lock()

def validate_people(people):
    if not isinstance(people, list) or len(people) != 2:
        raise ValueError('invalid_settings')
    for person in people:
        if not isinstance(person, dict) or set(person) != {'name','sex','birthDate'}:
            raise ValueError('invalid_settings')
        name = person['name']
        if not isinstance(name, str) or not 1 <= len(name.strip()) <= 32 or any(ord(c)<32 for c in name):
            raise ValueError('invalid_settings')
        if person['sex'] not in ('male','female'):
            raise ValueError('invalid_settings')
        value = person['birthDate']
        if not isinstance(value,str) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}',value):
            raise ValueError('invalid_settings')
        try: born = date.fromisoformat(value)
        except ValueError: raise ValueError('invalid_settings') from None
        if born > date.today() or born.year < 1900:
            raise ValueError('invalid_settings')
    return people

class LifeClockStore:
    def __init__(self, root, *, project_root):
        self.root = Path(root).absolute()
        if self.root.resolve().is_relative_to(Path(project_root).resolve()):
            raise ValueError('unsafe_path')
        self.base = self.root/'life-clock-private'
        self.path = self.base/'people.json'

    def read(self):
        try:
            with secure_file(self.path, private_base=self.base) as stream:
                raw = stream.read(4097)
            if len(raw)>4096: raise ValueError('invalid_settings')
            def pairs(rows):
                result = {}
                for k,v in rows:
                    if k in result: raise ValueError('invalid_settings')
                    result[k]=v
                return result
            value = json.loads(raw.decode('utf-8'), object_pairs_hook=pairs)
            if not isinstance(value,dict) or set(value)!={'schemaVersion','people'} or type(value['schemaVersion']) is not int or value['schemaVersion']!=1:
                raise ValueError('invalid_settings')
            return validate_people(value['people'])
        except FileNotFoundError: return []
        except PrivateAudioError as exc:
            if exc.category=='missing': return []
            raise ValueError('private_unavailable') from None
        except (UnicodeError, ValueError): raise ValueError('invalid_settings') from None

    def register(self, people):
        raw=json.dumps({'schemaVersion':1,'people':validate_people(people)},ensure_ascii=False).encode('utf-8')
        with _LOCK, locked_chain(self.root):
            if not self.base.exists(): self.base.mkdir(mode=0o700)
            with locked_chain(self.base): _set_private_acl(self.base)
            with locked_chain(self.base, private_base=self.base):
                if self.path.exists(): raise FileExistsError('already_registered')
                fd,name=tempfile.mkstemp(dir=self.base, suffix='.tmp')
                tmp=Path(name)
                try:
                    _set_private_acl(tmp)
                    with os.fdopen(fd,'wb') as stream:
                        fd=None
                        stream.write(raw); stream.flush(); os.fsync(stream.fileno())
                    # Windows rename refuses an existing destination. No overwrite.
                    if os.name=='nt': os.rename(tmp,self.path)
                    else: os.link(tmp,self.path)
                finally:
                    if fd is not None: os.close(fd)
                    tmp.unlink(missing_ok=True)
