// MHLW 2025 abridged life tables, annual ages 0..105, e_x in years.
// https://www.mhlw.go.jp/toukei/saikin/hw/life/life25/dl/life25-06.pdf
// https://www.mhlw.go.jp/toukei/saikin/hw/life/life25/dl/life25-07.pdf
const TABLE = {
 male: [81.35,80.51,79.53,78.55,77.56,76.57,75.58,74.58,73.59,72.59,71.60,70.60,69.61,68.61,67.62,66.63,65.64,64.66,63.67,62.69,61.72,60.74,59.77,58.80,57.82,56.85,55.88,54.90,53.93,52.96,51.98,51.01,50.04,49.06,48.09,47.12,46.16,45.19,44.22,43.26,42.29,41.33,40.38,39.42,38.47,37.52,36.57,35.63,34.69,33.75,32.82,31.90,30.98,30.06,29.16,28.26,27.36,26.47,25.59,24.72,23.86,23.01,22.16,21.32,20.50,19.68,18.88,18.09,17.31,16.54,15.78,15.04,14.31,13.60,12.91,12.24,11.58,10.94,10.31,9.69,9.10,8.53,7.98,7.45,6.94,6.44,5.97,5.53,5.11,4.73,4.38,4.06,3.74,3.45,3.16,2.90,2.65,2.42,2.20,2.00,1.81,1.64,1.48,1.34,1.21,1.08],
 female: [87.33,86.48,85.51,84.52,83.53,82.54,81.54,80.55,79.55,78.56,77.56,76.57,75.57,74.58,73.59,72.60,71.61,70.62,69.64,68.66,67.67,66.69,65.71,64.73,63.75,62.77,61.78,60.80,59.82,58.83,57.85,56.87,55.88,54.90,53.92,52.94,51.96,50.98,50.00,49.03,48.05,47.08,46.11,45.14,44.17,43.20,42.24,41.28,40.32,39.36,38.41,37.46,36.51,35.57,34.64,33.70,32.77,31.84,30.91,29.99,29.07,28.15,27.24,26.33,25.42,24.52,23.63,22.74,21.85,20.97,20.10,19.24,18.39,17.54,16.70,15.88,15.07,14.27,13.48,12.71,11.95,11.21,10.49,9.80,9.12,8.47,7.85,7.26,6.69,6.16,5.66,5.18,4.75,4.34,3.95,3.58,3.23,2.90,2.59,2.31,2.05,1.81,1.59,1.39,1.22,1.06]
};
const DAY=86400000;
export function tokyoDay(now=new Date()) { return new Date(now.getTime()+9*3600000).toISOString().slice(0,10); }
function parse(value) {
 if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) throw Error('invalid_date');
 const d=new Date(value+'T00:00:00Z');
 if (!Number.isFinite(+d)||d.toISOString().slice(0,10)!==value) throw Error('invalid_date');
 return d;
}
function addMonths(d, months) {
 const result=new Date(Date.UTC(d.getUTCFullYear(),d.getUTCMonth()+months,1));
 const last=new Date(Date.UTC(result.getUTCFullYear(),result.getUTCMonth()+1,0)).getUTCDate();
 result.setUTCDate(Math.min(d.getUTCDate(),last)); return result;
}
export function monthsBetween(start,end) {
 const a=parse(start), b=parse(end);
 let months=(b.getUTCFullYear()-a.getUTCFullYear())*12+b.getUTCMonth()-a.getUTCMonth();
 if(addMonths(a,months)>b) months--; return months;
}
export function calculateLife(person,today=tokyoDay()) {
 const birth=parse(person.birthDate), now=parse(today), table=TABLE[person.sex];
 const ageMonths=monthsBetween(person.birthDate,today), age=Math.floor(ageMonths/12);
 if(!table||age<0||age>=105) throw Error('outside_table');
 const anniversary=addMonths(birth,age*12), next=addMonths(birth,(age+1)*12);
 const fraction=(now-anniversary)/(next-anniversary);
 const remainingYears=table[age]+fraction*(table[age+1]-table[age]);
 // A single day endpoint drives all calendar durations and the bar (365.2425 days/year).
 const target=new Date(+now+Math.round(remainingYears*365.2425)*DAY);
 const targetDate=target.toISOString().slice(0,10);
 return {ageMonths,remainingYears,targetDate,targetMonths:monthsBetween(person.birthDate,targetDate),remainingMonths:monthsBetween(today,targetDate),percent:100*(now-birth)/(target-birth)};
}
