import json
import platform
import sys
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

from calendar_settings import load_calendar_settings
from display_control import (
    DisplaySettingsError,
    DisplaySettingsStore,
    KeepAwakeController,
    WindowsBrightnessController,
)
from google_calendar_provider import GoogleCalendarProvider
from household_settings import load_household_settings
from jma_weather_provider import JmaWeatherProvider


HOST = "127.0.0.1"
PORT = 3000
ROOT = Path(__file__).resolve().parent
APP_ID = "family-dashboard"
APP_VERSION = "1.2.0"
BUILD_ID = "20260902-display-runtime-r1"
MAX_DIAGNOSTIC_BODY_BYTES = 16_384
MAX_DISPLAY_BODY_BYTES = 4_096
DIAGNOSTIC_FIELDS = {
    "screenWidth",
    "screenHeight",
    "availableWidth",
    "availableHeight",
    "viewportWidth",
    "viewportHeight",
    "outerWidth",
    "outerHeight",
    "devicePixelRatio",
    "browserZoomEstimatePercent",
    "physicalWidthEstimate",
    "physicalHeightEstimate",
    "windowsScalingEstimatePercent",
    "calculatedDashboardScale",
    "fullscreenOrKiosk",
    "userAgentFamily",
}


class PreviewHandler(SimpleHTTPRequestHandler):
    weather_provider = None
    calendar_provider = None
    calendar_settings = None
    household_settings = None
    display_settings_store = None
    brightness_controller = None
    keep_awake_controller = None

    def do_GET(self):
        path = urlsplit(self.path).path
        if path in {
            "/api/display/status",
            "/api/display/brightness",
            "/api/display/settings",
        }:
            if not self._accept_local_request(require_origin=False):
                return
            settings, settings_status = self.display_settings_store.load()
            if path == "/api/display/settings":
                self._send_json({
                    "settings": settings,
                    "settingsStatus": settings_status,
                })
                return
            brightness = self.brightness_controller.get_status()
            if path == "/api/display/brightness":
                self._send_json(brightness.as_dict())
                return
            self._send_json({
                **brightness.as_dict(),
                "settings": settings,
                "settingsStatus": settings_status,
                "keepAwakeActive": bool(self.keep_awake_controller.active),
            })
            return
        if path == "/api/weather":
            self._send_json(self.weather_provider.get_snapshot())
            return
        if path == "/api/calendar":
            snapshot = self.calendar_provider.get_snapshot()
            status = 503 if snapshot.get("cacheState") == "empty" else 200
            self._send_json(snapshot, status=status)
            return
        if path == "/api/runtime":
            self._send_json({
                "mode": self.calendar_settings.runtime_mode,
                "appVersion": APP_VERSION,
                "buildId": BUILD_ID,
                "calendar": {
                    "defaultProvider": "google" if self.calendar_settings.runtime_mode == "production" else "mock",
                    "googleConfigured": self.calendar_settings.configured,
                    "householdConfigured": bool(
                        self.household_settings and self.household_settings.configured
                    ),
                },
            })
            return
        if path == "/api/health":
            self._send_json({
                "status": "ok",
                "appId": APP_ID,
                "appVersion": APP_VERSION,
                "buildId": BUILD_ID,
                "host": HOST,
                "port": PORT,
                "mode": self.calendar_settings.runtime_mode,
            })
            return
        if path == "/api/diagnostics/system":
            self._send_json({
                "appId": APP_ID,
                "appVersion": APP_VERSION,
                "buildId": BUILD_ID,
                "host": HOST,
                "port": PORT,
                "mode": self.calendar_settings.runtime_mode,
                "pythonVersion": platform.python_version(),
                "architecture": platform.machine(),
                "platform": platform.system(),
                "keepAwakeActive": bool(self.keep_awake_controller.active),
            })
            return
        super().do_GET()

    def do_POST(self):
        path = urlsplit(self.path).path
        allowed = {
            "/api/diagnostics/display",
            "/api/display/brightness",
            "/api/display/settings",
        }
        if path not in allowed:
            self._send_json({"error": "not_found"}, status=404)
            return
        if not self._accept_local_request(require_origin=True):
            return
        maximum = (
            MAX_DIAGNOSTIC_BODY_BYTES
            if path == "/api/diagnostics/display"
            else MAX_DISPLAY_BODY_BYTES
        )
        try:
            payload = self._read_strict_json(maximum)
        except (OSError, UnicodeDecodeError, ValueError, json.JSONDecodeError):
            self._send_json({"error": "invalid_json"}, status=400)
            return

        if path == "/api/display/brightness":
            if (
                not isinstance(payload, dict)
                or set(payload) != {"value"}
                or type(payload.get("value")) is not int
                or not 0 <= payload["value"] <= 100
            ):
                self._send_json({"error": "invalid_brightness"}, status=400)
                return
            result = self.brightness_controller.set_brightness(payload["value"])
            status = 200 if result.available else 503
            response = result.as_dict()
            if not result.available:
                response["error"] = "brightness_unavailable"
            self._send_json(response, status=status)
            return

        if path == "/api/display/settings":
            try:
                saved = self.display_settings_store.save(payload)
            except DisplaySettingsError:
                self._send_json({"error": "invalid_display_settings"}, status=400)
                return
            except OSError:
                self._send_json({"error": "display_settings_write_failed"}, status=500)
                return
            self._send_json({"settings": saved, "settingsStatus": "saved"})
            return

        try:
            sanitized = self._sanitize_display_diagnostics(payload)
            self._append_display_diagnostics(sanitized)
        except (OSError, ValueError):
            self._send_json({"error": "invalid_diagnostics"}, status=400)
            return
        self._send_json({"status": "saved"})

    def _accept_local_request(self, require_origin):
        expected_host = f"{HOST}:{PORT}"
        if self.headers.get("Host") != expected_host:
            self._send_json({"error": "host_rejected"}, status=403)
            return False
        if require_origin and self.headers.get("Origin") != f"http://{expected_host}":
            self._send_json({"error": "origin_rejected"}, status=403)
            return False
        return True

    def _read_strict_json(self, maximum):
        if self.headers.get("Transfer-Encoding") is not None:
            raise ValueError("Transfer-Encoding is not accepted")
        if self.headers.get("Content-Type", "").casefold() != "application/json":
            raise ValueError("Content-Type must be application/json")
        length_text = self.headers.get("Content-Length", "")
        if not length_text.isascii() or not length_text.isdecimal():
            raise ValueError("Content-Length is invalid")
        length = int(length_text)
        if length <= 0 or length > maximum:
            raise ValueError("Content-Length is outside the accepted range")
        raw = self.rfile.read(length)
        return json.loads(
            raw.decode("utf-8", errors="strict"),
            parse_constant=lambda _value: (_ for _ in ()).throw(
                ValueError("Non-finite JSON number")
            ),
        )

    @staticmethod
    def _sanitize_display_diagnostics(payload):
        if not isinstance(payload, dict) or set(payload) != DIAGNOSTIC_FIELDS:
            raise ValueError("Unexpected diagnostic field")
        sanitized = {}
        for field in DIAGNOSTIC_FIELDS:
            value = payload.get(field)
            if field == "userAgentFamily":
                if value not in {"Microsoft Edge", "Other"}:
                    raise ValueError("Unexpected browser family")
                sanitized[field] = value
                continue
            if field == "fullscreenOrKiosk":
                if type(value) is not bool:
                    raise ValueError("fullscreenOrKiosk must be boolean")
                sanitized[field] = value
                continue
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                raise ValueError("Diagnostic values must be numeric")
            if not 0 < float(value) <= 100_000:
                raise ValueError("Diagnostic value is outside the accepted range")
            sanitized[field] = round(float(value), 2)
        return sanitized

    def _append_display_diagnostics(self, payload):
        report_path = self.calendar_settings.app_data_root / "CHUWI_Dashboard_Install_Report.txt"
        report_path.parent.mkdir(parents=True, exist_ok=True)
        lines = ["", "[Browser display diagnostics]"]
        labels = {
            "screenWidth": "screen width (CSS px)",
            "screenHeight": "screen height (CSS px)",
            "availableWidth": "available width (CSS px)",
            "availableHeight": "available height (CSS px)",
            "viewportWidth": "browser viewport width (CSS px)",
            "viewportHeight": "browser viewport height (CSS px)",
            "outerWidth": "browser outer width (CSS px)",
            "outerHeight": "browser outer height (CSS px)",
            "devicePixelRatio": "devicePixelRatio",
            "browserZoomEstimatePercent": "browser zoom estimate (%)",
            "physicalWidthEstimate": "physical width estimate (px)",
            "physicalHeightEstimate": "physical height estimate (px)",
            "windowsScalingEstimatePercent": "Windows scaling estimate (%)",
            "calculatedDashboardScale": "calculated Dashboard scale",
            "fullscreenOrKiosk": "fullscreen/kiosk detected",
            "userAgentFamily": "browser family",
        }
        for field in sorted(DIAGNOSTIC_FIELDS):
            lines.append(f"{labels[field]}: {payload[field]}")
        with report_path.open("a", encoding="utf-8", newline="\n") as report:
            report.write("\n".join(lines) + "\n")

    def _send_json(self, payload, status=200):
        encoded = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(encoded)))
        self.end_headers()
        self.wfile.write(encoded)

    def end_headers(self):
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate")
        self.send_header("Pragma", "no-cache")
        self.send_header("Expires", "0")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("X-Frame-Options", "DENY")
        connect_sources = ["'self'", "wss://api.p2pquake.net"]
        if self.calendar_settings and self.calendar_settings.runtime_mode == "development":
            connect_sources.append("wss://api-realtime-sandbox.p2pquake.net")
        self.send_header(
            "Content-Security-Policy",
            "default-src 'self'; "
            "script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; "
            f"connect-src {' '.join(connect_sources)}; "
            "object-src 'none'; base-uri 'none'; frame-ancestors 'none'",
        )
        super().end_headers()

    def log_message(self, format, *args):
        return


def run_server():
    calendar_settings = load_calendar_settings(ROOT)
    household_settings = load_household_settings(
        ROOT,
        calendar_settings.app_data_root,
    )
    cache_path = calendar_settings.app_data_root / "cache" / "weather-latest.json"
    weather_provider = JmaWeatherProvider(cache_path)
    calendar_provider = GoogleCalendarProvider(
        calendar_settings,
        person_rules=household_settings.people,
    )
    display_settings_store = DisplaySettingsStore(
        calendar_settings.app_data_root / "display-settings.json"
    )
    brightness_controller = WindowsBrightnessController()
    keep_awake_controller = KeepAwakeController()
    if calendar_settings.runtime_mode == "production":
        keep_awake_controller.activate()
    weather_provider.start()
    calendar_provider.start()
    PreviewHandler.weather_provider = weather_provider
    PreviewHandler.calendar_provider = calendar_provider
    PreviewHandler.calendar_settings = calendar_settings
    PreviewHandler.household_settings = household_settings
    PreviewHandler.display_settings_store = display_settings_store
    PreviewHandler.brightness_controller = brightness_controller
    PreviewHandler.keep_awake_controller = keep_awake_controller
    handler = partial(PreviewHandler, directory=str(ROOT))
    server = ThreadingHTTPServer((HOST, PORT), handler)
    server.daemon_threads = True
    print(f"Family Dashboard {APP_VERSION} ({BUILD_ID}): http://{HOST}:{PORT}", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        calendar_provider.stop()
        weather_provider.stop()
        server.server_close()
        keep_awake_controller.deactivate()


if __name__ == "__main__":
    try:
        run_server()
    except Exception as exc:
        print(f"Family Dashboard startup failed: {type(exc).__name__}: {exc}", file=sys.stderr, flush=True)
        raise
