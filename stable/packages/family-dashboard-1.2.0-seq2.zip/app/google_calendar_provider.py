from __future__ import annotations

import copy
import json
import os
import threading
from datetime import date, datetime, time, timedelta, timezone
from pathlib import Path
from typing import Any, Callable
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlencode, urlparse
from urllib.request import HTTPRedirectHandler, ProxyHandler, Request, build_opener
from zoneinfo import ZoneInfo

from calendar_errors import (
    CalendarAuthenticationError,
    CalendarConfigurationError,
    CalendarDataError,
    CalendarPermissionError,
    CalendarTransientError,
)
from calendar_settings import CalendarSettings
from headache_history import build_headache_history, headache_day_specs
from person_classifier import PersonRule, classify_person


JST = ZoneInfo("Asia/Tokyo")
GOOGLE_CALENDAR_SCOPE = "https://www.googleapis.com/auth/calendar.events.readonly"
GOOGLE_TOKEN_URL = "https://oauth2.googleapis.com/token"
GOOGLE_CALENDAR_API_ORIGIN = "https://www.googleapis.com"
ALLOWED_GOOGLE_HOSTS = frozenset({"oauth2.googleapis.com", "www.googleapis.com"})
EVENT_FIELDS = "nextPageToken,items(id,summary,start(date,dateTime),end(date,dateTime))"
CALENDAR_LOOKBACK_DAYS = 5
CALENDAR_DISPLAY_DAYS = 7


class GoogleOnlyRedirectHandler(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        parsed = urlparse(newurl)
        if parsed.scheme != "https" or parsed.hostname not in ALLOWED_GOOGLE_HOSTS:
            raise CalendarDataError("Google request attempted to leave the approved hosts")
        return super().redirect_request(req, fp, code, msg, headers, newurl)


class GoogleCalendarProvider:
    """Reads one configured Google Calendar and stores a minimal last-good cache."""

    def __init__(
        self,
        settings: CalendarSettings,
        cache_path: Path | None = None,
        token_provider: Callable[[], str] | None = None,
        json_getter: Callable[[str, dict[str, str]], Any] | None = None,
        now_factory: Callable[[], datetime] | None = None,
        refresh_interval_seconds: int = 300,
        person_rules: tuple[PersonRule, ...] = (),
    ) -> None:
        self.settings = settings
        self.cache_path = cache_path or settings.app_data_root / "cache" / "calendar-latest.json"
        self.refresh_interval_seconds = refresh_interval_seconds
        self._person_rules = tuple(person_rules)
        self._token_provider = token_provider or self._google_access_token
        self._json_getter = json_getter or self._google_get_json
        self._now_factory = now_factory or (lambda: datetime.now(timezone.utc))
        self._opener = build_opener(ProxyHandler({}), GoogleOnlyRedirectHandler())
        self._lock = threading.RLock()
        self._stop_event = threading.Event()
        self._thread: threading.Thread | None = None
        self._snapshot: dict[str, Any] | None = None
        self._credentials = None
        self._failure_kind: str | None = None
        self._transient_failures = 0
        self._load_cache()
        if not settings.configured:
            self._mark_failure("configuration", settings.configuration_error or "Calendar is not configured")

    def start(self) -> None:
        if not self.settings.configured or (self._thread and self._thread.is_alive()):
            return
        self._thread = threading.Thread(target=self._refresh_loop, name="google-calendar-refresh", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop_event.set()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=2)

    def get_snapshot(self) -> dict[str, Any]:
        with self._lock:
            if self._snapshot is None:
                snapshot = self._empty_snapshot("configuration", "Google Calendar is not configured")
            else:
                snapshot = copy.deepcopy(self._snapshot)
        for day in snapshot["days"]:
            for event in day["events"]:
                event["owner"] = classify_person(event.get("summary"), self._person_rules)
        return snapshot

    def refresh_now(self) -> bool:
        if not self.settings.configured:
            self._mark_failure("configuration", self.settings.configuration_error or "Calendar is not configured")
            return False
        try:
            token = self._token_provider()
            items = self._fetch_event_items(token)
            snapshot = self._build_snapshot(items, self._now_factory())
            self._validate_snapshot(snapshot)
            self._store_success(snapshot)
            self._failure_kind = None
            self._transient_failures = 0
            return True
        except CalendarAuthenticationError:
            self._mark_failure("authentication", "Service Account authentication failed")
        except CalendarPermissionError:
            self._mark_failure("permission", "Configured calendar is not shared with this Service Account")
        except CalendarTransientError:
            self._transient_failures += 1
            self._mark_failure("network", "Google Calendar update is waiting for retry")
        except CalendarConfigurationError:
            self._mark_failure("configuration", "Google Calendar local configuration is invalid")
        except CalendarDataError:
            self._mark_failure("data", "Google Calendar response is invalid")
        return False

    def next_retry_seconds(self) -> int:
        if self._failure_kind in {"authentication", "permission", "configuration"}:
            return 1800
        if self._failure_kind == "network":
            return min(60 * (2 ** max(0, self._transient_failures - 1)), 900)
        if self._failure_kind == "data":
            return 600
        return self.refresh_interval_seconds

    def _refresh_loop(self) -> None:
        while not self._stop_event.is_set():
            self.refresh_now()
            self._stop_event.wait(self.next_retry_seconds())

    def _fetch_event_items(self, token: str) -> list[dict[str, Any]]:
        if not token:
            raise CalendarAuthenticationError("Google access token is empty")
        page_token = None
        items: list[dict[str, Any]] = []
        for _ in range(20):
            url = self._build_events_url(page_token)
            payload = self._json_getter(url, {"Authorization": f"Bearer {token}", "Accept": "application/json"})
            if not isinstance(payload, dict) or not isinstance(payload.get("items", []), list):
                raise CalendarDataError("Google Calendar events response schema is invalid")
            items.extend(item for item in payload.get("items", []) if isinstance(item, dict))
            page_token = payload.get("nextPageToken")
            if not page_token:
                return items
            if not isinstance(page_token, str):
                raise CalendarDataError("Google Calendar page token is invalid")
        raise CalendarDataError("Google Calendar pagination exceeded the safety limit")

    def _build_events_url(self, page_token: str | None = None) -> str:
        calendar_id = self.settings.calendar_id
        if not calendar_id or calendar_id.casefold() == "primary":
            raise CalendarConfigurationError("Exact Calendar ID is required")
        now_jst = self._now_factory().astimezone(JST)
        display_start = datetime.combine(now_jst.date(), time.min, tzinfo=JST)
        start = display_start - timedelta(days=CALENDAR_LOOKBACK_DAYS)
        end = display_start + timedelta(days=CALENDAR_DISPLAY_DAYS)
        query = {
            "timeMin": start.isoformat(),
            "timeMax": end.isoformat(),
            "timeZone": "Asia/Tokyo",
            "singleEvents": "true",
            "orderBy": "startTime",
            "showDeleted": "false",
            "maxResults": "2500",
            "fields": EVENT_FIELDS,
        }
        if page_token:
            query["pageToken"] = page_token
        encoded_calendar_id = quote(calendar_id, safe="")
        return f"{GOOGLE_CALENDAR_API_ORIGIN}/calendar/v3/calendars/{encoded_calendar_id}/events?{urlencode(query)}"

    def _google_access_token(self) -> str:
        try:
            from google.auth.exceptions import RefreshError, TransportError
            from google.auth.transport.requests import Request as GoogleAuthRequest
            from google.oauth2 import service_account
            import requests
        except ImportError as exc:
            raise CalendarConfigurationError("google-auth[requests] is required") from exc

        try:
            if self.settings.secret_path.stat().st_size > 128_000:
                raise CalendarConfigurationError("Service Account key file is unexpectedly large")
            info = json.loads(self.settings.secret_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise CalendarConfigurationError("Service Account key file cannot be read") from exc

        required = {"type", "private_key", "client_email", "token_uri"}
        if not isinstance(info, dict) or not required.issubset(info):
            raise CalendarConfigurationError("Service Account key schema is invalid")
        if info.get("type") != "service_account":
            raise CalendarConfigurationError("Credential is not a Service Account key")
        if info.get("token_uri") != GOOGLE_TOKEN_URL:
            raise CalendarConfigurationError("Service Account token URI is not approved")
        if not str(info.get("client_email", "")).endswith(".gserviceaccount.com"):
            raise CalendarConfigurationError("Service Account email is invalid")

        try:
            if self._credentials is None:
                self._credentials = service_account.Credentials.from_service_account_info(
                    info,
                    scopes=[GOOGLE_CALENDAR_SCOPE],
                )
            if not self._credentials.valid:
                session = requests.Session()
                session.trust_env = False
                session.max_redirects = 0
                self._credentials.refresh(GoogleAuthRequest(session=session))
            return self._credentials.token
        except RefreshError as exc:
            raise CalendarAuthenticationError("Service Account token request was rejected") from exc
        except TransportError as exc:
            raise CalendarTransientError("Service Account token request failed temporarily") from exc
        except requests.RequestException as exc:
            raise CalendarTransientError("Service Account token transport failed") from exc

    def _google_get_json(self, url: str, headers: dict[str, str]) -> Any:
        parsed = urlparse(url)
        if parsed.scheme != "https" or parsed.hostname != "www.googleapis.com":
            raise CalendarDataError("Calendar API host is not approved")
        request = Request(url, headers=headers)
        try:
            with self._opener.open(request, timeout=15) as response:
                if urlparse(response.geturl()).hostname != "www.googleapis.com":
                    raise CalendarDataError("Calendar response left the approved host")
                payload = response.read(2_500_000)
        except HTTPError as exc:
            if exc.code == 401:
                raise CalendarAuthenticationError("Calendar API rejected the token") from exc
            if exc.code in {403, 404}:
                raise CalendarPermissionError("Calendar is unavailable to the Service Account") from exc
            if exc.code == 429 or 500 <= exc.code <= 599:
                raise CalendarTransientError("Calendar API is temporarily unavailable") from exc
            raise CalendarDataError("Calendar API returned an unexpected status") from exc
        except (URLError, TimeoutError, OSError) as exc:
            raise CalendarTransientError("Calendar API network request failed") from exc
        try:
            return json.loads(payload.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise CalendarDataError("Calendar API returned invalid JSON") from exc

    def _build_snapshot(self, items: list[dict[str, Any]], fetched_at: datetime) -> dict[str, Any]:
        now_jst = fetched_at.astimezone(JST)
        start_date = now_jst.date()
        fetch_start_date = start_date - timedelta(days=CALENDAR_LOOKBACK_DAYS)
        end_date = start_date + timedelta(days=CALENDAR_DISPLAY_DAYS)
        events_by_date: dict[str, list[dict[str, Any]]] = {
            (fetch_start_date + timedelta(days=offset)).isoformat(): []
            for offset in range(CALENDAR_LOOKBACK_DAYS + CALENDAR_DISPLAY_DAYS)
        }

        for item in items:
            event_id = item.get("id")
            summary = item.get("summary")
            start_value = item.get("start")
            end_value = item.get("end")
            if not isinstance(event_id, str) or not isinstance(start_value, dict) or not isinstance(end_value, dict):
                continue
            safe_summary = summary if isinstance(summary, str) and summary else "--"

            if isinstance(start_value.get("date"), str) and isinstance(end_value.get("date"), str):
                try:
                    event_start = date.fromisoformat(start_value["date"])
                    event_end = date.fromisoformat(end_value["date"])
                except ValueError:
                    continue
                if event_end <= event_start:
                    continue
                occurrence_start = max(event_start, fetch_start_date)
                occurrence_end = min(event_end, end_date)
                current = occurrence_start
                while current < occurrence_end:
                    events_by_date[current.isoformat()].append({
                        "id": event_id,
                        "summary": safe_summary,
                        "start": start_value["date"],
                        "end": end_value["date"],
                        "allDay": True,
                        "time": "終日",
                    })
                    current += timedelta(days=1)
                continue

            if not isinstance(start_value.get("dateTime"), str) or not isinstance(end_value.get("dateTime"), str):
                continue
            try:
                event_start_time = datetime.fromisoformat(start_value["dateTime"].replace("Z", "+00:00"))
                event_end_time = datetime.fromisoformat(end_value["dateTime"].replace("Z", "+00:00"))
                if event_start_time.tzinfo is None or event_end_time.tzinfo is None:
                    continue
                event_start_jst = event_start_time.astimezone(JST)
                event_end_jst = event_end_time.astimezone(JST)
            except ValueError:
                continue
            if event_end_jst <= event_start_jst:
                continue
            date_key = event_start_jst.date().isoformat()
            if date_key not in events_by_date:
                continue
            events_by_date[date_key].append({
                "id": event_id,
                "summary": safe_summary,
                "start": start_value["dateTime"],
                "end": end_value["dateTime"],
                "allDay": False,
                "time": event_start_jst.strftime("%H:%M"),
            })

        days = []
        for offset in range(CALENDAR_DISPLAY_DAYS):
            date_key = (start_date + timedelta(days=offset)).isoformat()
            events = events_by_date[date_key]
            events.sort(key=lambda event: (not event["allDay"], event["time"], event["summary"]))
            days.append({"date": date_key, "events": events})

        return {
            "schemaVersion": 2,
            "provider": "google",
            "fetchedAt": fetched_at.isoformat(),
            "lastSuccessAt": fetched_at.isoformat(),
            "stale": False,
            "cacheState": "live",
            "errorType": None,
            "error": None,
            "startDate": start_date.isoformat(),
            "endExclusive": end_date.isoformat(),
            "fetchStartDate": fetch_start_date.isoformat(),
            "fetchEndExclusive": end_date.isoformat(),
            "days": days,
            "headacheHistory": build_headache_history(events_by_date, start_date),
        }

    def _validate_snapshot(self, snapshot: dict[str, Any]) -> None:
        if snapshot.get("schemaVersion") != 2 or snapshot.get("provider") != "google":
            raise CalendarDataError("Calendar cache schema is invalid")
        days = snapshot.get("days")
        if not isinstance(days, list) or len(days) != CALENDAR_DISPLAY_DAYS:
            raise CalendarDataError("Calendar cache must contain seven days")
        allowed_event_keys = {"id", "summary", "start", "end", "allDay", "time"}
        previous = None
        for day_item in days:
            if not isinstance(day_item, dict) or not isinstance(day_item.get("events"), list):
                raise CalendarDataError("Calendar day schema is invalid")
            current = date.fromisoformat(day_item.get("date", ""))
            if previous is not None and current != previous + timedelta(days=1):
                raise CalendarDataError("Calendar dates are not consecutive")
            previous = current
            for event in day_item["events"]:
                if not isinstance(event, dict) or set(event) != allowed_event_keys:
                    raise CalendarDataError("Calendar cache contains a non-minimal event")
        try:
            start_date = date.fromisoformat(snapshot.get("startDate", ""))
        except (TypeError, ValueError) as exc:
            raise CalendarDataError("Calendar start date is invalid") from exc
        expected_history = headache_day_specs(start_date)
        history = snapshot.get("headacheHistory")
        if not isinstance(history, list) or len(history) != len(expected_history):
            raise CalendarDataError("Calendar cache must contain five headache history days")
        for item, (expected_date, expected_label) in zip(history, expected_history, strict=True):
            if (
                not isinstance(item, dict)
                or set(item) != {"date", "label", "occurred"}
                or item.get("date") != expected_date
                or item.get("label") != expected_label
                or not isinstance(item.get("occurred"), bool)
            ):
                raise CalendarDataError("Calendar headache history schema is invalid")

    def _store_success(self, snapshot: dict[str, Any]) -> None:
        self.cache_path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.cache_path.with_suffix(".tmp")
        temporary.write_text(json.dumps(snapshot, ensure_ascii=False, indent=2), encoding="utf-8")
        os.chmod(temporary, 0o600)
        os.replace(temporary, self.cache_path)
        with self._lock:
            self._snapshot = copy.deepcopy(snapshot)

    def _mark_failure(self, kind: str, message: str) -> None:
        self._failure_kind = kind
        with self._lock:
            if self._snapshot is None:
                self._snapshot = self._empty_snapshot(kind, message)
            else:
                self._snapshot["stale"] = True
                self._snapshot["cacheState"] = "cached"
                self._snapshot["errorType"] = kind
                self._snapshot["error"] = message
                self._snapshot["lastAttemptAt"] = self._now_factory().isoformat()

    def _load_cache(self) -> None:
        if not self.cache_path.exists():
            return
        try:
            cached = json.loads(self.cache_path.read_text(encoding="utf-8"))
            self._validate_snapshot(cached)
        except (OSError, ValueError, json.JSONDecodeError, CalendarDataError):
            return
        cached["stale"] = True
        cached["cacheState"] = "cached"
        cached["errorType"] = "cache"
        cached["error"] = "Saved Google Calendar data is being displayed"
        self._snapshot = cached

    def _empty_snapshot(self, kind: str, message: str) -> dict[str, Any]:
        start_date = self._now_factory().astimezone(JST).date()
        fetch_start_date = start_date - timedelta(days=CALENDAR_LOOKBACK_DAYS)
        return {
            "schemaVersion": 2,
            "provider": "google",
            "fetchedAt": None,
            "lastSuccessAt": None,
            "stale": True,
            "cacheState": "empty",
            "errorType": kind,
            "error": message,
            "startDate": start_date.isoformat(),
            "endExclusive": (start_date + timedelta(days=CALENDAR_DISPLAY_DAYS)).isoformat(),
            "fetchStartDate": fetch_start_date.isoformat(),
            "fetchEndExclusive": (start_date + timedelta(days=CALENDAR_DISPLAY_DAYS)).isoformat(),
            "days": [
                {"date": (start_date + timedelta(days=offset)).isoformat(), "events": []}
                for offset in range(CALENDAR_DISPLAY_DAYS)
            ],
            "headacheHistory": build_headache_history({}, start_date),
        }
