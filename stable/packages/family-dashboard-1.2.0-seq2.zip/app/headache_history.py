from __future__ import annotations

from datetime import date, timedelta
from typing import Any, Mapping, Sequence


HEADACHE_KEYWORD = "片頭痛"
HEADACHE_DAY_OFFSETS = (
    (-5, "5日前"),
    (-4, "4日前"),
    (-3, "3日前"),
    (-1, "昨日"),
    (0, "本日"),
)


def summary_has_headache(summary: Any) -> bool:
    return isinstance(summary, str) and HEADACHE_KEYWORD in summary


def headache_day_specs(today: date) -> list[tuple[str, str]]:
    return [
        ((today + timedelta(days=offset)).isoformat(), label)
        for offset, label in HEADACHE_DAY_OFFSETS
    ]


def build_headache_history(
    events_by_date: Mapping[str, Sequence[Mapping[str, Any]]],
    today: date,
) -> list[dict[str, Any]]:
    history = []
    for date_key, label in headache_day_specs(today):
        occurred = any(
            summary_has_headache(event.get("summary"))
            for event in events_by_date.get(date_key, ())
            if isinstance(event, Mapping)
        )
        history.append({"date": date_key, "label": label, "occurred": occurred})
    return history
