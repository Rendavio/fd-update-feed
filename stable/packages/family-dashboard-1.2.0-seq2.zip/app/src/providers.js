import { classifyPerson } from './person-classifier.js';

const PUBLIC_DEMO_PERSON_RULES = Object.freeze([
  Object.freeze({
    id: 'person1',
    displayRole: 'person1',
    aliases: Object.freeze(['人物A']),
  }),
  Object.freeze({
    id: 'person2',
    displayRole: 'person2',
    aliases: Object.freeze(['人物B']),
  }),
]);

const OWNER_ROLES = new Set(['person1', 'person2', 'joint', 'neutral']);

export class WeatherProvider {
  async getWeather() {
    throw new Error('WeatherProvider.getWeather() must be implemented');
  }
}

export class LocalJmaWeatherProvider extends WeatherProvider {
  constructor(endpoint = '/api/weather') {
    super();
    this.endpoint = endpoint;
  }

  async getWeather() {
    const response = await fetch(this.endpoint, { cache: 'no-store' });
    if (!response.ok) throw new Error(`Weather request failed: ${response.status}`);
    const data = await response.json();
    if (!data || data.schemaVersion !== 1 || !Array.isArray(data.days) || data.days.length !== 7) {
      throw new Error('Weather response schema is invalid');
    }
    return data;
  }
}

export class CalendarProvider {
  constructor(calendarId) {
    this.calendarId = calendarId;
  }

  assertAllowedCalendarId(calendarId) {
    if (!calendarId || calendarId === 'primary' || calendarId !== this.calendarId) {
      throw new Error('CalendarProvider rejected an unconfigured calendar ID');
    }
  }

  async getEvents() {
    throw new Error('CalendarProvider.getEvents() must be implemented');
  }
}

const BASE_EVENTS = [
  [
    { time: '終日', summary: '家族の予定を確認', allDay: true },
    { time: '10:30', summary: '人物A 歯科' },
    { time: '18:30', summary: '人物A・人物B 夕食' },
  ],
  [
    { time: '09:00', summary: '人物B 美容院' },
    { time: '19:00', summary: '家族で買い物' },
  ],
  [],
  [
    { time: '終日', summary: '燃えるごみ', allDay: true },
    { time: '15:30', summary: '人物A：銀行の手続き' },
  ],
  [{ time: '18:00', summary: '人物B：買い物' }],
  [{ time: '11:00', summary: '人物A 打ち合わせ' }],
  [{ time: '終日', summary: '家族の日', allDay: true }],
];

function cloneEvents() {
  return BASE_EVENTS.map((events) => events.map((event) => ({ ...event })));
}

function eventsForScenario(scenario) {
  const result = cloneEvents();

  if (scenario === 'many') {
    result[0] = [
      { time: '終日', summary: '資源ごみの日', allDay: true },
      { time: '08:30', summary: '人物A 定期検査' },
      { time: '10:00', summary: '人物B 美容院' },
      { time: '12:30', summary: '家族で昼食' },
      { time: '15:00', summary: '人物A・人物B 買い出し' },
      { time: '17:30', summary: '荷物の受け取り' },
      { time: '19:00', summary: 'オンライン打ち合わせ' },
      { time: '20:30', summary: '明日の準備' },
    ];
    result[1] = [
      { time: '終日', summary: '振替休日', allDay: true },
      { time: '09:00', summary: '人物A 通院' },
      { time: '11:30', summary: '人物B 買い物' },
      { time: '14:00', summary: '家族の用事' },
      { time: '18:00', summary: '夕食' },
    ];
  }

  if (scenario === 'long') {
    result[0][1].summary = '人物A 区役所で住所変更に必要な書類を受け取る';
    result[1][0].summary = '人物B 美容院のあと駅前で日用品と夕食の買い物';
    result[3][1].summary = '人物A：銀行窓口で各種手続きと口座の確認をする';
  }

  if (scenario === 'joint') {
    result[0] = [
      { time: '終日', summary: '人物A・人物B 記念日', allDay: true },
      { time: '11:30', summary: '人物A・人物B ランチ' },
      { time: '16:00', summary: '家族で家具を見に行く' },
      { time: '19:00', summary: '人物A・人物B 映画' },
    ];
    result[4] = [{ time: '18:30', summary: '人物A・人物B 夕食' }];
  }

  return result;
}

function addDays(isoDate, offset) {
  const date = new Date(`${isoDate}T00:00:00Z`);
  date.setUTCDate(date.getUTCDate() + offset);
  return date.toISOString().slice(0, 10);
}

export class MockCalendarProvider extends CalendarProvider {
  async getEvents({ calendarId, startDate, days = 7, scenario = 'normal' }) {
    this.assertAllowedCalendarId(calendarId);
    const scenarioEvents = eventsForScenario(scenario);
    return {
      calendarId,
      headacheHistory: [
        [-5, '5日前'],
        [-4, '4日前'],
        [-3, '3日前'],
        [-1, '昨日'],
        [0, '本日'],
      ].map(([offset, label]) => ({ date: addDays(startDate, offset), label, occurred: false })),
      days: Array.from({ length: days }, (_, index) => ({
        date: addDays(startDate, index),
        events: (scenarioEvents[index] ?? []).map((event, eventIndex) => ({
          id: `mock-${index}-${eventIndex}`,
          summary: event.summary,
          time: event.time,
          allDay: Boolean(event.allDay),
          owner: classifyPerson(event.summary, PUBLIC_DEMO_PERSON_RULES),
        })),
      })),
    };
  }
}

export class GoogleCalendarProvider extends CalendarProvider {
  constructor(endpoint = '/api/calendar', fetchImpl = globalThis.fetch.bind(globalThis)) {
    super(null);
    this.endpoint = endpoint;
    this.fetchImpl = fetchImpl;
  }

  async getEvents() {
    const response = await this.fetchImpl(this.endpoint, { cache: 'no-store' });
    const data = await response.json();
    if (!response.ok) {
      const error = new Error(data?.error || `Google Calendar request failed: ${response.status}`);
      error.kind = data?.errorType || 'unknown';
      throw error;
    }
    if (
      !data
      || data.schemaVersion !== 2
      || data.provider !== 'google'
      || !Array.isArray(data.days)
      || data.days.length !== 7
      || !Array.isArray(data.headacheHistory)
      || data.headacheHistory.length !== 5
    ) {
      throw new Error('Google Calendar response schema is invalid');
    }
    return {
      calendarId: null,
      stale: Boolean(data.stale),
      cacheState: data.cacheState,
      lastSuccessAt: data.lastSuccessAt,
      errorType: data.errorType,
      headacheHistory: data.headacheHistory.map((item) => ({
        date: item.date,
        label: item.label,
        occurred: Boolean(item.occurred),
      })),
      days: data.days.map((day) => ({
        date: day.date,
        events: day.events.map((event) => ({
          id: event.id,
          summary: event.summary,
          start: event.start,
          end: event.end,
          time: event.time,
          allDay: Boolean(event.allDay),
          owner: OWNER_ROLES.has(event.owner) ? event.owner : 'neutral',
        })),
      })),
    };
  }
}

export class EarthquakeProvider {
  subscribe() {
    throw new Error('EarthquakeProvider.subscribe() must be implemented');
  }
}

export class MockEarthquakeProvider extends EarthquakeProvider {
  constructor() {
    super();
    this.listeners = new Set();
  }

  subscribe(listener) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  triggerTokyo23() {
    const event = {
      type: 'warning',
      region: '東京都23区',
      headline: '緊急地震速報',
      instruction: '強い揺れに警戒してください',
      issuedAt: new Date().toISOString(),
      mock: true,
    };
    this.listeners.forEach((listener) => listener(event));
  }

  clear() {
    this.listeners.forEach((listener) => listener(null));
  }
}

export class BatteryProvider {
  async getBattery() {
    throw new Error('BatteryProvider.getBattery() must be implemented');
  }
}

export class MockBatteryProvider extends BatteryProvider {
  async getBattery() {
    return { level: 62, acConnected: true, charging: false, mock: true };
  }
}

export class PowerPlugProvider {
  async getState() {
    throw new Error('PowerPlugProvider.getState() must be implemented');
  }
}

export class MockPowerPlugProvider extends PowerPlugProvider {
  constructor() {
    super();
    this.power = 'off';
  }

  async getState() {
    return { power: this.power, mock: true };
  }

  async setPower(power) {
    if (!['on', 'off'].includes(power)) throw new Error('Unsupported mock power state');
    this.power = power;
    return this.getState();
  }
}

export const MOCK_CALENDAR_ID = 'mock-family-calendar';

export function createProviders() {
  const mockCalendar = new MockCalendarProvider(MOCK_CALENDAR_ID);
  const googleCalendar = new GoogleCalendarProvider();
  return {
    weather: new LocalJmaWeatherProvider(),
    calendar: mockCalendar,
    calendars: {
      mock: mockCalendar,
      google: googleCalendar,
    },
    earthquake: new MockEarthquakeProvider(),
    battery: new MockBatteryProvider(),
    powerPlug: new MockPowerPlugProvider(),
  };
}
