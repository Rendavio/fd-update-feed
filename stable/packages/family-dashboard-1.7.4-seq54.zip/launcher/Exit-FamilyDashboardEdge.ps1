#requires -Version 5.1
param([switch]$PreserveReceiver)
Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"
if ($PreserveReceiver) {
    # This branch must never fall through to termination, even on failure.
    . (Join-Path $PSScriptRoot "FamilyDashboard.Common.ps1")
    $owned = @(Get-FamilyDashboardOwnedEdge)
    if ($owned.Count -ne 1) { throw "Exactly one owned dashboard browser is required to preserve reception." }
    Minimize-FamilyDashboardOwnedEdge -Candidate $owned[0]
    return
}
$productionUrl = "http://127.0.0.1:3000/?display=1&theme=auto&calendar=google&eew=production"
Start-Sleep -Milliseconds 500
$matches = @(Get-CimInstance Win32_Process -Filter "Name='msedge.exe'" | Where-Object {
    $_.CommandLine -and
    $_.CommandLine.Contains($productionUrl) -and
    $_.CommandLine -match '(?i)(?:^|\s)--kiosk(?:\s|=)'
})
foreach ($candidate in $matches) {
    $owner = Invoke-CimMethod -InputObject $candidate -MethodName GetOwner
    if ($owner.ReturnValue -eq 0 -and $owner.User -ieq "DashboardAdmin") {
        Stop-Process -Id $candidate.ProcessId -ErrorAction Stop
    }
}
