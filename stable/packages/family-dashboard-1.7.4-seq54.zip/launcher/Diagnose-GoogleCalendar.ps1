. (Join-Path $PSScriptRoot "FamilyDashboard.Common.ps1")

if ([Environment]::UserName -ine "DashboardAdmin") {
    throw "Google Calendar diagnostics must be run while signed in as DashboardAdmin."
}
$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
if ($principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw "Google Calendar diagnostics must not be run from an elevated process."
}
if (-not $env:LOCALAPPDATA) {
    throw "LOCALAPPDATA is unavailable for the DashboardAdmin user."
}

$diagnosticPath = Join-Path $script:AppRoot "google_calendar_diagnostics.py"
if (-not (Test-Path -LiteralPath $script:PythonPath -PathType Leaf)) {
    throw "Bundled Python runtime is missing."
}
if (-not (Test-Path -LiteralPath $diagnosticPath -PathType Leaf)) {
    throw "Google Calendar diagnostic module is missing."
}

$dataRoot = Join-Path $env:LOCALAPPDATA "FamilyDashboard"
$previousMode = $env:FAMILY_DASHBOARD_MODE
$previousHome = $env:FAMILY_DASHBOARD_HOME
$previousUtf8 = $env:PYTHONUTF8
$previousNoBytecode = $env:PYTHONDONTWRITEBYTECODE
try {
    $env:FAMILY_DASHBOARD_MODE = "production"
    $env:FAMILY_DASHBOARD_HOME = $dataRoot
    $env:PYTHONUTF8 = "1"
    $env:PYTHONDONTWRITEBYTECODE = "1"
    & $script:PythonPath -B $diagnosticPath
    $diagnosticExitCode = $LASTEXITCODE
} finally {
    $env:FAMILY_DASHBOARD_MODE = $previousMode
    $env:FAMILY_DASHBOARD_HOME = $previousHome
    $env:PYTHONUTF8 = $previousUtf8
    $env:PYTHONDONTWRITEBYTECODE = $previousNoBytecode
}

$reportPath = Join-Path $dataRoot "GoogleCalendar-Diagnostic-Report.txt"
Write-Host "Sanitized report: $reportPath"
if ($diagnosticExitCode -ne 0) {
    throw "Google Calendar diagnostics completed with one or more failures. Review the sanitized report."
}
Write-Host "Google Calendar diagnostics PASS"
