#requires -Version 5.1
[CmdletBinding()]
param([switch]$Full,[ValidateSet('STARTUP_ITEMS','TASKS','SERVICES','FIREWALL_PROFILE','FIREWALL_RULE','FIREWALL_APP_FILTER','FIREWALL_PORT_FILTER','FIREWALL_ADDRESS_FILTER','LOCAL_SECURITY')][string]$Part)

# The Python source owns the 20-second whole-child timeout. Dot sourcing only
# defines functions. All records below are private evidence, never public UI data.
function Write-BehaviorStage([string]$Stage,$Context) {
    # Only fixed protocol identifiers, never query values or exception text.
    if($Stage -cin @('STARTUP','OS','PROCESS_PRE','TCP','PROCESS_POST','ROUTES','RUN','RUNONCE','STARTUP_FOLDER','TASKS_QUERY','TASKS_METADATA','SERVICES_QUERY','SERVICES_METADATA','FIREWALL_PROFILE_QUERY','FIREWALL_PROFILE_METADATA','FIREWALL_RULE_QUERY','FIREWALL_RULE_METADATA','FIREWALL_APP_FILTER_QUERY','FIREWALL_APP_FILTER_METADATA','FIREWALL_PORT_FILTER_QUERY','FIREWALL_PORT_FILTER_METADATA','FIREWALL_ADDRESS_FILTER_QUERY','FIREWALL_ADDRESS_FILTER_METADATA','LOCAL_USER_QUERY','LOCAL_USER_METADATA','ADMIN_MEMBER_QUERY','ADMIN_MEMBER_METADATA','RDP','SMB_CONFIG','SMB_SHARES','SERIALIZE','COMPLETE')){
        [Console]::Error.WriteLine('BEHAVIOR_STAGE:'+$Stage)
        [Console]::Error.WriteLine('BEHAVIOR_METRIC:'+$Stage+':START')
        # Windows Python and .NET share QPC. The parent publishes only a bounded
        # duration, including for a stage interrupted before its END marker.
        $started=[long]([Diagnostics.Stopwatch]::GetTimestamp()*1000.0/[Diagnostics.Stopwatch]::Frequency)
        [Console]::Error.WriteLine(('BEHAVIOR_CLOCK:{0}:{1}' -f $Stage,$started))
        [Console]::Error.Flush()
        if($null -eq $Context.metrics){$Context.metrics=@{}}
        $Context.metrics.stage=$Stage
        $Context.metrics.result='OK'
        $Context.metrics.watch=[Diagnostics.Stopwatch]::StartNew()
    }
}
function Complete-BehaviorStage($Context,[int]$Count) {
    $metrics=$Context.metrics
    if(-not $metrics.stage){return}
    $metrics.watch.Stop()
    $result=$metrics.result
    if($result -eq 'OK' -and $Count -eq 0){$result='EMPTY'}
    $elapsed=[math]::Min(99999999L,$metrics.watch.ElapsedMilliseconds)
    [Console]::Error.WriteLine(('BEHAVIOR_METRIC:{0}:END:{1}:{2}:{3}' -f $metrics.stage,$elapsed,$Count,$result))
    [Console]::Error.Flush()
    $metrics.stage=$null
}
function Get-BehaviorProperty($Item,[string]$Name) {
    if($null -eq $Item){return $null}
    $p=$Item.PSObject.Properties[$Name]
    if($null -ne $p){return $p.Value}
    return $null
}
function Add-BehaviorLimitation($Context,[string]$Code) {
    if($Context.metrics.stage){
        # Attribute outcomes to this operation even when an earlier query has
        # already made the section PARTIAL. Never emit an exception or a row.
        $metrics=$Context.metrics
        switch($Code){
            'SOURCE_ACCESS_DENIED' {$metrics.result='DENIED'}
            'SOURCE_UNAVAILABLE' {if($metrics.result -ne 'DENIED'){$metrics.result='UNAVAILABLE'}}
            'TRUNCATED' {if($metrics.result -in @('OK','PARTIAL')){$metrics.result='CAPPED'}}
            'SOURCE_PARTIAL' {if($metrics.result -eq 'OK'){$metrics.result='PARTIAL'}}
        }
    }
    if(-not $Context.limitations.Contains($Code)){$Context.limitations.Add($Code)}
}
function Set-BehaviorSourcePartial($Context,[string]$Section) {
    $Context.coverage[$Section]='PARTIAL'
    Add-BehaviorLimitation $Context 'SOURCE_PARTIAL'
}
function Convert-BehaviorText($Value,$Context) {
    if($null -eq $Value){return $null}
    $s=[string]$Value
    if($s.Length -gt 1024){Add-BehaviorLimitation $Context 'TRUNCATED';return $s.Substring(0,1024)}
    return $s
}
function Get-BehaviorNow {return [datetimeoffset]::UtcNow}
function Convert-BehaviorUtc($Value) {
    if($null -eq $Value){return $null}
    try{return ([datetimeoffset]$Value).ToUniversalTime().ToString('o')}catch{return $null}
}
function Get-BehaviorDigest($Value) {
    $json=ConvertTo-Json -InputObject $Value -Depth 8 -Compress
    $hash=[Security.Cryptography.SHA256]::Create()
    try{return ([BitConverter]::ToString($hash.ComputeHash([Text.Encoding]::UTF8.GetBytes($json)))).Replace('-','').ToLowerInvariant()}
    finally{$hash.Dispose()}
}
function Get-BehaviorDirectTarget($Command) {
    if($null -eq $Command){return $null}
    $text=([string]$Command).Trim()
    if($text.Length -gt 8192){return $null}
    $candidate=$null
    if($text -match '^"([A-Za-z]:\\[^"\r\n]+\.(?:exe|com))"(?:\s|$)'){$candidate=$matches[1]}
    elseif($text -match '^([A-Za-z]:\\[^\s"\r\n]+\.(?:exe|com))(?:\s|$)'){$candidate=$matches[1]}
    if(-not $candidate -or $candidate.Length -gt 1024){return $null}
    # Do not expand variables, resolve links, touch files, or accept ADS/relative components.
    if($candidate -match '[%*?<>|]' -or $candidate.Substring(2).Contains(':') -or $candidate -match '\\(?:\.|\.\.)(?:\\|$)'){return $null}
    return $candidate
}
function Invoke-BehaviorQuery($Context,[string]$Section,[scriptblock]$Query,[int]$Limit) {
    if($Limit -le 0){$Context.coverage[$Section]='PARTIAL';Add-BehaviorLimitation $Context 'TRUNCATED';return @()}
    try {
        $rows=@(& $Query | Select-Object -First ($Limit+1))
        if($rows.Count -gt $Limit){$Context.coverage[$Section]='PARTIAL';Add-BehaviorLimitation $Context 'TRUNCATED'}
        return @($rows | Select-Object -First $Limit)
    } catch {
        $Context.coverage[$Section]='PARTIAL'
        $Context.queryFailures++
        Add-BehaviorLimitation $Context 'SOURCE_PARTIAL'
        if($_.Exception -is [UnauthorizedAccessException] -or $_.CategoryInfo.Category -eq 'PermissionDenied'){Add-BehaviorLimitation $Context 'SOURCE_ACCESS_DENIED'}
        else{Add-BehaviorLimitation $Context 'SOURCE_UNAVAILABLE'}
        return @()
    }
}
function Get-BehaviorFixedMetadata($Item,[string[]]$Names,$Context,[string]$Section='security') {
    $data=[ordered]@{}
    foreach($name in $Names){
        $value=Get-BehaviorProperty $Item $name
        if($null -eq $value -or $value -is [bool]){$data[$name]=$value}
        elseif($value -is [datetime] -or $value -is [datetimeoffset]){$data[$name]=Convert-BehaviorUtc $value}
        else {
            # Avoid creating two pipelines per metadata property. The 65th item
            # remains a sentinel and retains the original truncation side effects.
            $items=[Collections.Generic.List[string]]::new()
            foreach($element in $value){
                if($null -eq $element){continue} # The former pipeline omitted null records.
                if($items.Count -ge 65){break}
                $text=[string]$element
                if($text.Length -gt 65536){$text=$text.Substring(0,65536);Add-BehaviorLimitation $Context 'TRUNCATED';$Context.coverage[$Section]='PARTIAL'}
                $items.Add($text)
            }
            if($items.Count -gt 64){$items.RemoveAt(64);Add-BehaviorLimitation $Context 'TRUNCATED';$Context.coverage[$Section]='PARTIAL'}
            $data[$name]=@($items.ToArray())
        }
    }
    return $data
}
function Convert-BehaviorProcesses($Rows,$Context) {
    foreach($row in $Rows){
        $image=Convert-BehaviorText (Get-BehaviorProperty $row 'ExecutablePath') $Context
        if(-not $image -or $image -notmatch '^[A-Za-z]:\\' -or $image.Substring(2).Contains(':')){$image=$null}
        [ordered]@{pid=[long]$row.ProcessId;parentPid=[long]$row.ParentProcessId;start=(Convert-BehaviorUtc $row.CreationDate);
            path=$image;name=(Convert-BehaviorText $row.Name $Context);identityVerified=$false;sha256='UNKNOWN';trust='UNKNOWN';inspectedAt=$null;pathClass='UNKNOWN'}
    }
}
function Test-BehaviorInstance($Before,$After) {
    return $null -ne $Before -and $null -ne $After -and $null -ne $Before.start -and $null -ne $Before.path -and
        $Before.pid -eq $After.pid -and $Before.start -ceq $After.start -and [string]::Equals($Before.path,$After.path,[StringComparison]::OrdinalIgnoreCase)
}
function Add-BehaviorPersistence($Context,[string]$Kind,[string]$Key,$Metadata,$Target,$Enabled) {
    if($Context.persistence.Count -ge 512){$Context.coverage.persistence='PARTIAL';Add-BehaviorLimitation $Context 'TRUNCATED';return}
    if($null -eq $Target){Add-BehaviorLimitation $Context 'OPAQUE_PERSISTENCE_TARGET'}
    $Context.persistence.Add([ordered]@{kind=$Kind;key=(Convert-BehaviorText $Key $Context);digest=(Get-BehaviorDigest $Metadata);target=$Target;enabled=$Enabled})
}
function Add-BehaviorSecurity($Context,[string]$Kind,[string]$Key,$Metadata,$Value) {
    if($Context.security.Count -ge 2048){$Context.coverage.security='PARTIAL';Add-BehaviorLimitation $Context 'TRUNCATED';return}
    $Context.security.Add([ordered]@{kind=$Kind;key=(Convert-BehaviorText $Key $Context);digest=(Get-BehaviorDigest $Metadata);value=$Value})
}
function Test-BehaviorFixedDrive([string]$Path) {
    if($Path -notmatch '^[A-Za-z]:\\'){return $false}
    # GetDriveType via DriveInfo reads the local drive mapping; it does not open
    # files or contact a remote share. Never enumerate mapped/removable roots.
    try{return ([IO.DriveInfo]::new($Path.Substring(0,3))).DriveType -eq [IO.DriveType]::Fixed}catch{return $false}
}
function Test-BehaviorPlainLocalFolder($Context,[string]$Path) {
    if(-not (Test-BehaviorFixedDrive $Path)){return $false}
    if($Path.Length -gt 1024 -or $Path -notmatch '^[A-Za-z]:\\' -or $Path.Substring(2).Contains(':') -or $Path -match '\\(?:\.|\.\.)(?:\\|$)'){return $false}
    $parts=@($Path.Substring(3).Split('\') | Where-Object {$_})
    if($parts.Count -gt 32){return $false}
    $cursor=$Path.Substring(0,3)
    foreach($part in @('')+$parts){
        if($part){$cursor=Join-Path $cursor $part}
        $folder=@(Invoke-BehaviorQuery $Context 'persistence' {Get-Item -LiteralPath $cursor -ErrorAction Stop} 1)
        if($folder.Count -ne 1 -or ($folder[0].Attributes -band [IO.FileAttributes]::Directory) -eq 0 -or ($folder[0].Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0){return $false}
    }
    return $true
}
function Get-BehaviorPersistence($Context,[string]$Part) {
    if(-not $Part -or $Part -eq 'STARTUP_ITEMS'){
        foreach($entry in @(@('RUN','HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'),@('RUNONCE','HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce'))){
            $kind=$entry[0];$registryPath=$entry[1]
            Write-BehaviorStage $kind $Context
            if($Context.persistence.Count -ge 512){
                $Context.coverage.persistence='PARTIAL'
                Add-BehaviorLimitation $Context 'TRUNCATED'
                Complete-BehaviorStage $Context 0
                continue
            }
            $initialCount=$Context.persistence.Count
            $keys=@(Invoke-BehaviorQuery $Context 'persistence' {
                try{Get-Item -LiteralPath $registryPath -ErrorAction Stop}
                catch{
                    # Check the original ErrorRecord. A typed catch in Windows
                    # PowerShell drops the cmdlet suffix from its ID.
                    if($_.Exception -isnot [System.Management.Automation.ItemNotFoundException] -or
                       $_.CategoryInfo.Category -ne 'ObjectNotFound' -or
                       $_.FullyQualifiedErrorId -cne 'PathNotFound,Microsoft.PowerShell.Commands.GetItemCommand'){throw}
                }
            } 1)
            foreach($key in $keys){
                $remaining=512-$Context.persistence.Count; $names=@($key.Property | Select-Object -First ($remaining+1))
                if($names.Count -gt $remaining){$Context.coverage.persistence='PARTIAL';Add-BehaviorLimitation $Context 'TRUNCATED'}
                foreach($name in @($names | Select-Object -First $remaining)){
                    $values=@(Invoke-BehaviorQuery $Context 'persistence' {Get-ItemPropertyValue -LiteralPath $registryPath -Name $name -ErrorAction Stop} 1)
                    if($values.Count -eq 0){continue}
                    $command=[string]$values[0]
                    if($command.Length -gt 65536){$Context.coverage.persistence='PARTIAL';Add-BehaviorLimitation $Context 'TRUNCATED';continue}
                    Add-BehaviorPersistence $Context $kind $name $command (Get-BehaviorDirectTarget $command) $null
                }
            }
            Complete-BehaviorStage $Context ($Context.persistence.Count-$initialCount)
        }
        $initialCount=$Context.persistence.Count
        Write-BehaviorStage 'STARTUP_FOLDER' $Context
        $startup=Join-Path ([string]$env:APPDATA) 'Microsoft\Windows\Start Menu\Programs\Startup'
        if(Test-BehaviorPlainLocalFolder $Context $startup){
            $folders=@(Invoke-BehaviorQuery $Context 'persistence' {Get-Item -LiteralPath $startup -ErrorAction Stop} 1)
            foreach($folder in $folders){
                if(($folder.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0){$Context.coverage.persistence='PARTIAL';Add-BehaviorLimitation $Context 'SOURCE_PARTIAL';continue}
                $files=@(Invoke-BehaviorQuery $Context 'persistence' {Get-ChildItem -LiteralPath $startup -File -Force -ErrorAction Stop} (512-$Context.persistence.Count))
                foreach($file in $files){
                    if(($file.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0){$Context.coverage.persistence='PARTIAL';Add-BehaviorLimitation $Context 'SOURCE_PARTIAL';continue}
                    $meta=Get-BehaviorFixedMetadata $file @('Name','Length','LastWriteTimeUtc','Attributes') $Context 'persistence'
                    Add-BehaviorPersistence $Context 'STARTUP' $file.Name $meta (Get-BehaviorDirectTarget ('"'+$file.FullName+'"')) $true
                }
            }
        }else{$Context.coverage.persistence='PARTIAL';Add-BehaviorLimitation $Context 'SOURCE_UNAVAILABLE'}
        Complete-BehaviorStage $Context ($Context.persistence.Count-$initialCount)
    }
    if(-not $Part -or $Part -eq 'TASKS'){
        Write-BehaviorStage 'TASKS_QUERY' $Context
        $tasks=@(Invoke-BehaviorQuery $Context 'persistence' {Get-ScheduledTask -ErrorAction Stop} (512-$Context.persistence.Count))
        $queryResult=$Context.metrics.result
        Complete-BehaviorStage $Context $tasks.Count
        Write-BehaviorStage 'TASKS_METADATA' $Context
        if($tasks.Count -eq 0){$Context.metrics.result=$queryResult}
        $initialCount=$Context.persistence.Count
        foreach($task in $tasks){
            if([string]::IsNullOrWhiteSpace($task.TaskName) -or [string]::IsNullOrWhiteSpace($task.TaskPath)){
                Set-BehaviorSourcePartial $Context 'persistence'
                continue
            }
            if($null -eq $task.PSObject.Properties['Actions']){
                Set-BehaviorSourcePartial $Context 'persistence'
            }
            $actions=@($task.Actions | Select-Object -First 9)
            if($actions.Count -gt 8){$Context.coverage.persistence='PARTIAL';Add-BehaviorLimitation $Context 'TRUNCATED'}
            $knownActions=$true
            $metadata=@($actions | Select-Object -First 8 | ForEach-Object {
                $class=[string]$_.CimClass.CimClassName
                $hasExecute=-not [string]::IsNullOrWhiteSpace($_.Execute)
                $hasClassId=-not [string]::IsNullOrWhiteSpace($_.ClassId)
                # The fixed fields cover executable and COM-handler payloads.
                # Other action types can carry opaque configuration.
                if((-not $hasExecute -and -not $hasClassId) -or
                   ($class -and $class -notin @('MSFT_TaskExecAction','MSFT_TaskComHandlerAction'))){
                    $knownActions=$false
                    Set-BehaviorSourcePartial $Context 'persistence'
                }
                Get-BehaviorFixedMetadata $_ @('Execute','Arguments','WorkingDirectory','ClassId','Data') $Context 'persistence'
            })
            $target=$null
            if($knownActions -and $actions.Count -eq 1){$execute=[string]$actions[0].Execute;if($execute -match '^[A-Za-z]:\\'){$candidate=Get-BehaviorDirectTarget ('"'+$execute+'"');if($candidate -ceq $execute){$target=$candidate}}}
            $enabled=if([string]$task.State -eq 'Disabled'){$false}elseif([string]$task.State -in @('Ready','Running','Queued')){$true}else{$null}
            $triggers=@($task.Triggers | Select-Object -First 9)
            if($triggers.Count -gt 8){$Context.coverage.persistence='PARTIAL';Add-BehaviorLimitation $Context 'TRUNCATED'}
            $triggerMetadata=@($triggers | Select-Object -First 8 | ForEach-Object {
                $t=Get-BehaviorFixedMetadata $_ @('StartBoundary','EndBoundary','Enabled','ExecutionTimeLimit','DaysInterval','WeeksInterval','DaysOfWeek','RandomDelay','Delay','Subscription') $Context 'persistence'
                $t['repetition']=Get-BehaviorFixedMetadata $_.Repetition @('Interval','Duration','StopAtDurationEnd') $Context 'persistence'
                $t
            })
            Add-BehaviorPersistence $Context 'TASK' ($task.TaskPath+$task.TaskName) ([ordered]@{actions=$metadata;triggers=$triggerMetadata;enabled=$enabled}) $target $enabled
        }
        Complete-BehaviorStage $Context ($Context.persistence.Count-$initialCount)
    }
    if(-not $Part -or $Part -eq 'SERVICES'){
        Write-BehaviorStage 'SERVICES_QUERY' $Context
        $services=@(Invoke-BehaviorQuery $Context 'persistence' {Get-CimInstance -ClassName Win32_Service -Property Name,PathName,StartMode -ErrorAction Stop} (512-$Context.persistence.Count))
        $queryResult=$Context.metrics.result
        Complete-BehaviorStage $Context $services.Count
        Write-BehaviorStage 'SERVICES_METADATA' $Context
        if($services.Count -eq 0){$Context.metrics.result=$queryResult}
        $initialCount=$Context.persistence.Count
        foreach($service in $services){
            $name=[string]$service.Name
            if([string]::IsNullOrWhiteSpace($name)){
                $Context.coverage.persistence='PARTIAL'
                Add-BehaviorLimitation $Context 'SOURCE_PARTIAL'
                continue
            }
            if($name.Length -gt 1024 -or [string]::IsNullOrWhiteSpace($service.PathName) -or [string]::IsNullOrWhiteSpace($service.StartMode)){
                $Context.coverage.persistence='PARTIAL'
                Add-BehaviorLimitation $Context 'SOURCE_PARTIAL'
            }
            $metadata=Get-BehaviorFixedMetadata $service @('PathName','StartMode') $Context 'persistence'
            $enabled=if($service.StartMode -eq 'Disabled'){$false}elseif($service.StartMode -in @('Auto','Manual')){$true}else{$null}
            Add-BehaviorPersistence $Context 'SERVICE' $name $metadata (Get-BehaviorDirectTarget $service.PathName) $enabled
        }
        Complete-BehaviorStage $Context ($Context.persistence.Count-$initialCount)
    }
}
function Convert-BehaviorProfileEnabled($Value) {
    if($Value -is [bool]){return $Value}
    if($null -eq $Value){return $null}
    $type=$Value.GetType()
    $knownEnum=$type.IsEnum -and $type.FullName -ceq 'Microsoft.PowerShell.Cmdletization.GeneratedTypes.NetSecurity.GpoBoolean' -and [Enum]::GetUnderlyingType($type) -eq [uint16]
    if($Value -is [uint16] -or $knownEnum){
        # Local NetFirewallProfile CDXML declares False=0, True=1,
        # NotConfigured=2, underlying uint16. Unknown is never false.
        $code=[uint16]$Value
        if($code -eq 0){return $false}
        if($code -eq 1){return $true}
    }
    return $null
}
function Get-BehaviorSecurityConfig($Context,[string]$Part) {
    Add-BehaviorLimitation $Context 'ACTOR_UNKNOWN'
    $definitions=@(
        @('FIREWALL_PROFILE','Name',@('Enabled','DefaultInboundAction','DefaultOutboundAction','AllowInboundRules','AllowLocalFirewallRules','AllowLocalIPsecRules','NotifyOnListen'),{Get-NetFirewallProfile -ErrorAction Stop}),
        @('FIREWALL_RULE','Name',@('Enabled','Direction','Action','Profile','PolicyStoreSourceType','EdgeTraversalPolicy','LooseSourceMapping','LocalOnlyMapping','Owner','PrimaryStatus'),{Get-NetFirewallRule -ErrorAction Stop}),
        @('FIREWALL_APP_FILTER','InstanceID',@('Program','Package'),{Get-NetFirewallApplicationFilter -ErrorAction Stop}),
        @('FIREWALL_PORT_FILTER','InstanceID',@('Protocol','LocalPort','RemotePort','IcmpType','DynamicTarget'),{Get-NetFirewallPortFilter -ErrorAction Stop}),
        @('FIREWALL_ADDRESS_FILTER','InstanceID',@('LocalAddress','RemoteAddress'),{Get-NetFirewallAddressFilter -ErrorAction Stop}),
        @('LOCAL_USER','SID',@('Enabled','PasswordRequired','PasswordExpires','UserMayChangePassword','AccountExpires'),{Get-LocalUser -ErrorAction Stop}),
        @('ADMIN_MEMBER','SID',@('ObjectClass','PrincipalSource'),{Get-LocalGroupMember -SID 'S-1-5-32-544' -ErrorAction Stop}))
    foreach($definition in $definitions){
        if($Part -and $definition[0] -ne $Part -and
           -not ($Part -eq 'LOCAL_SECURITY' -and $definition[0] -in @('LOCAL_USER','ADMIN_MEMBER'))){continue}
        Write-BehaviorStage ($definition[0]+'_QUERY') $Context
        $rows=@(Invoke-BehaviorQuery $Context 'security' $definition[3] (2048-$Context.security.Count))
        $queryResult=$Context.metrics.result
        Complete-BehaviorStage $Context $rows.Count
        Write-BehaviorStage ($definition[0]+'_METADATA') $Context
        if($rows.Count -eq 0){$Context.metrics.result=$queryResult}
        $initialCount=$Context.security.Count
        foreach($row in $rows){
            $key=[string](Get-BehaviorProperty $row $definition[1])
            if(-not $key){$Context.coverage.security='PARTIAL';Add-BehaviorLimitation $Context 'SOURCE_PARTIAL';continue}
            $metadata=Get-BehaviorFixedMetadata $row $definition[2] $Context
            $value=$null
            if($definition[0] -eq 'FIREWALL_PROFILE'){
                $value=Convert-BehaviorProfileEnabled (Get-BehaviorProperty $row 'Enabled')
                if($null -eq $value){$Context.coverage.security='PARTIAL';Add-BehaviorLimitation $Context 'SOURCE_PARTIAL'}
            }elseif($definition[0] -eq 'LOCAL_USER'){
                $enabled=Get-BehaviorProperty $row 'Enabled'
                if($enabled -is [bool]){$value=$enabled}
                else{$Context.coverage.security='PARTIAL';Add-BehaviorLimitation $Context 'SOURCE_PARTIAL'}
            }
            Add-BehaviorSecurity $Context $definition[0] $key $metadata $value
        }
        Complete-BehaviorStage $Context ($Context.security.Count-$initialCount)
    }
    if($Part -and $Part -ne 'LOCAL_SECURITY'){return}
    Write-BehaviorStage 'RDP' $Context
    $rdp=@(Invoke-BehaviorQuery $Context 'security' {Get-ItemPropertyValue -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server' -Name fDenyTSConnections -ErrorAction Stop} 1)
    if($rdp.Count -eq 1 -and ($rdp[0] -is [int] -or $rdp[0] -is [uint32]) -and $rdp[0] -in @(0,1)){
        Add-BehaviorSecurity $Context 'RDP' 'fDenyTSConnections' ([int]$rdp[0]) ([int]$rdp[0])
    }else{Set-BehaviorSourcePartial $Context 'security'}
    Complete-BehaviorStage $Context $rdp.Count
    Write-BehaviorStage 'SMB_CONFIG' $Context
    $smb=@(Invoke-BehaviorQuery $Context 'security' {Get-SmbServerConfiguration -ErrorAction Stop} 1)
    if($smb.Count -ne 1){Set-BehaviorSourcePartial $Context 'security'}
    foreach($config in $smb){
        $fields=@('EnableSMB1Protocol','EnableSMB2Protocol','RequireSecuritySignature','EnableSecuritySignature','EncryptData')
        foreach($field in $fields){
            if($config.$field -isnot [bool]){Set-BehaviorSourcePartial $Context 'security';break}
        }
        Add-BehaviorSecurity $Context 'SMB' 'ServerConfiguration' (Get-BehaviorFixedMetadata $config $fields $Context) $null
    }
    Complete-BehaviorStage $Context $smb.Count
    Write-BehaviorStage 'SMB_SHARES' $Context
    $shares=@(Invoke-BehaviorQuery $Context 'security' {Get-SmbShare -ErrorAction Stop} 512)
    if($Context.metrics.result -eq 'OK'){Add-BehaviorSecurity $Context 'SMB' 'ShareCount' $shares.Count $shares.Count}
    Complete-BehaviorStage $Context $shares.Count
}
function Get-BehaviorSecuritySnapshot {
    param([switch]$Full,[ValidateSet('STARTUP_ITEMS','TASKS','SERVICES','FIREWALL_PROFILE','FIREWALL_RULE','FIREWALL_APP_FILTER','FIREWALL_PORT_FILTER','FIREWALL_ADDRESS_FILTER','LOCAL_SECURITY')][string]$Part,[hashtable]$Metrics=@{})
    if($Part -and -not $Full){throw 'Part requires Full'}
    $context=@{metrics=$Metrics;queryFailures=0;coverage=[ordered]@{processes='OK';network='OK';persistence='NOT_COLLECTED';security='NOT_COLLECTED';integrity='NOT_COLLECTED'};
        limitations=(New-Object 'Collections.Generic.List[string]');persistence=(New-Object 'Collections.Generic.List[object]');security=(New-Object 'Collections.Generic.List[object]')}
    Add-BehaviorLimitation $context 'SHORT_AND_UDP_TRAFFIC_MAY_BE_MISSED'
    $os=[ordered]@{version='UNKNOWN';build='UNKNOWN';bootAt=$null}
    Write-BehaviorStage 'OS' $Context
    $osRows=@(Invoke-BehaviorQuery $context 'processes' {Get-CimInstance -ClassName Win32_OperatingSystem -Property Version,BuildNumber,LastBootUpTime -ErrorAction Stop} 1)
    if($osRows.Count -eq 1){$os.version=Convert-BehaviorText $osRows[0].Version $context;$os.build=Convert-BehaviorText $osRows[0].BuildNumber $context;$os.bootAt=Convert-BehaviorUtc $osRows[0].LastBootUpTime}
    if($osRows.Count -ne 1 -or -not $os.bootAt -or [string]::IsNullOrWhiteSpace($os.version) -or [string]::IsNullOrWhiteSpace($os.build)){
        Set-BehaviorSourcePartial $context 'processes'
    }
    Complete-BehaviorStage $context $osRows.Count
    if(-not $Part){
        Write-BehaviorStage 'PROCESS_PRE' $Context
        $pre=@(Convert-BehaviorProcesses @(Invoke-BehaviorQuery $context 'processes' {Get-CimInstance -ClassName Win32_Process -Property ProcessId,ParentProcessId,CreationDate,ExecutablePath,Name -ErrorAction Stop} 384) $context)
        $preAt=Get-BehaviorNow
        Complete-BehaviorStage $context $pre.Count
        Write-BehaviorStage 'TCP' $Context
        $tcp=@(Invoke-BehaviorQuery $context 'network' {Get-NetTCPConnection -ErrorAction Stop} 512)
        $networkAt=Get-BehaviorNow
        Complete-BehaviorStage $context $tcp.Count
        Write-BehaviorStage 'PROCESS_POST' $Context
        $post=@(Convert-BehaviorProcesses @(Invoke-BehaviorQuery $context 'processes' {Get-CimInstance -ClassName Win32_Process -Property ProcessId,ParentProcessId,CreationDate,ExecutablePath,Name -ErrorAction Stop} 384) $context)
        $postAt=Get-BehaviorNow
        $preMap=@{};$postMap=@{}
        foreach($row in $pre){$preMap[[string]$row.pid]=$row};foreach($row in $post){$postMap[[string]$row.pid]=$row}
        foreach($row in $pre){$row.identityVerified=(Test-BehaviorInstance $row $postMap[[string]$row.pid]) -and [datetimeoffset]$row.start -le $preAt -and [datetimeoffset]$row.start -le $postAt;if(-not $row.identityVerified){Add-BehaviorLimitation $context 'PROCESS_RACE'}}
        foreach($row in $post){$row.identityVerified=(Test-BehaviorInstance $preMap[[string]$row.pid] $row) -and [datetimeoffset]$row.start -le $postAt -and [datetimeoffset]$row.start -le $preAt}
        $connections=@(foreach($connection in $tcp){
            $processId=[long]$connection.OwningProcess;$process=$preMap[[string]$processId];$verified=(Test-BehaviorInstance $process $postMap[[string]$processId]) -and $process.identityVerified
            $created=Convert-BehaviorUtc (Get-BehaviorProperty $connection 'CreationTime')
            if(-not $created -or -not $verified){$verified=$false}else{try{$verified=[datetimeoffset]$created -ge [datetimeoffset]$process.start -and [datetimeoffset]$created -le $networkAt}catch{$verified=$false}}
            if(-not $verified){Add-BehaviorLimitation $context 'PROCESS_RACE'}
            $state=[string]$connection.State
            if($state -notin @('Listen','SynSent','SynReceived','Established','FinWait1','FinWait2','CloseWait','Closing','LastAck','TimeWait','Closed','DeleteTCB','Bound')){$state='UNKNOWN'}
            [ordered]@{pid=$processId;processStart=if($null -ne $process){$process.start}else{$null};processPath=if($null -ne $process){$process.path}else{$null};identityVerified=[bool]$verified;
                localAddress=(Convert-BehaviorText $connection.LocalAddress $context);localPort=[int]$connection.LocalPort;remoteAddress=(Convert-BehaviorText $connection.RemoteAddress $context);remotePort=[int]$connection.RemotePort;state=$state;createdAt=$created}
        })
        Complete-BehaviorStage $context $post.Count
        Write-BehaviorStage 'ROUTES' $Context
        $gateways=@(Invoke-BehaviorQuery $context 'network' {Get-NetRoute -DestinationPrefix @('0.0.0.0/0','::/0') -ErrorAction Stop} 16 | ForEach-Object {Convert-BehaviorText $_.NextHop $context} | Where-Object {$_ -and $_ -notin @('0.0.0.0','::')} | Select-Object -Unique)
        Complete-BehaviorStage $context $gateways.Count
    }else{
        $context.coverage.processes='NOT_COLLECTED';$context.coverage.network='NOT_COLLECTED'
        $pre=@();$post=@();$connections=@();$gateways=@();$postAt=$null;$networkAt=$null
    }
    $observed=[ordered]@{processes=(Convert-BehaviorUtc $postAt);network=(Convert-BehaviorUtc $networkAt);persistence=$null;security=$null;integrity=$null}
    if($Full){
        if(-not $Part -or $Part -in @('STARTUP_ITEMS','TASKS','SERVICES')){
            $context.coverage.persistence='OK'
            Get-BehaviorPersistence $context $Part
            $observed.persistence=Convert-BehaviorUtc (Get-BehaviorNow)
        }
        if(-not $Part -or $Part -notin @('STARTUP_ITEMS','TASKS','SERVICES')){
            $context.coverage.security='OK'
            Get-BehaviorSecurityConfig $context $Part
            $observed.security=Convert-BehaviorUtc (Get-BehaviorNow)
        }
    }
    $now=Convert-BehaviorUtc (Get-BehaviorNow)
    return [ordered]@{schemaVersion=1;observedAt=$now;os=$os;app=[ordered]@{version='UNKNOWN';sequence=$null};coverage=$context.coverage;observed=$observed;
        processes=$pre;processesAfter=$post;connections=$connections;persistence=@($context.persistence.ToArray());security=@($context.security.ToArray());integrity=@();gateways=$gateways;
        update=[ordered]@{source='NOT_AVAILABLE';version=$null;sequence=$null;state='NOT_AVAILABLE';lastResult='NOT_AVAILABLE';verification='NOT_AVAILABLE';releaseMapVersion=$null;releaseMapSequence=$null};limitations=@($context.limitations.ToArray())}
}
if($MyInvocation.InvocationName -ne '.') {
    $ErrorActionPreference='Stop'
    [Console]::OutputEncoding=New-Object Text.UTF8Encoding($false)
    $OutputEncoding=New-Object Text.UTF8Encoding($false)
    $context=@{metrics=@{}}
    try {
        Write-BehaviorStage 'STARTUP' $Context
        Complete-BehaviorStage $context 1
        $params=@{Full=$Full;Metrics=$context.metrics}
        if($Part){$params.Part=$Part}
        $snapshot=Get-BehaviorSecuritySnapshot @params
        Write-BehaviorStage 'SERIALIZE' $Context
        $json=ConvertTo-Json -InputObject $snapshot -Depth 12 -Compress
        if([Text.Encoding]::UTF8.GetByteCount($json) -gt 1048576){throw 'Snapshot exceeds private transport limit'}
        [Console]::WriteLine($json)
        Complete-BehaviorStage $context 1
        Write-BehaviorStage 'COMPLETE' $Context
        Complete-BehaviorStage $context 1
    }catch{
        $context.metrics.result='ERROR'
        Complete-BehaviorStage $context 0
        [Console]::WriteLine('{"schemaVersion":1,"coverage":{"processes":"UNAVAILABLE","network":"UNAVAILABLE","persistence":"UNAVAILABLE","security":"UNAVAILABLE","integrity":"NOT_COLLECTED"},"processes":[],"processesAfter":[],"connections":[],"persistence":[],"security":[],"integrity":[],"gateways":[],"limitations":["SOURCE_UNAVAILABLE"]}')}
}
