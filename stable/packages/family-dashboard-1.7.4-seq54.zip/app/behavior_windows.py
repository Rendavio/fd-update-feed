"""Fixed read-only OS collector and bounded offline file worker; no probes."""
from __future__ import annotations
from collections import OrderedDict
from datetime import datetime,timezone
import copy,json,ntpath,os,re,subprocess,sys,time
from pathlib import Path
import eew_private_audio as private
from behavior_process import run_owned
from behavior_native import CRITICAL_ARCHIVE_FILES,MAX_SIGNATURE_INSPECTIONS,MAX_INSPECTION_REQUESTS
from behavior_events import canonical_path,instant,TRUST,LIMITATION_CODES,SECTION_FRESHNESS_SECONDS
from security_health import BEHAVIOR_TIMEOUT_STAGES,BEHAVIOR_PARTS,STAGE_RESULTS,safe_timeout_stage
POWERSHELL=r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe'
COLLECTOR=r'C:\FamilyDashboard\launcher\Read-BehaviorSecuritySnapshot.ps1'
WORKER=r'C:\FamilyDashboard\app\behavior_native.py'
SECTIONS=('processes','network','persistence','security','integrity')
PART_KINDS={'STARTUP_ITEMS':('RUN','RUNONCE','STARTUP'), 'TASKS':('TASK',), 'SERVICES':('SERVICE',),
            'LOCAL_SECURITY':('LOCAL_USER','ADMIN_MEMBER','RDP','SMB'),
            **{part:(part,) for part in BEHAVIOR_PARTS if part.startswith('FIREWALL_')}}
def _json(raw,limit):
 if not isinstance(raw,bytes) or not 1<=len(raw)<=limit:raise ValueError()
 def pairs(rows):
  out={}
  for k,v in rows:
   if k in out:raise ValueError()
   out[k]=v
  return out
 return json.loads(raw.decode('utf-8-sig'),object_pairs_hook=pairs,parse_constant=lambda _: (_ for _ in ()).throw(ValueError()))
def _timeout_stage(stderr):
 # Bound before decoding; only LF/CRLF delimiters form complete protocol lines.
 if not isinstance(stderr,(str,bytes)):return 'UNKNOWN'
 newline=b'\n' if isinstance(stderr,bytes) else '\n'
 if not stderr.endswith(newline):return 'UNKNOWN'
 if len(stderr)>8192:
  partial=stderr[-8193:-8192]!=newline;stderr=stderr[-8192:]
  if partial:stderr=stderr.partition(newline)[2]
 if isinstance(stderr,bytes):stderr=stderr.decode('ascii',errors='replace')
 stage='UNKNOWN'
 for line in stderr.split('\n')[:-1]:
  if line.endswith('\r'):line=line[:-1]
  if line.startswith('BEHAVIOR_STAGE:'):
   candidate=line[len('BEHAVIOR_STAGE:'):]
   stage=candidate if candidate in BEHAVIOR_TIMEOUT_STAGES else 'UNKNOWN'
  elif stage!='UNKNOWN' and line.startswith('BEHAVIOR_METRIC:'+stage+':END:'):
   # A timeout after END is between marked stages, including after COMPLETE.
   stage='UNKNOWN'
 return stage

def _stage_metrics(stderr, timeout_stage=None, started=None, budget=None):
 # Parse only complete, delimited ASCII records. No source text enters the result.
 if not isinstance(stderr,(bytes,str)):return []
 newline=b'\n' if isinstance(stderr,bytes) else '\n'
 if len(stderr)>8192:stderr=stderr[-8193:].partition(newline)[2]
 if isinstance(stderr,bytes):stderr=stderr.decode('ascii','replace')
 rows=[]
 active=None
 stage_start=None
 for line in stderr.split('\n')[:-1]:
  fields=line.removesuffix('\r').split(':')
  if len(fields)==3 and fields[0]=='BEHAVIOR_CLOCK':
   if active and fields[1]==active and re.fullmatch(r'[0-9]{1,16}',fields[2]):
    stage_start=int(fields[2])
   continue
  if len(fields)<3 or fields[0]!='BEHAVIOR_METRIC' or fields[1] not in BEHAVIOR_TIMEOUT_STAGES:continue
  stage=fields[1]
  if fields[2:]==['START']:
   active=stage
   stage_start=None
  elif len(fields)==6 and fields[2]=='END' and stage==active:
   active=None
   if fields[5] not in STAGE_RESULTS[:-1] or not re.fullmatch(r'[0-9]{1,8}',fields[3]) or not re.fullmatch(r'[0-9]{1,4}',fields[4]):continue
   ms,count=int(fields[3]),int(fields[4])
   if ms<=75000 and count<=4096:rows.append(dict(stage=stage,durationMs=ms,count=count,result=fields[5]))
 if active==timeout_stage and active in BEHAVIOR_TIMEOUT_STAGES:
  elapsed=None
  if stage_start is not None and started is not None and budget is not None:
   # Stopwatch and perf_counter on Windows both use QueryPerformanceCounter.
   # Use the owned child's deadline; cleanup and pipe draining occur after it.
   start_ms=round(started*1000)
   deadline_ms=round((started+budget)*1000)
   if start_ms<=stage_start<=deadline_ms:elapsed=deadline_ms-stage_start
  rows.append(dict(stage=active,durationMs=elapsed,count=None,result='TIMEOUT'))
 return rows[-36:]


def _run_environment():
 env=dict(os.environ);env['PSModulePath']=r'C:\Windows\System32\WindowsPowerShell\v1.0\Modules;C:\Program Files\WindowsPowerShell\Modules';env['PATH']=r'C:\Windows\System32;C:\Windows';return env
def _digest(v):return v.lower() if isinstance(v,str) and re.fullmatch('[a-fA-F0-9]{64}',v) else 'UNKNOWN'
class NativeBatchInspector:
 def __init__(self,*,runner=None):self.run=runner or run_owned
 def __call__(self,requests):
  if not isinstance(requests,list) or len(requests)>MAX_INSPECTION_REQUESTS:return []
  try:
   raw=json.dumps(requests,separators=(',',':')).encode()
   if len(raw)>32768:return []
   cp=self.run([sys.executable,'-I','-s','-B',WORKER,'--inspect'],input=raw,stdout=subprocess.PIPE,stderr=subprocess.PIPE,shell=False,timeout=10,env=_run_environment(),creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
   if cp.returncode:return []
   rows=_json(cp.stdout,32768)
   if not isinstance(rows,list) or len(rows)>MAX_INSPECTION_REQUESTS:return []
   result=[];seen=set()
   for row in rows:
    if not isinstance(row,dict):continue
    i=row.get('index')
    if type(i) is not int or not 0<=i<len(requests) or i in seen:continue
    seen.add(i);at=instant(row.get('inspectedAt'))
    result.append({'index':i,'trust':row.get('trust') if row.get('trust') in TRUST else 'UNKNOWN','sha256':_digest(row.get('sha256')),'inspectedAt':at.isoformat() if at else None,'error':row.get('error') if row.get('error') in {'NONE','UNSAFE_PATH','OVERSIZED','BYTE_BUDGET','UNREADABLE','UNKNOWN'} else 'UNKNOWN'})
   return result
  except (OSError,ValueError,TypeError,AttributeError,subprocess.TimeoutExpired):return []
class BehaviorWindowsSource:
 def __init__(self,*,app_version,app_sequence=None,update_provider=None,runner=None,inspector=None,platform=None,clock=None,map_loader=None):
  self.version=app_version;self.sequence=app_sequence;self.update_provider=update_provider;self.run=runner or run_owned;self.inspect=inspector or NativeBatchInspector();self._platform=sys.platform if platform is None else platform;self.clock=clock or (lambda:datetime.now(timezone.utc));self.cache=OrderedDict();self.map_loader=map_loader or self._read_map;self.slow_cache=None;self.slow_boot=None;self.release_cache={};self.attempts={}
  self.sliced=False
  self.fast_fallback=False
  self.parts={}
  self.part_boot=None
  self.part_attempts={}
  self.part_coverage={}
  self.part_serial=0
  self.solo_part=None
  self.last_diagnostic={}
  self.probes=[]
 def _read_map(self):
  with private.secure_file(Path(r'C:\FamilyDashboard\app\behavior_release.json')) as stream:return _json(stream.read(20001),20000)
 def _failure(self,now,code='SOURCE_UNAVAILABLE',reason='BEHAVIOR_SOURCE_UNAVAILABLE',timeout_stage='UNKNOWN'):
  return {'schemaVersion':1,'healthReason':reason,'timeoutStage':safe_timeout_stage(timeout_stage) if reason=='BEHAVIOR_QUERY_TIMEOUT' else 'NONE','observedAt':now.isoformat(),'os':{},'app':{'version':self.version,'sequence':self.sequence},'coverage':{s:'UNAVAILABLE' for s in SECTIONS},'observed':{s:None for s in SECTIONS},'processes':[],'connections':[],'persistence':[],'security':[],'integrity':[],'gateways':[],'update':{},'limitations':[code]}
 def _query(self,full=False,part=None,timeout=20):
  argv=[POWERSHELL,'-NoLogo','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',COLLECTOR]
  if full:argv.append('-Full')
  if part:argv.extend(['-Part',part])
  self.last_diagnostic={'part':part or ('ALL' if full else 'FAST'),'stages':[],'budgetMs':round(timeout*1000)}
  self.probes.append(self.last_diagnostic)
  started=time.perf_counter()
  try:
   cp=self.run(argv,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,shell=False,timeout=timeout,env=_run_environment(),creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
  except subprocess.TimeoutExpired as exc:
   self.last_diagnostic['stages']=_stage_metrics(exc.stderr,_timeout_stage(exc.stderr),started,timeout)
   raise
  finally:
   self.last_diagnostic['durationMs']=round((time.perf_counter()-started)*1000)
  self.last_diagnostic['stages']=_stage_metrics(cp.stderr)
  if cp.returncode==5:raise PermissionError()
  if cp.returncode:raise OSError()
  v=_json(cp.stdout,1048576)
  if not isinstance(v,dict) or v.get('schemaVersion')!=1 or not isinstance(v.get('coverage'),dict) or not instant(v.get('observedAt')):raise ValueError()
  for field in ['processes','processesAfter','connections','persistence','security','gateways']:
   if not isinstance(v.get(field),list):raise ValueError()
  if not isinstance(v.get('observed'),dict):raise ValueError()
  for flag in ('collectionPending','healthReason','timeoutStage','integrityCollected','configObservedAt'):v.pop(flag,None)
  v['limitations']=[x for x in v.get('limitations',[])[:32] if isinstance(x,str) and x in LIMITATION_CODES]
  v['coverage']={s:v['coverage'].get(s) if v['coverage'].get(s) in {'OK','PARTIAL','UNAVAILABLE','NOT_COLLECTED'} else 'UNAVAILABLE' for s in SECTIONS}
  for name,section,cap in [('processes','processes',384),('connections','network',512),('persistence','persistence',512),('security','security',2048)]:
   if len(v[name])>cap or any(not isinstance(x,dict) for x in v[name]):v['coverage'][section]='PARTIAL'
   v[name]=[x for x in v[name][:cap] if isinstance(x,dict)]
  if not part and v['coverage']['processes']=='OK' and (not v['processes'] or not v['processesAfter']):raise ValueError('empty Windows process inventory')
  if full and not part:
   # Empty TCP connections, tasks and optional firewall filters can be legitimate.
   # A completed Windows inventory must contain the required service/profile facts.
   for section,kind in [('persistence','SERVICE'),('security','FIREWALL_PROFILE')]:
    if v['coverage'][section]=='OK' and not any(row.get('kind')==kind for row in v[section]):
     v['coverage'][section]='PARTIAL'
  v['gateways']=[x for x in v['gateways'][:16] if isinstance(x,str) and len(x)<=64]
  return v

 def _slow_parts(self,v,*,refresh):
  # A successful prefix survives the next ordinary poll. Only the nine fixed parts
  # are accepted and only observations of the same OS boot can form a snapshot.
  boot=instant(v.get('os',{}).get('bootAt'))
  if boot!=self.part_boot:
   self.parts.clear()
   self.part_attempts.clear()
   self.part_coverage.clear()
   self.part_boot=boot
   self.solo_part=None
  v['collectionPending']=True
  if not boot:return
  now=self.clock()
  def age(part):
   return (now-self.parts[part]['at']).total_seconds() if part in self.parts else float('inf')
  # Start refresh one ordinary poll before the 900s Full interval. Expiry
  # still uses the existing 1020s rule and the oldest constituent timestamp.
  selected=[]
  if refresh:
   due=[part for part in BEHAVIOR_PARTS if not 0<=age(part)<780]
   due.sort(key=lambda part:self.part_attempts.get(part,-1))
   selected=[self.solo_part] if self.solo_part in due else due
   self.solo_part=None
  deadline=time.monotonic()+20
  for index in range(min(2,len(selected))):
   remaining=deadline-time.monotonic()
   if remaining<8:break
   part=selected[0]
   if index:
    # Keep the first slot fair. Spend the remainder only on a due child whose
    # last measured runtime fits, or an unmeasured child with one bounded retry.
    part=next((p for p in selected[1:] if p not in self.parts or self.parts[p]['durationMs']<=remaining*1000),None)
    if part is None:break
   section='persistence' if part in BEHAVIOR_PARTS[:3] else 'security'
   self.part_serial+=1
   self.part_attempts[part]=self.part_serial
   self.part_coverage[part]='UNAVAILABLE'
   self.parts.pop(part,None)
   try:
    result=self._query(True,part,remaining)
    at=instant(result['observed'].get(section))
    if instant(result.get('os',{}).get('bootAt'))!=boot or not at or not 0<=(self.clock()-at).total_seconds()<=300:
     raise ValueError('unverified part observation')
    limits=result['limitations']
    if 'SOURCE_ACCESS_DENIED' in limits:raise PermissionError()
    if result['coverage'][section]!='OK' or (part in ('SERVICES','FIREWALL_PROFILE','LOCAL_SECURITY') and not result[section]):
     self.part_coverage[part]='PARTIAL' if result['coverage'][section] in ('PARTIAL','OK') else 'UNAVAILABLE'
     v['limitations'].extend(limits)
     break
    if any(row.get('kind') not in PART_KINDS[part] for row in result[section]):
     raise ValueError('unexpected kind for part')
    self.parts[part]={'at':at,'rows':result[section],'limits':limits,'durationMs':self.last_diagnostic['durationMs']}
    self.part_coverage[part]='OK'
   except subprocess.TimeoutExpired as exc:
    # A second child may have received only the unused fraction of 20s.
    # Give it the next scheduled slot alone before diagnosing an intrinsic stall.
    if index:self.solo_part=part
    v.update(healthReason='BEHAVIOR_QUERY_TIMEOUT',timeoutStage=_timeout_stage(exc.stderr))
    break
   except PermissionError:
    v['healthReason']='BEHAVIOR_SOURCE_ACCESS_DENIED'
    break
   except OSError:
    v['healthReason']='BEHAVIOR_SOURCE_UNAVAILABLE'
    break
   except (TypeError,AttributeError,ValueError):
    v['healthReason']='BEHAVIOR_INVALID_SNAPSHOT'
    break
  now=self.clock()
  # Disappearance is observed when that category was queried, including an empty result.
  v['configObservedAt']={kind:item['at'].isoformat() for part,item in self.parts.items() for kind in PART_KINDS[part]}
  for section,parts,cap in [('persistence',BEHAVIOR_PARTS[:3],512),('security',BEHAVIOR_PARTS[3:],2048)]:
   fresh=[self.parts[p] for p in parts if p in self.parts and 0<=age(p)<=SECTION_FRESHNESS_SECONDS[section]]
   coverage='NOT_COLLECTED'
   if any(p in self.part_attempts for p in parts):
    coverage='PARTIAL' if fresh or any(self.part_coverage.get(p)=='PARTIAL' for p in parts) else 'UNAVAILABLE'
   rows=[row for item in fresh for row in item['rows']]
   if len(fresh)==len(parts) and len(rows)<=cap:coverage='OK'
   if len(rows)>cap:v['limitations'].append('TRUNCATED')
   v[section]=rows[:cap]
   v['observed'][section]=min(item['at'] for item in fresh).isoformat() if fresh else None
   v['coverage'][section]=coverage
   for item in fresh:v['limitations'].extend(item['limits'])
  v['collectionPending']=any(v['coverage'][s]!='OK' for s in ('persistence','security'))

 def collect(self,*,full=False):
  self.probes=[]
  now=self.clock()
  if self._platform!='win32':return self._failure(now)
  # A fast retry can project the current same-boot parts but cannot refresh
  # them or restore the older slow-cache image captured on the last Full poll.
  sliced=self.sliced
  fast_retry=sliced and self.fast_fallback and not full
  self.fast_fallback=False
  try:
   v=self._query(full and not sliced)
   now=self.clock()
   if sliced:
    self._slow_parts(v,refresh=not fast_retry)
    full=not fast_retry and not v['collectionPending'] and (full or not self.slow_cache or self.slow_boot!=v.get('os',{}).get('bootAt'))
   v['app']={'version':self.version,'sequence':self.sequence};v['integrity']=[]
   boot=v.get('os',{}).get('bootAt')
   if boot!=self.slow_boot:self.slow_cache=None;self.release_cache={}
   if not full and self.slow_cache:
    for section in (('integrity',) if sliced else ('persistence','security','integrity')):
     v[section]=copy.deepcopy(self.slow_cache[section]);v['coverage'][section]=self.slow_cache['coverage'][section];v['observed'][section]=self.slow_cache['observed'][section]
   limits=[x for x in v.get('limitations',[]) if isinstance(x,str) and x in LIMITATION_CODES]
   limits+=['DISK_IMAGE_NOT_MEMORY','CATALOG_SIGNATURE_NOT_CHECKED','CACHE_ONLY_REVOCATION_UNKNOWN','SHORT_AND_UDP_TRAFFIC_MAY_BE_MISSED']
   after={p.get('pid'):p for p in v.pop('processesAfter')[:384] if isinstance(p,dict) and type(p.get('pid')) is int}
   before={};requests=[];paths=[];candidates={};current_images=set()
   for p in v['processes']:
    pid=p.get('pid');path=canonical_path(p.get('path'));start=instant(p.get('start'));post=after.get(pid,{}) if type(pid) is int else {}
    p['identityVerified']=bool(path and start and canonical_path(post.get('path'))==path and instant(post.get('start'))==start)
    p['pathClass']=self._path_class(path);p.update(sha256='UNKNOWN',trust='UNKNOWN',inspectedAt=None)
    if type(pid) is int:before[pid]=p
    if path:current_images.add(path)
    cached=self.cache.get(path)
    if cached and start and (instant(cached['inspectedAt']) or datetime.min.replace(tzinfo=timezone.utc))>=start and 0<=(now-instant(cached['inspectedAt'])).total_seconds()<900:
     p.update(cached);self.cache.move_to_end(path)
    elif path and ntpath.splitext(path)[1] in {'.exe','.com','.dll'}:candidates[path]=p['pathClass']
   # A bounded deferred queue: new paths first, then least-recently attempted.
   # Failed/expired early images must not permanently starve the tail.
   self.attempts={path:at for path,at in self.attempts.items() if path in current_images}
   floor=datetime.min.replace(tzinfo=timezone.utc)
   paths=sorted(candidates,key=lambda path:(path in self.attempts, self.attempts.get(path,floor),candidates[path] not in {'USER_TEMP','USER_PROFILE','OTHER_LOCAL'},path))[:MAX_SIGNATURE_INSPECTIONS]
   if len(candidates)>MAX_SIGNATURE_INSPECTIONS:limits.append('INSPECTION_BUDGET_EXHAUSTED')
   for path in paths:self.attempts[path]=now;requests.append({'path':path,'signature':True})
   network_at=instant(v['observed'].get('network'))
   for flow in v['connections']:
    p=before.get(flow.get('pid'),{}) if type(flow.get('pid')) is int else {};created=instant(flow.get('createdAt'));start=instant(p.get('start'))
    flow.update(processStart=p.get('start'),processPath=p.get('path'),identityVerified=bool(p.get('identityVerified') and start and created and network_at and start<=created<=network_at<=now))
   release={} if full else self.release_cache
   if full:
    try:
     m=self.map_loader()
     if isinstance(m,dict) and m.get('schemaVersion')==1 and isinstance(m.get('files'),dict) and len(m['files'])<=len(CRITICAL_ARCHIVE_FILES)-1 and all(k in CRITICAL_ARCHIVE_FILES[:-1] and _digest(h)!='UNKNOWN' for k,h in m['files'].items()):release=m
    except Exception:pass
    for name in CRITICAL_ARCHIVE_FILES:
     requests.append({'path':ntpath.join(r'C:\FamilyDashboard',name.replace('/','\\')),'signature':False})
   results={r['index']:r for r in (self.inspect(requests) if requests else []) if isinstance(r,dict) and type(r.get('index')) is int}
   for i,path in enumerate(paths):
    r=results.get(i,{})
    if instant(r.get('inspectedAt')):
     self.cache[path]={'sha256':_digest(r.get('sha256')),'trust':r.get('trust') if r.get('trust') in TRUST else 'UNKNOWN','inspectedAt':r['inspectedAt']};self.cache.move_to_end(path)
     for p in v['processes']:
      if canonical_path(p.get('path'))==path:p.update(self.cache[path])
   while len(self.cache)>256:self.cache.popitem(last=False)
   if full:
    for offset,name in enumerate(CRITICAL_ARCHIVE_FILES):
     r=results.get(len(paths)+offset,{});actual=_digest(r.get('sha256'));expected=_digest(release.get('files',{}).get(name))
     v['integrity'].append({'path':ntpath.join(r'C:\FamilyDashboard',name.replace('/','\\')),'sha256':actual,'expectedSha256':expected,'expectedMatch':actual==expected if 'UNKNOWN' not in (actual,expected) else None,'checkedAt':r.get('inspectedAt')})
    # Self hash has no recursive expectation; all fixed release files must be covered.
    v['coverage']['integrity']='OK' if all(x['sha256']!='UNKNOWN' and x['expectedSha256']!='UNKNOWN' for x in v['integrity'][:-1]) else 'PARTIAL';v['observed']['integrity']=self.clock().isoformat()
   elif not self.slow_cache:v['coverage']['integrity']='NOT_COLLECTED';v['observed']['integrity']=None
   if full:
    self.slow_cache={section:copy.deepcopy(v[section]) for section in ('persistence','security','integrity')};self.slow_cache['coverage']=copy.deepcopy(v['coverage']);self.slow_cache['observed']=copy.deepcopy(v['observed']);self.slow_boot=boot;self.release_cache=copy.deepcopy(release)
   update={}
   if self.update_provider:
    try:update=self.update_provider()
    except Exception:pass
   v['update']={'source':'UPDATER_V1_REPORT' if update else 'NOT_AVAILABLE','version':update.get('currentVersion'),'sequence':update.get('currentSequence'),'state':update.get('state','UNKNOWN'),'lastResult':update.get('lastResult','UNKNOWN'),'verification':'REPORT_ONLY' if update else 'NOT_AVAILABLE','releaseMapVersion':release.get('version'),'releaseMapSequence':release.get('sequence')}
   v['observedAt']=self.clock().isoformat()
   if full:
    v['integrityCollected']=True
    if any(v['coverage'][s]!='OK' for s in SECTIONS):v['collectionPending']=True
   v.setdefault('healthReason','NONE');v.setdefault('timeoutStage','NONE');v['limitations']=list(dict.fromkeys(limits))[:32];return v
  except subprocess.TimeoutExpired as exc:
   if full:self.sliced=True
   if self.sliced:self.fast_fallback=True
   return self._failure(now,reason='BEHAVIOR_QUERY_TIMEOUT',timeout_stage=_timeout_stage(exc.stderr))
  except PermissionError:return self._failure(now,'SOURCE_ACCESS_DENIED','BEHAVIOR_SOURCE_ACCESS_DENIED')
  except OSError:return self._failure(now)
  except (ValueError,TypeError,AttributeError):return self._failure(now,reason='BEHAVIOR_INVALID_SNAPSHOT')
 @staticmethod
 def _path_class(path):
  if not path:return 'UNKNOWN'
  if path.startswith(ntpath.normcase(ntpath.join('C:/FamilyDashboard/app',''))):return 'APP_CODE'
  if path.startswith((ntpath.normcase(ntpath.join('C:/Windows/System32','')),ntpath.normcase(ntpath.join('C:/Windows/SysWOW64','')),ntpath.normcase(ntpath.join('C:/Windows/WinSxS','')))):return 'SYSTEM'
  if path.startswith(('c:\\program files\\','c:\\program files (x86)\\')):return 'PROGRAM_FILES'
  if ntpath.sep+ntpath.normcase(ntpath.join('AppData/Local/Temp','')) in path or path.startswith(ntpath.normcase(ntpath.join('C:/Windows/Temp',''))):return 'USER_TEMP'
  if path.startswith(ntpath.normcase(ntpath.join('C:/Users',''))):return 'USER_PROFILE'
  return 'OTHER_LOCAL'
