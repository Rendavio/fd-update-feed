"""Fixed-role, local private PCM assets. Never fetches, converts, plays or logs audio."""
from __future__ import annotations
import contextlib
import ctypes
import getpass
import json
import os
import stat
import struct
import sys
import tempfile
import threading
from pathlib import Path

MAX_BYTES = 8 * 1024 * 1024
MAX_SECONDS = 30
ROLES = {"production": "production.wav", "training": "training.wav"}
ERRORS = {"missing", "unreadable", "invalid", "unsafe_path"}
_LOCK = threading.RLock()

class PrivateAudioError(ValueError):
    def __init__(self, category="invalid"):
        self.category = category if category in ERRORS else "invalid"
        super().__init__(self.category)

def validate_pcm_wav(raw):
    if not isinstance(raw, bytes) or not 44 <= len(raw) <= MAX_BYTES:
        raise PrivateAudioError()
    if raw[:4] != b"RIFF" or raw[8:12] != b"WAVE" or struct.unpack_from("<I",raw,4)[0] != len(raw)-8:
        raise PrivateAudioError()
    offset=12; fmt=None; data=None; chunks=0
    while offset < len(raw):
        chunks+=1
        if chunks > 128 or offset+8 > len(raw): raise PrivateAudioError()
        kind=raw[offset:offset+4]; size=struct.unpack_from("<I",raw,offset+4)[0]
        begin=offset+8; end=begin+size
        if end>len(raw) or end+(size%2)>len(raw): raise PrivateAudioError()
        if kind==b"fmt ":
            if fmt is not None or size != 16: raise PrivateAudioError()
            fmt=struct.unpack_from("<HHIIHH",raw,begin)
        elif kind==b"data":
            if data is not None or fmt is None: raise PrivateAudioError()
            data=size
        offset=end+(size%2)
    if offset != len(raw) or fmt is None or data is None: raise PrivateAudioError()
    tag,channels,rate,byte_rate,align,bits=fmt
    if tag!=1 or channels not in (1,2) or rate not in (44100,48000) or bits!=16:
        raise PrivateAudioError()
    if align!=channels*2 or byte_rate!=rate*align or not data or data%align or data>rate*align*MAX_SECONDS:
        raise PrivateAudioError()
    return {"channels":channels,"sampleRate":rate,"frames":data//align}

def _windows():
    k=ctypes.WinDLL("kernel32",use_last_error=True)
    a=ctypes.WinDLL("advapi32",use_last_error=True)
    k.CreateFileW.argtypes=[ctypes.c_wchar_p,ctypes.c_uint32,ctypes.c_uint32,ctypes.c_void_p,ctypes.c_uint32,ctypes.c_uint32,ctypes.c_void_p]
    k.CreateFileW.restype=ctypes.c_void_p
    k.CloseHandle.argtypes=[ctypes.c_void_p]
    k.GetFinalPathNameByHandleW.argtypes=[ctypes.c_void_p,ctypes.c_wchar_p,ctypes.c_uint32,ctypes.c_uint32]
    k.GetFileInformationByHandleEx.argtypes=[ctypes.c_void_p,ctypes.c_int,ctypes.c_void_p,ctypes.c_uint32]
    k.GetDriveTypeW.argtypes=[ctypes.c_wchar_p]
    k.GetCurrentProcess.restype=ctypes.c_void_p
    k.LocalFree.argtypes=[ctypes.c_void_p]
    a.OpenProcessToken.argtypes=[ctypes.c_void_p,ctypes.c_uint32,ctypes.POINTER(ctypes.c_void_p)]
    a.GetTokenInformation.argtypes=[ctypes.c_void_p,ctypes.c_int,ctypes.c_void_p,ctypes.c_uint32,ctypes.POINTER(ctypes.c_uint32)]
    a.ConvertSidToStringSidW.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_void_p)]
    a.GetSecurityInfo.argtypes=[ctypes.c_void_p,ctypes.c_int,ctypes.c_uint32,ctypes.POINTER(ctypes.c_void_p),ctypes.c_void_p,ctypes.POINTER(ctypes.c_void_p),ctypes.c_void_p,ctypes.POINTER(ctypes.c_void_p)]
    a.GetSecurityInfo.restype=ctypes.c_uint32
    a.GetSecurityDescriptorControl.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_uint16),ctypes.POINTER(ctypes.c_uint32)]
    a.GetAce.argtypes=[ctypes.c_void_p,ctypes.c_uint32,ctypes.POINTER(ctypes.c_void_p)]
    a.ConvertStringSecurityDescriptorToSecurityDescriptorW.argtypes=[ctypes.c_wchar_p,ctypes.c_uint32,ctypes.POINTER(ctypes.c_void_p),ctypes.c_void_p]
    a.SetFileSecurityW.argtypes=[ctypes.c_wchar_p,ctypes.c_uint32,ctypes.c_void_p]
    return k,a

def _sid_text(pointer,k,a):
    text=ctypes.c_void_p()
    if not a.ConvertSidToStringSidW(pointer,ctypes.byref(text)): raise PrivateAudioError("unsafe_path")
    try: return ctypes.wstring_at(text.value)
    finally: k.LocalFree(text)

def current_sid():
    k,a=_windows();token=ctypes.c_void_p();needed=ctypes.c_uint32()
    if not a.OpenProcessToken(k.GetCurrentProcess(),8,ctypes.byref(token)): raise PrivateAudioError("unsafe_path")
    try:
        a.GetTokenInformation(token,1,None,0,ctypes.byref(needed))
        buf=ctypes.create_string_buffer(needed.value)
        if not a.GetTokenInformation(token,1,buf,len(buf),ctypes.byref(needed)): raise PrivateAudioError("unsafe_path")
        return _sid_text(ctypes.c_void_p.from_buffer(buf),k,a)
    finally: k.CloseHandle(token)

def _check_acl(handle, *, protected=True):
    k,a=_windows();owner=ctypes.c_void_p();dacl=ctypes.c_void_p();sd=ctypes.c_void_p()
    allowed={current_sid(),"S-1-5-18","S-1-5-32-544"}
    try:
        if a.GetSecurityInfo(handle,1,5,ctypes.byref(owner),None,ctypes.byref(dacl),None,ctypes.byref(sd)) or not owner or not dacl:
            raise PrivateAudioError("unsafe_path")
        if _sid_text(owner,k,a) not in allowed: raise PrivateAudioError("unsafe_path")
        control=ctypes.c_uint16();rev=ctypes.c_uint32()
        if not a.GetSecurityDescriptorControl(sd,ctypes.byref(control),ctypes.byref(rev)): raise PrivateAudioError("unsafe_path")
        if protected and not control.value&0x1000: raise PrivateAudioError("unsafe_path")
        count=ctypes.c_uint16.from_address(dacl.value+4).value
        if not 1<=count<=32: raise PrivateAudioError("unsafe_path")
        seen=set()
        for i in range(count):
            ace=ctypes.c_void_p()
            if not a.GetAce(dacl,i,ctypes.byref(ace)) or not ace: raise PrivateAudioError("unsafe_path")
            if ctypes.c_uint8.from_address(ace.value).value!=0: raise PrivateAudioError("unsafe_path")
            if ctypes.c_uint8.from_address(ace.value+1).value & 8: continue  # inherit-only ACE does not grant this object
            sid=_sid_text(ctypes.c_void_p(ace.value+8),k,a);seen.add(sid)
            mask=ctypes.c_uint32.from_address(ace.value+4).value
            if sid not in allowed and (protected or mask & ~0x001200A9): raise PrivateAudioError("unsafe_path")
        if protected and seen!=allowed: raise PrivateAudioError("unsafe_path")
    finally:
        if sd: k.LocalFree(sd)

def _set_private_acl(path):
    k,a=_windows();sd=ctypes.c_void_p()
    sddl="O:"+current_sid()+"D:P(A;OICI;FA;;;"+current_sid()+")(A;OICI;FA;;;SY)(A;OICI;FA;;;BA)"
    if not a.ConvertStringSecurityDescriptorToSecurityDescriptorW(sddl,1,ctypes.byref(sd),None): raise PrivateAudioError("unsafe_path")
    try:
        if not a.SetFileSecurityW(str(path),0x80000004,sd): raise PrivateAudioError("unsafe_path")
    finally: k.LocalFree(sd)

def _local_path(path):
    path=Path(path)
    if not path.is_absolute() or ".." in path.parts or str(path).startswith(("\\\\","//")):
        raise PrivateAudioError("unsafe_path")
    if os.name=="nt":
        k,_=_windows()
        if k.GetDriveTypeW(path.anchor)!=3: raise PrivateAudioError("unsafe_path")
    return path

@contextlib.contextmanager
def locked_chain(path, *, private_base=None, source_acl=False):
    path=_local_path(path);handles=[]
    try:
        if os.name!="nt":
            for p in reversed((path,*path.parents)):
                if p.is_symlink(): raise PrivateAudioError("unsafe_path")
            yield None;return
        k,_=_windows()
        for part in reversed((path,*path.parents)):
            handle=k.CreateFileW(str(part),0x20080,3,None,3,0x02200000,None)
            if handle in (None,ctypes.c_void_p(-1).value):
                error=ctypes.get_last_error()
                raise PrivateAudioError("missing" if error in (2,3) else "unreadable")
            handles.append(handle)
            attrs=(ctypes.c_uint32*2)()
            if not k.GetFileInformationByHandleEx(handle,9,attrs,8) or attrs[0]&0x400: raise PrivateAudioError("unsafe_path")
            name=ctypes.create_unicode_buffer(32768)
            size=k.GetFinalPathNameByHandleW(handle,name,len(name),0)
            if not 0<size<len(name): raise PrivateAudioError("unsafe_path")
            actual=name.value.removeprefix("\\\\?\\")
            if os.path.normcase(actual.rstrip("\\"))!=os.path.normcase(str(part).rstrip("\\")): raise PrivateAudioError("unsafe_path")
            if private_base is not None and (part==private_base or private_base in part.parents):
                _check_acl(handle)
            elif source_acl and part in (path, path.parent):
                _check_acl(handle,protected=False)
        yield handles[-1]
    finally:
        if os.name=="nt":
            k,_=_windows()
            for handle in reversed(handles): k.CloseHandle(handle)

@contextlib.contextmanager
def secure_file(path, *, private_base=None, source_acl=False):
    path=_local_path(path)
    with locked_chain(path,private_base=private_base,source_acl=source_acl) as probe_handle:
        info=path.lstat()
        if not stat.S_ISREG(info.st_mode) or getattr(info,"st_file_attributes",0)&0x400: raise PrivateAudioError("unsafe_path")
        if os.name=="nt":
            k,_=_windows()
            handle=k.CreateFileW(str(path),0x80020000,1,None,3,0x00200000,None)
            if handle in (None,ctypes.c_void_p(-1).value): raise PrivateAudioError("unreadable")
            import msvcrt
            try: fd=msvcrt.open_osfhandle(handle,os.O_RDONLY|os.O_BINARY)
            except Exception:
                k.CloseHandle(handle);raise
            with os.fdopen(fd,"rb") as stream:
                read_handle=msvcrt.get_osfhandle(stream.fileno())
                if _file_identity(probe_handle)!=_file_identity(read_handle): raise PrivateAudioError("unsafe_path")
                if private_base is not None: _check_acl(read_handle)
                elif source_acl: _check_acl(read_handle,protected=False)
                if os.fstat(stream.fileno()).st_size!=info.st_size: raise PrivateAudioError("invalid")
                yield stream
        else:
            with path.open("rb") as stream: yield stream

def _file_identity(handle):
    k,_=_windows()
    info=ctypes.create_string_buffer(24)  # FILE_ID_INFO: volume serial + 128-bit ID
    if not k.GetFileInformationByHandleEx(handle,18,info,len(info)): raise PrivateAudioError("unsafe_path")
    return info.raw

@contextlib.contextmanager
def registration_transaction():
    if os.name!="nt": raise PrivateAudioError("unsafe_path")
    k,_=_windows()
    k.CreateMutexW.argtypes=[ctypes.c_void_p,ctypes.c_int,ctypes.c_wchar_p]
    k.CreateMutexW.restype=ctypes.c_void_p
    k.WaitForSingleObject.argtypes=[ctypes.c_void_p,ctypes.c_uint32]
    k.WaitForSingleObject.restype=ctypes.c_uint32
    k.ReleaseMutex.argtypes=[ctypes.c_void_p]
    handle=k.CreateMutexW(None,0,"Global\\FamilyDashboard.PrivateAudio."+current_sid())
    if not handle: raise PrivateAudioError("unsafe_path")
    acquired=False
    try:
        acquired=k.WaitForSingleObject(handle,0) in (0,0x80)
        if not acquired: raise PrivateAudioError("unreadable")
        yield
    finally:
        if acquired: k.ReleaseMutex(handle)
        k.CloseHandle(handle)

class EewPrivateAudioStore:
    def __init__(self,root,public_root):
        self.root=Path(root).absolute()
        self.public_root=Path(public_root).resolve()
        if self.root.resolve().is_relative_to(self.public_root): raise PrivateAudioError("unsafe_path")
        self.base=self.root/"private-assets"
        self.directory=self.base/"eew"
    def _path(self,role):
        if role not in ROLES: raise PrivateAudioError()
        return self.directory/ROLES[role]
    def _read_role(self,role):
        with secure_file(self._path(role),private_base=self.base) as stream:
            if os.fstat(stream.fileno()).st_size>MAX_BYTES: raise PrivateAudioError()
            return stream.read(MAX_BYTES+1)
    def read(self,role):
        self._path(role)
        try:
            raw=self._read_role(role);validate_pcm_wav(raw);return raw
        except FileNotFoundError: raise PrivateAudioError("missing") from None
        except OSError: raise PrivateAudioError("unreadable") from None
    def status(self):
        result={}
        for role in ROLES:
            try: self.read(role);result[role]="READY"
            except PrivateAudioError as exc: result[role]="MISSING" if exc.category=="missing" else "INVALID"
            except OSError: result[role]="INVALID"
        return result
    def _read_source(self,source):
        with secure_file(source,source_acl=True) as stream:
            if os.fstat(stream.fileno()).st_size>MAX_BYTES: raise PrivateAudioError()
            return stream.read(MAX_BYTES+1)
    def import_asset(self,role,source):
        self._path(role)
        raw=self._read_source(source)
        return self.install_bytes(role,raw)
    def install_bytes(self,role,raw):
        self._path(role)
        validate_pcm_wav(raw)
        with _LOCK, registration_transaction():
            other="training" if role=="production" else "production"
            try: other_raw=self.read(other)
            except PrivateAudioError as exc:
                if exc.category not in {"missing","invalid"}: raise
                other_raw=None
            if raw==other_raw: raise PrivateAudioError()
            try:
                if self.read(role)==raw: return "READY"
            except PrivateAudioError: pass
            self._atomic_install(role,raw)
        return "READY"
    def _atomic_install(self,role,raw):
        # Hold every parent against rename/reparse while creating and replacing.
        with locked_chain(self.root) as root_handle:
            if os.name=="nt": _check_acl(root_handle,protected=False)
            for directory in (self.base,self.directory):
                if not directory.exists(): directory.mkdir()
                with locked_chain(directory):
                    _set_private_acl(directory)
            with locked_chain(self.directory,private_base=self.base):
                target=self._path(role)
                if target.exists():
                    with secure_file(target,private_base=self.base): pass
                fd,name=tempfile.mkstemp(prefix="import-",suffix=".tmp",dir=self.directory)
                tmp=Path(name)
                try:
                    _set_private_acl(tmp)
                    stream=os.fdopen(fd,"wb");fd=None
                    with stream:
                        stream.write(raw);stream.flush();os.fsync(stream.fileno())
                    with secure_file(tmp,private_base=self.base) as stream: validate_pcm_wav(stream.read(MAX_BYTES+1))
                    os.replace(tmp,target)
                finally:
                    if fd is not None: os.close(fd)
                    tmp.unlink(missing_ok=True)

def main():
    # Fixed local GUI helper only. No URL, destination or arbitrary command interface.
    try:
        if os.name!="nt" or getpass.getuser().casefold()!="dashboardadmin" or ctypes.windll.shell32.IsUserAnAdmin():
            raise PrivateAudioError("unsafe_path")
        if sys.argv[1:] not in (["--status-private"],["--import-private"]): raise PrivateAudioError()
        root=Path(os.environ["LOCALAPPDATA"])/"FamilyDashboard"
        store=EewPrivateAudioStore(root,Path(__file__).parent)
        if sys.argv[1]=="--status-private": result=store.status()
        else:
            raw=sys.stdin.buffer.read(16385)
            if len(raw)>16384: raise PrivateAudioError()
            request=json.loads(raw.decode("utf-8"))
            if type(request) is not dict or set(request)!={"role","source"} or type(request["source"]) is not str: raise PrivateAudioError()
            store.import_asset(request["role"],Path(request["source"]))
            result=store.status()
        print(json.dumps(result));return 0
    except Exception:
        print('{"production":"INVALID","training":"INVALID"}');return 2

if __name__=="__main__": raise SystemExit(main())

