import { requestEew } from './eew-observability.js';
const ROLES = ['production', 'training'];
const SOUND = new Set(['READY', 'MISSING', 'INVALID']);
const STATES = new Set(['IDLE', 'RUNNING', 'COMPLETE', 'NEEDS_SELECTION', 'PARTIAL', 'CANCELLED', 'FAILED']);
const ERRORS = new Set(['ambiguous', 'not_found', 'scan_limit', 'validation_failed', 'unsafe_source',
  'registration_failed', 'verification_failed', 'unavailable', 'picker_failed', 'picker_timeout', 'cancelled']);
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
export function safeEewSetupState(raw) {
  const value = raw && typeof raw === 'object' ? raw : {};
  const sounds = Object.fromEntries(ROLES.map(role => [role, SOUND.has(value.sounds?.[role]) ? value.sounds[role] : 'INVALID']));
  let state = STATES.has(value.state) ? value.state : 'UNAVAILABLE';
  const needsSelection = Array.isArray(value.needsSelection) ? ROLES.filter(role => value.needsSelection.includes(role)) : [];
  const error = ERRORS.has(value.error) ? value.error : null;
  if (state === 'COMPLETE' && (error || needsSelection.length || ROLES.some(role => sounds[role] !== 'READY'))) state = 'PARTIAL';
  return { state, sounds, needsSelection, error, jobId: typeof value.jobId === 'string' && UUID.test(value.jobId) ? value.jobId : null };
}
export function describeEewSetup(raw) {
  const value = safeEewSetupState(raw);
  const messages = {
    IDLE: ROLES.every(role => value.sounds[role] === 'READY') ? 'EEW音源は登録済みです。' : '任意のカスタム音源を設定できます。標準警報音は登録不要です。',
    RUNNING: 'EEW音源をセットアップしています…',
    COMPLETE: 'EEW音源のセットアップが完了しました',
    NEEDS_SELECTION: '自動判別できませんでした。本番音と訓練音を選択してください。',
    PARTIAL: 'EEW音源のセットアップを一部完了できませんでした。',
    CANCELLED: 'EEW音源のセットアップを中止しました。',
    FAILED: 'EEW音源のセットアップを完了できませんでした。',
    UNAVAILABLE: 'セットアップの状態を確認できませんでした。',
  };
  return {
    message: messages[value.state],
    button: ROLES.every(role => value.sounds[role] === 'READY') ? 'カスタムEEW音源を再セットアップ' : 'カスタムEEW音源をセットアップ',
    sounds: 'Production sound: ' + value.sounds.production + '\nTraining sound: ' + value.sounds.training,
    busy: value.state === 'RUNNING',
    showSelection: value.state !== 'RUNNING' && value.needsSelection.length > 0,
    needsSelection: value.needsSelection,
  };
}
export function createEewSetupClient({
  request = (path, body) => requestEew(path, body),
  schedule = globalThis.setTimeout.bind(globalThis), cancelTimer = globalThis.clearTimeout.bind(globalThis),
  onState = () => {}, onComplete = () => {},
} = {}) {
  let value = safeEewSetupState({ state: 'IDLE', sounds: { production: 'MISSING', training: 'MISSING' } });
  let generation = 0, blocked = false, disposed = false, inFlight = false, timer = null, uncertain = false, completedId = null;
  const snapshot = () => ({ ...safeEewSetupState(value), blocked, inFlight });
  const publish = () => { if (!disposed) { try { onState(snapshot()); } catch {} } };
  const clearPoll = () => { if (timer !== null) cancelTimer(timer); timer = null; };
  async function cancelRemote(jobId) {
    if (!jobId || !UUID.test(jobId)) return;
    try { await request('/api/eew/setup/cancel', { jobId }); }
    catch { uncertain = true; if (!blocked) { value = { ...value, state: 'UNAVAILABLE' }; publish(); } }
  }
  function apply(row, epoch) {
    const next = safeEewSetupState(row);
    if (disposed) return;
    if (epoch !== generation) {
      if (blocked && next.state === 'RUNNING') void cancelRemote(next.jobId);
      return;
    }
    value = next;
    publish();
    if (blocked && value.state === 'RUNNING') { void cancelRemote(value.jobId); return; }
    if (value.state === 'COMPLETE' && value.jobId !== completedId) {
      completedId = value.jobId;
      try { onComplete(); } catch {}
    }
    if (!blocked && value.state === 'RUNNING') {
      clearPoll();
      timer = schedule(() => { timer = null; void refresh(); }, 500);
    }
  }
  async function refresh() {
    if (disposed) return false;
    const epoch = generation;
    clearPoll();
    try {
      const row = await request('/api/eew/setup/status');
      if (epoch === generation) uncertain = false;
      apply(row, epoch); return true;
    } catch {
      if (epoch === generation) { uncertain = true; value = { ...value, state: 'UNAVAILABLE' }; publish(); }
      return false;
    }
  }
  async function mutate(action) {
    if (disposed || blocked || inFlight || value.state === 'RUNNING') return false;
    if (uncertain) {
      if (!await refresh() || blocked || value.state === 'RUNNING') return false;
    }
    const epoch = ++generation;
    inFlight = true; clearPoll();
    value = { ...value, state: 'RUNNING', error: null, jobId: null }; publish();
    try {
      const row = await request('/api/eew/setup/' + action, {});
      if (epoch !== generation || blocked || disposed) {
        await cancelRemote(safeEewSetupState(row).jobId); return false;
      }
      uncertain = false; apply(row, epoch); return true;
    } catch {
      // Unknown write outcome: read the existing job, never resend the mutation.
      uncertain = true;
      if (!disposed) await refresh();
      return false;
    } finally { inFlight = false; publish(); }
  }
  return {
    refresh, state: snapshot,
    start: () => mutate('start'),
    pick: role => ROLES.includes(role) && value.needsSelection.includes(role) ? mutate('pick-' + role) : Promise.resolve(false),
    observeSounds(sounds) {
      const safe = safeEewSetupState({ ...value, sounds });
      value = { ...value, sounds: safe.sounds }; publish();
    },
    setBlocked(next) {
      next = next === true;
      if (next === blocked) return;
      blocked = next; ++generation; clearPoll(); publish();
      if (blocked) void cancelRemote(value.jobId);
      else if (value.state === 'RUNNING' || uncertain) void refresh();
    },
    dispose() { disposed = true; ++generation; clearPoll(); },
  };
}
export function bindEewSetupUi({ root = document, canStart = () => true, onComplete = () => {}, ...options } = {}) {
  const button = root.getElementById('setupEewSounds');
  const result = root.getElementById('eewSetupResult');
  const sounds = root.getElementById('eewSetupSounds');
  const selection = root.getElementById('eewSetupSelection');
  const choices = { production: root.getElementById('selectEewProduction'), training: root.getElementById('selectEewTraining') };
  const render = state => {
    const view = describeEewSetup(state);
    button.textContent = view.button;
    button.disabled = view.busy || state.blocked || state.inFlight;
    result.textContent = view.message;
    sounds.textContent = view.sounds;
    selection.hidden = !view.showSelection;
    for (const role of ROLES) choices[role].disabled = view.busy || state.blocked || state.inFlight || !view.needsSelection.includes(role);
  };
  const client = createEewSetupClient({ ...options, onComplete, onState: render });
  button.addEventListener('click', () => { if (canStart()) void client.start(); });
  for (const role of ROLES) choices[role].addEventListener('click', () => { if (canStart()) void client.pick(role); });
  render(client.state());
  return client;
}

