/* Runs independently of the application module graph during an interrupted restart. */
(() => {
  'use strict';
  const productionPath = '/?display=1&theme=auto&calendar=google&eew=production';
  const budgetKey = 'family-dashboard-startup-recovery';
  const started = Date.now();
  let ready = false;
  let failedScript = false;
  let stableVersion = null;
  let confirmations = 0;
  let timer = null;

  window.addEventListener('family-dashboard-ready', () => {
    ready = true;
    window.clearTimeout(timer);
    const status = document.getElementById('startupStatus');
    if (status) status.hidden = true;
    try { window.sessionStorage.removeItem(budgetKey); } catch {}
  }, { once: true });
  window.addEventListener('error', (event) => {
    if (event.target?.tagName === 'SCRIPT') failedScript = true;
  }, true);

  function reserveReload() {
    // Keep a broken installation from entering an unlimited reload loop.
    // No URLs, account identifiers, or server responses are persisted.
    try {
      const now = Date.now();
      const saved = JSON.parse(window.sessionStorage.getItem(budgetKey) || 'null');
      const current = saved && Number.isInteger(saved.attempts) && saved.attempts >= 0
        && Number.isFinite(saved.started) && now >= saved.started && now - saved.started < 300000
        ? saved : { attempts: 0, started: now };
      if (current.attempts >= 3) return false;
      current.attempts += 1;
      window.sessionStorage.setItem(budgetKey, JSON.stringify(current));
      return true;
    } catch {
      // If a durable per-tab budget is unavailable, keep the safe waiting view.
      return false;
    }
  }

  async function poll() {
    if (ready) return;
    const controller = new AbortController();
    const deadline = window.setTimeout(() => controller.abort(), 5000);
    try {
      const response = await window.fetch('/api/health?startupRecovery=' + Date.now(), {
        cache: 'no-store', signal: controller.signal,
      });
      const health = response.ok ? await response.json() : null;
      if (health?.status !== 'ok' || health?.appId !== 'family-dashboard'
        || health?.mode !== 'production' || health?.processIntegrity !== 'nonElevated'
        || typeof health?.appVersion !== 'string' || !health.appVersion) {
        confirmations = 0;
        stableVersion = null;
      } else {
        confirmations = health.appVersion === stableVersion ? confirmations + 1 : 1;
        stableVersion = health.appVersion;
        if (!ready && confirmations >= 3 && (failedScript || Date.now() - started >= 15000)) {
          if (reserveReload()) {
            window.location.replace(productionPath);
            return;
          }
        }
      }
    } catch {
      confirmations = 0;
      stableVersion = null;
    } finally {
      window.clearTimeout(deadline);
    }
    if (!ready) timer = window.setTimeout(poll, 2000);
  }
  timer = window.setTimeout(poll, 2000);
})();

