export const UPDATE_STATUS_ENDPOINT = '/api/update/status';
export const UPDATE_APPLY_ENDPOINT = '/api/update/apply';
const HEALTH_ENDPOINT = '/api/health';

const IN_PROGRESS_STATES = new Set([
  'APPLY_REQUESTED',
  'WAITING_FOR_DASHBOARD_STOP',
  'APPLYING',
  'SMOKE_TEST',
]);
const FAILED_STATES = new Set(['ROLLBACK_COMPLETE', 'RECOVERY_REQUIRED', 'ERROR']);

export class UpdateApplyError extends Error {
  constructor(code, message) {
    super(message);
    this.name = 'UpdateApplyError';
    this.code = code;
  }
}

export function describeUpdateStatus(status) {
  const currentVersion = typeof status?.currentVersion === 'string' ? status.currentVersion : '--';
  const stagedVersion = typeof status?.stagedVersion === 'string' ? status.stagedVersion : null;
  const state = typeof status?.state === 'string' ? status.state : 'UNKNOWN';
  const updaterInstalled = status?.updaterInstalled === true;
  const pending = status?.pending === true;
  let statusText = 'Up to date';

  if (!updaterInstalled || state === 'UNAVAILABLE') {
    statusText = 'Updater unavailable';
  } else if (state === 'CHECKING') {
    statusText = 'Checking for updates...';
  } else if (state === 'UPDATE_AVAILABLE') {
    statusText = 'Update available';
  } else if (state === 'DOWNLOADING') {
    statusText = 'Downloading update...';
  } else if (state === 'VERIFYING') {
    statusText = 'Verifying update...';
  } else if (state === 'STAGING') {
    statusText = 'Staging update...';
  } else if (pending && state === 'PENDING_APPLY' && stagedVersion) {
    statusText = `Update ${stagedVersion} ready`;
  } else if (IN_PROGRESS_STATES.has(state)) {
    statusText = 'Update in progress...';
  } else if (state === 'ROLLBACK_COMPLETE') {
    statusText = 'Update failed; previous version restored.';
  } else if (state === 'RECOVERY_REQUIRED') {
    statusText = 'Updater maintenance required';
  } else if (state === 'ERROR' || state === 'UNKNOWN') {
    statusText = 'Update status unavailable';
  }

  return {
    currentVersion,
    stagedVersion,
    statusText,
    canApply: updaterInstalled && pending && state === 'PENDING_APPLY' && Boolean(stagedVersion),
  };
}

export async function requestUpdateApply(
  fetchImpl = window.fetch.bind(window),
  { timeoutMs = 65_000, setTimer = setTimeout, clearTimer = clearTimeout } = {},
) {
  const controller = new AbortController();
  const timer = setTimer(() => controller.abort(), timeoutMs);
  try {
    const response = await fetchImpl(UPDATE_APPLY_ENDPOINT, {
      method: 'POST',
      cache: 'no-store',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({}),
      signal: controller.signal,
    });
    let result = null;
    try { result = await response.json(); } catch {}
    if (!response.ok) {
      const code = typeof result?.error === 'string' ? result.error : 'request_rejected';
      throw new UpdateApplyError(code, `Update request rejected (${response.status})`);
    }
    if (result?.accepted !== true || result?.state !== 'APPLY_REQUESTED') {
      throw new UpdateApplyError('invalid_response', 'Update request response was invalid');
    }
    return result;
  } catch (error) {
    if (error instanceof UpdateApplyError) throw error;
    if (controller.signal.aborted) {
      throw new UpdateApplyError('request_timeout', 'Update request timed out');
    }
    throw error;
  } finally {
    clearTimer(timer);
  }
}

async function readJson(fetchImpl, endpoint) {
  const separator = endpoint.includes('?') ? '&' : '?';
  const response = await fetchImpl(`${endpoint}${separator}poll=${Date.now()}`, { cache: 'no-store' });
  if (!response.ok) throw new Error(`Local status unavailable (${response.status})`);
  return response.json();
}

function isExpectedDashboardHealth(health, expectedVersion) {
  return (
    typeof expectedVersion === 'string'
    && health?.status === 'ok'
    && health?.appId === 'family-dashboard'
    && health?.appVersion === expectedVersion
    && health?.mode === 'production'
    && health?.processIntegrity === 'nonElevated'
  );
}

async function readDocument(fetchImpl, endpoint) {
  const separator = endpoint.includes('?') ? '&' : '?';
  const response = await fetchImpl(
    `${endpoint}${separator}recoveryDocument=${Date.now()}`,
    { cache: 'no-store' },
  );
  if (!response.ok) throw new Error(`Dashboard document unavailable (${response.status})`);
}

function defaultWait(milliseconds) {
  return new Promise((resolve) => window.setTimeout(resolve, milliseconds));
}

export function createSingleFlightNavigation(navigate) {
  let started = false;
  return () => {
    if (started) return false;
    started = true;
    navigate();
    return true;
  };
}

export async function confirmDashboardNavigationReady({
  expectedVersion,
  initialHealth,
  fetchImpl = window.fetch.bind(window),
  wait = defaultWait,
  confirmationCount = 3,
  confirmationIntervalMs = 350,
  documentEndpoint = '/',
} = {}) {
  if (!isExpectedDashboardHealth(initialHealth, expectedVersion)) return false;
  for (let confirmation = 1; confirmation < confirmationCount; confirmation += 1) {
    await wait(confirmationIntervalMs);
    try {
      const health = await readJson(fetchImpl, HEALTH_ENDPOINT);
      if (!isExpectedDashboardHealth(health, expectedVersion)) return false;
    } catch {
      return false;
    }
  }
  try {
    await readDocument(fetchImpl, documentEndpoint);
    return true;
  } catch {
    return false;
  }
}

export async function pollForDashboardRecovery({
  expectedVersion,
  previousVersion,
  fetchImpl = window.fetch.bind(window),
  wait = defaultWait,
  intervalMs = 2_000,
  maxAttempts = null,
  maxShutdownAttempts = 15,
  maxRecoveryAttempts = 300,
  confirmationCount = 3,
  confirmationIntervalMs = 350,
  documentEndpoint = '/',
  onPhase = () => {},
} = {}) {
  let outageObserved = false;
  let shutdownAttempts = 0;
  let recoveryAttempts = 0;
  const shutdownLimit = Number.isInteger(maxAttempts) ? maxAttempts : maxShutdownAttempts;
  const recoveryLimit = Number.isInteger(maxAttempts) ? maxAttempts : maxRecoveryAttempts;
  while (shutdownAttempts < shutdownLimit || (outageObserved && recoveryAttempts < recoveryLimit)) {
    try {
      const health = await readJson(fetchImpl, HEALTH_ENDPOINT);
      if (isExpectedDashboardHealth(health, expectedVersion)
        && (outageObserved || expectedVersion !== previousVersion)) {
        const ready = await confirmDashboardNavigationReady({
          expectedVersion,
          initialHealth: health,
          fetchImpl,
          wait,
          confirmationCount,
          confirmationIntervalMs,
          documentEndpoint,
        });
        if (ready) {
          return { outcome: 'updated', version: expectedVersion, outageObserved };
        }
      }
      if (outageObserved) {
        try {
          const status = await readJson(fetchImpl, UPDATE_STATUS_ENDPOINT);
          if (
            status?.state === 'ROLLBACK_COMPLETE'
            || status?.rollbackResult === 'PASS'
            || status?.lastResult === 'INTERRUPTED_ROLLBACK'
          ) {
            return { outcome: 'rolled_back', version: health?.appVersion || previousVersion };
          }
          if (FAILED_STATES.has(status?.state) || status?.lastResult === 'FAIL') {
            return { outcome: 'failed', version: health?.appVersion || previousVersion };
          }
        } catch {
          // The restored server may become healthy just before its status endpoint is ready.
        }
      }
      onPhase(outageObserved ? 'server_restored_waiting' : 'waiting_for_shutdown');
      if (outageObserved) recoveryAttempts += 1;
      else shutdownAttempts += 1;
    } catch {
      outageObserved = true;
      onPhase('server_offline');
      recoveryAttempts += 1;
    }
    if (!outageObserved && shutdownAttempts >= shutdownLimit) {
      return { outcome: 'shutdown_timeout', outageObserved: false };
    }
    if (outageObserved && recoveryAttempts >= recoveryLimit) break;
    await wait(intervalMs);
  }
  return { outcome: 'timeout', outageObserved };
}

// Recovery always leaves the preview/mock query space, even when Apply began there.
export function recoverProductionDashboard(location = window.location) {
  location.replace('/?display=1&theme=auto&calendar=google&eew=production');
}
