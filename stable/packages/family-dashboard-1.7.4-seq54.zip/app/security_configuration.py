"""Pure, fail-closed Defender configuration classification; no device or file I/O."""
from datetime import datetime, timezone
import re

CONFIGURATION_CLASSIFICATIONS = frozenset({'CONFIGURATION_CHANGE_ONLY','SECURITY_SENSITIVE','THREAT_CORRELATED','INSUFFICIENT_EVIDENCE'})
CONFIGURATION_SETTINGS = frozenset({'AV_SIGNATURE_VERSION','AS_SIGNATURE_VERSION','ENGINE_VERSION','SECURITY_POLICY','UNKNOWN'})
SAFE_CONFIGURATION_SETTINGS = frozenset({'AV_SIGNATURE_VERSION','AS_SIGNATURE_VERSION','ENGINE_VERSION'})
CONFIGURATION_STATUSES = frozenset({'REVIEW_REQUIRED','SUPERSEDED_CONFIGURATION_CHANGE'})
CONFIGURATION_CLASSIFIER_VERSION = 1
_SAFE_PATHS = {r'signature updates\avsignatureversion':('AV_SIGNATURE_VERSION','AntivirusSignatureVersion'),
               r'signature updates\assignatureversion':('AS_SIGNATURE_VERSION','AntispywareSignatureVersion'),
               r'engine\engineversion':('ENGINE_VERSION','AMEngineVersion')}
_PROTECTION = ('RealTimeProtectionEnabled','AMServiceEnabled','AntivirusEnabled','BehaviorMonitorEnabled','IoavProtectionEnabled','NISEnabled')
_THREAT_KEYS = frozenset({'detectionid','threatid','threatname','actionname','action','actionattempted','actionsuccess','errorcode','resources','isactive'})

def _time(value):
    if not isinstance(value,str) or len(value)>64:return None
    try:
        at=datetime.fromisoformat(value.replace('Z','+00:00'))
        return at.astimezone(timezone.utc) if at.tzinfo else None
    except (ValueError,OverflowError):return None

def _fields(data):
    if not isinstance(data,dict) or len(data)>64:return None
    result={}
    for key,value in data.items():
        if not isinstance(key,str) or len(key)>96:return None
        alias=re.sub('[^a-z0-9]','',key.lower())
        if alias in result:return None
        result[alias]=value
    return result

def _path(value):
    if not isinstance(value,str):return None
    path=value.strip().casefold()
    prefix=r'hklm\software\microsoft\windows defender' + chr(92)
    return path[len(prefix):] if path.startswith(prefix) else path

def _value(value):
    if not isinstance(value,str) or not 1<=len(value)<512 or value.count('=')!=1:return None
    path,version=value.split('=',1)
    return _path(path),version.strip()

def _version(value):
    if not isinstance(value,str) or len(value)>64 or not re.fullmatch(r'[0-9]+(?:\.[0-9]+){1,5}',value):return None
    parts=tuple(int(x) for x in value.split('.'))
    if any(x>2**31-1 for x in parts):return None
    return parts+(0,)*(6-len(parts))

def _identity(value):
    if type(value) is int:return str(value) if 0<=value<2**63 else None
    if isinstance(value,str) and value.upper()!='UNKNOWN' and re.fullmatch(r'[A-Za-z0-9{}-]{1,80}',value):return value.casefold()
    return None

def _threat_identity(value):
    if type(value) is int:return str(value) if 0<=value<2**63 else None
    if isinstance(value,str) and re.fullmatch(r'[0-9]{1,19}',value):
        number=int(value)
        return str(number) if number<2**63 else None
    return None

def _history_correlation(snapshot,at,now):
    """Separate proved correlation, uncertain history, and dated completed lifecycles."""
    events=[e for e in snapshot['events'] if e['eventId'] in {1116,1117,1118,1119}]
    # Temporal proximity is evidence; a missing/future clock is only uncertainty.
    uncertain=False
    for event in events:
        clock=_time(event.get('at'))
        if clock is None or clock>now:uncertain=True
        elif abs((clock-at).total_seconds())<=600:return 'THREAT_CORRELATED'
    threats=snapshot['threats'];detections=snapshot['detections']
    if not threats and not detections:return 'INSUFFICIENT_EVIDENCE' if events else None
    # The collector bounds these queries; a full result cannot prove completeness.
    if len(threats)>=32 or len(detections)>=64:uncertain=True
    by_threat={};cleared={};seen_detections=set();covered=set()
    def resources_valid(row):
        values=row.get('Resources',[])
        return isinstance(values,list) and len(values)<=8 and all(isinstance(v,str) and len(v)<512 for v in values)
    for row in threats:
        if not isinstance(row,dict):uncertain=True;continue
        tid=_threat_identity(row.get('ThreatID'))
        if tid is None or tid in by_threat:uncertain=True;continue
        by_threat[tid]=row
        if row.get('IsActive') is not False or not resources_valid(row):uncertain=True
    for row in detections:
        if not isinstance(row,dict):uncertain=True;continue
        tid=_threat_identity(row.get('ThreatID'));did=_identity(row.get('DetectionID'))
        initial=_time(row.get('InitialDetectionTime'));changed=_time(row.get('LastThreatStatusChangeTime'));remediated=_time(row.get('RemediationTime'))
        clocks=(initial,changed,remediated)
        if any(clock is None or clock>now for clock in clocks):uncertain=True;continue
        if initial>changed or initial>remediated:uncertain=True;continue
        if any(abs((clock-at).total_seconds())<=600 for clock in clocks):return 'THREAT_CORRELATED'
        threat=by_threat.get(tid)
        completed=all(key not in row or (type(row[key]) is int and row[key]==0) or
            (isinstance(row[key],str) and re.fullmatch(r'(?:0[xX])?0{1,16}',row[key]))
            for key in ('ThreatStatusErrorCode','AdditionalActionsBitMask'))
        if (not completed or tid is None or did is None or did in seen_detections or threat is None or
                threat.get('IsActive') is not False or row.get('ActionSuccess') is not True or
                not resources_valid(row) or not resources_valid(threat) or
                any((at-clock).total_seconds()<=600 for clock in clocks)):
            uncertain=True;continue
        seen_detections.add(did);covered.add(tid);cleared[(did,tid)]=(initial,max(changed,remediated))
    if set(by_threat)!=covered:uncertain=True
    for event in events:
        clock=_time(event.get('at'));data=_fields(event.get('data'))
        if clock is None or clock>now or data is None:uncertain=True;continue
        key=(_identity(data.get('detectionid')),_threat_identity(data.get('threatid')))
        lifecycle=cleared.get(key)
        if lifecycle is None or not lifecycle[0]<=clock<=lifecycle[1] or (at-clock).total_seconds()<=600:uncertain=True
    return 'INSUFFICIENT_EVIDENCE' if uncertain else None

def classify_configuration_event(event,snapshot,now):
    """Return only fixed enums; absent or contradictory proof always remains reviewable."""
    def result(classification='INSUFFICIENT_EVIDENCE',setting='UNKNOWN',reason='INVALID_EVENT'):
        return {'classification':classification,'setting':setting,'reason':reason}
    if not isinstance(event,dict) or type(event.get('eventId')) is not int or event['eventId']!=5007:return result()
    if type(event.get('recordId')) is not int or not 0<event['recordId']<2**63:return result()
    if type(event.get('version')) is not int or event['version']!=0:return result()
    if event.get('provider','Microsoft-Windows-Windows Defender')!='Microsoft-Windows-Windows Defender':return result()
    at=_time(event.get('at'))
    if not isinstance(now,datetime) or now.tzinfo is None or at is None or at>now:return result()
    fields=_fields(event.get('data'))
    if fields is None:return result(reason='INCOMPLETE_CONFIGURATION_VALUES')
    if any(key in _THREAT_KEYS and value not in (None,'') for key,value in fields.items()):
        return result('THREAT_CORRELATED',reason='THREAT_EVIDENCE_PRESENT')
    if not isinstance(snapshot,dict):return result(reason='SOURCE_INCOMPLETE')
    for key in ('events','threats','detections'):
        if not isinstance(snapshot.get(key),list):return result(reason='SOURCE_INCOMPLETE')
    if any(not isinstance(e,dict) or type(e.get('eventId')) is not int for e in snapshot['events']):return result(reason='SOURCE_INCOMPLETE')
    correlation=_history_correlation(snapshot,at,now)
    if correlation:
        return result(correlation,reason='THREAT_EVIDENCE_PRESENT' if correlation=='THREAT_CORRELATED' else 'THREAT_CORRELATION_UNCERTAIN')
    old=_value(fields.get('oldvalue'));new=_value(fields.get('newvalue'))
    # Security-policy evidence is reviewable even after current protection recovers.
    paths=[x[0] for x in (old,new) if x]
    if any(re.search(r'exclusions?|disable|realtime|spynet|cloud|tamper|exploit|(?:^|\\)asr(?:\\|$)|policy|policies|ioav|behavior|nis|network|puaprotection|controlledfolder',p) for p in paths):
        return result('SECURITY_SENSITIVE','SECURITY_POLICY','SECURITY_POLICY_CHANGE')
    if not old or not new:return result(reason='INCOMPLETE_CONFIGURATION_VALUES')
    if old[0]!=new[0] or ('settingname' in fields and _path(fields['settingname'])!=new[0]):return result(reason='SETTING_MISMATCH')
    known=_SAFE_PATHS.get(new[0])
    if known is None:return result(reason='UNKNOWN_SETTING')
    setting,current_key=known
    if snapshot.get('available') is not True or snapshot.get('error')!='NONE' or snapshot.get('sourceErrors')!=[] or snapshot.get('logReset') is not False:
        return result(setting=setting,reason='SOURCE_INCOMPLETE')
    protection=snapshot.get('protection')
    if not isinstance(protection,dict) or protection.get('serviceStatus')!='RUNNING' or any(protection.get(k) is not True for k in _PROTECTION):
        return result(setting=setting,reason='PROTECTION_NOT_HEALTHY')
    previous=_version(old[1]);changed=_version(new[1]);current=_version(protection.get(current_key))
    if previous is None or changed is None or previous>changed:return result(setting=setting,reason='INVALID_VERSION_TRANSITION')
    if current is None or changed>current:return result(setting=setting,reason='CURRENT_VERSION_UNVERIFIED')
    return result('CONFIGURATION_CHANGE_ONLY',setting,'KNOWN_SAFE_METADATA_CHANGE')

def superseded_configuration_case(case):
    """Only a complete benign5007 proof may leave the pending review count."""
    if not isinstance(case,dict) or case.get('EVENT_SOURCE')!='MICROSOFT_DEFENDER' or type(case.get('EVENT_ID')) is not int or case['EVENT_ID']!=5007:return False
    if case.get('ALERT_LEVEL')!='WARNING' or case.get('REASON_CODES')!=['CONFIGURATION_CHANGED']:return False
    if case.get('CONFIGURATION_STATUS')!='SUPERSEDED_CONFIGURATION_CHANGE' or case.get('CONFIGURATION_CLASSIFICATION')!='CONFIGURATION_CHANGE_ONLY':return False
    if not isinstance(case.get('CONFIGURATION_SETTING'),str) or case.get('CONFIGURATION_SETTING') not in SAFE_CONFIGURATION_SETTINGS or type(case.get('CONFIGURATION_CLASSIFIER_VERSION')) is not int or case['CONFIGURATION_CLASSIFIER_VERSION']!=1:return False
    reviewed=_time(case.get('CONFIGURATION_REVIEWED_AT'));seen=_time(case.get('CONFIGURATION_LAST_SEEN_AT'));detected=_time(case.get('DETECTED_AT'))
    if not reviewed or not seen or not detected or not detected<=seen<=reviewed:return False
    if type(case.get('CONFIGURATION_SAMPLE_COUNT')) is not int or not 1<=case['CONFIGURATION_SAMPLE_COUNT']<2**63:return False
    for key in ('THREAT_ID','THREAT_NAME','THREAT_CATEGORY','DEFENDER_SEVERITY','DETECTION_SOURCE','DETECTION_METHOD','ACTION_ATTEMPTED','ACTION_RESULT','ERROR_CODE'):
        if case.get(key)!='UNKNOWN':return False
    if case.get('RESOURCE_CLASS') not in ([],['UNKNOWN']) or case.get('RESOURCE_TYPES')!=[] or case.get('RESOURCE_HASHES')!=[]:return False
    related=case.get('RELATED_EVENTS')
    if not isinstance(related,list) or any(not isinstance(e,dict) or e.get('EVENT_ID')!=5007 for e in related):return False
    if case.get('ISOLATION_RESULT')!='DISABLED':return False
    missing=case.get('MISSING_EVIDENCE')
    if not isinstance(missing,list) or any(x in missing for x in ('EVIDENCE_NOT_SAVED','ORIGINAL_RAW_EVIDENCE')):return False
    if any(case.get(key) not in (None,'','UNKNOWN') for key in ('DetectionID','DETECTION_ID')):return False
    return True


# A display category is not a benign verdict or a case-state transition.
_REVIEW_FIELDS = frozenset({
    'CASE_ID','DETECTED_AT','ALERT_LEVEL','EVENT_SOURCE','EVENT_ID','RECORD_ID',
    'THREAT_NAME','THREAT_ID','THREAT_CATEGORY','DEFENDER_SEVERITY','DETECTION_SOURCE',
    'DETECTION_METHOD','ACTION_ATTEMPTED','ACTION_RESULT','ERROR_CODE',
    'DEFENDER_PROTECTION_STATE','SIGNATURE_VERSION','SIGNATURE_AGE','RELATED_EVENTS',
    'WIFI_STATE','ISOLATION_RESULT','HUMAN_REVIEW_REQUIRED','ACKNOWLEDGED','REASON_CODES',
    'MISSING_EVIDENCE','RESOURCE_CLASS','RESOURCE_TYPES','RESOURCE_HASHES',
    'CONFIGURATION_CLASSIFICATION','CONFIGURATION_SETTING','CONFIGURATION_STATUS',
    'CONFIGURATION_SAMPLE_COUNT','CONFIGURATION_LAST_SEEN_AT','CONFIGURATION_REVIEWED_AT',
    'CONFIGURATION_CLASSIFIER_VERSION','CONFIGURATION_REVIEW_ONLY'})
_REVIEW_MISSING = frozenset({'MATCHING_DETECTION','MATCHING_ACTIVE_THREAT','EXPLICIT_SEVERITY',
    'ACTION_SUCCESS','PROTECTION_STATE','EVENT_TIME','THREAT_ID','DETECTION_ID',
    'CURRENT_EVIDENCE','ORIGINAL_RAW_EVIDENCE'})
_REVIEW_PROTECTION = frozenset({'SERVICE_STATUS','REAL_TIME_PROTECTION','ANTIMALWARE_SERVICE',
    'ANTIVIRUS','BEHAVIOR_MONITOR','IOAV_PROTECTION','NETWORK_INSPECTION'})

_REVIEW_CONFIGURATION_FIELDS = frozenset(k for k in _REVIEW_FIELDS if k.startswith('CONFIGURATION_') and k!='CONFIGURATION_REVIEW_ONLY')

def configuration_review_case(case):
    """Strict unresolved 5007 display partition; a negative survives lossy projection."""
    if not isinstance(case,dict) or set(case)-_REVIEW_FIELDS:return False
    if 'CONFIGURATION_REVIEW_ONLY' in case and case['CONFIGURATION_REVIEW_ONLY'] is not True:return False
    supplied=set(case)&_REVIEW_CONFIGURATION_FIELDS
    if not supplied:
        case=dict(case,CONFIGURATION_CLASSIFICATION='INSUFFICIENT_EVIDENCE',CONFIGURATION_SETTING='UNKNOWN',
            CONFIGURATION_STATUS='REVIEW_REQUIRED',CONFIGURATION_SAMPLE_COUNT=1,
            CONFIGURATION_LAST_SEEN_AT=case.get('DETECTED_AT'),CONFIGURATION_REVIEWED_AT=None,
            CONFIGURATION_CLASSIFIER_VERSION=0)
    elif supplied!=_REVIEW_CONFIGURATION_FIELDS:return False
    if case.get('EVENT_SOURCE')!='MICROSOFT_DEFENDER' or type(case.get('EVENT_ID')) is not int or case['EVENT_ID']!=5007:return False
    if case.get('ALERT_LEVEL')!='WARNING' or case.get('REASON_CODES')!=['CONFIGURATION_CHANGED']:return False
    if case.get('CONFIGURATION_CLASSIFICATION')!='INSUFFICIENT_EVIDENCE' or case.get('CONFIGURATION_STATUS')!='REVIEW_REQUIRED':return False
    if not isinstance(case.get('CONFIGURATION_SETTING'),str) or case['CONFIGURATION_SETTING'] not in SAFE_CONFIGURATION_SETTINGS|{'UNKNOWN'}:return False
    if type(case.get('CONFIGURATION_CLASSIFIER_VERSION')) is not int or case['CONFIGURATION_CLASSIFIER_VERSION'] not in (0,1):return False
    if case.get('CONFIGURATION_REVIEWED_AT','missing') is not None or case.get('HUMAN_REVIEW_REQUIRED') is not True:return False
    if type(case.get('ACKNOWLEDGED')) is not bool:return False
    if not isinstance(case.get('CASE_ID'),str) or not re.fullmatch(r'[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}',case['CASE_ID']):return False
    for key in ('RECORD_ID','CONFIGURATION_SAMPLE_COUNT'):
        if type(case.get(key)) is not int or not 1<=case[key]<=9007199254740991:return False
    detected=_time(case.get('DETECTED_AT'));seen=_time(case.get('CONFIGURATION_LAST_SEEN_AT'))
    if detected is None or seen is None or seen<detected:return False
    if case['CONFIGURATION_CLASSIFIER_VERSION']==0 and (case['CONFIGURATION_SETTING']!='UNKNOWN' or case['CONFIGURATION_SAMPLE_COUNT']!=1 or seen!=detected):return False
    for key in ('THREAT_ID','THREAT_NAME','THREAT_CATEGORY','DEFENDER_SEVERITY',
                'DETECTION_SOURCE','DETECTION_METHOD','ACTION_ATTEMPTED','ACTION_RESULT','ERROR_CODE'):
        if case.get(key)!='UNKNOWN':return False
    for key in ('RELATED_EVENTS','RESOURCE_TYPES','RESOURCE_HASHES'):
        if case.get(key)!=[]:return False
    if case.get('RESOURCE_CLASS') not in ([],['UNKNOWN']):return False
    if case.get('ISOLATION_RESULT')!='DISABLED' or case.get('WIFI_STATE') not in ('ON','OFF','UNKNOWN','NOT_AVAILABLE'):return False
    missing=case.get('MISSING_EVIDENCE')
    if not isinstance(missing,list) or len(missing)>32 or any(not isinstance(v,str) or v not in _REVIEW_MISSING for v in missing):return False
    protection=case.get('DEFENDER_PROTECTION_STATE')
    if not isinstance(protection,dict) or set(protection)!=_REVIEW_PROTECTION:return False
    for key,value in protection.items():
        if value not in (('RUNNING','UNKNOWN') if key=='SERVICE_STATUS' else ('ON','UNKNOWN')):return False
    version=case.get('SIGNATURE_VERSION')
    if version!='UNKNOWN' and (not isinstance(version,str) or len(version)>64 or not re.fullmatch(r'[0-9]+(?:\.[0-9]+){1,5}',version)):return False
    age=case.get('SIGNATURE_AGE')
    if age!='UNKNOWN' and (type(age) is not int or not 0<=age<=315576000):return False
    return True
