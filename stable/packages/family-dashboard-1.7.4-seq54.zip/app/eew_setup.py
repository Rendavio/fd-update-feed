"""On-demand, local-only EEW setup. No audio download, upload, playback or source logging."""
from __future__ import annotations
import contextlib
import ctypes
import getpass
import json
import os
import re
import stat
import subprocess
import threading
import time
import unicodedata
import uuid
from pathlib import Path

from eew_private_audio import (
    MAX_BYTES, ROLES, PrivateAudioError, secure_file, locked_chain,
    registration_transaction, validate_pcm_wav, _local_path,
)

MAX_ENTRIES = 1024
MAX_CANDIDATES = 8
SCAN_SECONDS = 5
SAFE_ERRORS = frozenset({
    "ambiguous", "not_found", "scan_limit", "validation_failed", "unsafe_source",
    "registration_failed", "verification_failed", "unavailable",
    "picker_failed", "picker_timeout", "cancelled",
})
STATES = {"IDLE", "RUNNING", "COMPLETE", "NEEDS_SELECTION", "PARTIAL", "CANCELLED", "FAILED"}
SOUNDS = {"READY", "MISSING", "INVALID"}
ROLE_ORDER = ("production", "training")
_EEW = re.compile(r"(?<![a-z0-9])eew(?![a-z0-9])|緊急地震速報")
_PRODUCTION = re.compile(r"本番|(?<![a-z0-9])(?:production|actual|real|live)(?![a-z0-9])")
_TRAINING = re.compile(r"訓練|(?<![a-z0-9])(?:training|drill|test)(?![a-z0-9])")

class SetupError(ValueError):
    def __init__(self, category):
        self.category = category if category in SAFE_ERRORS else "unavailable"
        super().__init__(self.category)

def _normal_name(name):
    return unicodedata.normalize("NFKC", name).casefold()

def is_eew_candidate(name):
    if type(name) is not str or not 1 <= len(name) <= 255 or any(c in name for c in "/\\:\0"):
        return False
    value = _normal_name(name)
    return value.endswith(".wav") and _EEW.search(value) is not None

def _name_role(name):
    if not is_eew_candidate(name):
        return None
    value = _normal_name(name)
    production = _PRODUCTION.search(value) is not None
    training = _TRAINING.search(value) is not None
    return ("production" if production else "training") if production != training else None

def infer_role(name, raw, registered):
    if not is_eew_candidate(name):
        return None
    value = _normal_name(name)
    if _PRODUCTION.search(value) and _TRAINING.search(value):
        return None
    labelled = _name_role(name)
    matched = [role for role in ROLE_ORDER if registered.get(role) is not None and registered[role] == raw]
    if len(matched) > 1 or (matched and labelled and matched[0] != labelled):
        return None
    return labelled or (matched[0] if matched else None)

def ensure_setup_user():
    if os.name != "nt" or getpass.getuser().casefold() != "dashboardadmin":
        raise SetupError("unavailable")
    if ctypes.windll.shell32.IsUserAnAdmin():
        raise SetupError("unavailable")

def windows_downloads():
    if os.name != "nt":
        raise SetupError("unavailable")
    folder_id = ctypes.create_string_buffer(uuid.UUID("374de290-123f-4565-9164-39c4925e467b").bytes_le)
    result = ctypes.c_void_p()
    shell = ctypes.WinDLL("shell32", use_last_error=True)
    ole = ctypes.WinDLL("ole32")
    shell.SHGetKnownFolderPath.argtypes = [ctypes.c_void_p, ctypes.c_uint32, ctypes.c_void_p, ctypes.POINTER(ctypes.c_void_p)]
    shell.SHGetKnownFolderPath.restype = ctypes.c_long
    ole.CoTaskMemFree.argtypes = [ctypes.c_void_p]
    try:
        if shell.SHGetKnownFolderPath(ctypes.byref(folder_id), 0, None, ctypes.byref(result)) != 0 or not result:
            raise SetupError("unavailable")
        return _local_path(Path(ctypes.wstring_at(result.value)))
    finally:
        if result:
            ole.CoTaskMemFree(result)

class _SourceLease:
    def __init__(self, stream):
        self.stream = stream
    def read(self):
        info = os.fstat(self.stream.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or not 1 <= info.st_size <= MAX_BYTES:
            raise PrivateAudioError("invalid")
        raw = self.stream.read(MAX_BYTES + 1)
        if len(raw) != info.st_size:
            raise PrivateAudioError("invalid")
        return raw

@contextlib.contextmanager
def open_setup_source(path):
    with secure_file(path, source_acl=True) as stream:
        yield _SourceLease(stream)

def _stop_process(process):
    if process.poll() is None:
        process.terminate()
    try:
        process.communicate(timeout=5)
    except subprocess.TimeoutExpired:
        process.kill()
        process.communicate(timeout=5)

@contextlib.contextmanager
def owned_picker_process(process):
    # Transient job, not a service. Parent death closes the handle and kills its picker.
    class Basic(ctypes.Structure):
        _fields_ = [("processTime", ctypes.c_int64), ("jobTime", ctypes.c_int64),
                    ("flags", ctypes.c_uint32), ("minWorking", ctypes.c_size_t), ("maxWorking", ctypes.c_size_t),
                    ("processCount", ctypes.c_uint32), ("affinity", ctypes.c_size_t),
                    ("priority", ctypes.c_uint32), ("scheduling", ctypes.c_uint32)]
    class Io(ctypes.Structure):
        _fields_ = [(name, ctypes.c_uint64) for name in ("readOps","writeOps","otherOps","readBytes","writeBytes","otherBytes")]
    class Extended(ctypes.Structure):
        _fields_ = [("basic", Basic), ("io", Io), ("processMemory", ctypes.c_size_t),
                    ("jobMemory", ctypes.c_size_t), ("peakProcess", ctypes.c_size_t), ("peakJob", ctypes.c_size_t)]
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.CreateJobObjectW.argtypes = [ctypes.c_void_p, ctypes.c_wchar_p]
    kernel.CreateJobObjectW.restype = ctypes.c_void_p
    kernel.SetInformationJobObject.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_void_p, ctypes.c_uint32]
    kernel.AssignProcessToJobObject.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    kernel.CloseHandle.argtypes = [ctypes.c_void_p]
    job = kernel.CreateJobObjectW(None, None)
    try:
        info = Extended()
        info.basic.flags = 0x2000  # JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
        if not job or not kernel.SetInformationJobObject(job, 9, ctypes.byref(info), ctypes.sizeof(info)) or not kernel.AssignProcessToJobObject(job, int(process._handle)):
            _stop_process(process)
            raise SetupError("picker_failed")
        yield
    finally:
        if job:
            kernel.CloseHandle(job)

def native_picker(role, downloads, cancel):
    if role not in ROLES or cancel.is_set():
        return None
    executable = Path(os.environ.get("SystemRoot", r"C:\Windows")) / "System32/WindowsPowerShell/v1.0/powershell.exe"
    helper = Path(r"C:\FamilyDashboard\launcher\Import-EewPrivateSounds.ps1")
    argv = [str(executable), "-NoLogo", "-NoProfile", "-STA", "-WindowStyle", "Hidden",
            "-ExecutionPolicy", "Bypass", "-File", str(helper), "-PickerRole", role]
    process = subprocess.Popen(argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                               creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    body = json.dumps({"initialDirectory": str(downloads)}, ensure_ascii=False).encode("utf-8")
    deadline = time.monotonic() + 120
    first = True
    try:
        with owned_picker_process(process):
            while True:
                if cancel.is_set():
                    _stop_process(process)
                    return None
                if time.monotonic() >= deadline:
                    _stop_process(process)
                    raise SetupError("picker_timeout")
                try:
                    raw, _ = process.communicate(input=body if first else None, timeout=0.2)
                    break
                except subprocess.TimeoutExpired:
                    first = False
            if process.returncode or len(raw) > 65536:
                raise SetupError("picker_failed")
            value = json.loads(raw.decode("utf-8"))
            if type(value) is not dict or set(value) != {"selected", "path"} or type(value["selected"]) is not bool:
                raise SetupError("picker_failed")
            if value["selected"] is False and value["path"] is None:
                return None
            if value["selected"] is not True or type(value["path"]) is not str or not 1 <= len(value["path"]) <= 32767:
                raise SetupError("picker_failed")
            return _local_path(Path(value["path"]))
    except SetupError:
        if process.poll() is None:
            _stop_process(process)
        raise
    except (OSError, UnicodeError, ValueError):
        if process.poll() is None:
            _stop_process(process)
        raise SetupError("picker_failed") from None


def safe_result(result, fallback=None):
    fallback = fallback or {role: "MISSING" for role in ROLE_ORDER}
    result = result if type(result) is dict else {}
    raw_sounds = result.get("sounds") if type(result.get("sounds")) is dict else fallback
    selection = result.get("needsSelection") if type(result.get("needsSelection")) is list else []
    state = result.get("state")
    error = result.get("error")
    return {
        "state": state if type(state) is str and state in STATES else "FAILED",
        "sounds": {role: raw_sounds.get(role) if type(raw_sounds.get(role)) is str and raw_sounds.get(role) in SOUNDS else "INVALID" for role in ROLE_ORDER},
        "needsSelection": [role for role in ROLE_ORDER if role in selection],
        "error": error if type(error) is str and error in SAFE_ERRORS else None,
    }

class EewSetupEngine:
    def __init__(self, store, *, downloads_provider=windows_downloads, entries=os.scandir,
                 source_open=open_setup_source, guard=ensure_setup_user,
                 directory_guard=lambda path: locked_chain(path, source_acl=True),
                 transaction=registration_transaction, picker=native_picker, clock=time.monotonic):
        self.store = store
        self.downloads_provider = downloads_provider
        self.entries = entries
        self.source_open = source_open
        self.guard = guard
        self.directory_guard = directory_guard
        self.transaction = transaction
        self.picker = picker
        self.clock = clock

    def _states(self):
        try:
            return safe_result({"state": "IDLE", "sounds": self.store.status()})["sounds"]
        except Exception:
            return {role: "INVALID" for role in ROLE_ORDER}

    def _result(self, state, needs=(), error=None):
        return safe_result({"state": state, "sounds": self._states(), "needsSelection": list(needs), "error": error})

    def _downloads(self):
        path = self.downloads_provider()
        # Never treat app/public/private data as a Downloads ingress.
        for root in (getattr(self.store, "root", None), getattr(self.store, "public_root", None)):
            if root is not None and path.resolve().is_relative_to(Path(root).resolve()):
                raise SetupError("unsafe_source")
        return path

    def _commit(self, role, raw, cancel):
        if cancel.is_set():
            raise SetupError("cancelled")
        with self.transaction():
            self.store.install_bytes(role, raw)
            installed = self.store.read(role)
            validate_pcm_wav(installed)
            if installed != raw:
                raise SetupError("verification_failed")
            if cancel.is_set():
                raise SetupError("cancelled")

    def scan(self, cancel):
        needs = set()
        error = None
        try:
            self.guard()
            if cancel.is_set():
                return self._result("CANCELLED")
            downloads = self._downloads()
            deadline = self.clock() + SCAN_SECONDS
            names = []
            with self.directory_guard(downloads):
                iterator = self.entries(downloads)
                try:
                    for index, entry in enumerate(iterator):
                        if cancel.is_set():
                            return self._result("CANCELLED")
                        if index >= MAX_ENTRIES or self.clock() > deadline:
                            raise SetupError("scan_limit")
                        if is_eew_candidate(entry.name):
                            if len(names) >= MAX_CANDIDATES:
                                raise SetupError("scan_limit")
                            if entry.is_file(follow_symlinks=False):
                                names.append(entry.name)
                finally:
                    close = getattr(iterator, "close", None)
                    if close:
                        close()
            if not names:
                return self._result("NEEDS_SELECTION", ROLE_ORDER, "not_found")
            registered = {}
            for role in ROLE_ORDER:
                try:
                    registered[role] = self.store.read(role)
                except (PrivateAudioError, OSError):
                    registered[role] = None
            planned = {role: [] for role in ROLE_ORDER}
            claimed = {role: 0 for role in ROLE_ORDER}
            unknown = False
            with contextlib.ExitStack() as stack:
                for name in names:
                    if cancel.is_set():
                        return self._result("CANCELLED")
                    if self.clock() > deadline:
                        raise SetupError("scan_limit")
                    hint = _name_role(name)
                    if hint:
                        claimed[hint] += 1
                    try:
                        lease = stack.enter_context(self.source_open(downloads / name))
                        raw = lease.read()
                        validate_pcm_wav(raw)
                        role = infer_role(name, raw, registered)
                        if role is None:
                            unknown = True
                        else:
                            planned[role].append(raw)
                    except (PrivateAudioError, OSError):
                        if hint:
                            needs.add(hint)
                        else:
                            unknown = True
                        error = "validation_failed"
                if unknown:
                    return self._result("NEEDS_SELECTION", ROLE_ORDER, "ambiguous")
                if planned["production"] and planned["training"] and planned["production"][0] == planned["training"][0]:
                    return self._result("NEEDS_SELECTION", ROLE_ORDER, "ambiguous")
                for role in ROLE_ORDER:
                    candidates = planned[role]
                    if len(candidates) > 1 or claimed[role] > 1:
                        needs.add(role)
                        error = "ambiguous"
                        continue
                    if role in needs:
                        continue
                    if not candidates:
                        if self._states()[role] != "READY":
                            needs.add(role)
                        continue
                    raw = candidates[0]
                    try:
                        self._commit(role, raw, cancel)
                    except SetupError as exc:
                        if exc.category == "cancelled":
                            return self._result("CANCELLED")
                        error = exc.category
                        needs.add(role)
                    except (PrivateAudioError, OSError):
                        needs.add(role)
                        error = "registration_failed"
            states = self._states()
            if needs:
                return self._result("NEEDS_SELECTION", needs, error or "not_found")
            if error or any(value != "READY" for value in states.values()):
                return self._result("PARTIAL", (), error or "registration_failed")
            return self._result("COMPLETE")
        except SetupError as exc:
            return self._result("CANCELLED" if exc.category == "cancelled" else "FAILED",
                                ROLE_ORDER if exc.category == "scan_limit" else (), exc.category)
        except Exception:
            return self._result("FAILED", (), "unavailable")

    def select(self, role, cancel, remaining):
        if role not in ROLES:
            return self._result("FAILED", (), "unavailable")
        needs = set(remaining)
        try:
            self.guard()
            downloads = self._downloads()
            source = self.picker(role, downloads, cancel)
            if cancel.is_set():
                return self._result("CANCELLED")
            if source is None:
                return self._result("NEEDS_SELECTION", needs)
            with self.source_open(source) as lease:
                raw = lease.read()
                validate_pcm_wav(raw)
                self._commit(role, raw, cancel)
            needs.discard(role)
            needs.update(key for key, value in self._states().items() if value != "READY")
            return self._result("NEEDS_SELECTION" if needs else "COMPLETE", needs)
        except SetupError as exc:
            return self._result("CANCELLED" if exc.category == "cancelled" else "PARTIAL", needs, exc.category)
        except (PrivateAudioError, OSError):
            return self._result("NEEDS_SELECTION", needs | {role}, "validation_failed")
        except Exception:
            return self._result("FAILED", needs, "unavailable")

class EewSetupControl:
    def __init__(self, engine):
        self.engine = engine
        self._lock = threading.RLock()
        self._cancel = threading.Event()
        self._thread = None
        self._job = None
        self._value = safe_result({"state": "IDLE", "sounds": engine.store.status()})

    def status(self):
        with self._lock:
            return {**safe_result(self._value), "jobId": self._job}

    def _start(self, role=None):
        with self._lock:
            if self._value["state"] == "RUNNING":
                return self.status()
            if role is not None and role not in self._value["needsSelection"]:
                raise ValueError("invalid_setup_request")
            job = str(uuid.uuid4())
            self._job = job
            cancel = threading.Event()
            self._cancel = cancel
            remaining = list(self._value["needsSelection"])
            self._value = safe_result({**self._value, "state": "RUNNING", "error": None})
            def work():
                try:
                    result = self.engine.scan(cancel) if role is None else self.engine.select(role, cancel, remaining)
                except Exception:
                    result = {"state": "FAILED", "sounds": self._value["sounds"], "error": "unavailable"}
                with self._lock:
                    if self._job == job:
                        self._value = safe_result(result, self._value["sounds"])
            self._thread = threading.Thread(target=work, name="eew-local-setup", daemon=True)
            self._thread.start()
            return self.status()

    def start(self):
        return self._start()

    def pick(self, role):
        if role not in ROLES:
            raise ValueError("invalid_setup_request")
        return self._start(role)

    def cancel(self, job_id):
        try:
            if type(job_id) is not str or str(uuid.UUID(job_id)) != job_id:
                raise ValueError()
        except (ValueError, AttributeError):
            raise ValueError("invalid_setup_request") from None
        with self._lock:
            matches = self._job == job_id and self._value["state"] == "RUNNING"
            if matches:
                self._cancel.set()
            return {"cancelled": matches}

    def wait(self, seconds):
        thread = self._thread
        if thread:
            thread.join(seconds)

