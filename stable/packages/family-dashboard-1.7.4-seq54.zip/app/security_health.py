"""Positive projections for monitor health. No commands or personal data."""
from datetime import datetime, timezone

MONITOR_REASONS = frozenset({
    'NONE','UNKNOWN','MONITOR_WORKER_NOT_RUNNING','DEFENDER_STATUS_QUERY_TIMEOUT',
    'DEFENDER_STATUS_QUERY_FAILED','DEFENDER_SERVICE_QUERY_FAILED','DEFENDER_SERVICE_STOPPED',
    'REALTIME_PROTECTION_OFF','DEFENDER_EVENT_LOG_UNAVAILABLE','DEFENDER_EVENT_LOG_DISABLED',
    'DEFENDER_EVENT_LOG_ACCESS_DENIED','EVENT_LOG_RESET_OR_ROLLOVER','CHECKPOINT_INVALID',
    'POLL_TIMEOUT','INVALID_SNAPSHOT','SOURCE_PARTIAL','STATE_WRITE_FAILED',
    'BEHAVIOR_PROTECTION_OFF','IOAV_PROTECTION_OFF','NETWORK_INSPECTION_OFF',
    'ANTIVIRUS_PROTECTION_OFF','ANTIMALWARE_SERVICE_OFF',
    'BEHAVIOR_QUERY_TIMEOUT','BEHAVIOR_SOURCE_ACCESS_DENIED','BEHAVIOR_SOURCE_UNAVAILABLE',
    'BEHAVIOR_INVALID_SNAPSHOT','BEHAVIOR_COVERAGE_PARTIAL','BEHAVIOR_DATA_STALE',
    'BEHAVIOR_WORKER_NOT_RUNNING','BEHAVIOR_STATE_WRITE_FAILED','BEHAVIOR_STATE_INTEGRITY_FAILED',
    'BEHAVIOR_BASELINE_UNAVAILABLE','BEHAVIOR_INITIALIZATION_FAILED','BEHAVIOR_START_FAILED',
    'BEHAVIOR_POLL_TIMEOUT'})
BEHAVIOR_TIMEOUT_STAGES = frozenset(('STARTUP', 'OS', 'PROCESS_PRE', 'TCP', 'PROCESS_POST', 'ROUTES', 'RUN', 'RUNONCE', 'STARTUP_FOLDER', 'TASKS', 'SERVICES', 'TASKS_QUERY', 'TASKS_METADATA', 'SERVICES_QUERY', 'SERVICES_METADATA', 'FIREWALL_PROFILE_QUERY', 'FIREWALL_PROFILE_METADATA', 'FIREWALL_RULE_QUERY', 'FIREWALL_RULE_METADATA', 'FIREWALL_APP_FILTER_QUERY', 'FIREWALL_APP_FILTER_METADATA', 'FIREWALL_PORT_FILTER_QUERY', 'FIREWALL_PORT_FILTER_METADATA', 'FIREWALL_ADDRESS_FILTER_QUERY', 'FIREWALL_ADDRESS_FILTER_METADATA', 'LOCAL_USER_QUERY', 'LOCAL_USER_METADATA', 'ADMIN_MEMBER_QUERY', 'ADMIN_MEMBER_METADATA', 'RDP', 'SMB_CONFIG', 'SMB_SHARES', 'SERIALIZE', 'COMPLETE'))


BEHAVIOR_PARTS = ('STARTUP_ITEMS', 'TASKS', 'SERVICES', 'FIREWALL_PROFILE',
    'FIREWALL_RULE', 'FIREWALL_APP_FILTER', 'FIREWALL_PORT_FILTER', 'FIREWALL_ADDRESS_FILTER', 'LOCAL_SECURITY')
STAGE_RESULTS = ('OK', 'EMPTY', 'PARTIAL', 'DENIED', 'UNAVAILABLE', 'CAPPED', 'ERROR', 'TIMEOUT')


def _bounded_count(value, limit):
    return value if type(value) is int and 0 <= value <= limit else None


def _public_stages(source):
    stages = []
    for row in source[:36] if isinstance(source, list) else []:
        if not isinstance(row, dict):
            continue
        stage = safe_timeout_stage(row.get('stage'))
        if stage not in BEHAVIOR_TIMEOUT_STAGES or row.get('result') not in STAGE_RESULTS:
            continue
        stages.append(dict(stage=stage, durationMs=_bounded_count(row.get('durationMs'), 75000),
                           count=_bounded_count(row.get('count'), 4096), result=row['result']))
    return stages


def public_collection_attempts(attempts):
    result = []
    for item in attempts[:2] if isinstance(attempts, list) else []:
        if not isinstance(item, dict) or item.get('mode') not in ('FULL', 'FAST', 'FULL_RETRY', 'FAST_RETRY'):
            continue
        part = item.get('part')
        stages = _public_stages(item.get('stages'))
        reason = safe_reason(item.get('reason'))
        result.append(dict(mode=item['mode'], part=part if part in ('ALL', 'FAST') + BEHAVIOR_PARTS else 'UNKNOWN',
                           reason=reason, timeoutStage=safe_timeout_stage(item.get('timeoutStage')) if reason=='BEHAVIOR_QUERY_TIMEOUT' else 'NONE',
                           durationMs=_bounded_count(item.get('durationMs'), 75000), stages=stages))
        probes = item.get('probes')
        if isinstance(probes, list):
            result[-1]['probes'] = [
                dict(part=probe['part'], durationMs=_bounded_count(probe.get('durationMs'), 75000),
                     budgetMs=_bounded_count(probe.get('budgetMs'), 20000), stages=_public_stages(probe.get('stages')))
                for probe in probes[:3] if isinstance(probe, dict) and probe.get('part') in ('ALL','FAST') + BEHAVIOR_PARTS]
    return result


def safe_timeout_stage(value):
    return value if isinstance(value,str) and value in BEHAVIOR_TIMEOUT_STAGES | {'NONE','UNKNOWN'} else 'UNKNOWN'


HEALTH_BOOLEAN_FIELDS=('serviceRunning','realtimeProtection','behaviorMonitoring','antimalwareService',
    'antivirus','ioavProtection','networkInspection','eventLogExists','eventLogEnabled','eventLogReadable')
LEGACY_MONITOR_CODES=frozenset({'MONITOR_UNAVAILABLE','PROTECTION_UNHEALTHY','PROTECTION_UNKNOWN','SOURCE_PARTIAL','STATE_CORRUPT','STATE_WRITE_FAILED','LOG_RESET','INVALID_SNAPSHOT'})

def safe_reason(value):
    return value if isinstance(value,str) and value in MONITOR_REASONS else 'UNKNOWN'

def safe_time(value):
    if not isinstance(value,str) or len(value)>64:return None
    try:
        at=datetime.fromisoformat(value.replace('Z','+00:00'))
        return at.astimezone(timezone.utc).isoformat() if at.tzinfo else None
    except (ValueError,OverflowError):return None

def safe_record(value):
    return value if type(value) is int and 0<=value<2**63 else None

def public_monitor_health(value):
    value=value if isinstance(value,dict) else {}
    result={
        'status':value.get('status') if value.get('status') in ('MONITOR_OK','MONITOR_UNAVAILABLE','STARTING') else 'STARTING',
        'reason':safe_reason(value.get('reason','NONE')),
        'lastReason':safe_reason(value.get('lastReason','NONE')),
        'workerAlive':value.get('workerAlive') is True,
        'retryCount':1 if type(value.get('retryCount')) is int and value['retryCount']==1 else 0,
        'lastRecovery':value.get('lastRecovery') if value.get('lastRecovery') in ('NONE','AUTOMATIC') else 'NONE',
        'recoveryResult':value.get('recoveryResult') if value.get('recoveryResult') in ('NONE','RECOVERED_AUTOMATICALLY','STILL_UNAVAILABLE') else 'NONE',
    }
    stage=safe_timeout_stage(value.get('timeoutStage','UNKNOWN'))
    result['timeoutStage']=(stage if stage!='NONE' else 'UNKNOWN') if result['reason']=='BEHAVIOR_QUERY_TIMEOUT' else 'NONE'
    result['lastTimeoutStage']=safe_timeout_stage(value.get('lastTimeoutStage','NONE'))
    for key in ('lastSuccessfulPollAt','lastAttemptAt','lastRecoveryAt'):result[key]=safe_time(value.get(key))
    if isinstance(value.get('collectionAttempts'),list):result['collectionAttempts']=public_collection_attempts(value['collectionAttempts'])
    if isinstance(value.get('lastTimeoutAttempt'),dict):
        attempts=public_collection_attempts([value['lastTimeoutAttempt']]);result['lastTimeoutAttempt']=attempts[0] if attempts and attempts[0]['reason']=='BEHAVIOR_QUERY_TIMEOUT' else None
    for key in HEALTH_BOOLEAN_FIELDS:result[key]=value.get(key) if type(value.get(key)) is bool else None
    for key in ('oldestRecordId','newestRecordId','checkpoint'):result[key]=safe_record(value.get(key))
    return result

def source_reason(snapshot):
    if not isinstance(snapshot,dict):return 'INVALID_SNAPSHOT'
    h=snapshot.get('health');h=h if isinstance(h,dict) else {}
    reason=safe_reason(h.get('reason','NONE'))
    if reason!='NONE':return reason
    if not snapshot.get('available'):
        return {'TIMEOUT':'POLL_TIMEOUT','ACCESS_DENIED':'DEFENDER_EVENT_LOG_ACCESS_DENIED','INVALID_SNAPSHOT':'INVALID_SNAPSHOT'}.get(snapshot.get('error'),'DEFENDER_EVENT_LOG_UNAVAILABLE')
    p=snapshot.get('protection');p=p if isinstance(p,dict) else {}
    if p.get('serviceStatus')=='STOPPED':return 'DEFENDER_SERVICE_STOPPED'
    if p.get('AMServiceEnabled') is False:return 'ANTIMALWARE_SERVICE_OFF'
    if p.get('RealTimeProtectionEnabled') is False:return 'REALTIME_PROTECTION_OFF'
    for field,reason in (('BehaviorMonitorEnabled','BEHAVIOR_PROTECTION_OFF'),
            ('IoavProtectionEnabled','IOAV_PROTECTION_OFF'),('NISEnabled','NETWORK_INSPECTION_OFF'),
            ('AntivirusEnabled','ANTIVIRUS_PROTECTION_OFF')):
        if p.get(field) is False:return reason
    errors=snapshot.get('sourceErrors',[])
    if 'EVENT_LOG_UNAVAILABLE' in errors or snapshot.get('watermark') is None:return 'DEFENDER_EVENT_LOG_UNAVAILABLE'
    if 'STATUS_UNAVAILABLE' in errors or type(p.get('RealTimeProtectionEnabled')) is not bool:return 'DEFENDER_STATUS_QUERY_FAILED'
    if 'SERVICE_UNAVAILABLE' in errors or p.get('serviceStatus') not in ('RUNNING','STOPPED'):return 'DEFENDER_SERVICE_QUERY_FAILED'
    if snapshot.get('logReset') is True or 'LOG_RESET' in errors:return 'EVENT_LOG_RESET_OR_ROLLOVER'
    return 'SOURCE_PARTIAL' if errors else 'NONE'

def monitor_case(case):
    """Only an unmixed source-health record may recover or leave the case count."""
    if not isinstance(case,dict) or case.get('EVENT_SOURCE')!='SECURITY_MONITOR' or case.get('MONITOR_HEALTH_ONLY') is False or case.get('ALERT_LEVEL')!='WARNING':return False
    reasons=case.get('REASON_CODES')
    if not isinstance(reasons,list) or not reasons or any(not isinstance(code,str) or code not in LEGACY_MONITOR_CODES for code in reasons):return False
    for key in ('EVENT_ID','RECORD_ID','THREAT_ID','THREAT_NAME','THREAT_CATEGORY','DEFENDER_SEVERITY','DETECTION_SOURCE','DETECTION_METHOD','ACTION_ATTEMPTED','ACTION_RESULT'):
        if case.get(key,'UNKNOWN')!='UNKNOWN':return False
    for key in ('RELATED_EVENTS','RESOURCE_TYPES','RESOURCE_HASHES'):
        if case.get(key,[])!=[]:return False
    if case.get('RESOURCE_CLASS',['UNKNOWN']) not in ([],['UNKNOWN']):return False
    if case.get('ISOLATION_RESULT','DISABLED')!='DISABLED':return False
    return True


def recovered_case(case):
    return monitor_case(case) and case.get('MONITOR_INCIDENT_STATUS')=='RECOVERED'


def public_protection_state(value):
    """Project already-normalized live protection, never infer unknown controls."""
    value=value if isinstance(value,dict) else {}
    result={}
    for key in ('SERVICE_STATUS','REAL_TIME_PROTECTION','ANTIMALWARE_SERVICE','ANTIVIRUS',
                'BEHAVIOR_MONITOR','IOAV_PROTECTION','NETWORK_INSPECTION'):
        allowed=('RUNNING','STOPPED','UNKNOWN') if key=='SERVICE_STATUS' else ('ON','OFF','UNKNOWN')
        item=value.get(key)
        result[key]=item if isinstance(item,str) and item in allowed else 'UNKNOWN'
    return result
