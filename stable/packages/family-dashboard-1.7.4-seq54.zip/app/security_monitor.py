"""Private, durable, monitor-only Defender journal. No device controls or HTTP queries."""
from __future__ import annotations
import copy
import json
import os
import stat
import tempfile
import threading
import uuid
import time
from security_health import (public_monitor_health,source_reason,safe_reason,safe_record,
    HEALTH_BOOLEAN_FIELDS,monitor_case,recovered_case,LEGACY_MONITOR_CODES,public_protection_state,safe_time)
from datetime import datetime, timezone
from pathlib import Path
import eew_private_audio as private
from security_events import (correlate_snapshot,health_case,public_case,instant,integer,error_code,protection_state,WIFI_STATES)

from security_configuration import classify_configuration_event,superseded_configuration_case,configuration_review_case

MAX_STATE_BYTES=1024*1024
MAX_EVIDENCE_BYTES=1024*1024
MAX_CASES=32
SOURCE_ERRORS={'NONE','ACCESS_DENIED','SOURCE_UNAVAILABLE','TIMEOUT','INVALID_SNAPSHOT'}
ISOLATION_ERRORS={'NONE','RADIO_UNAVAILABLE','INVALID_RADIO_STATE','EVIDENCE_NOT_SAVED','EVIDENCE_WRITE_FAILED'}


def _reject_duplicates(pairs):
    result={}
    for key,value in pairs:
        if key in result:raise ValueError('duplicate key')
        result[key]=value
    return result


class PrivateMonitorStore:
    """Bounded files with pinned parent handles and existing protected ACL helpers."""
    def __init__(self,data_root):
        self.root=Path(data_root).absolute();self.directory=self.root/'security-monitor'
        if self.root==Path(__file__).absolute().parent or Path(__file__).absolute().parent in self.root.parents:
            raise ValueError('unsafe data root')
        self.path=self.directory/'state.json';self.previous=self.directory/'state.previous.json'

    def _safe(self,path):
        if not path.is_absolute() or '..' in path.parts or str(path).startswith(('\\\\','//')):raise ValueError('unsafe path')
        for part in reversed((path,*path.parents)):
            try:info=part.lstat()
            except FileNotFoundError:continue
            if stat.S_ISLNK(info.st_mode) or getattr(info,'st_file_attributes',0)&0x400:raise ValueError('unsafe path')
            if part!=path and not stat.S_ISDIR(info.st_mode):raise ValueError('unsafe path')

    def _read(self,path,limit):
        self._safe(path)
        try:
            with private.secure_file(path,private_base=self.directory) as stream:
                if os.fstat(stream.fileno()).st_size>limit:raise ValueError('oversized')
                raw=stream.read(limit+1)
        except private.PrivateAudioError as exc:
            # Windows locked_chain reports absent paths with this explicit category.
            # Permission, reparse and unsafe ACL errors must continue to fail closed.
            if exc.category=='missing':raise FileNotFoundError('missing private journal') from None
            raise
        if len(raw)>limit:raise ValueError('oversized')
        return raw
    def _decode(self,raw):
        s=json.loads(raw.decode('utf-8'),object_pairs_hook=_reject_duplicates,parse_constant=lambda _: (_ for _ in ()).throw(ValueError('nonfinite')))
        if not isinstance(s,dict) or s.get('schema')!=1 or type(s.get('initialized')) is not bool:raise ValueError('invalid state')
        uuid.UUID(s.get('epoch',''))
        if s.get('cursor') is not None and type(s.get('cursor')) is not int:raise ValueError('invalid cursor')
        if s.get('cursor') is not None and integer(s['cursor'])=='UNKNOWN':raise ValueError('invalid cursor')
        if not isinstance(s.get('cases'),list) or len(s['cases'])>MAX_CASES:raise ValueError('invalid cases')
        s['cases']=[public_case(c) for c in s['cases']]
        if s.get('monitorIncident') is not None:
            s['monitorIncident']=public_case(s['monitorIncident'])
            if not monitor_case(s['monitorIncident']):raise ValueError('invalid monitor incident')
        if len({c['CASE_ID'] for c in s['cases']})!=len(s['cases']):raise ValueError('duplicate cases')
        fingerprints=s.get('health',{})
        if not isinstance(fingerprints,dict) or len(fingerprints)>32:raise ValueError('invalid health')
        s['health']={k:v for k,v in fingerprints.items() if k in {'MONITOR_UNAVAILABLE','PROTECTION_UNHEALTHY','PROTECTION_UNKNOWN','SOURCE_PARTIAL','STATE_CORRUPT','STATE_WRITE_FAILED','LOG_RESET','INVALID_SNAPSHOT','CASE_OVERFLOW'} and isinstance(v,str)}
        s['lastCheckedAt']=(instant(s.get('lastCheckedAt')).isoformat() if instant(s.get('lastCheckedAt')) else None)
        s['disabledSince']=(instant(s.get('disabledSince')).isoformat() if instant(s.get('disabledSince')) else None)
        s['wifiState']=s.get('wifiState') if s.get('wifiState') in WIFI_STATES else 'UNKNOWN'
        s['monitorState']=s.get('monitorState') if s.get('monitorState') in {'STARTING','OK','DEGRADED','NOT_AVAILABLE'} else 'DEGRADED'
        s['monitorHealth']=public_monitor_health(s.get('monitorHealth'))
        s['currentProtection']=public_protection_state(s.get('currentProtection'))
        s['currentProtectionObservedAt']=safe_time(s.get('currentProtectionObservedAt'))
        return s

    def load(self):
        try:return self._decode(self._read(self.path,MAX_STATE_BYTES)),False
        except FileNotFoundError:return None,False
        except Exception:
            try:return self._decode(self._read(self.previous,MAX_STATE_BYTES)),True
            except Exception:return None,True

    def _ensure(self):
        self._safe(self.root);self._safe(self.directory)
        self.root.mkdir(parents=True,exist_ok=True)
        with private.locked_chain(self.root) as root_handle:
            if os.name=='nt':private._check_acl(root_handle,protected=False)
            if not self.directory.exists():self.directory.mkdir()
            self._safe(self.directory)
            with private.locked_chain(self.directory):private._set_private_acl(self.directory)

    def _atomic(self,path,raw):
        self._safe(path)
        if path.exists():
            with private.secure_file(path,private_base=self.directory):pass
        fd,name=tempfile.mkstemp(prefix='journal-',suffix='.tmp',dir=self.directory);temp=Path(name)
        try:
            private._set_private_acl(temp)
            with os.fdopen(fd,'wb') as stream:
                fd=None;stream.write(raw);stream.flush();os.fsync(stream.fileno())
            with private.secure_file(temp,private_base=self.directory) as stream:
                if stream.read(len(raw)+1)!=raw:raise OSError('verification failed')
            os.replace(temp,path)
            if os.name!='nt':
                parent=os.open(self.directory,os.O_RDONLY)
                try:os.fsync(parent)
                finally:os.close(parent)
        finally:
            if fd is not None:os.close(fd)
            temp.unlink(missing_ok=True)

    def save(self,state):
        raw=json.dumps(state,ensure_ascii=True,separators=(',',':'),allow_nan=False).encode('utf-8')
        if len(raw)>MAX_STATE_BYTES:raise ValueError('oversized state')
        self._decode(raw);self._ensure()
        with private.locked_chain(self.directory,private_base=self.directory):
            try:
                old=self._read(self.path,MAX_STATE_BYTES);self._decode(old)
            except FileNotFoundError:old=None
            except ValueError:old=None
            if old is not None:self._atomic(self.previous,old)
            self._atomic(self.path,raw)

    def evidence(self,snapshot):
        # Raw source evidence stays private; no personal file reads or hashing.
        raw=json.dumps(snapshot,ensure_ascii=True,separators=(',',':'),allow_nan=False).encode('utf-8')+b'\n'
        if len(raw)>MAX_EVIDENCE_BYTES:
            raw=b'{"truncated":true,"error":"EVIDENCE_OVERSIZED"}\n'
        self._ensure()
        with private.locked_chain(self.directory,private_base=self.directory):
            current=self.directory/'evidence-0.jsonl'
            try:previous=self._read(current,MAX_EVIDENCE_BYTES)
            except FileNotFoundError:previous=b''
            # The checked existing file, not an in-memory cache, is authoritative.
            if previous.endswith(b'\n') and previous.rsplit(b'\n',2)[-2]+b'\n'==raw:return
            if len(previous)+len(raw)>MAX_EVIDENCE_BYTES:
                for index in (3,2,1):
                    prior=self.directory/('evidence-'+str(index-1)+'.jsonl')
                    destination=self.directory/('evidence-'+str(index)+'.jsonl')
                    try:old=self._read(prior,MAX_EVIDENCE_BYTES)
                    except FileNotFoundError:continue
                    self._atomic(destination,old)
                previous=b''
            self._atomic(current,previous+raw)

    def configuration_evidence(self):
        """Read only bounded original snapshots; any unreadable/corrupt input fails closed."""
        snapshots=[];line_count=0
        try:
            for index in range(4):
                try:raw=self._read(self.directory/('evidence-'+str(index)+'.jsonl'),MAX_EVIDENCE_BYTES)
                except FileNotFoundError:continue
                if raw and not raw.endswith(b'\n'):return None
                for line in raw.splitlines():
                    line_count+=1
                    if line_count>4096:return None
                    value=json.loads(line.decode('utf-8'),object_pairs_hook=_reject_duplicates,
                        parse_constant=lambda _: (_ for _ in ()).throw(ValueError('nonfinite')))
                    if not isinstance(value,dict):return None
                    if set(value)=={'recoveredSanitizedCases'}:continue
                    if value.get('truncated') is True:return None
                    if 'events' not in value:return None
                    snapshots.append(value)
            return snapshots
        except Exception:return None

    def _append_private_rows(self,stem,rows,limit,retention):
        if not rows:return
        raw_rows=[json.dumps(row,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode('ascii')+b'\n' for row in rows]
        if any(len(row)>limit for row in raw_rows):raise ValueError('oversized private row')
        self._ensure()
        with private.locked_chain(self.directory,private_base=self.directory):
            current=self.directory/(stem+'-0.jsonl')
            try:prior=self._read(current,limit)
            except FileNotFoundError:prior=b''
            for row in raw_rows:
                if len(prior)+len(row)>limit:
                    self._atomic(current,prior)
                    for index in range(retention-1,0,-1):
                        try:old=self._read(self.directory/(stem+'-'+str(index-1)+'.jsonl'),limit)
                        except FileNotFoundError:continue
                        self._atomic(self.directory/(stem+'-'+str(index)+'.jsonl'),old)
                    prior=b''
                prior+=row
            self._atomic(current,prior)

    def configuration_history(self,rows):
        from security_configuration import CONFIGURATION_CLASSIFICATIONS,CONFIGURATION_SETTINGS
        reasons={'KNOWN_SAFE_METADATA_CHANGE','SECURITY_POLICY_CHANGE','THREAT_EVIDENCE_PRESENT',
            'INVALID_EVENT','INCOMPLETE_CONFIGURATION_VALUES','SETTING_MISMATCH','UNKNOWN_SETTING',
            'INVALID_VERSION_TRANSITION','CURRENT_VERSION_UNVERIFIED','PROTECTION_NOT_HEALTHY','SOURCE_INCOMPLETE','THREAT_CORRELATION_UNCERTAIN'}
        safe=[]
        for row in rows[:4096]:
            safe.append({'timestamp':safe_time(row.get('timestamp')),'eventAt':safe_time(row.get('eventAt')),
                'recordId':safe_record(row.get('recordId')),
                'classification':row.get('classification') if row.get('classification') in CONFIGURATION_CLASSIFICATIONS else 'INSUFFICIENT_EVIDENCE',
                'setting':row.get('setting') if row.get('setting') in CONFIGURATION_SETTINGS else 'UNKNOWN',
                'reason':row.get('reason') if row.get('reason') in reasons else 'INVALID_EVENT',
                'result':'SUPERSEDED_CONFIGURATION_CHANGE' if row.get('result')=='SUPERSEDED_CONFIGURATION_CHANGE' else 'OBSERVED'})
        self._append_private_rows('configuration-history',safe,65536,2)

    def archive_configurations(self,cases):
        rows=[]
        for case in cases[:MAX_CASES]:
            value=public_case(case)
            if not superseded_configuration_case(value):raise ValueError('not a superseded configuration case')
            rows.append({'kind':'SUPERSEDED_CONFIGURATION_CASE_ARCHIVE','case':value})
        self._append_private_rows('configuration-archive',rows,MAX_EVIDENCE_BYTES,4)

    def diagnostic(self,row):
        # Fixed enums and booleans only. Reuse the private path/ACL/atomic helpers.
        h=public_monitor_health(row)
        entry={'timestamp':row['timestamp'],'result':h['status'],'reason':h['reason'],
               'retryCount':h['retryCount'],'transition':row['transition'] if row.get('transition') in
               {'CHECKED','OPENED','REASON_CHANGED','RECOVERED','RETRY','RESYNC','WORKER_RESTART'} else 'CHECKED',
               'serviceRunning':h['serviceRunning'],'realtimeProtection':h['realtimeProtection'],
               'eventLogReadable':h['eventLogReadable'],'recovery':h['recoveryResult']}
        raw=json.dumps(entry,separators=(',',':'),allow_nan=False).encode('ascii')+b'\n'
        self._ensure()
        with private.locked_chain(self.directory,private_base=self.directory):
            path=self.directory/'health-0.jsonl'
            try:prior=self._read(path,65536)
            except FileNotFoundError:prior=b''
            if len(prior)+len(raw)>65536:
                self._atomic(self.directory/'health-1.jsonl',prior);prior=b''
            self._atomic(path,prior+raw)

class SecurityMonitor:
    def __init__(self,data_root,source,wifi_query=None,clock=None,interval_seconds=60):
        self.source=source;self.wifi_query=wifi_query;self.clock=clock or (lambda:datetime.now(timezone.utc))
        self.interval_seconds=max(1,float(interval_seconds));self._lock=threading.RLock();self._poll_lock=threading.Lock();self._stop=threading.Event();self._thread=None
        self.store=PrivateMonitorStore(data_root);state,corrupt=self.store.load()
        self._state=state or {'schema':1,'initialized':False,'epoch':str(uuid.uuid4()),'cursor':None,'cases':[],'health':{},'lastCheckedAt':None,'disabledSince':None,'wifiState':'UNKNOWN','monitorState':'STARTING'}
        self._ephemeral=[];self._ephemeral_seen=set();self._pending_configuration_archive=[]
        self._supervisor=None;self._worker_restart_used=False;self._poll_started=None
        self._pending_recovery_reason='CHECKPOINT_INVALID' if corrupt else None
        self._state['monitorHealth']=public_monitor_health(self._state.get('monitorHealth'))
        self._migrate_health(self._state)
        if corrupt:
            self._state['initialized']=False;self._state['cursor']=None;self._state['epoch']=str(uuid.uuid4());self._state['monitorState']='DEGRADED'
            self._transition(self._state,'CHECKPOINT_INVALID',self._now(),'UNKNOWN')
            incident=next((c for c in self._state['cases'] if monitor_case(c) and not recovered_case(c)),self._state.get('monitorIncident'))
            if incident is not None and 'STATE_CORRUPT' not in incident['REASON_CODES']:incident['REASON_CODES'].append('STATE_CORRUPT')

    def _migrate_health(self,state):
        legacy=[c for c in state['cases'] if monitor_case(c) and not recovered_case(c)]
        if legacy:
            keeper=legacy[-1]
            # Old generations had multiple pending monitor warnings; retain one active
            # identity and never alter MICROSOFT_DEFENDER or CRITICAL records.
            state['cases']=[c for c in state['cases'] if c not in legacy or c is keeper]
            keeper.setdefault('MONITOR_INCIDENT_STATUS','ACTIVE')
            keeper.setdefault('MONITOR_REASON','UNKNOWN')
            keeper.setdefault('MONITOR_TIMELINE',[])
            state['health']['MONITOR_UNAVAILABLE']=keeper['CASE_ID']
        for code in LEGACY_MONITOR_CODES-{'MONITOR_UNAVAILABLE'}:state['health'].pop(code,None)

    def _transition(self,state,reason,now,wifi,retries=0,recovery_reason=None,snapshot=None,attempted_at=None):
        h=public_monitor_health(state.get('monitorHealth'))
        h.update(reason=safe_reason(reason),retryCount=retries,workerAlive=bool(self._thread and self._thread.is_alive()),checkpoint=safe_record(state.get('cursor')))
        if attempted_at is not None:h['lastAttemptAt']=safe_time(attempted_at)
        if isinstance(snapshot,dict):
            raw=snapshot.get('health');raw=raw if isinstance(raw,dict) else {}
            p=snapshot.get('protection',{});p=p if isinstance(p,dict) else {}
            for key in HEALTH_BOOLEAN_FIELDS:h[key]=raw.get(key) if type(raw.get(key)) is bool else None
            if h['serviceRunning'] is None and p.get('serviceStatus') in ('RUNNING','STOPPED'):h['serviceRunning']=p['serviceStatus']=='RUNNING'
            if h['realtimeProtection'] is None and type(p.get('RealTimeProtectionEnabled')) is bool:h['realtimeProtection']=p['RealTimeProtectionEnabled']
            for target,field in (('behaviorMonitoring','BehaviorMonitorEnabled'),('antimalwareService','AMServiceEnabled'),('antivirus','AntivirusEnabled'),('ioavProtection','IoavProtectionEnabled'),('networkInspection','NISEnabled')):
                if type(p.get(field)) is bool:h[target]=p[field]
            if h['eventLogReadable'] is None and snapshot.get('available') is True:h['eventLogReadable']=True
            for key in ('oldestRecordId','newestRecordId'):h[key]=safe_record(raw.get(key))
        active=next((c for c in state['cases'] if monitor_case(c) and not recovered_case(c)),None)
        detached=state.get('monitorIncident')
        if active is None and isinstance(detached,dict) and not recovered_case(detached):active=detached
        transition='CHECKED'
        if reason!='NONE':
            h.update(status='MONITOR_UNAVAILABLE',lastReason=safe_reason(reason),recoveryResult='STILL_UNAVAILABLE')
            if active is None:
                active=health_case('MONITOR_UNAVAILABLE',now,wifi)
                active.update(MONITOR_REASON=reason,MONITOR_INCIDENT_STATUS='ACTIVE',MONITOR_TIMELINE=[])
                # Health must never increment malware overflow or evict real cases.
                if len(state['cases'])<MAX_CASES-1:
                    state['cases'].append(active)
                else:state['monitorIncident']=active
                transition='OPENED'
            elif active.get('MONITOR_REASON')!=reason:transition='REASON_CHANGED'
            if active is not None:
                active['MONITOR_REASON']=reason
                active['MONITOR_INCIDENT_STATUS']='ACTIVE'
                state['health']['MONITOR_UNAVAILABLE']=active['CASE_ID']
                if transition in ('OPENED','REASON_CHANGED'):
                    active['MONITOR_TIMELINE']=(active.get('MONITOR_TIMELINE',[])+[{'at':now.isoformat(),'reason':reason,'transition':transition}])[-16:]
        else:
            previous=recovery_reason or (active.get('MONITOR_REASON') if active else None)
            h.update(status='MONITOR_OK',lastSuccessfulPollAt=now.isoformat())
            if previous and previous!='NONE':
                h.update(lastReason=safe_reason(previous),lastRecovery='AUTOMATIC',lastRecoveryAt=now.isoformat(),recoveryResult='RECOVERED_AUTOMATICALLY')
                transition='RECOVERED'
            if active:
                active.update(MONITOR_INCIDENT_STATUS='RECOVERED',MONITOR_RECOVERED_AT=now.isoformat(),HUMAN_REVIEW_REQUIRED=False)
                active['MONITOR_TIMELINE']=(active.get('MONITOR_TIMELINE',[])+[{'at':now.isoformat(),'reason':'NONE','transition':'RECOVERED'}])[-16:]
            state['health'].pop('MONITOR_UNAVAILABLE',None)
        state['monitorHealth']=h
        return transition

    def _now(self):
        now=self.clock()
        if not isinstance(now,datetime) or now.tzinfo is None:raise ValueError('clock must be aware')
        return now.astimezone(timezone.utc)

    @staticmethod
    def _case_key(case):
        return (case['EVENT_SOURCE'],case['EVENT_ID'],case['RECORD_ID'],case['DETECTED_AT'])

    @staticmethod
    def _configuration_eligible(case):
        if case.get('EVENT_SOURCE')!='MICROSOFT_DEFENDER' or case.get('EVENT_ID')!=5007 or case.get('ALERT_LEVEL')!='WARNING':return False
        if case.get('REASON_CODES')!=['CONFIGURATION_CHANGED'] or superseded_configuration_case(case):return False
        if case.get('CONFIGURATION_SAMPLE_COUNT',1)!=1:return False
        if any(case.get(k)!='UNKNOWN' for k in ('THREAT_ID','THREAT_NAME','THREAT_CATEGORY','DEFENDER_SEVERITY','DETECTION_SOURCE','DETECTION_METHOD','ACTION_ATTEMPTED','ACTION_RESULT','ERROR_CODE')):return False
        if case.get('RELATED_EVENTS') or case.get('RESOURCE_TYPES') or case.get('RESOURCE_HASHES') or case.get('RESOURCE_CLASS') not in ([],['UNKNOWN']):return False
        if case.get('ISOLATION_RESULT')!='DISABLED':return False
        return not set(case.get('MISSING_EVIDENCE',[]))&{'EVIDENCE_NOT_SAVED','ORIGINAL_RAW_EVIDENCE'}

    def _reclassify_configuration(self,state,now,snapshot):
        p=snapshot.get('protection',{}) if isinstance(snapshot,dict) else {}
        fields=('RealTimeProtectionEnabled','AMServiceEnabled','AntivirusEnabled','BehaviorMonitorEnabled','IoavProtectionEnabled','NISEnabled')
        if not isinstance(p,dict) or p.get('serviceStatus')!='RUNNING' or any(p.get(k) is not True for k in fields):return []
        eligible=[case for case in state['cases'] if self._configuration_eligible(case)]
        if not eligible:return []
        raw=self.store.configuration_evidence()
        if raw is None:return []
        wanted={(c['RECORD_ID'],instant(c['DETECTED_AT'])) for c in eligible};matches={key:[] for key in wanted}
        for observed in raw:
            if not isinstance(observed.get('events'),list):return []
            for event in observed['events']:
                if not isinstance(event,dict) or event.get('eventId')!=5007:continue
                key=(integer(event.get('recordId')),instant(event.get('at')))
                if key in matches:matches[key].append((observed,event))
        rows=[]
        for case in eligible:
            matching=matches[(case['RECORD_ID'],instant(case['DETECTED_AT']))]
            if not matching:continue
            encodings={json.dumps(event,sort_keys=True,separators=(',',':'),allow_nan=False) for _,event in matching}
            if len(encodings)!=1:continue
            verdicts=[classify_configuration_event(event,observed,now) for observed,event in matching]
            if any(v['classification']!='CONFIGURATION_CHANGE_ONLY' for v in verdicts):continue
            if len({v['setting'] for v in verdicts})!=1:continue
            proposed=dict(case,CONFIGURATION_STATUS='SUPERSEDED_CONFIGURATION_CHANGE',
                CONFIGURATION_CLASSIFICATION='CONFIGURATION_CHANGE_ONLY',CONFIGURATION_SETTING=verdicts[0]['setting'],
                CONFIGURATION_SAMPLE_COUNT=1,CONFIGURATION_LAST_SEEN_AT=case['DETECTED_AT'],
                CONFIGURATION_REVIEWED_AT=now.isoformat(),CONFIGURATION_CLASSIFIER_VERSION=1)
            if not superseded_configuration_case(proposed):continue
            case.update(proposed);case['HUMAN_REVIEW_REQUIRED']=False
            rows.append(dict(verdicts[0],timestamp=now.isoformat(),eventAt=case['DETECTED_AT'],recordId=case['RECORD_ID'],result='SUPERSEDED_CONFIGURATION_CHANGE'))
        return rows

    def _add(self,state,case):
        case=public_case(case)
        if 'CASE_OVERFLOW' in case['REASON_CODES'] and len(state['cases'])<MAX_CASES and not any('CASE_OVERFLOW' in c['REASON_CODES'] for c in state['cases']):
            state['cases'].append(case);return case['CASE_ID']
        if case['EVENT_SOURCE']=='MICROSOFT_DEFENDER':
            existing=next((c for c in state['cases'] if self._case_key(c)==self._case_key(case)),None)
            if existing:return existing['CASE_ID']
            if self._configuration_eligible(case) and case.get('CONFIGURATION_CLASSIFICATION')=='INSUFFICIENT_EVIDENCE':
                aggregate=next((c for c in state['cases'] if self._configuration_eligible(dict(c,CONFIGURATION_SAMPLE_COUNT=1)) and not c['ACKNOWLEDGED'] and c.get('CONFIGURATION_CLASSIFICATION')=='INSUFFICIENT_EVIDENCE' and c.get('CONFIGURATION_SETTING')==case.get('CONFIGURATION_SETTING')),None)
                if aggregate is not None:
                    aggregate['CONFIGURATION_SAMPLE_COUNT']=min(2**63-1,aggregate.get('CONFIGURATION_SAMPLE_COUNT',1)+1)
                    aggregate['CONFIGURATION_LAST_SEEN_AT']=max(aggregate.get('CONFIGURATION_LAST_SEEN_AT') or aggregate['DETECTED_AT'],case['DETECTED_AT'])
                    return aggregate['CASE_ID']
        if len(state['cases'])>=MAX_CASES-1:
            classified=next((c for c in state['cases'] if superseded_configuration_case(c)),None)
            if classified is not None:
                state.setdefault('_configurationArchive',[]).append(copy.deepcopy(classified));state['cases'].remove(classified)
            recovered=next((c for c in state['cases'] if recovered_case(c)),None)
            if recovered is not None:state['cases'].remove(recovered)
        if len(state['cases'])<MAX_CASES-1:state['cases'].append(case);return case['CASE_ID']
        acknowledged=next((c for c in state['cases'] if c['ACKNOWLEDGED'] and 'CASE_OVERFLOW' not in c['REASON_CODES']),None)
        if acknowledged:
            state['cases'].remove(acknowledged);state['cases'].append(case);return case['CASE_ID']
        overflow=next((c for c in state['cases'] if 'CASE_OVERFLOW' in c['REASON_CODES']),None)
        if overflow is None:
            overflow=health_case('CASE_OVERFLOW',self._now(),state['wifiState']);overflow['OVERFLOW_COUNT']=0;state['cases'].append(overflow)
        overflow['OVERFLOW_COUNT']=min(overflow.get('OVERFLOW_COUNT',0)+1,2**63-1)
        if case['ALERT_LEVEL']=='CRITICAL':overflow['ALERT_LEVEL']='CRITICAL'
        overflow['ACKNOWLEDGED']=False
        return overflow['CASE_ID']

    def _commit(self,state):
        archives=state.pop('_configurationArchive',[])
        if archives:self.store.archive_configurations(archives)
        self.store.save(state);self._state=state;self._ephemeral=[];self._ephemeral_seen.clear();self._pending_configuration_archive=[]

    def _failed(self,candidate=None,critical_keys=(),original_evidence_saved=False):
        # _state remains the last durable state/cursor. This bounded overlay is
        # display-only until a later evidence write and state commit both succeed.
        visible=copy.deepcopy(self._state)
        if self._ephemeral:visible['cases']=copy.deepcopy(self._ephemeral)
        durable={c['CASE_ID']:c for c in self._state['cases']}
        for case in candidate['cases'] if candidate else []:
            if case['ALERT_LEVEL']!='CRITICAL' or case['ACKNOWLEDGED']:continue
            if durable.get(case['CASE_ID'])==case:continue
            retained=public_case(case)
            for code in ('EVIDENCE_NOT_SAVED',)+(() if original_evidence_saved else ('ORIGINAL_RAW_EVIDENCE',)):
                if code not in retained['MISSING_EVIDENCE']:retained['MISSING_EVIDENCE'].append(code)
            existing=next((c for c in visible['cases'] if c['CASE_ID']==retained['CASE_ID']),None)
            if existing is not None:visible['cases'][visible['cases'].index(existing)]=retained
            else:self._add(visible,retained)
        self._transition(visible,'STATE_WRITE_FAILED',self._now(),self._state['wifiState'])
        warning=next((c for c in visible['cases'] if monitor_case(c) and not recovered_case(c)),None)
        if warning is not None:
            if 'STATE_WRITE_FAILED' not in warning['REASON_CODES']:warning['REASON_CODES'].append('STATE_WRITE_FAILED')
            warning['ACKNOWLEDGED']=False
        self._state['monitorHealth']=visible['monitorHealth']
        self._state['monitorIncident']=visible.get('monitorIncident')
        self._ephemeral=[public_case(c) for c in visible['cases']]
        archives=self._pending_configuration_archive+visible.get('_configurationArchive',[])+(candidate.get('_configurationArchive',[]) if candidate else [])
        self._pending_configuration_archive=list({c['CASE_ID']:c for c in archives}.values())[:MAX_CASES]
        # Source batches are capped at 2048; aggregate overflow remains bounded
        # and visible even once exact replay identities reach this memory cap.
        for key in critical_keys:
            if len(self._ephemeral_seen)<2048:self._ephemeral_seen.add(key)
        self._state['monitorState']='DEGRADED'

    def _launch_worker(self):
        self._thread=threading.Thread(target=self._run,name='SecurityMonitor',daemon=True)
        self._thread.start()

    def start(self):
        with self._lock:
            self._stop.clear()
            if not self._thread or not self._thread.is_alive():
                try:self._launch_worker()
                except Exception:self._thread=None
            if not self._supervisor or not self._supervisor.is_alive():
                self._supervisor=threading.Thread(target=self._supervise,name='SecurityMonitorSupervisor',daemon=True)
                self._supervisor.start()

    def supervise_once(self):
        with self._lock:
            if self._stop.is_set():return
            dead=not self._thread or not self._thread.is_alive()
            overdue=self._poll_started is not None and time.monotonic()-self._poll_started>45
            if not dead and not overdue:return
            reason='MONITOR_WORKER_NOT_RUNNING' if dead else 'POLL_TIMEOUT'
            s=copy.deepcopy(self._state);s['monitorState']='DEGRADED'
            if self._ephemeral:s['cases']=copy.deepcopy(self._ephemeral)
            now=self._now();transition=self._transition(s,reason,now,s['wifiState'])
            try:
                self.store.diagnostic(dict(s['monitorHealth'],timestamp=now.isoformat(),transition=transition))
                if self._ephemeral:
                    # Only the ordinary evidence+state transaction may release this overlay.
                    self._ephemeral=[public_case(c) for c in s['cases']]
                    self._state['monitorState']='DEGRADED';self._state['monitorHealth']=s['monitorHealth']
                    self._state['monitorIncident']=s.get('monitorIncident')
                else:self._commit(s)
            except Exception:self._failed(s)
            if dead and not self._worker_restart_used:
                self._worker_restart_used=True
                try:self._launch_worker()
                except Exception:pass

    def _supervise(self):
        while not self._stop.wait(self.interval_seconds):
            try:self.supervise_once()
            except Exception:
                with self._lock:self._failed()

    def _run(self):
        while not self._stop.is_set():
            try:self.poll_once()
            except Exception:
                with self._lock:self._failed()
            self._stop.wait(self.interval_seconds)

    def stop(self):
        self._stop.set()
        for thread in (self._thread,self._supervisor):
            if thread and thread is not threading.current_thread():thread.join(timeout=2)

    def poll_once(self):
        # A single collector may be active; snapshots only take the short state lock.
        if not self._poll_lock.acquire(blocking=False):return
        try:
            self._poll_started=time.monotonic();attempt_started_at=self._now().isoformat()
            with self._lock:
                cursor=self._state['cursor'] if self._state['initialized'] else None
                recovery_reason=self._pending_recovery_reason
            if cursor is not None and safe_record(cursor) is None:
                cursor=None;recovery_reason='CHECKPOINT_INVALID'
            def collect(after,recent=False):
                try:
                    if recent and callable(getattr(self.source,'resync_checkpoint',None)):return self.source.resync_checkpoint()
                    return self.source.collect(after)
                except TimeoutError:return {'available':False,'error':'TIMEOUT'}
                except Exception:return {'available':False,'error':'SOURCE_UNAVAILABLE'}
            snapshot=collect(cursor,recent=recovery_reason=='CHECKPOINT_INVALID');attempts=[snapshot];retries=0;resync=bool(recovery_reason=='CHECKPOINT_INVALID');poll_failure_reason=None
            if isinstance(snapshot,dict) and snapshot.get('available') and not self._valid_snapshot(snapshot):
                reason='INVALID_SNAPSHOT'
            else:reason=source_reason(snapshot)
            h=snapshot.get('health',{}) if isinstance(snapshot,dict) else {}
            h=h if isinstance(h,dict) else {}
            oldest=safe_record(h.get('oldestRecordId'));newest=safe_record(h.get('newestRecordId'))
            reset=(isinstance(snapshot,dict) and (snapshot.get('logReset') is True or
                (isinstance(snapshot.get('sourceErrors'),list) and 'LOG_RESET' in snapshot['sourceErrors']))) or reason=='EVENT_LOG_RESET_OR_ROLLOVER' or (cursor is not None and
                ((newest is not None and newest<cursor) or (oldest is not None and cursor<oldest-1)))
            if reset:
                recovery_reason='EVENT_LOG_RESET_OR_ROLLOVER';resync=True
            retryable=reason in {'POLL_TIMEOUT','DEFENDER_STATUS_QUERY_TIMEOUT','DEFENDER_STATUS_QUERY_FAILED','DEFENDER_SERVICE_QUERY_FAILED','DEFENDER_EVENT_LOG_UNAVAILABLE','INVALID_SNAPSHOT'}
            if (retryable or reset) and not self._stop.is_set():
                recovery_reason=recovery_reason or reason;retries=1
                first=snapshot
                snapshot=collect(None if reset or reason=='INVALID_SNAPSHOT' else cursor,recent=reset or reason=='INVALID_SNAPSHOT')
                attempts.append(snapshot)
                if (not reset and isinstance(first,dict) and first.get('available') is True and self._valid_snapshot(first)
                        and not (isinstance(snapshot,dict) and snapshot.get('available') is True and self._valid_snapshot(snapshot))):
                    # An unavailable retry cannot erase already collected valid malware proof.
                    poll_failure_reason=source_reason(snapshot) if isinstance(snapshot,dict) and not snapshot.get('available') else 'INVALID_SNAPSHOT'
                    snapshot=first
                if reason=='INVALID_SNAPSHOT':resync=True
            now=self._now();wifi='UNKNOWN'
            if self.wifi_query:
                try:
                    value=self.wifi_query();wifi=value if value in WIFI_STATES else 'UNKNOWN'
                except Exception:pass
            with self._lock:
                s=copy.deepcopy(self._state);s.update(lastCheckedAt=now.isoformat(),wifiState=wifi,monitorState='OK')
                if self._ephemeral:s['cases']=copy.deepcopy(self._ephemeral)
                if self._pending_configuration_archive:s['_configurationArchive']=copy.deepcopy(self._pending_configuration_archive)
                critical_keys=[];configuration_rows=[]
                if not isinstance(snapshot,dict) or type(snapshot.get('available')) is not bool:
                    snapshot={'available':False,'error':'INVALID_SNAPSHOT'}
                valid=isinstance(snapshot,dict) and snapshot.get('available') is True and self._valid_snapshot(snapshot)
                reason=poll_failure_reason or (source_reason(snapshot) if valid or not snapshot.get('available') else 'INVALID_SNAPSHOT')
                if not valid:s['monitorState']='DEGRADED'
                else:
                    p=snapshot['protection']
                    s['currentProtection']=protection_state(p);s['currentProtectionObservedAt']=now.isoformat()
                    configuration_rows.extend(self._reclassify_configuration(s,now,snapshot))
                    disabled=p.get('RealTimeProtectionEnabled') is False
                    if disabled and not s['disabledSince']:s['disabledSince']=now.isoformat()
                    elif not disabled:s['disabledSince']=None
                    reset=snapshot.get('logReset') is True or (cursor is not None and snapshot['watermark'] is not None and snapshot['watermark']<cursor)
                    if reset:
                        resync=True;s['epoch']=str(uuid.uuid4())
                        recovery_reason=recovery_reason or 'EVENT_LOG_RESET_OR_ROLLOVER'
                    if s['initialized'] and not reset and not resync and snapshot['watermark'] is not None:
                        candidates={}
                        for observed in attempts:
                            if not (isinstance(observed,dict) and observed.get('available') is True and self._valid_snapshot(observed)):continue
                            fresh=[e for e in observed['events'] if integer(e.get('recordId'))!='UNKNOWN' and (cursor is None or integer(e['recordId'])>cursor)]
                            unique={e['recordId']:e for e in fresh}
                            batch=dict(observed,events=list(unique.values()))
                            for e in batch['events']:
                                if e.get('eventId')==5007:
                                    verdict=classify_configuration_event(e,observed,now)
                                    configuration_rows.append(dict(verdict,timestamp=now.isoformat(),eventAt=e.get('at'),recordId=e['recordId'],result='OBSERVED'))
                            # Corroborate each observation alone. A poorer retry cannot erase
                            # independently sufficient proof, nor combine unrelated evidence.
                            for case in correlate_snapshot(batch,now,wifi,instant(s['disabledSince'])):
                                key=self._case_key(case);prior=candidates.get(key)
                                if prior is None or prior['ALERT_LEVEL']!='CRITICAL':candidates[key]=case
                        for key,case in candidates.items():
                            if key in self._ephemeral_seen:continue
                            self._add(s,case)
                            if case['ALERT_LEVEL']=='CRITICAL':critical_keys.append(key)
                    if snapshot['watermark'] is not None:
                        s['initialized']=True;s['cursor']=snapshot['watermark']
                    elif reset:s['initialized']=False;s['cursor']=None
                if reason!='NONE':s['monitorState']='DEGRADED'
                transition=self._transition(s,reason,now,wifi,retries,recovery_reason,snapshot,attempt_started_at)
                original_evidence_saved=False
                try:
                    for observed in attempts:self.store.evidence(observed)
                    original_evidence_saved=True
                    if configuration_rows:
                        unique_rows={json.dumps(row,sort_keys=True,separators=(',',':')):row for row in configuration_rows}
                        self.store.configuration_history(list(unique_rows.values()))
                    recovered=[public_case(c) for c in s['cases'] if 'EVIDENCE_NOT_SAVED' in c['MISSING_EVIDENCE']]
                    if recovered:
                        # Public facts can be recovered even when the original raw
                        # collection was lost. Its separate missing marker remains.
                        self.store.evidence({'recoveredSanitizedCases':recovered})
                        for case in s['cases']:
                            case['MISSING_EVIDENCE']=[code for code in case['MISSING_EVIDENCE'] if code!='EVIDENCE_NOT_SAVED']
                    self.store.diagnostic(dict(s['monitorHealth'],timestamp=now.isoformat(),transition=transition))
                    self._commit(s)
                    if reason=='NONE':
                        self._pending_recovery_reason=None;self._worker_restart_used=False
                except Exception:self._failed(s,critical_keys,original_evidence_saved)
        finally:
            self._poll_started=None
            self._poll_lock.release()

    @staticmethod
    def _valid_snapshot(s):
        if not isinstance(s.get('error'),str) or s.get('error') not in SOURCE_ERRORS or type(s.get('logReset')) is not bool:return False
        if s.get('watermark') is not None and (type(s.get('watermark')) is not int or integer(s.get('watermark'))=='UNKNOWN'):return False
        if not isinstance(s.get('protection'),dict):return False
        scalar=(str,int,float,bool,type(None))
        if any(not isinstance(k,str) or not isinstance(v,scalar) for k,v in s['protection'].items()):return False
        if not all(isinstance(s.get(k),list) for k in ('events','threats','detections','sourceErrors')):return False
        if len(s['events'])>2048 or len(s['threats'])>1024 or len(s['detections'])>1024:return False
        allowed_errors={'EVENT_LOG_UNAVAILABLE','STATUS_UNAVAILABLE','THREATS_UNAVAILABLE','DETECTIONS_UNAVAILABLE','SERVICE_UNAVAILABLE','TRUNCATED','LOG_RESET'}
        if len(s['sourceErrors'])>8 or any(not isinstance(e,str) or e not in allowed_errors for e in s['sourceErrors']):return False
        for row in s['threats']+s['detections']:
            if not isinstance(row,dict):return False
            for key,value in row.items():
                if not isinstance(key,str):return False
                if key=='Resources':
                    if not isinstance(value,list) or len(value)>256 or any(not isinstance(v,str) for v in value):return False
                elif not isinstance(value,scalar):return False
        for event in s['events']:
            if not isinstance(event,dict) or type(event.get('eventId')) is not int or type(event.get('recordId')) is not int or integer(event.get('recordId'))=='UNKNOWN' or not isinstance(event.get('data'),dict):return False
            if any(not isinstance(k,str) or not isinstance(v,scalar) for k,v in event['data'].items()):return False
            if s['watermark'] is not None and event['recordId']>s['watermark']:return False
        return True

    def snapshot(self):
        with self._lock:
            cases=[public_case(c) for c in (self._ephemeral or self._state['cases'])]
            result={'schemaVersion':1,'mode':'MONITOR_ONLY','monitorState':self._state['monitorState'],'autoIsolationEnabled':False,'lastCheckedAt':self._state['lastCheckedAt'],'wifiState':self._state['wifiState'],'unacknowledgedCount':sum(not c['ACKNOWLEDGED'] and not recovered_case(c) and not superseded_configuration_case(c) for c in cases),'pendingCaseCount':sum(not c['ACKNOWLEDGED'] and not monitor_case(c) and not superseded_configuration_case(c) for c in cases),'monitorHealthCount':int(self._state.get('monitorHealth',{}).get('status')=='MONITOR_UNAVAILABLE'),'currentProtection':public_protection_state(self._state.get('currentProtection')),'currentProtectionObservedAt':safe_time(self._state.get('currentProtectionObservedAt')),'cases':cases,'monitorHealth':public_monitor_health(dict(self._state.get('monitorHealth',{}),workerAlive=bool(self._thread and self._thread.is_alive())))}

            result['securityReviewCount']=sum(not c['ACKNOWLEDGED'] and configuration_review_case(c) for c in cases)
            result['securityAlertCount']=result['pendingCaseCount']-result['securityReviewCount']
            return result

    def acknowledge(self,case_id):
        with self._lock:
            if self._ephemeral:return False
            s=copy.deepcopy(self._state);case=next((c for c in s['cases'] if c['CASE_ID']==case_id),None)
            if not case:return False
            case['ACKNOWLEDGED']=True
            try:self._commit(s);return True
            except Exception:self._failed();return False

    def prepare_isolation(self,case_id):
        with self._lock:
            if self._ephemeral:return False
            s=copy.deepcopy(self._state);case=next((c for c in s['cases'] if c['CASE_ID']==case_id),None)
            if not case or case['ACKNOWLEDGED'] or case['ALERT_LEVEL']!='CRITICAL' or case['ISOLATION_RESULT']!='DISABLED':return False
            # Aggregated overflow is visible but lacks a unique actionable evidence identity.
            if 'CASE_OVERFLOW' in case['REASON_CODES']:return False
            case['ISOLATION_RESULT']='PREPARED'
            try:self._commit(s);return True
            except Exception:
                self._failed();raise OSError('EVIDENCE_NOT_SAVED') from None

    def finish_isolation(self,case_id,result,wifi_state,error_code='NONE'):
        with self._lock:
            if self._ephemeral:raise OSError('EVIDENCE_WRITE_FAILED')
            s=copy.deepcopy(self._state);case=next((c for c in s['cases'] if c['CASE_ID']==case_id),None)
            if not case or case['ISOLATION_RESULT']=='DISABLED':return
            case['ISOLATION_RESULT']=result if result in {'OFF_VERIFIED','ISOLATION_FAILED','UNKNOWN'} else 'UNKNOWN'
            case['WIFI_STATE']=wifi_state if wifi_state in WIFI_STATES else 'UNKNOWN'
            if case['ISOLATION_RESULT']=='OFF_VERIFIED' and case['WIFI_STATE']!='OFF':case['ISOLATION_RESULT']='UNKNOWN'
            safe=error_code if error_code in ISOLATION_ERRORS else globals()['error_code'](error_code)
            # Keep remediation error independent of isolation, and expose only fixed enums.
            case['ISOLATION_ERROR_CODE']=safe
            s['wifiState']=case['WIFI_STATE']
            try:self._commit(s)
            except Exception:
                self._failed();raise OSError('EVIDENCE_WRITE_FAILED') from None






