"""Run the fixed Windows behavior collectors in a private, kill-on-close job."""

import ctypes
import subprocess
import threading
import time
from ctypes import wintypes


class _BasicLimits(ctypes.Structure):
    _fields_ = [
        ("process_time", ctypes.c_int64), ("job_time", ctypes.c_int64),
        ("flags", wintypes.DWORD), ("min_working_set", ctypes.c_size_t),
        ("max_working_set", ctypes.c_size_t), ("process_limit", wintypes.DWORD),
        ("affinity", ctypes.c_size_t), ("priority", wintypes.DWORD),
        ("scheduling", wintypes.DWORD),
    ]


class _ExtendedLimits(ctypes.Structure):
    _fields_ = [
        ("basic", _BasicLimits), ("io", ctypes.c_uint64 * 6),
        ("memory_limits_and_peaks", ctypes.c_size_t * 4),
    ]


class _Accounting(ctypes.Structure):
    _fields_ = [
        ("times", ctypes.c_int64 * 4), ("page_faults", wintypes.DWORD),
        ("total_processes", wintypes.DWORD), ("active_processes", wintypes.DWORD),
        ("terminated_processes", wintypes.DWORD),
    ]


class _ThreadEntry(ctypes.Structure):
    _fields_ = [
        ("size", wintypes.DWORD), ("usage", wintypes.DWORD), ("id", wintypes.DWORD),
        ("owner", wintypes.DWORD), ("base_priority", wintypes.LONG),
        ("delta_priority", wintypes.LONG), ("flags", wintypes.DWORD),
    ]


def _kernel():
    api = ctypes.WinDLL("kernel32", use_last_error=True)
    handle, dword, ptr = wintypes.HANDLE, wintypes.DWORD, ctypes.c_void_p
    signatures = {
        "CreateJobObjectW": (handle, (ptr, wintypes.LPCWSTR)),
        "SetInformationJobObject": (wintypes.BOOL, (handle, ctypes.c_int, ptr, dword)),
        "QueryInformationJobObject": (wintypes.BOOL, (handle, ctypes.c_int, ptr, dword, ptr)),
        "AssignProcessToJobObject": (wintypes.BOOL, (handle, handle)),
        "TerminateJobObject": (wintypes.BOOL, (handle, wintypes.UINT)),
        "CreateToolhelp32Snapshot": (handle, (dword, dword)),
        "Thread32First": (wintypes.BOOL, (handle, ptr)),
        "Thread32Next": (wintypes.BOOL, (handle, ptr)),
        "OpenThread": (handle, (dword, wintypes.BOOL, dword)),
        "GetProcessIdOfThread": (dword, (handle,)),
        "ResumeThread": (dword, (handle,)),
        "CloseHandle": (wintypes.BOOL, (handle,)),
    }
    for name, (result, arguments) in signatures.items():
        function = getattr(api, name)
        function.restype, function.argtypes = result, arguments
    return api


def _check(result):
    if not result:
        raise ctypes.WinError(ctypes.get_last_error())
    return result


def _resume_owned(api, pid):
    # Popen closes the primary thread handle. CREATE_SUSPENDED keeps that
    # thread from executing any collector code while we assign the job.
    snapshot = api.CreateToolhelp32Snapshot(4, 0)  # TH32CS_SNAPTHREAD
    if snapshot == ctypes.c_void_p(-1).value:
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        entry = _ThreadEntry()
        entry.size = ctypes.sizeof(entry)
        found = api.Thread32First(snapshot, ctypes.byref(entry))
        while found:
            if entry.owner == pid:
                thread = _check(api.OpenThread(0x0802, False, entry.id))
                try:
                    if api.GetProcessIdOfThread(thread) != pid or api.ResumeThread(thread) != 1:
                        raise OSError("collector thread could not be resumed safely")
                finally:
                    api.CloseHandle(thread)
                return
            entry.size = ctypes.sizeof(entry)
            found = api.Thread32Next(snapshot, ctypes.byref(entry))
        raise OSError("collector thread unavailable")
    finally:
        api.CloseHandle(snapshot)


def _active(api, job):
    counts = _Accounting()
    _check(api.QueryInformationJobObject(job, 1, ctypes.byref(counts), ctypes.sizeof(counts), None))
    return counts.active_processes


_lock = threading.Lock()
_draining = []


def _finish_job(api, job, process, assigned):
    # Retain the real handles (including a suspended unassigned process)
    # until Windows confirms that launching another collector is safe.
    try:
        if process is not None and not assigned and process.poll() is None:
            process.kill()
            process.wait(timeout=2)
        if _active(api, job):
            _check(api.TerminateJobObject(job, 1))
            deadline = time.monotonic() + 2
            while _active(api, job):
                if time.monotonic() >= deadline:
                    raise OSError("collector cleanup pending")
                time.sleep(0.01)
        if process is not None:
            # communicate's Windows readers own the streams until EOF.
            for name in ("stdout_thread", "stderr_thread"):
                reader = getattr(process, name, None)
                if reader is not None and reader.is_alive():
                    reader.join(timeout=0.25)
                    if reader.is_alive():
                        raise OSError("collector pipe cleanup pending")
            for stream in (process.stdin, process.stdout, process.stderr):
                if stream and not stream.closed:
                    stream.close()
    except (OSError, subprocess.TimeoutExpired):
        _draining.append((job, process, assigned))
        raise OSError("collector cleanup pending") from None
    api.CloseHandle(job)


def _send_input(stream, data):
    # Windows Popen.communicate writes stdin synchronously before it starts
    # its timeout wait. A stalled inspector might never read a full pipe.
    with stream:
        try:
            stream.write(data)
            stream.flush()
        except BrokenPipeError:
            pass


def run_owned(argv, *, stdin=None, input=None, stdout=None, stderr=None, shell=False,
              timeout, env=None, creationflags=0):
    if shell or timeout <= 0 or (input is not None and stdin is not None):
        raise ValueError("invalid collector invocation")
    deadline = time.monotonic() + timeout
    if not _lock.acquire(blocking=False):
        raise OSError("collector already running")
    try:
        api = _kernel()
        if _draining:
            _finish_job(api, *_draining.pop())
        job = _check(api.CreateJobObjectW(None, None))
        process = None
        assigned = False
        try:
            limits = _ExtendedLimits()
            limits.basic.flags = 0x2000  # JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
            _check(api.SetInformationJobObject(job, 9, ctypes.byref(limits), ctypes.sizeof(limits)))
            process = subprocess.Popen(
                argv, stdin=subprocess.PIPE if input is not None else stdin,
                stdout=stdout, stderr=stderr, env=env, close_fds=True,
                creationflags=creationflags | 4,  # CREATE_SUSPENDED
            )
            _check(api.AssignProcessToJobObject(job, int(process._handle)))
            assigned = True
            _resume_owned(api, process.pid)
            if input is not None:
                stream, process.stdin = process.stdin, None
                writer = threading.Thread(target=_send_input, args=(stream, input), daemon=True)
                writer.start()
            try:
                output, errors = process.communicate(timeout=max(0, deadline - time.monotonic()))
            except subprocess.TimeoutExpired:
                _check(api.TerminateJobObject(job, 1))
                output, errors = process.communicate(timeout=2)
                raise subprocess.TimeoutExpired(argv, timeout, output=output, stderr=errors) from None
            return subprocess.CompletedProcess(argv, process.returncode, output, errors)
        finally:
            _finish_job(api, job, process, assigned)
    finally:
        _lock.release()
