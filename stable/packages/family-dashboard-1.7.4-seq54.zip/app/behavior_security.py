"""Independent source facade. No collection, commands or containment in API reads."""
import copy,re,uuid
from datetime import datetime,timezone
from security_events import instant,public_case
from security_health import public_monitor_health,public_protection_state,recovered_case,monitor_case,safe_time
from security_configuration import superseded_configuration_case,configuration_review_case
from behavior_events import public_behavior_case,make_case,LIMITS,behavior_health_case,recovered_behavior_health
def _metadata(value):
 value=value if isinstance(value,dict) else {};result={}
 for key,allowed in [('monitorState',{'OK','DEGRADED','STARTING','NOT_AVAILABLE'}),('baselineTrust',{'OBSERVED_UNREVIEWED','INTEGRITY_FAILED','NOT_AVAILABLE'}),('baselineQuality',{'COMPLETE_UNREVIEWED','PARTIAL_UNREVIEWED','INTEGRITY_FAILED','NOT_AVAILABLE'})]:
  v=value.get(key);result[key]=v if isinstance(v,str) and v in allowed else 'NOT_AVAILABLE'
 for key in ('lastCheckedAt','baselineObservedAt'):
  v=instant(value.get(key));result[key]=v.isoformat() if v else None
 try:result['baselineId']=str(uuid.UUID(value.get('baselineId')))
 except Exception:result['baselineId']='UNKNOWN'
 for key in ('osVersion','appVersion'):
  v=value.get(key);result[key]=v if isinstance(v,str) and len(v)<=64 and re.fullmatch(r'[0-9]+(?:[.][0-9A-Za-z]+){0,5}',v) else 'UNKNOWN'
 result['coverage']={};result['sectionObservedAt']={}
 for key in ('processes','network','persistence','security','integrity'):
  cov=value.get('coverage',{});v=cov.get(key) if isinstance(cov,dict) else None;result['coverage'][key]=v if isinstance(v,str) and v in {'OK','PARTIAL','UNAVAILABLE','NOT_COLLECTED'} else 'UNAVAILABLE'
  times=value.get('sectionObservedAt',{});at=instant(times.get(key)) if isinstance(times,dict) else None;result['sectionObservedAt'][key]=at.isoformat() if at else None
 count=value.get('stableObservations');result['stableObservations']=min(65535,max(0,count)) if type(count) is int else 0;result['limits']=dict(LIMITS);return result

class UnifiedSecurityMonitor:
 def __init__(self,defender,behavior):self.defender=defender;self.behavior=behavior;self.failed=set();self.start_failed=set();self.health_cases={};self.last_good={}
 def start(self):
  for name,monitor in [('defender',self.defender),('behavior',self.behavior)]:
   try:monitor.start()
   except Exception:self.start_failed.add(name)
 def stop(self):
  for monitor in (self.defender,self.behavior):
   try:monitor.stop()
   except Exception:pass
 def _read(self,name,monitor):
  try:
   value=monitor.snapshot();cap=32 if name=='defender' else 16
   if not isinstance(value,dict) or value.get('monitorState') not in ('OK','DEGRADED','STARTING','NOT_AVAILABLE') or not isinstance(value.get('cases'),list) or len(value['cases'])>cap:raise ValueError()
   if value.get('lastCheckedAt') is not None and instant(value.get('lastCheckedAt')) is None:raise ValueError()
   for case in value['cases']:
    if not isinstance(case,dict) or str(uuid.UUID(case.get('CASE_ID')))!=case.get('CASE_ID') or not instant(case.get('DETECTED_AT')):raise ValueError()
   value=dict(value);value['cases']=[public_case(c) if name=='defender' else public_behavior_case(c) for c in value['cases']]
   if name=='behavior':
    value['behavior']=_metadata(value.get('behavior'))
    h=value.get('behaviorHealth')
    if not isinstance(h,dict):h={'status':'MONITOR_OK' if value['monitorState']=='OK' else 'STARTING' if value['monitorState']=='STARTING' else 'MONITOR_UNAVAILABLE','reason':'NONE' if value['monitorState'] in ('OK','STARTING') else 'BEHAVIOR_SOURCE_UNAVAILABLE','lastSuccessfulPollAt':value.get('lastCheckedAt') if value['monitorState']=='OK' else None,'lastAttemptAt':value.get('lastCheckedAt')}
    value['behaviorHealth']=public_monitor_health(h)
    if name in self.start_failed:
     if value['behaviorHealth']['workerAlive'] and value['behaviorHealth']['status']=='MONITOR_OK':self.start_failed.discard(name)
     else:value['behaviorHealth']=public_monitor_health(dict(value['behaviorHealth'],status='MONITOR_UNAVAILABLE',reason='BEHAVIOR_START_FAILED'))
   elif isinstance(value.get('monitorHealth'),dict):value['monitorHealth']=public_monitor_health(value['monitorHealth'])
   if name=='defender':
    value['currentProtection']=public_protection_state(value.get('currentProtection'));value['currentProtectionObservedAt']=safe_time(value.get('currentProtectionObservedAt'))
   self.last_good[name]=copy.deepcopy({k:value[k] for k in ('cases','behavior','behaviorHealth','monitorHealth','currentProtection','currentProtectionObservedAt','lastCheckedAt','wifiState') if k in value})
   self.failed.discard(name);self.health_cases.pop(name,None);return value
  except Exception:
   self.failed.add(name)
   reason='BEHAVIOR_INITIALIZATION_FAILED' if monitor is None else 'BEHAVIOR_START_FAILED' if name in self.start_failed else 'BEHAVIOR_INVALID_SNAPSHOT'
   if name=='behavior' and name not in self.health_cases:self.health_cases[name]=make_case(datetime.now(timezone.utc),'SOURCE_DEGRADED',MONITOR_REASON=reason,MONITOR_INCIDENT_STATUS='ACTIVE',LIMITATIONS=['SOURCE_UNAVAILABLE'],MISSING_EVIDENCE=['EVIDENCE_NOT_SAVED','ORIGINAL_RAW_EVIDENCE'],RECOMMENDED_INVESTIGATION=['CHECK_MONITOR_HEALTH'])
   value=copy.deepcopy(self.last_good.get(name,{'cases':[],'lastCheckedAt':None}));value['monitorState']='NOT_AVAILABLE'
   if name in self.health_cases and len(value['cases'])<(32 if name=='defender' else 16):value['cases'].append(self.health_cases[name])
   key='behaviorHealth' if name=='behavior' else 'monitorHealth';h=value.get(key,{})
   value[key]=public_monitor_health(dict(h,status='MONITOR_UNAVAILABLE',reason=reason if name=='behavior' else 'UNKNOWN',lastReason=reason if name=='behavior' else 'UNKNOWN',recoveryResult='STILL_UNAVAILABLE'))
   return value
 def snapshot(self):
  d=self._read('defender',self.defender);b=self._read('behavior',self.behavior)
  dc=d.get('cases',[])[:32];bc=[public_behavior_case(c) for c in b.get('cases',[])[:16]]
  for c in bc:
   c['DEFENDER_REFERENCE']='NOT_LINKED';c['DEFENDER_CASE_ID']='UNKNOWN';sha=c.get('BINARY_SHA256');at=instant(c.get('OBSERVED_AT'))
   if sha!='UNKNOWN' and at:
    matches=[x for x in dc if sha in x.get('RESOURCE_HASHES',[]) and instant(x.get('DETECTED_AT')) and abs((at-instant(x['DETECTED_AT'])).total_seconds())<=300]
    if matches:c['DEFENDER_REFERENCE']='SAME_SHA256_TIME_WINDOW';c['DEFENDER_CASE_ID']=matches[-1]['CASE_ID']
  def priority(c):
   if c.get('ALERT_LEVEL')=='CRITICAL':return 0
   if c.get('EVENT_SOURCE')!='BEHAVIOR_MONITOR':return 1
   if c.get('CONFIDENCE')=='MULTI_SOURCE_IDENTITY_LINKED':return 2
   if 'BASELINE_REVIEW' in c.get('ANOMALY_TYPE',[]):return 5
   if set(c.get('ANOMALY_TYPE',[]))&{'SOURCE_DEGRADED','STATE_WRITE_FAILED','STATE_INTEGRITY_FAILED','STATE_RECOVERED','CASE_OVERFLOW'}:return 4
   return 3
  cases=sorted(dc+bc,key=priority)
  times={name:instant(value.get('lastCheckedAt')) for name,value in [('defender',d),('behavior',b)]}
  source_checked={name:at.isoformat() if at else None for name,at in times.items()};checked=source_checked['defender']
  state='DEGRADED' if self.failed or self.start_failed or any(x.get('monitorState') not in ('OK','STARTING') for x in (d,b)) else 'STARTING' if any(x.get('monitorState')=='STARTING' for x in (d,b)) else 'OK'
  def pending(c):
   return not c.get('ACKNOWLEDGED') and not recovered_case(c) and not recovered_behavior_health(c) and not superseded_configuration_case(c)
  result={'schemaVersion':1,'mode':'MONITOR_ONLY','autoIsolationEnabled':False,'monitorState':state,'lastCheckedAt':checked,'wifiState':d.get('wifiState','UNKNOWN'),'cases':cases,'unacknowledgedCount':sum(pending(c) for c in cases),'behavior':b.get('behavior',{}),'sourceStates':{'defender':d.get('monitorState','NOT_AVAILABLE'),'behavior':b.get('monitorState','NOT_AVAILABLE')},'sourceCheckedAt':source_checked}
  if isinstance(d.get('monitorHealth'),dict):result['monitorHealth']=d['monitorHealth']
  result['behaviorHealth']=public_monitor_health(b.get('behaviorHealth'))
  result['currentProtection']=public_protection_state(d.get('currentProtection'))
  result['currentProtectionObservedAt']=safe_time(d.get('currentProtectionObservedAt'))
  result['pendingCaseCount']=sum(pending(c) and not monitor_case(c) and not behavior_health_case(c) for c in cases)
  result['securityReviewCount']=sum(pending(c) and configuration_review_case(c) for c in cases)
  result['securityAlertCount']=result['pendingCaseCount']-result['securityReviewCount']
  result['monitorHealthCount']=sum(h.get('status')=='MONITOR_UNAVAILABLE' for h in (d.get('monitorHealth',{}),result['behaviorHealth']))
  return result
 def acknowledge(self,case_id):
  for name,monitor in [('defender',self.defender),('behavior',self.behavior)]:
   s=self._read(name,monitor)
   if any(c.get('CASE_ID')==case_id for c in s.get('cases',[])):
    try:return monitor.acknowledge(case_id)
    except Exception:return False
  return False
