param(
    [string]$IncidentAt,
    [ValidateRange(6,168)][int]$HoursBefore = 48,
    [ValidateRange(1,72)][int]$HoursAfter = 12,
    [switch]$LibraryOnly
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

function Set-FixedForensicEnvironment {
    $env:PSModulePath = 'C:\Windows\System32\WindowsPowerShell\v1.0\Modules;C:\Program Files\WindowsPowerShell\Modules'
    $env:PATH = 'C:\Windows\System32;C:\Windows'
    [Environment]::CurrentDirectory = 'C:\Windows\System32'
}
Set-FixedForensicEnvironment

function Convert-IsoTime($Value) {
    if ($null -eq $Value) { return $null }
    try {
        $date = [datetimeoffset]$Value
        return $date.ToLocalTime().ToString('yyyy-MM-ddTHH:mm:ss.fffzzz', [Globalization.CultureInfo]::InvariantCulture)
    } catch { return $null }
}

function Resolve-DashboardDataRoot([object[]]$Accounts, [object[]]$Profiles) {
    $account = @($Accounts | Where-Object { $_.Name -ceq 'DashboardAdmin' -and $_.LocalAccount -eq $true })
    if ($account.Count -ne 1 -or [string]$account[0].SID -notmatch '^S-1-5-21-(?:\d+-){3}\d+$') {
        throw 'DashboardAdmin account could not be identified uniquely by SID.'
    }
    $profile = @($Profiles | Where-Object { $_.SID -ceq $account[0].SID })
    if ($profile.Count -ne 1 -or [string]::IsNullOrWhiteSpace([string]$profile[0].LocalPath)) {
        throw 'DashboardAdmin profile could not be identified uniquely by SID.'
    }
    $localPath = [IO.Path]::GetFullPath([string]$profile[0].LocalPath)
    if (-not [IO.Path]::IsPathRooted($localPath) -or $localPath -notmatch '^[A-Za-z]:\\') {
        throw 'DashboardAdmin profile path is not a fixed local path.'
    }
    return [IO.Path]::Combine($localPath, 'AppData', 'Local', 'FamilyDashboard')
}

function Get-KernelPower41Fields([string]$XmlText) {
    $allowed = @('BugcheckCode','BugcheckParameter1','BugcheckParameter2','BugcheckParameter3',
        'BugcheckParameter4','PowerButtonTimestamp','SleepInProgress','BootAppStatus',
        'LongPowerButtonPressDetected')
    $result = [ordered]@{}
    try {
        [xml]$doc = $XmlText
        foreach ($node in @($doc.SelectNodes("//*[local-name()='EventData']/*[local-name()='Data']"))) {
            $name = [string]$node.GetAttribute('Name')
            $value = [string]$node.InnerText
            if ($allowed -ccontains $name -and $value -match '^(?:0x[0-9A-Fa-f]+|[0-9]+|true|false)$') {
                $result[$name] = $value
            }
        }
    } catch {}
    return $result
}

function Get-Event6008ReportedTime([string]$XmlText) {
    try {
        [xml]$doc = $XmlText
        $values = @($doc.SelectNodes("//*[local-name()='EventData']/*[local-name()='Data']") |
            Select-Object -First 2 | ForEach-Object { [string]$_.InnerText })
        if ($values.Count -ne 2 -or $values[0] -notmatch '^\d{1,2}:\d\d:\d\d(?:\s*[AP]M)?$' -or
            $values[1] -notmatch '^\d{1,4}[/.-]\d{1,2}[/.-]\d{1,4}$') { return $null }
        $parsed = [datetime]::MinValue
        foreach ($culture in @([Globalization.CultureInfo]::CurrentCulture,
                [Globalization.CultureInfo]::GetCultureInfo('en-US'))) {
            if ([datetime]::TryParse(($values[1] + ' ' + $values[0]), $culture,
                    [Globalization.DateTimeStyles]::AssumeLocal, [ref]$parsed)) {
                return Convert-IsoTime $parsed
            }
        }
    } catch {}
    return $null
}

function Get-SafeTaskEventName([string]$XmlText) {
    try {
        [xml]$doc = $XmlText
        $node = $doc.SelectSingleNode("//*[local-name()='EventData']/*[local-name()='Data' and @Name='TaskName']")
        if ($node -and [string]$node.InnerText -match '(?:^|\\)(FamilyDashboard-[A-Za-z0-9_-]{1,60})$') {
            return $Matches[1]
        }
    } catch {}
    return 'OTHER_TASK'
}

function Get-SafeApplicationLabel([string]$XmlText) {
    try {
        [xml]$doc = $XmlText
        foreach ($node in @($doc.SelectNodes("//*[local-name()='EventData']/*[local-name()='Data']")) | Select-Object -First 8) {
            $value = [string]$node.InnerText
            if ($value -match '(?:^|[\\/])(pythonw?\.exe|msedge\.exe|FamilyDashboard(?:\.exe)?)$') {
                return $Matches[1].ToLowerInvariant()
            }
        }
    } catch {}
    return 'OTHER_APP'
}

function Test-KernelPower41Event($Event) {
    return [int]$Event.Id -eq 41 -and [string]$Event.ProviderName -eq 'Microsoft-Windows-Kernel-Power'
}

function Resolve-CollectionWindow([datetimeoffset]$Anchor, [int]$BeforeHours,
        [int]$AfterHours, [datetimeoffset]$Now) {
    if ($Anchor -gt $Now.AddMinutes(5)) { throw 'IncidentAt is in the future.' }
    $start = $Anchor.AddHours(-$BeforeHours)
    $end = $Anchor.AddHours($AfterHours)
    if ($end -gt $Now) { $end = $Now }
    if ($start -ge $end) { throw 'Incident window has no elapsed time.' }
    return [pscustomobject]@{ Start=$start; End=$end }
}

function Assert-NoReparseComponents([string]$Path) {
    $current = [IO.Path]::GetFullPath($Path)
    while ($current) {
        if (Test-Path -LiteralPath $current) {
            $item = Get-Item -LiteralPath $current -Force -ErrorAction Stop
            if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
                throw 'A source path contains a reparse point.'
            }
        }
        $parent = [IO.Directory]::GetParent($current)
        if ($null -eq $parent) { break }
        $current = $parent.FullName
    }
}

function New-PrivateCaseSecurity {
    $security = New-Object Security.AccessControl.DirectorySecurity
    $security.SetAccessRuleProtection($true,$false)
    $admin = New-Object Security.Principal.SecurityIdentifier('S-1-5-32-544')
    $security.SetOwner($admin)
    $inherit = [Security.AccessControl.InheritanceFlags]::ContainerInherit -bor
        [Security.AccessControl.InheritanceFlags]::ObjectInherit
    foreach ($sidText in @('S-1-5-18','S-1-5-32-544')) {
        $sid = New-Object Security.Principal.SecurityIdentifier($sidText)
        $rule = New-Object Security.AccessControl.FileSystemAccessRule($sid,
            [Security.AccessControl.FileSystemRights]::FullControl,$inherit,
            [Security.AccessControl.PropagationFlags]::None,
            [Security.AccessControl.AccessControlType]::Allow)
        $security.AddAccessRule($rule)
    }
    return $security
}

function Test-LogSnapshotStable($Before, $After, [int]$ByteCount) {
    return ($Before.Length -eq $After.Length -and
        $Before.LastWriteTimeUtc -eq $After.LastWriteTimeUtc -and
        $ByteCount -eq $Before.Length)
}

function Copy-InitialDashboardLogSnapshot([string]$LogRoot, [string]$PrivateRoot,
        [string]$Name, [System.Collections.ArrayList]$Errors) {
    if (@('server-output.log','server-error.log') -cnotcontains $Name) { throw 'INVALID_LOG_NAME' }
    $record = [ordered]@{ name=$Name; result='MISSING'; bytes=$null; sourceLastWriteAt=$null;
        snapshotAt=Convert-IsoTime ([datetimeoffset]::Now); evidenceScope='collection-start-only; not guaranteed pre-incident' }
    $source = Join-Path $LogRoot $Name
    if (-not (Test-Path -LiteralPath $source -PathType Leaf)) {
        Add-CollectionError $Errors 'DashboardLogSnapshot' 'MISSING'
        return $record
    }
    try {
        Assert-NoReparseComponents $source
        Assert-NoReparseComponents $PrivateRoot
        $before = Get-Item -LiteralPath $source -Force -ErrorAction Stop
        if ($before.PSIsContainer -or $before.Length -gt 1048576) {
            $record.result = 'OVERSIZED_OR_NOT_REGULAR'
            Add-CollectionError $Errors 'DashboardLogSnapshot' $record.result
            return $record
        }
        $record.bytes = [long]$before.Length
        $record.sourceLastWriteAt = Convert-IsoTime $before.LastWriteTime
        $destination = Join-Path $PrivateRoot $Name
        $bytes = [IO.File]::ReadAllBytes($source)
        if ($bytes.Length -gt 1048576) { throw 'SOURCE_GREW' }
        [IO.File]::WriteAllBytes($destination, $bytes)
        $after = Get-Item -LiteralPath $source -Force -ErrorAction Stop
        Assert-NoReparseComponents $source
        if (-not (Test-LogSnapshotStable $before $after $bytes.Length)) {
            $record.result = 'RACING'
            Add-CollectionError $Errors 'DashboardLogSnapshot' 'RACING'
        } else { $record.result = 'SNAPSHOTTED' }
    } catch {
        $record.result = 'UNREADABLE'
        Add-CollectionError $Errors 'DashboardLogSnapshot' 'UNREADABLE'
    }
    return $record
}

function Convert-UpdaterRecord([string]$Line) {
    try { $item = ConvertFrom-Json -InputObject $Line -ErrorAction Stop } catch { return $null }
    if ($Line -notmatch '"at"\s*:\s*"20\d\d-\d\d-\d\dT\d\d:\d\d:\d\dZ"' -or
        [string]$item.event -notmatch '^[a-z0-9_-]{1,64}$' -or
        [string]$item.category -notmatch '^[A-Z0-9_-]{1,64}$' -or
        [string]$item.outcome -notmatch '^[a-z0-9_-]{1,64}$') { return $null }
    return [ordered]@{ at = Convert-IsoTime $item.at; event = [string]$item.event;
        category = [string]$item.category; outcome = [string]$item.outcome }
}

function Convert-DashboardErrorLine([string]$Line) {
    if ($Line -match '^Family Dashboard startup failed: ([A-Za-z][A-Za-z0-9_]{0,63}):') {
        return $Matches[1]
    }
    return $null
}

function Get-XmlNumericChild($Node, [string]$Name) {
    if ($null -eq $Node) { return $null }
    $child = $Node.SelectSingleNode("./*[local-name()='$Name']")
    if ($null -eq $child -or [string]$child.InnerText -notmatch '^\d{1,12}$') { return $null }
    return [long]$child.InnerText
}

function Convert-BatteryXml([string]$XmlText) {
    [xml]$doc = $XmlText
    $first = $doc.SelectSingleNode("//*[local-name()='Batteries']/*[local-name()='Battery']")
    $history = @()
    foreach ($node in @($doc.SelectNodes("//*[local-name()='HistoryEntry']")) | Select-Object -Last 60) {
        $start = $node.SelectSingleNode("./*[local-name()='LocalStartDate' or local-name()='StartDate']")
        $history += [ordered]@{
            period = if ($start -and [string]$start.InnerText -match '^20\d\d-\d\d-\d\d') { $Matches[0] } else { $null }
            fullChargeCapacityMWh = Get-XmlNumericChild $node 'FullChargeCapacity'
            designCapacityMWh = Get-XmlNumericChild $node 'DesignCapacity'
        }
    }
    $usage = @()
    foreach ($node in @($doc.SelectNodes("//*[local-name()='RecentUsage']/*")) | Select-Object -Last 120) {
        $time = $node.SelectSingleNode("./*[local-name()='LocalTimestamp' or local-name()='Timestamp']")
        $ac = $node.SelectSingleNode("./*[local-name()='Ac']")
        $entryType = $node.SelectSingleNode("./*[local-name()='EntryType']")
        $usage += [ordered]@{
            at = if ($time) { Convert-IsoTime ([string]$time.InnerText) } else { $null }
            entryType = if ($entryType -and [string]$entryType.InnerText -match '^[A-Za-z ]{1,32}$') { [string]$entryType.InnerText } else { $null }
            acConnected = if ($ac -and [string]$ac.InnerText -match '^(true|false|0|1)$') { [string]$ac.InnerText } else { $null }
            chargeCapacityMWh = Get-XmlNumericChild $node 'ChargeCapacity'
            fullChargeCapacityMWh = Get-XmlNumericChild $node 'FullChargeCapacity'
        }
    }
    return [ordered]@{
        designCapacityMWh = Get-XmlNumericChild $first 'DesignCapacity'
        fullChargeCapacityMWh = Get-XmlNumericChild $first 'FullChargeCapacity'
        capacityHistory = $history
        recentUsage = $usage
        note = 'Empty arrays mean the Windows battery-report XML did not expose recognizable rows; private HTML remains available for local review.'
    }
}

function Write-SafeJson([string]$Path, $Value) {
    $json = ConvertTo-Json -InputObject $Value -Depth 12
    [IO.File]::WriteAllText($Path, $json + [Environment]::NewLine, (New-Object Text.UTF8Encoding($false)))
}

function Add-CollectionError([System.Collections.ArrayList]$List, [string]$Component, [string]$Category) {
    [void]$List.Add([ordered]@{ component=$Component; category=$Category })
}

function Get-CollectionStatus([int]$SystemEventCount, [string]$BatteryReportStatus,
        [System.Collections.ArrayList]$Errors, [bool]$Truncated) {
    if ($SystemEventCount -le 0 -or @('PASS','HTML_ONLY') -cnotcontains $BatteryReportStatus) { return 'FAIL' }
    if ($BatteryReportStatus -eq 'HTML_ONLY' -or $Errors.Count -gt 0 -or $Truncated) { return 'PARTIAL' }
    return 'PASS'
}

function Get-SafeEvent($Event) {
    return [ordered]@{
        at = Convert-IsoTime $Event.TimeCreated
        log = [string]$Event.LogName
        provider = [string]$Event.ProviderName
        id = [int]$Event.Id
        recordId = [long]$Event.RecordId
        level = [int]$Event.Level
    }
}

function Test-RelevantSystemEvent($Event) {
    $provider = [string]$Event.ProviderName
    $id = [int]$Event.Id
    if ($provider -match '^(?:Microsoft-Windows-)?(?:WHEA-Logger|Disk|storahci|stornvme|Ntfs|volmgr|partmgr|Kernel-Storage|Storage-ClassPnP|Kernel-Boot|Power-Troubleshooter)$' -or
        $provider -match '^iaStor(?:A|AC|V)?$') { return $true }
    if ($provider -match '^(?:Microsoft-Windows-)?Kernel-Power$' -and $id -in @(41,42,107,109,172,506,507)) { return $true }
    if ($provider -eq 'EventLog' -and $id -in @(6005,6006,6008)) { return $true }
    if ($provider -eq 'User32' -and $id -eq 1074) { return $true }
    if ($provider -match '^(?:Microsoft-Windows-)?(?:BugCheck|WER-SystemErrorReporting)$' -and $id -eq 1001) { return $true }
    return $false
}

function Test-RelevantApplicationEvent($Event) {
    $provider = [string]$Event.ProviderName
    return $provider -match '^(Application Error|Application Hang|Windows Error Reporting|WER-SystemErrorReporting)$' -and
        [int]$Event.Id -in @(1000,1001,1002)
}

if ($LibraryOnly) { return }

$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'Run from an elevated Windows PowerShell session. No data was collected.'
}

$accounts = @(Get-CimInstance Win32_UserAccount -Filter "LocalAccount=True AND Name='DashboardAdmin'")
if ($accounts.Count -ne 1 -or [string]$accounts[0].SID -notmatch '^S-1-5-21-(?:\d+-){3}\d+$') {
    throw 'DashboardAdmin local account SID is unavailable or ambiguous.'
}
$profiles = @(Get-CimInstance Win32_UserProfile -Filter ("SID='" + [string]$accounts[0].SID + "'") |
    Select-Object SID, LocalPath)
$dashboardData = Resolve-DashboardDataRoot -Accounts $accounts -Profiles $profiles
$expectedLauncher = 'C:\FamilyDashboard\launcher\Start-FamilyDashboard.ps1'
if (-not (Test-Path -LiteralPath $expectedLauncher -PathType Leaf)) { throw 'Installed Dashboard launcher not found.' }
Assert-NoReparseComponents $expectedLauncher
$expectedLauncherSha256 = 'AA49F488AD51490E243FDD10BA855F0E01B8831D89D5427EB2B1F3E6E7361CFF'
if ((Get-FileHash -Algorithm SHA256 -LiteralPath $expectedLauncher).Hash -cne $expectedLauncherSha256) {
    throw 'Installed launcher does not match the signed 1.6.24 / sequence 39 launcher.'
}
$launcherText = [IO.File]::ReadAllText($expectedLauncher)
if ($launcherText -notmatch 'DashboardAdmin' -or $launcherText -notmatch 'Join-Path \$env:LOCALAPPDATA "FamilyDashboard"') {
    throw 'Installed launcher does not match the expected DashboardAdmin private-data convention.'
}
if (-not (Test-Path -LiteralPath $dashboardData -PathType Container)) { throw 'DashboardAdmin FamilyDashboard data root not found.' }
Assert-NoReparseComponents $dashboardData

if ($IncidentAt) {
    try { $anchor = [datetimeoffset]::Parse($IncidentAt, [Globalization.CultureInfo]::InvariantCulture) }
    catch { throw 'IncidentAt must be ISO 8601 with timezone offset, e.g. 2026-09-22T07:00:00+09:00.' }
    if ($IncidentAt -notmatch '(Z|[+-]\d\d:\d\d)$') { throw 'IncidentAt requires a timezone offset.' }
} else {
    $since = (Get-Date).AddDays(-14)
    $candidates = @(Get-WinEvent -FilterHashtable @{LogName='System';Id=41,6008;StartTime=$since} -ErrorAction SilentlyContinue |
        Where-Object { (Test-KernelPower41Event $_) -or
            ($_.Id -eq 6008 -and $_.ProviderName -eq 'EventLog') } | Sort-Object TimeCreated -Descending)
    if ($candidates.Count -eq 0) { throw 'No recent 41/6008 anchor found. Supply -IncidentAt with an ISO 8601 offset.' }
    $anchor = [datetimeoffset]$candidates[0].TimeCreated
}
$window = Resolve-CollectionWindow -Anchor $anchor -BeforeHours $HoursBefore -AfterHours $HoursAfter -Now ([datetimeoffset]::Now)
$start = $window.Start
$end = $window.End

$caseId = 'case-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + [Guid]::NewGuid().ToString('N').Substring(0,8)
$base = 'C:\ProgramData\FamilyDashboardForensics'
if (-not (Test-Path -LiteralPath $base -PathType Container)) { throw 'Protected evidence root is unavailable.' }
Assert-NoReparseComponents $base
$case = Join-Path $base $caseId
$caseSecurity = New-PrivateCaseSecurity
[void][IO.Directory]::CreateDirectory($case,$caseSecurity)
$private = Join-Path $case 'private-evidence-DO-NOT-SHARE'
$shared = Join-Path $case 'sanitized-share'
[void][IO.Directory]::CreateDirectory($private,(New-PrivateCaseSecurity))
[void][IO.Directory]::CreateDirectory($shared,(New-PrivateCaseSecurity))
$errors = New-Object System.Collections.ArrayList
$logSnapshots = @(@('server-output.log','server-error.log') | ForEach-Object {
    Copy-InitialDashboardLogSnapshot -LogRoot (Join-Path $dashboardData 'logs') `
        -PrivateRoot $private -Name $_ -Errors $errors
})

$systemAll = @()
try { $systemAll = @(Get-WinEvent -FilterHashtable @{LogName='System';StartTime=$start.LocalDateTime;EndTime=$end.LocalDateTime} -MaxEvents 20000 -ErrorAction Stop) }
catch { Add-CollectionError $errors 'System' 'EVENT_READ_FAILED' }
$systemSelected = @($systemAll | Where-Object { Test-RelevantSystemEvent $_ } | ForEach-Object { Get-SafeEvent $_ })
Write-SafeJson (Join-Path $shared 'system-events.json') $systemSelected
$event41 = @($systemAll | Where-Object { Test-KernelPower41Event $_ } | ForEach-Object {
    [ordered]@{ at=Convert-IsoTime $_.TimeCreated; recordId=[long]$_.RecordId; provider='Microsoft-Windows-Kernel-Power';
        fields=Get-KernelPower41Fields $_.ToXml() }
})
Write-SafeJson (Join-Path $shared 'kernel-power-41.json') $event41

$application = @()
try { $application = @(Get-WinEvent -FilterHashtable @{LogName='Application';StartTime=$start.LocalDateTime;EndTime=$end.LocalDateTime} -MaxEvents 12000 -ErrorAction Stop) }
catch { Add-CollectionError $errors 'Application' 'EVENT_READ_FAILED' }
$applicationSelected = @($application | Where-Object { Test-RelevantApplicationEvent $_ } | ForEach-Object {
    $safe = Get-SafeEvent $_
    $safe['app'] = Get-SafeApplicationLabel -XmlText ($_.ToXml())
    $safe
})
Write-SafeJson (Join-Path $shared 'application-events.json') $applicationSelected

$reliability = @()
try { $reliability = @(Get-CimInstance Win32_ReliabilityRecords -ErrorAction Stop | Where-Object {
    $_.TimeGenerated -ge $start.LocalDateTime -and $_.TimeGenerated -le $end.LocalDateTime
} | Select-Object -First 500 | ForEach-Object {
    [ordered]@{ at=Convert-IsoTime $_.TimeGenerated; source=if ([string]$_.SourceName -match '^(?:Microsoft-Windows-[A-Za-z0-9_-]+|Windows Error Reporting|Application Hang|Application Error)$') { [string]$_.SourceName } else { 'OTHER' };
        eventId=if ([string]$_.EventIdentifier -match '^\d{1,10}$') { [string]$_.EventIdentifier } else { $null } }
}) } catch { Add-CollectionError $errors 'Reliability' 'CIM_UNAVAILABLE' }
Write-SafeJson (Join-Path $shared 'reliability.json') $reliability

$dumps = @()
foreach ($path in @('C:\Windows\MEMORY.DMP')) {
    if (Test-Path -LiteralPath $path -PathType Leaf) {
        try {
            Assert-NoReparseComponents $path
            $file = Get-Item -LiteralPath $path -ErrorAction Stop
            $dumps += [ordered]@{ kind='MEMORY.DMP'; bytes=[long]$file.Length; lastWriteAt=Convert-IsoTime $file.LastWriteTime }
        } catch { Add-CollectionError $errors 'MemoryDump' 'METADATA_UNAVAILABLE' }
    }
}
if (Test-Path -LiteralPath 'C:\Windows\Minidump' -PathType Container) {
    try {
        foreach ($file in @(Get-ChildItem -LiteralPath 'C:\Windows\Minidump' -File -Filter '*.dmp' -ErrorAction Stop | Sort-Object LastWriteTime -Descending | Select-Object -First 30)) {
            Assert-NoReparseComponents $file.FullName
            $dumps += [ordered]@{ kind='minidump'; bytes=[long]$file.Length; lastWriteAt=Convert-IsoTime $file.LastWriteTime }
        }
    } catch { Add-CollectionError $errors 'Minidump' 'METADATA_UNAVAILABLE' }
}
Write-SafeJson (Join-Path $shared 'dump-metadata.json') $dumps

$battery = [ordered]@{ reportStatus='UNAVAILABLE'; designCapacityMWh=$null; fullChargeCapacityMWh=$null;
    capacityHistory=@(); recentUsage=@(); currentEstimatedPercent=$null }
$html = Join-Path $private 'battery-report.html'
$xmlPath = Join-Path $private 'battery-report.xml'
try {
    & 'C:\Windows\System32\powercfg.exe' /batteryreport /output $html | Out-Null
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $html -PathType Leaf)) { throw 'BATTERYREPORT_HTML_FAILED' }
    & 'C:\Windows\System32\powercfg.exe' /batteryreport /xml /output $xmlPath | Out-Null
    if ($LASTEXITCODE -eq 0 -and (Test-Path -LiteralPath $xmlPath -PathType Leaf)) {
        $battery = Convert-BatteryXml -XmlText ([IO.File]::ReadAllText($xmlPath))
        $battery['reportStatus'] = 'PASS'
    } else { $battery['reportStatus'] = 'HTML_ONLY' }
} catch { Add-CollectionError $errors 'BatteryReport' 'REPORT_FAILED' }
try {
    $batteryCim = @(Get-CimInstance Win32_Battery -ErrorAction Stop | Select-Object -First 1)
    if ($batteryCim.Count -gt 0 -and $batteryCim[0].EstimatedChargeRemaining -ge 0 -and $batteryCim[0].EstimatedChargeRemaining -le 100) {
        $battery['currentEstimatedPercent'] = [int]$batteryCim[0].EstimatedChargeRemaining
    }
} catch { Add-CollectionError $errors 'BatteryCim' 'CIM_UNAVAILABLE' }
Write-SafeJson (Join-Path $shared 'battery.json') $battery

$dashboard = [ordered]@{ profileResolution='DashboardAdmin SID -> Win32_UserProfile.LocalPath'; launcherConvention='VERIFIED';
    logs=@(); lastDashboardEventAt=$null; lastDashboardLogWriteAt=$null; lastBatteryReadingAt=$null; lastSwitchBotStatusAt=$null;
    lastSwitchBotCommandAt=$null; lastSwitchBotCommandResultAt=$null;
    evidenceLimit='SwitchBot battery/status/command history is process-memory only in release 1.6.24; no durable per-cycle log exists.' }
$logRoot = Join-Path $dashboardData 'logs'
if (Test-Path -LiteralPath $logRoot) {
    if (((Get-Item -LiteralPath $logRoot -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
        Add-CollectionError $errors 'DashboardLog' 'REPARSE_POINT_REJECTED'
        $logRoot = $null
    }
}
foreach ($name in @('server-output.log','server-error.log')) {
    if (-not $logRoot) { break }
    $path = Join-Path $logRoot $name
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { continue }
    try {
        Assert-NoReparseComponents $path
        $file = Get-Item -LiteralPath $path
        $entry = [ordered]@{ name=$name; bytes=[long]$file.Length; lastWriteAt=Convert-IsoTime $file.LastWriteTime; startupVersion=$null; startupErrorCategory=$null }
        if ($file.Length -le 1048576) {
            foreach ($line in @(Get-Content -LiteralPath $path -Tail 100 -ErrorAction Stop)) {
                if ($name -eq 'server-output.log' -and $line -match '^Family Dashboard (\d+\.\d+\.\d+) \(') { $entry.startupVersion=$Matches[1] }
                if ($name -eq 'server-error.log') { $cat = Convert-DashboardErrorLine $line; if ($cat) { $entry.startupErrorCategory=$cat } }
            }
        } else { Add-CollectionError $errors 'DashboardLog' 'OVERSIZE_NOT_READ' }
        $dashboard.logs += $entry
        if (-not $dashboard.lastDashboardLogWriteAt -or $entry.lastWriteAt -gt $dashboard.lastDashboardLogWriteAt) {
            $dashboard.lastDashboardLogWriteAt = $entry.lastWriteAt
        }
    } catch { Add-CollectionError $errors 'DashboardLog' 'READ_FAILED' }
}
Write-SafeJson (Join-Path $shared 'dashboard.json') $dashboard
Write-SafeJson (Join-Path $shared 'dashboard-log-snapshots.json') $logSnapshots

$updaterRoot = 'C:\ProgramData\FamilyDashboardUpdater'
$updater = [ordered]@{ installedVersion=$null; installedSequence=$null; installedAt=$null; records=@(); statusUpdatedAt=$null }
if (Test-Path -LiteralPath $updaterRoot) { Assert-NoReparseComponents $updaterRoot }
foreach ($relative in @('state\installed.json','status\status.json')) {
    $path = Join-Path $updaterRoot $relative
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { continue }
    try {
        Assert-NoReparseComponents $path
        $file = Get-Item -LiteralPath $path
        if ($file.Length -gt 65536) { throw 'OVERSIZE' }
        $value = Get-Content -LiteralPath $path -Raw | ConvertFrom-Json
        if ($relative -eq 'state\installed.json') {
            if ([string]$value.installedVersion -match '^\d+\.\d+\.\d+$') { $updater.installedVersion=[string]$value.installedVersion }
            if ($value.installedSequence -is [int] -or $value.installedSequence -is [long]) { $updater.installedSequence=[int]$value.installedSequence }
            $updater.installedAt=Convert-IsoTime $value.updatedAt
        } else { $updater.statusUpdatedAt=Convert-IsoTime $value.updatedAt }
    } catch { Add-CollectionError $errors 'UpdaterState' 'READ_FAILED' }
}
foreach ($name in @('updater.5.jsonl','updater.4.jsonl','updater.3.jsonl','updater.2.jsonl','updater.jsonl')) {
    $path = Join-Path $updaterRoot (Join-Path 'logs' $name)
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { continue }
    try {
        Assert-NoReparseComponents $path
        if ((Get-Item -LiteralPath $path).Length -gt 1100000) { throw 'OVERSIZE' }
        foreach ($line in @(Get-Content -LiteralPath $path -ErrorAction Stop)) {
            $record = Convert-UpdaterRecord $line
            if ($record) { $updater.records += $record }
        }
    } catch { Add-CollectionError $errors 'UpdaterLog' 'READ_FAILED' }
}
Write-SafeJson (Join-Path $shared 'updater.json') $updater

$recent = [ordered]@{ windowsUpdates=@(); hotfixes=@(); driverEvents=@(); driverDates=@(); edge=@(); scheduledTasks=@() }
$changeStart = (Get-Date).AddDays(-45)
try {
    $recent.hotfixes = @(Get-HotFix -ErrorAction Stop | Where-Object { $_.InstalledOn -and $_.InstalledOn -ge $changeStart } |
        Select-Object -First 100 | ForEach-Object { [ordered]@{
            installedOn=Convert-IsoTime $_.InstalledOn;
            kb=if ([string]$_.HotFixID -match '^KB\d{5,8}$') { [string]$_.HotFixID } else { $null }
        } })
} catch { Add-CollectionError $errors 'WindowsHotFix' 'HISTORY_UNAVAILABLE' }
foreach ($spec in @(
    @{ log='Microsoft-Windows-WindowsUpdateClient/Operational'; target='windowsUpdates' },
    @{ log='Microsoft-Windows-Kernel-PnP/Configuration'; target='driverEvents' },
    @{ log='Microsoft-Windows-UserPnp/DeviceInstall'; target='driverEvents' }
)) {
    try {
        foreach ($event in @(Get-WinEvent -FilterHashtable @{LogName=$spec.log;StartTime=$changeStart} -MaxEvents 500 -ErrorAction Stop)) {
            $recent[$spec.target] += [ordered]@{ at=Convert-IsoTime $event.TimeCreated; source=$spec.target; id=[int]$event.Id }
        }
    } catch { Add-CollectionError $errors $spec.log 'LOG_UNAVAILABLE' }
}
try {
    $recent.driverDates = @(Get-CimInstance Win32_PnPSignedDriver -ErrorAction Stop | Where-Object { $_.DriverDate -ge $changeStart } |
        Select-Object -First 100 | ForEach-Object { [ordered]@{ driverDate=Convert-IsoTime $_.DriverDate;
            deviceClass=if ([string]$_.DeviceClass -match '^[A-Za-z0-9_-]{1,40}$') { [string]$_.DeviceClass } else { 'OTHER' };
            driverVersion=if ([string]$_.DriverVersion -match '^[0-9.]{1,40}$') { [string]$_.DriverVersion } else { $null } } })
} catch { Add-CollectionError $errors 'DriverCim' 'CIM_UNAVAILABLE' }
foreach ($edgePath in @('C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe','C:\Program Files\Microsoft\Edge\Application\msedge.exe')) {
    if (Test-Path -LiteralPath $edgePath -PathType Leaf) {
        try {
            Assert-NoReparseComponents $edgePath
            $edgeFile = Get-Item -LiteralPath $edgePath -ErrorAction Stop
            $version = [string]$edgeFile.VersionInfo.ProductVersion
            $recent.edge = @([ordered]@{ version=if ($version -match '^[0-9.]{1,40}$') { $version } else { $null };
                binaryLastWriteAt=Convert-IsoTime $edgeFile.LastWriteTime })
        } catch { Add-CollectionError $errors 'EdgeBinary' 'METADATA_UNAVAILABLE' }
        break
    }
}
try {
    foreach ($task in @(Get-ScheduledTask -ErrorAction Stop)) {
        if ($task.TaskName -match '^FamilyDashboard-[A-Za-z0-9_-]{1,60}$') {
            $recent.scheduledTasks += [ordered]@{ observedAt=Convert-IsoTime ([datetimeoffset]::Now); task=$task.TaskName;
                registrationAt=$null; source='current task enumeration; no action or task XML read' }
        }
    }
} catch { Add-CollectionError $errors 'ScheduledTask' 'ENUMERATION_FAILED' }
try {
    foreach ($event in @(Get-WinEvent -FilterHashtable @{LogName='Microsoft-Windows-TaskScheduler/Operational';
            StartTime=$changeStart;Id=106,140,141} -MaxEvents 500 -ErrorAction Stop)) {
        $recent.scheduledTasks += [ordered]@{ observedAt=Convert-IsoTime $event.TimeCreated; task=Get-SafeTaskEventName -XmlText ($event.ToXml());
            registrationAt=Convert-IsoTime $event.TimeCreated; sourceProvider='TaskScheduler'; id=[int]$event.Id;
            source='TaskScheduler operational log; task names and action XML omitted' }
    }
} catch { Add-CollectionError $errors 'TaskSchedulerHistory' 'LOG_UNAVAILABLE' }
Write-SafeJson (Join-Path $shared 'recent-changes.json') $recent

$boot = $null
try { $boot = Convert-IsoTime (Get-CimInstance Win32_OperatingSystem -ErrorAction Stop).LastBootUpTime } catch { Add-CollectionError $errors 'BootTime' 'CIM_UNAVAILABLE' }
$last41 = @($systemAll | Where-Object { Test-KernelPower41Event $_ } | Sort-Object TimeCreated -Descending | Select-Object -First 1)
$last6008 = @($systemAll | Where-Object { $_.Id -eq 6008 -and $_.ProviderName -eq 'EventLog' } | Sort-Object TimeCreated -Descending | Select-Object -First 1)
$reportedShutdown = $null
if ($last6008.Count -gt 0) { $reportedShutdown = Get-Event6008ReportedTime -XmlText ($last6008[0].ToXml()) }
$lastNormal = @()
if ($reportedShutdown) {
    $cutoff = [datetimeoffset]::Parse($reportedShutdown)
    $lastNormal = @($systemAll | Where-Object { $_.TimeCreated -lt $cutoff.LocalDateTime -and
        $_.Level -eq 4 -and $_.Id -notin @(41,6008) } | Sort-Object TimeCreated -Descending | Select-Object -First 1)
}
$timeline = @(
    [ordered]@{ at=if ($lastNormal.Count -gt 0) { Convert-IsoTime $lastNormal[0].TimeCreated } else { $null }; kind='last_informational_system_event_before_reported_shutdown'; precision='informational event; not proof of system health' },
    [ordered]@{ at=$dashboard.lastDashboardEventAt; kind='last_family_dashboard_event'; precision='not durably logged; unknown' },
    [ordered]@{ at=$dashboard.lastDashboardLogWriteAt; kind='last_dashboard_log_file_write'; precision='file metadata only; may be from restart after incident' },
    [ordered]@{ at=$dashboard.lastBatteryReadingAt; kind='last_battery_reading'; precision='not durably logged; unknown' },
    [ordered]@{ at=$dashboard.lastSwitchBotCommandAt; kind='last_switchbot_command_result'; precision='not durably logged; unknown' },
    [ordered]@{ at=$reportedShutdown; kind='event6008_reported_unexpected_shutdown'; precision='Windows-reported prior shutdown time, if parsable' },
    [ordered]@{ at=if ($last41.Count -gt 0) { Convert-IsoTime $last41[0].TimeCreated } else { $null }; kind='event41_recorded_at_next_boot'; precision='not exact shutdown time' },
    [ordered]@{ at=$boot; kind='current_boot'; precision='Win32_OperatingSystem.LastBootUpTime' }
)
Write-SafeJson (Join-Path $shared 'timeline.json') $timeline
@($timeline | Where-Object { $_.at } | Sort-Object at | ForEach-Object {
    [pscustomobject]@{ at=$_.at; kind=$_.kind; precision=$_.precision }
}) | Export-Csv -LiteralPath (Join-Path $shared 'timeline.csv') -NoTypeInformation -Encoding UTF8
Write-SafeJson (Join-Path $shared 'collection-errors.json') @($errors)
$summary = [ordered]@{ collectedAt=Convert-IsoTime ([datetimeoffset]::Now); anchorAt=Convert-IsoTime $anchor;
    windowStart=Convert-IsoTime $start; windowEnd=Convert-IsoTime $end; currentBootAt=$boot;
    latestEvent41At=if ($last41.Count -gt 0) { Convert-IsoTime $last41[0].TimeCreated } else { $null };
    event6008ReportedShutdownAt=$reportedShutdown;
    selectedSystemEventCount=$systemSelected.Count; selectedApplicationEventCount=$applicationSelected.Count;
    eventQueryTruncated=($systemAll.Count -ge 20000 -or $application.Count -ge 12000);
    dashboardProfileMethod='DashboardAdmin SID to Win32_UserProfile.LocalPath; installed launcher checked';
    collectionStatus=Get-CollectionStatus -SystemEventCount $systemSelected.Count `
        -BatteryReportStatus $battery.reportStatus -Errors $errors `
        -Truncated ($systemAll.Count -ge 20000 -or $application.Count -ge 12000);
    evidenceLimits=@('Event 41 time is next-boot record, not exact power-loss time.',
        'Dashboard logs have no per-cycle battery or SwitchBot history.',
        'Dashboard log LastWriteTime is file metadata, not a guaranteed last healthy event.',
        'A failed or unavailable source is listed in collection-errors.json; no absence is treated as proof of health.') }
Write-SafeJson (Join-Path $shared 'summary.json') $summary

Write-Output "Collection complete. Sanitized share folder: $shared"
Write-Output "Case ID: $caseId"
Write-Output 'No Dashboard, Updater, SwitchBot, Windows power, Scheduled Task, or production setting was changed.'
