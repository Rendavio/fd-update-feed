#requires -Version 5.1
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

function Set-FixedForensicEnvironment {
    $env:PSModulePath = 'C:\Windows\System32\WindowsPowerShell\v1.0\Modules;C:\Program Files\WindowsPowerShell\Modules'
    $env:PATH = 'C:\Windows\System32;C:\Windows'
    [Environment]::CurrentDirectory = 'C:\Windows\System32'
}
Set-FixedForensicEnvironment

function Convert-FixedUacFailure([Exception]$ErrorValue) {
    if ($ErrorValue -is [System.ComponentModel.Win32Exception] -and
        $ErrorValue.NativeErrorCode -eq 1223) { return 20 }
    return 30
}

function Assert-NoRequestReparse([string]$Path) {
    $current = [IO.Path]::GetFullPath($Path)
    while ($current) {
        if (Test-Path -LiteralPath $current) {
            $item = Get-Item -LiteralPath $current -Force -ErrorAction Stop
            if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'REPARSE_DETECTED' }
        }
        $parent = [IO.Directory]::GetParent($current)
        if ($null -eq $parent) { break }
        $current = $parent.FullName
    }
}

function Assert-RequestSafeAcl([string]$Path, [string]$DashboardSid,
        [string]$StandardDashboardSid = '') {
    $acl = Get-Acl -LiteralPath $Path -ErrorAction Stop
    $owner = $acl.GetOwner([Security.Principal.SecurityIdentifier]).Value
    if (@('S-1-5-18','S-1-5-32-544') -cnotcontains $owner) {
        throw 'OWNER_INVALID'
    }
    $dangerous = [Security.AccessControl.FileSystemRights]::WriteData -bor
        [Security.AccessControl.FileSystemRights]::AppendData -bor
        [Security.AccessControl.FileSystemRights]::WriteExtendedAttributes -bor
        [Security.AccessControl.FileSystemRights]::WriteAttributes -bor
        [Security.AccessControl.FileSystemRights]::Delete -bor
        [Security.AccessControl.FileSystemRights]::ChangePermissions -bor
        [Security.AccessControl.FileSystemRights]::TakeOwnership
    foreach ($rule in $acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier])) {
        $sid = $rule.IdentityReference.Value
        if ($rule.AccessControlType -ne [Security.AccessControl.AccessControlType]::Allow -or
            @('S-1-5-18','S-1-5-32-544',$DashboardSid,$StandardDashboardSid) -cnotcontains $sid -or
            (($rule.FileSystemRights -band $dangerous) -ne 0 -and
                @('S-1-5-18','S-1-5-32-544') -cnotcontains $sid)) {
            throw 'ACL_INVALID'
        }
    }
}

function Get-FixedSafeCategories {
    return @('NONE','UAC_CANCELLED','REQUEST_LAUNCH_FAILED','RUNNER_NOT_CONFIRMED',
        'ALREADY_RUNNING','STALE_RUNNING_RECOVERED','HASH_MISMATCH','ACL_INVALID',
        'OWNER_INVALID','REPARSE_DETECTED','STATUS_ROOT_INVALID','RUNNER_PREFLIGHT_FAILED',
        'COLLECTOR_START_FAILED','COLLECTOR_TIMEOUT','COLLECTOR_FAILED','STATUS_WRITE_FAILED',
        'ATTEMPT_STATE_INVALID','LATEST_STATUS_INVALID','LAUNCH_ACK_FAILED','RUNNER_FINAL_STATUS_MISSING')
}

function Test-FixedAttemptRecord($Record) {
    if ($null -eq $Record) { return $false }
    try {
        $names = @($Record.PSObject.Properties.Name)
        if ($names.Count -ne 7) { return $false }
        foreach ($required in @('schemaVersion','state','category','bootId','runnerPid','runnerStartedAt','startedAt')) {
            if ($names -cnotcontains $required) { return $false }
        }
        if ([int]$Record.schemaVersion -ne 1 -or @('RUNNING','FINAL') -cnotcontains [string]$Record.state -or
            (Get-FixedSafeCategories) -cnotcontains [string]$Record.category) { return $false }
        $pidValue = 0L
        if (-not [int64]::TryParse([string]$Record.runnerPid,[ref]$pidValue) -or $pidValue -le 0 -or
            $pidValue -gt [int]::MaxValue) { return $false }
        foreach ($name in @('bootId','runnerStartedAt','startedAt')) {
            $parsed = [datetimeoffset]::MinValue
            if (-not [datetimeoffset]::TryParseExact([string]$Record.$name,'o',
                    [Globalization.CultureInfo]::InvariantCulture,
                    [Globalization.DateTimeStyles]::RoundtripKind,[ref]$parsed)) { return $false }
        }
        return $true
    } catch { return $false }
}

function Get-FixedAttemptDisposition($Record, [string]$CurrentBootId, [datetimeoffset]$Now,
        [bool]$NamedMutexActive, [scriptblock]$ProcessStartLookup) {
    if ($null -eq $Record) { return 'MISSING' }
    if (-not (Test-FixedAttemptRecord $Record)) { return 'INVALID' }
    $startedAt = [datetimeoffset]::ParseExact([string]$Record.startedAt,'o',
        [Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::RoundtripKind)
    if ($startedAt -gt $Now.AddMinutes(5)) { return 'INVALID' }
    if ([string]$Record.state -ceq 'FINAL') { return 'COMPLETE' }
    if ($NamedMutexActive) { return 'ACTIVE' }
    if ([string]$Record.bootId -cne $CurrentBootId) { return 'STALE_RUNNING_RECOVERED' }
    # The elevated runner can die while its child collector survives.  A missing or reused
    # runner PID therefore cannot prove same-boot collection has stopped; fail closed.
    return 'UNKNOWN'
}

function Get-FixedBootId {
    $boot = (Get-CimInstance Win32_OperatingSystem -ErrorAction Stop).LastBootUpTime
    return ([datetimeoffset]$boot).ToUniversalTime().ToString('o',[Globalization.CultureInfo]::InvariantCulture)
}

function Get-FixedProcessStart([int]$ProcessId) {
    try {
        return ([datetimeoffset]([Diagnostics.Process]::GetProcessById($ProcessId).StartTime)).ToUniversalTime().ToString(
            'o',[Globalization.CultureInfo]::InvariantCulture)
    } catch [ArgumentException] { return $null }
}

function Test-FixedMutexActive {
    try {
        $existing = [Threading.Mutex]::OpenExisting('Global\FamilyDashboardPowerForensics')
        try { return $true } finally { $existing.Dispose() }
    } catch [Threading.WaitHandleCannotBeOpenedException] { return $false }
    catch { return $true }
}

function Read-FixedAttemptDisposition([string]$Root, [string]$DashboardSid,
        [string]$StandardDashboardSid) {
    $status = Join-Path $Root 'status'
    $path = Join-Path $status 'attempt.json'
    if (-not (Test-Path -LiteralPath $Root)) { return 'MISSING' }
    foreach ($checked in @($Root,$status)) {
        if (-not (Test-Path -LiteralPath $checked -PathType Container)) { throw 'STATUS_ROOT_INVALID' }
        Assert-NoRequestReparse $checked
        Assert-RequestSafeAcl $checked $DashboardSid $StandardDashboardSid
    }
    if (-not (Test-Path -LiteralPath $path)) { return 'MISSING' }
    Assert-NoRequestReparse $path
    Assert-RequestSafeAcl $path $DashboardSid $StandardDashboardSid
    $item = Get-Item -LiteralPath $path -Force -ErrorAction Stop
    if ($item.Length -le 0 -or $item.Length -gt 2048) { return 'INVALID' }
    try { $record = [IO.File]::ReadAllText($path) | ConvertFrom-Json -ErrorAction Stop }
    catch { return 'INVALID' }
    return Get-FixedAttemptDisposition $record (Get-FixedBootId) ([datetimeoffset]::Now) `
        (Test-FixedMutexActive) { param($pidValue) Get-FixedProcessStart $pidValue }
}

function Convert-FixedRunnerExit([int]$ExitCode) {
    if ($ExitCode -in @(32,33,34,35,36,37,38,39,40,41,42,43)) { return $ExitCode }
    return 31
}

function Convert-FixedRequestFailure([string]$Message) {
    switch ($Message) {
        'ALREADY_RUNNING' { return 32 }
        'HASH_MISMATCH' { return 33 }
        'ACL_INVALID' { return 34 }
        'OWNER_INVALID' { return 35 }
        'REPARSE_DETECTED' { return 36 }
        'STATUS_ROOT_INVALID' { return 37 }
        'RUNNER_PREFLIGHT_FAILED' { return 38 }
        'COLLECTOR_START_FAILED' { return 39 }
        'STATUS_WRITE_FAILED' { return 40 }
        'ATTEMPT_STATE_INVALID' { return 41 }
        'LATEST_STATUS_INVALID' { return 42 }
        'LAUNCH_ACK_FAILED' { return 43 }
        default { return 30 }
    }
}

function Test-FixedLaunchRecord([string]$Value, $Item, [int]$RunnerPid,
        [datetime]$StartedAtUtc) {
    return ($Item.Length -le 16 -and $Item.LastWriteTimeUtc -ge $StartedAtUtc.AddSeconds(-2) -and
        $Value -match '^\d{1,10}$' -and [int64]$Value -eq $RunnerPid)
}

function Wait-FixedLaunchAck($RunnerProcess, [datetime]$StartedAtUtc,
        [string]$DashboardSid, [string]$StandardDashboardSid) {
    $runnerPid = [int]$RunnerProcess.Id
    $root = 'C:\ProgramData\FamilyDashboardForensics'
    $status = Join-Path $root 'status'
    $ack = Join-Path $status 'launch.pid'
    for ($attempt = 0; $attempt -lt 300; $attempt++) {
        if (Test-Path -LiteralPath $ack -PathType Leaf) {
            try {
                Assert-NoRequestReparse $ack
                foreach ($path in @($root,$status,$ack)) {
                    Assert-RequestSafeAcl $path $DashboardSid $StandardDashboardSid
                }
                $item = Get-Item -LiteralPath $ack -Force -ErrorAction Stop
                if ($item.Length -le 16) {
                    $value = [IO.File]::ReadAllText($ack)
                    if (Test-FixedLaunchRecord $value $item $RunnerPid $StartedAtUtc) { return 0 }
                }
            } catch {
                $message = [string]$_.Exception.Message
                if ($message -in @('ACL_INVALID','OWNER_INVALID','REPARSE_DETECTED')) { throw $message }
                # The runner atomically archives an older acknowledgement before publishing
                # its own.  A disappearance during that narrow read window is benign.
                if (Test-Path -LiteralPath $ack) { throw 'LAUNCH_ACK_FAILED' }
            }
        }
        if ($RunnerProcess.HasExited) { return Convert-FixedRunnerExit ([int]$RunnerProcess.ExitCode) }
        Start-Sleep -Milliseconds 100
    }
    return 31
}

function Invoke-FixedUacStart([string]$DashboardSid, [string]$StandardDashboardSid) {
    $runner = 'C:\FamilyDashboard\launcher\Invoke-FamilyDashboardPowerForensics.ps1'
    $powershell = 'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe'
    try {
        $startedAtUtc = [datetime]::UtcNow
        $process = Start-Process -FilePath $powershell -Verb RunAs -WindowStyle Hidden -PassThru `
            -WorkingDirectory 'C:\FamilyDashboard\launcher' `
            -ArgumentList @('-NoLogo','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass',
                '-File', ('"{0}"' -f $runner)) -ErrorAction Stop
        if ($null -eq $process -or $process.Id -le 0) { return 30 }
        return Wait-FixedLaunchAck $process $startedAtUtc $DashboardSid $StandardDashboardSid
    } catch [System.ComponentModel.Win32Exception] {
        return Convert-FixedUacFailure $_.Exception
    } catch {
        return Convert-FixedRequestFailure ([string]$_.Exception.Message)
    }
}

$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
if ($principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator) -or
    [Environment]::UserName -ine 'DashboardAdmin') { exit 30 }

$runner = 'C:\FamilyDashboard\launcher\Invoke-FamilyDashboardPowerForensics.ps1'
$powershell = 'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe'
if (-not (Test-Path -LiteralPath $runner -PathType Leaf) -or
    -not (Test-Path -LiteralPath $powershell -PathType Leaf)) { exit 30 }
try {
    Assert-NoRequestReparse $runner
    $item = Get-Item -LiteralPath $runner -Force -ErrorAction Stop
    if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { exit 30 }
    $standardUser = Get-LocalUser -Name 'Dashboard' -ErrorAction Stop
    if ($null -eq $standardUser -or -not $standardUser.SID.Value) { exit 30 }
    foreach ($path in @('C:\FamilyDashboard','C:\FamilyDashboard\launcher',$runner)) {
        Assert-RequestSafeAcl $path $identity.User.Value $standardUser.SID.Value
    }
    $disposition = Read-FixedAttemptDisposition 'C:\ProgramData\FamilyDashboardForensics' `
        $identity.User.Value $standardUser.SID.Value
    if ($disposition -ceq 'ACTIVE') { exit 32 }
    if ($disposition -in @('INVALID','UNKNOWN')) { exit 41 }
    exit (Invoke-FixedUacStart $identity.User.Value $standardUser.SID.Value)
} catch {
    switch ([string]$_.Exception.Message) {
        'OWNER_INVALID' { exit 35 }
        'ACL_INVALID' { exit 34 }
        'REPARSE_DETECTED' { exit 36 }
        'STATUS_ROOT_INVALID' { exit 37 }
        'ATTEMPT_STATE_INVALID' { exit 41 }
        default { exit 30 }
    }
}
