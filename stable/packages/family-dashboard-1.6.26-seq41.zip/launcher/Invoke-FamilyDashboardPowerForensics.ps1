#requires -Version 5.1
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

function Set-FixedForensicEnvironment {
    $env:PSModulePath = 'C:\Windows\System32\WindowsPowerShell\v1.0\Modules;C:\Program Files\WindowsPowerShell\Modules'
    $env:PATH = 'C:\Windows\System32;C:\Windows'
    [Environment]::CurrentDirectory = 'C:\Windows\System32'
}
Set-FixedForensicEnvironment

function Assert-NoForensicReparse([string]$Path) {
    $current = [IO.Path]::GetFullPath($Path)
    while ($current) {
        if (Test-Path -LiteralPath $current) {
            $item = Get-Item -LiteralPath $current -Force -ErrorAction Stop
            if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
                throw 'REPARSE_DETECTED'
            }
        }
        $parent = [IO.Directory]::GetParent($current)
        if ($null -eq $parent) { break }
        $current = $parent.FullName
    }
}

function Test-FixedForensicAcl([Security.AccessControl.FileSystemSecurity]$Acl,
        [string]$DashboardSid, [string]$StandardDashboardSid = '') {
    $owner = $Acl.GetOwner([Security.Principal.SecurityIdentifier]).Value
    if (@('S-1-5-18','S-1-5-32-544') -cnotcontains $owner) {
        return $false
    }
    $dangerous = [Security.AccessControl.FileSystemRights]::WriteData -bor
        [Security.AccessControl.FileSystemRights]::AppendData -bor
        [Security.AccessControl.FileSystemRights]::CreateFiles -bor
        [Security.AccessControl.FileSystemRights]::CreateDirectories -bor
        [Security.AccessControl.FileSystemRights]::WriteExtendedAttributes -bor
        [Security.AccessControl.FileSystemRights]::WriteAttributes -bor
        [Security.AccessControl.FileSystemRights]::Delete -bor
        [Security.AccessControl.FileSystemRights]::DeleteSubdirectoriesAndFiles -bor
        [Security.AccessControl.FileSystemRights]::ChangePermissions -bor
        [Security.AccessControl.FileSystemRights]::TakeOwnership
    $fullControl = New-Object 'Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
    foreach ($rule in $Acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier])) {
        if ($rule.AccessControlType -ne [Security.AccessControl.AccessControlType]::Allow) { return $false }
        $sid = $rule.IdentityReference.Value
        if (@('S-1-5-18','S-1-5-32-544',$DashboardSid,$StandardDashboardSid) -cnotcontains $sid) { return $false }
        if (($rule.FileSystemRights -band $dangerous) -ne 0 -and
            @('S-1-5-18','S-1-5-32-544') -cnotcontains $sid) { return $false }
        if (($rule.FileSystemRights -band [Security.AccessControl.FileSystemRights]::FullControl) -eq
                [Security.AccessControl.FileSystemRights]::FullControl) {
            [void]$fullControl.Add($sid)
        }
    }
    return $fullControl.Contains('S-1-5-18') -and $fullControl.Contains('S-1-5-32-544')
}

function Assert-ForensicAcl([string]$Path, [string]$DashboardSid,
        [string]$StandardDashboardSid = '') {
    $acl = Get-Acl -LiteralPath $Path -ErrorAction Stop
    $owner = $acl.GetOwner([Security.Principal.SecurityIdentifier]).Value
    if (@('S-1-5-18','S-1-5-32-544') -cnotcontains $owner) { throw 'OWNER_INVALID' }
    if (-not (Test-FixedForensicAcl $acl $DashboardSid $StandardDashboardSid)) {
        throw 'ACL_INVALID'
    }
}

function Assert-FixedCollector([string]$Path, [string]$ExpectedHash) {
    Assert-NoForensicReparse $Path
    $item = Get-Item -LiteralPath $Path -Force -ErrorAction Stop
    if ($item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
        throw 'REPARSE_DETECTED'
    }
    if ((Get-FileHash -Algorithm SHA256 -LiteralPath $Path).Hash -cne $ExpectedHash) {
        throw 'HASH_MISMATCH'
    }
}

function Get-FixedSafeCategories {
    return @('NONE','UAC_CANCELLED','REQUEST_LAUNCH_FAILED','RUNNER_NOT_CONFIRMED',
        'ALREADY_RUNNING','STALE_RUNNING_RECOVERED','HASH_MISMATCH','ACL_INVALID',
        'OWNER_INVALID','REPARSE_DETECTED','STATUS_ROOT_INVALID','RUNNER_PREFLIGHT_FAILED',
        'COLLECTOR_START_FAILED','COLLECTOR_TIMEOUT','COLLECTOR_FAILED','STATUS_WRITE_FAILED',
        'ATTEMPT_STATE_INVALID','LATEST_STATUS_INVALID','LAUNCH_ACK_FAILED','RUNNER_FINAL_STATUS_MISSING')
}

function Test-SafeForensicStatus([hashtable]$Record) {
    if ($null -eq $Record -or $Record.Count -ne 4) { return $false }
    $missing = @(@('status','caseId','sanitizedSharePath','category') |
        Where-Object { -not $Record.ContainsKey($_) })
    if ($missing.Count -ne 0) { return $false }
    if (@('PASS','PARTIAL','FAIL') -cnotcontains [string]$Record.status) { return $false }
    if ((Get-FixedSafeCategories) -cnotcontains [string]$Record.category) { return $false }
    if ($Record.status -ceq 'FAIL' -and $null -eq $Record.caseId -and
        $null -eq $Record.sanitizedSharePath) { return $true }
    if ([string]$Record.caseId -cnotmatch '^case-\d{8}-\d{6}-[0-9a-f]{8}$') { return $false }
    $expected = 'C:\ProgramData\FamilyDashboardForensics\' + [string]$Record.caseId + '\sanitized-share'
    return [string]::Equals([string]$Record.sanitizedSharePath, $expected,
        [StringComparison]::OrdinalIgnoreCase)
}

function New-ForensicStatusFileSecurity([string]$DashboardSid) {
    $security = New-Object Security.AccessControl.FileSecurity
    $security.SetAccessRuleProtection($true,$false)
    $admin = New-Object Security.Principal.SecurityIdentifier('S-1-5-32-544')
    $security.SetOwner($admin)
    foreach ($sidText in @('S-1-5-18','S-1-5-32-544')) {
        $sid = New-Object Security.Principal.SecurityIdentifier($sidText)
        $rule = New-Object Security.AccessControl.FileSystemAccessRule($sid,
            [Security.AccessControl.FileSystemRights]::FullControl,
            [Security.AccessControl.AccessControlType]::Allow)
        $security.AddAccessRule($rule)
    }
    $dashboard = New-Object Security.Principal.SecurityIdentifier($DashboardSid)
    $readRule = New-Object Security.AccessControl.FileSystemAccessRule($dashboard,
        [Security.AccessControl.FileSystemRights]::Read,
        [Security.AccessControl.AccessControlType]::Allow)
    $security.AddAccessRule($readRule)
    return $security
}

function Assert-ForensicStatusFile([string]$Path, [string]$DashboardSid) {
    Assert-NoForensicReparse $Path
    Assert-ForensicAcl $Path $DashboardSid
    $owner = (Get-Acl -LiteralPath $Path).GetOwner([Security.Principal.SecurityIdentifier]).Value
    if (@('S-1-5-18','S-1-5-32-544') -cnotcontains $owner) { throw 'UNSAFE_STATUS_OWNER' }
}

function Test-FixedAttemptRecord($Record) {
    if ($null -eq $Record) { return $false }
    try {
        $names = @($Record.PSObject.Properties.Name)
        if ($names.Count -ne 7) { return $false }
        foreach ($required in @('schemaVersion','state','category','bootId','runnerPid','runnerStartedAt','startedAt')) {
            if ($names -cnotcontains $required) { return $false }
        }
        if ([int]$Record.schemaVersion -ne 1 -or @('RUNNING','FINAL') -cnotcontains [string]$Record.state -or
            (Get-FixedSafeCategories) -cnotcontains [string]$Record.category) { return $false }
        $pidValue = 0L
        if (-not [int64]::TryParse([string]$Record.runnerPid,[ref]$pidValue) -or $pidValue -le 0 -or
            $pidValue -gt [int]::MaxValue) { return $false }
        foreach ($name in @('bootId','runnerStartedAt','startedAt')) {
            $parsed = [datetimeoffset]::MinValue
            if (-not [datetimeoffset]::TryParseExact([string]$Record.$name,'o',
                    [Globalization.CultureInfo]::InvariantCulture,
                    [Globalization.DateTimeStyles]::RoundtripKind,[ref]$parsed)) { return $false }
        }
        return $true
    } catch { return $false }
}

function Get-FixedAttemptDisposition($Record, [string]$CurrentBootId, [datetimeoffset]$Now,
        [bool]$NamedMutexActive, [scriptblock]$ProcessStartLookup) {
    if ($null -eq $Record) { return 'MISSING' }
    if (-not (Test-FixedAttemptRecord $Record)) { return 'INVALID' }
    $startedAt = [datetimeoffset]::ParseExact([string]$Record.startedAt,'o',
        [Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::RoundtripKind)
    if ($startedAt -gt $Now.AddMinutes(5)) { return 'INVALID' }
    if ([string]$Record.state -ceq 'FINAL') { return 'COMPLETE' }
    if ($NamedMutexActive) { return 'ACTIVE' }
    if ([string]$Record.bootId -cne $CurrentBootId) { return 'STALE_RUNNING_RECOVERED' }
    # The elevated runner can die while its child collector survives.  A missing or reused
    # runner PID therefore cannot prove same-boot collection has stopped; fail closed.
    return 'UNKNOWN'
}

function Get-FixedBootId {
    $boot = (Get-CimInstance Win32_OperatingSystem -ErrorAction Stop).LastBootUpTime
    return ([datetimeoffset]$boot).ToUniversalTime().ToString('o',[Globalization.CultureInfo]::InvariantCulture)
}

function Get-FixedProcessStart([int]$ProcessId) {
    try {
        return ([datetimeoffset]([Diagnostics.Process]::GetProcessById($ProcessId).StartTime)).ToUniversalTime().ToString(
            'o',[Globalization.CultureInfo]::InvariantCulture)
    } catch [ArgumentException] { return $null }
}

function Read-FixedAttemptState([string]$Path, [string]$DashboardSid) {
    if (-not (Test-Path -LiteralPath $Path)) { return $null }
    Assert-ForensicStatusFile $Path $DashboardSid
    $item = Get-Item -LiteralPath $Path -Force -ErrorAction Stop
    if ($item.Length -le 0 -or $item.Length -gt 2048) { throw 'ATTEMPT_STATE_INVALID' }
    try { $record = [IO.File]::ReadAllText($Path) | ConvertFrom-Json -ErrorAction Stop }
    catch { throw 'ATTEMPT_STATE_INVALID' }
    if (-not (Test-FixedAttemptRecord $record)) { throw 'ATTEMPT_STATE_INVALID' }
    return $record
}

function New-FixedAttemptRecord([string]$State, [string]$Category, [string]$BootId,
        [string]$RunnerStartedAt) {
    return [ordered]@{ schemaVersion=1;state=$State;category=$Category;bootId=$BootId;
        runnerPid=[int]$PID;runnerStartedAt=$RunnerStartedAt;
        startedAt=([datetimeoffset]::Now).ToUniversalTime().ToString('o',[Globalization.CultureInfo]::InvariantCulture) }
}

function Write-ForensicStatus([hashtable]$Record, [string]$StatusDirectory,
        [string]$PrivateStatusDirectory, [string]$DashboardSid) {
    if (-not (Test-SafeForensicStatus $Record)) { throw 'INVALID_STATUS' }
    Assert-NoForensicReparse $StatusDirectory
    Assert-NoForensicReparse $PrivateStatusDirectory
    $target = Join-Path $StatusDirectory 'latest.json'
    $temp = Join-Path $PrivateStatusDirectory ('latest-' + [Guid]::NewGuid().ToString('N') + '.tmp')
    $json = ConvertTo-Json -InputObject $Record -Compress
    try {
        [IO.File]::WriteAllText($temp, $json, (New-Object Text.UTF8Encoding($false)))
        [IO.File]::SetAccessControl($temp,(New-ForensicStatusFileSecurity $DashboardSid))
        if ([IO.File]::ReadAllText($temp) -cne $json) { throw 'STATUS_WRITE_RACE' }
        if (Test-Path -LiteralPath $target) {
            Assert-ForensicStatusFile $target $DashboardSid
            [IO.File]::Replace($temp,$target,$null)
        } else { [IO.File]::Move($temp,$target) }
        Assert-ForensicStatusFile $target $DashboardSid
    } catch {
        $message = [string]$_.Exception.Message
        if ($message -in @('ACL_INVALID','OWNER_INVALID','REPARSE_DETECTED','STATUS_WRITE_FAILED')) {
            throw $message
        }
        throw 'STATUS_WRITE_FAILED'
    } finally {
        if (Test-Path -LiteralPath $temp) { Remove-Item -LiteralPath $temp -Force }
    }
}

function Archive-PriorForensicStatus([string]$StatusDirectory, [string]$PrivateStatusDirectory,
        [string]$DashboardSid) {
    Assert-NoForensicReparse $StatusDirectory
    Assert-NoForensicReparse $PrivateStatusDirectory
    $previous = Join-Path $StatusDirectory 'latest.json'
    if (-not (Test-Path -LiteralPath $previous)) { return }
    Assert-ForensicStatusFile $previous $DashboardSid
    $archive = Join-Path $PrivateStatusDirectory ('previous-' + [Guid]::NewGuid().ToString('N') + '.json')
    [IO.File]::Move($previous,$archive)
    Assert-ForensicStatusFile $archive $DashboardSid
}

function Archive-FixedControlFile([string]$StatusDirectory, [string]$PrivateStatusDirectory,
        [string]$DashboardSid, [string]$Name) {
    if (@('attempt.json','launch.pid') -cnotcontains $Name) { throw 'RUNNER_PREFLIGHT_FAILED' }
    Assert-NoForensicReparse $StatusDirectory
    Assert-NoForensicReparse $PrivateStatusDirectory
    $previous = Join-Path $StatusDirectory $Name
    if (-not (Test-Path -LiteralPath $previous)) { return }
    Assert-ForensicStatusFile $previous $DashboardSid
    $extension = [IO.Path]::GetExtension($Name)
    $archive = Join-Path $PrivateStatusDirectory (
        [IO.Path]::GetFileNameWithoutExtension($Name) + '-' + [Guid]::NewGuid().ToString('N') + $extension)
    [IO.File]::Move($previous,$archive)
    Assert-ForensicStatusFile $archive $DashboardSid
}

function Write-FixedAttemptState($Record, [string]$StatusDirectory,
        [string]$PrivateStatusDirectory, [string]$DashboardSid) {
    if (-not (Test-FixedAttemptRecord ([pscustomobject]$Record))) { throw 'STATUS_WRITE_FAILED' }
    $target = Join-Path $StatusDirectory 'attempt.json'
    $temp = Join-Path $PrivateStatusDirectory ('attempt-' + [Guid]::NewGuid().ToString('N') + '.tmp')
    $json = ConvertTo-Json -InputObject $Record -Compress
    try {
        [IO.File]::WriteAllText($temp,$json,(New-Object Text.UTF8Encoding($false)))
        [IO.File]::SetAccessControl($temp,(New-ForensicStatusFileSecurity $DashboardSid))
        if ([IO.File]::ReadAllText($temp) -cne $json) { throw 'STATUS_WRITE_FAILED' }
        if (Test-Path -LiteralPath $target) {
            Assert-ForensicStatusFile $target $DashboardSid
            [IO.File]::Replace($temp,$target,$null)
        } else { [IO.File]::Move($temp,$target) }
        Assert-ForensicStatusFile $target $DashboardSid
    } catch {
        $message = [string]$_.Exception.Message
        if ($message -in @('ACL_INVALID','OWNER_INVALID','REPARSE_DETECTED','STATUS_WRITE_FAILED')) {
            throw $message
        }
        throw 'STATUS_WRITE_FAILED'
    } finally {
        if (Test-Path -LiteralPath $temp) { Remove-Item -LiteralPath $temp -Force }
    }
}

function Write-FixedLaunchAck([string]$StatusDirectory, [string]$PrivateStatusDirectory,
        [string]$DashboardSid) {
    Assert-NoForensicReparse $StatusDirectory
    Assert-NoForensicReparse $PrivateStatusDirectory
    $target = Join-Path $StatusDirectory 'launch.pid'
    $temp = Join-Path $PrivateStatusDirectory ('launch-' + [Guid]::NewGuid().ToString('N') + '.tmp')
    $value = [string]$PID
    try {
        [IO.File]::WriteAllText($temp,$value,(New-Object Text.UTF8Encoding($false)))
        [IO.File]::SetAccessControl($temp,(New-ForensicStatusFileSecurity $DashboardSid))
        Archive-FixedControlFile $StatusDirectory $PrivateStatusDirectory $DashboardSid 'launch.pid'
        [IO.File]::Move($temp,$target)
        Assert-ForensicStatusFile $target $DashboardSid
    } catch {
        $message = [string]$_.Exception.Message
        if ($message -in @('ACL_INVALID','OWNER_INVALID','REPARSE_DETECTED')) { throw $message }
        throw 'LAUNCH_ACK_FAILED'
    } finally {
        if (Test-Path -LiteralPath $temp) { Remove-Item -LiteralPath $temp -Force }
    }
}

function New-ForensicDirectory([string]$Path, [string]$DashboardSid, [bool]$ReadableByDashboard) {
    Assert-NoForensicReparse $Path
    if (Test-Path -LiteralPath $Path) {
        Assert-ForensicAcl $Path $DashboardSid
        return
    }
    $security = New-Object Security.AccessControl.DirectorySecurity
    $security.SetAccessRuleProtection($true,$false)
    $admin = New-Object Security.Principal.SecurityIdentifier('S-1-5-32-544')
    $security.SetOwner($admin)
    $inherit = [Security.AccessControl.InheritanceFlags]::ContainerInherit -bor
        [Security.AccessControl.InheritanceFlags]::ObjectInherit
    foreach ($sidText in @('S-1-5-18','S-1-5-32-544')) {
        $sid = New-Object Security.Principal.SecurityIdentifier($sidText)
        $rule = New-Object Security.AccessControl.FileSystemAccessRule($sid,
            [Security.AccessControl.FileSystemRights]::FullControl,$inherit,
            [Security.AccessControl.PropagationFlags]::None,
            [Security.AccessControl.AccessControlType]::Allow)
        $security.AddAccessRule($rule)
    }
    if ($ReadableByDashboard) {
        $sid = New-Object Security.Principal.SecurityIdentifier($DashboardSid)
        $rule = New-Object Security.AccessControl.FileSystemAccessRule($sid,
            [Security.AccessControl.FileSystemRights]::ReadAndExecute,$inherit,
            [Security.AccessControl.PropagationFlags]::None,
            [Security.AccessControl.AccessControlType]::Allow)
        $security.AddAccessRule($rule)
    }
    [void][IO.Directory]::CreateDirectory($Path,$security)
    Assert-ForensicAcl $Path $DashboardSid
}

function Wait-FixedCollector([Diagnostics.Process]$Process, [int]$TimeoutMs) {
    if ($TimeoutMs -le 0 -or $TimeoutMs -gt 900000) { throw 'INVALID_TIMEOUT' }
    if (-not $Process.WaitForExit($TimeoutMs)) {
        & 'C:\Windows\System32\taskkill.exe' /PID $Process.Id /T /F 2>$null | Out-Null
        if (-not $Process.WaitForExit(10000)) { throw 'COLLECTOR_KILL_FAILED' }
        return 'TIMEOUT'
    }
    if ($Process.ExitCode -ne 0) { return 'FAIL' }
    return 'COMPLETE'
}

function Get-FixedFailureCategory([string]$Message, [string]$Phase) {
    if ((Get-FixedSafeCategories) -ccontains $Message) { return $Message }
    if ($Phase -ceq 'STATUS_ROOT') { return 'STATUS_ROOT_INVALID' }
    if ($Phase -ceq 'ATTEMPT_STATE') { return 'ATTEMPT_STATE_INVALID' }
    if ($Phase -ceq 'LATEST_STATUS') { return 'LATEST_STATUS_INVALID' }
    if ($Phase -ceq 'LAUNCH_ACK') { return 'LAUNCH_ACK_FAILED' }
    if ($Phase -ceq 'COLLECTOR_START') { return 'COLLECTOR_START_FAILED' }
    if ($Phase -ceq 'COLLECTOR') { return 'COLLECTOR_FAILED' }
    return 'RUNNER_PREFLIGHT_FAILED'
}

function Get-FixedCategoryExit([string]$Category) {
    switch ($Category) {
        'ALREADY_RUNNING' { return 32 }
        'HASH_MISMATCH' { return 33 }
        'ACL_INVALID' { return 34 }
        'OWNER_INVALID' { return 35 }
        'REPARSE_DETECTED' { return 36 }
        'STATUS_ROOT_INVALID' { return 37 }
        'COLLECTOR_START_FAILED' { return 39 }
        'STATUS_WRITE_FAILED' { return 40 }
        'ATTEMPT_STATE_INVALID' { return 41 }
        'LATEST_STATUS_INVALID' { return 42 }
        'LAUNCH_ACK_FAILED' { return 43 }
        default { return 38 }
    }
}

$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator) -or
    [Environment]::UserName -ine 'DashboardAdmin') { exit 30 }
$dashboardSid = $identity.User.Value
$standardUser = Get-LocalUser -Name 'Dashboard' -ErrorAction SilentlyContinue
if ($null -eq $standardUser -or -not $standardUser.SID.Value) { exit 30 }
$standardDashboardSid = $standardUser.SID.Value
$collector = 'C:\FamilyDashboard\launcher\Collect-CHUWIPowerForensics.ps1'
$expectedHash = '0A4E34C6446AF5AA5C86780ABC486DBE932E62718C87994DE13CF03A44397167'
$powershell = 'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe'
$root = 'C:\ProgramData\FamilyDashboardForensics'
$statusDirectory = Join-Path $root 'status'
$privateStatusDirectory = Join-Path $root 'status-private'
$mutex = New-Object Threading.Mutex($false,'Global\FamilyDashboardPowerForensics')
$lockHeld = $false
$statusReady = $false
$attemptReady = $false
$launchAcknowledged = $false
$phase = 'STATUS_ROOT'
$attemptPath = Join-Path $statusDirectory 'attempt.json'
$bootId = $null
$runnerStartedAt = ([datetimeoffset]([Diagnostics.Process]::GetCurrentProcess().StartTime)).ToUniversalTime().ToString(
    'o',[Globalization.CultureInfo]::InvariantCulture)
$attemptCategory = 'NONE'
try {
    $lockHeld = $mutex.WaitOne(0)
    if (-not $lockHeld) { exit 32 }
    New-ForensicDirectory $root $dashboardSid $true
    New-ForensicDirectory $statusDirectory $dashboardSid $true
    New-ForensicDirectory $privateStatusDirectory $dashboardSid $false
    $statusReady = $true
    $bootId = Get-FixedBootId
    $phase = 'ATTEMPT_STATE'
    $priorAttempt = Read-FixedAttemptState $attemptPath $dashboardSid
    if ($null -ne $priorAttempt) {
        $disposition = Get-FixedAttemptDisposition $priorAttempt $bootId ([datetimeoffset]::Now) $false `
            { param($pidValue) Get-FixedProcessStart $pidValue }
        if ($disposition -ceq 'STALE_RUNNING_RECOVERED') { $attemptCategory = 'STALE_RUNNING_RECOVERED' }
        elseif ($disposition -notin @('COMPLETE')) { throw 'ATTEMPT_STATE_INVALID' }
        Archive-FixedControlFile $statusDirectory $privateStatusDirectory $dashboardSid 'attempt.json'
    }
    Write-FixedAttemptState (New-FixedAttemptRecord 'RUNNING' $attemptCategory $bootId $runnerStartedAt) `
        $statusDirectory $privateStatusDirectory $dashboardSid
    $attemptReady = $true
    $phase = 'LATEST_STATUS'
    Archive-PriorForensicStatus $statusDirectory $privateStatusDirectory $dashboardSid
    $phase = 'LAUNCH_ACK'
    Write-FixedLaunchAck $statusDirectory $privateStatusDirectory $dashboardSid
    $launchAcknowledged = $true
    $phase = 'PREFLIGHT'
    Assert-NoForensicReparse 'C:\FamilyDashboard\launcher'
    Assert-ForensicAcl 'C:\FamilyDashboard' $dashboardSid $standardDashboardSid
    Assert-ForensicAcl 'C:\FamilyDashboard\launcher' $dashboardSid $standardDashboardSid
    Assert-FixedCollector $collector $expectedHash
    Assert-ForensicAcl $collector $dashboardSid $standardDashboardSid
    if (-not (Test-Path -LiteralPath $powershell -PathType Leaf)) { throw 'RUNNER_PREFLIGHT_FAILED' }
    $startedAt = Get-Date
    $phase = 'COLLECTOR_START'
    try {
        $process = Start-Process -FilePath $powershell -WindowStyle Hidden -PassThru `
            -WorkingDirectory 'C:\FamilyDashboard\launcher' `
            -ArgumentList @('-NoLogo','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass',
                '-File', ('"{0}"' -f $collector)) -ErrorAction Stop
    } catch { throw 'COLLECTOR_START_FAILED' }
    $phase = 'COLLECTOR'
    $exitState = Wait-FixedCollector $process 900000
    $result = if ($exitState -eq 'COMPLETE') { $null } else { 'FAIL' }
    $resultCategory = if ($exitState -eq 'TIMEOUT') { 'COLLECTOR_TIMEOUT' }
        elseif ($exitState -eq 'FAIL') { 'COLLECTOR_FAILED' } else { $attemptCategory }
    $cases = @(Get-ChildItem -LiteralPath $root -Directory -Filter 'case-*' -ErrorAction Stop |
        Where-Object { $_.CreationTime -ge $startedAt.AddSeconds(-2) })
    if ($cases.Count -ne 1) {
        $resultCategory = if ($exitState -eq 'TIMEOUT') { 'COLLECTOR_TIMEOUT' } else { 'COLLECTOR_FAILED' }
        Write-ForensicStatus @{status='FAIL';caseId=$null;sanitizedSharePath=$null;category=$resultCategory} `
            $statusDirectory $privateStatusDirectory $dashboardSid
        Write-FixedAttemptState (New-FixedAttemptRecord 'FINAL' $resultCategory $bootId $runnerStartedAt) `
            $statusDirectory $privateStatusDirectory $dashboardSid
        exit 38
    }
    $case = $cases[0]
    Assert-NoForensicReparse $case.FullName
    $summaryPath = Join-Path $case.FullName 'sanitized-share\summary.json'
    Assert-NoForensicReparse $summaryPath
    if (-not $result) {
        $summary = Get-Content -LiteralPath $summaryPath -Raw -ErrorAction Stop | ConvertFrom-Json
        $result = [string]$summary.collectionStatus
    }
    $record = @{ status=$result; caseId=$case.Name; category=$resultCategory;
        sanitizedSharePath=(Join-Path $case.FullName 'sanitized-share') }
    Write-ForensicStatus $record $statusDirectory $privateStatusDirectory $dashboardSid
    Write-FixedAttemptState (New-FixedAttemptRecord 'FINAL' $resultCategory $bootId $runnerStartedAt) `
        $statusDirectory $privateStatusDirectory $dashboardSid
    exit 0
} catch {
    $category = Get-FixedFailureCategory ([string]$_.Exception.Message) $phase
    if ($statusReady -and $launchAcknowledged) {
        try {
            Write-ForensicStatus @{status='FAIL';caseId=$null;sanitizedSharePath=$null;category=$category} `
                $statusDirectory $privateStatusDirectory $dashboardSid
        } catch {}
    }
    if ($attemptReady) {
        try {
            Write-FixedAttemptState (New-FixedAttemptRecord 'FINAL' $category $bootId $runnerStartedAt) `
                $statusDirectory $privateStatusDirectory $dashboardSid
        } catch {}
    }
    exit (Get-FixedCategoryExit $category)
} finally {
    if ($lockHeld) { $mutex.ReleaseMutex() }
    $mutex.Dispose()
}
