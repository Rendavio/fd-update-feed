#requires -Version 5.1
Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"

function Test-IsAdministrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

if (Test-IsAdministrator) { exit 6 }
if ([Environment]::UserName -ine "DashboardAdmin") { exit 6 }
$elevatedScript = "C:\FamilyDashboard\launcher\Invoke-FamilyDashboardUpdate.ps1"
$powershell = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
if (-not (Test-Path -LiteralPath $elevatedScript -PathType Leaf)) { exit 6 }
try {
    $process = Start-Process -FilePath $powershell -Verb RunAs -WindowStyle Hidden -PassThru -ArgumentList @(
        "-NoLogo", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
        "-File", ('"{0}"' -f $elevatedScript)
    )
} catch {
    exit 5
}
if ($null -eq $process -or $process.Id -le 0) { exit 6 }
[Console]::Out.Write([string]$process.Id)
exit 0
