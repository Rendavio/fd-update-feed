#requires -Version 5.1
param(
    [Parameter(Mandatory = $true)]
    [ValidateRange(1, 4294967295)]
    [int64]$UpdateProcessId
)
Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"
$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
if ($principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { exit 5 }
if ([Environment]::UserName -ine "DashboardAdmin") { exit 5 }

for ($second = 0; $second -lt 900; $second++) {
    if ($null -eq (Get-Process -Id $UpdateProcessId -ErrorAction SilentlyContinue)) { break }
    Start-Sleep -Seconds 1
}
if ($null -ne (Get-Process -Id $UpdateProcessId -ErrorAction SilentlyContinue)) { exit 6 }

$startScript = "C:\FamilyDashboard\launcher\Start-FamilyDashboard.ps1"
for ($attempt = 0; $attempt -lt 60; $attempt++) {
    try {
        & $startScript -Mode production -Page dashboard
        exit 0
    } catch {
        Start-Sleep -Seconds 2
    }
}
exit 7
