"""Fixed local bridge from Dashboard to the existing Updater V1."""

from __future__ import annotations

import datetime as dt
import json
import os
import re
import stat
import subprocess
import threading
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

UPDATER_ROOT = Path(r"C:\ProgramData\FamilyDashboardUpdater")
V1_STATUS_PATH = UPDATER_ROOT / "status" / "status.json"
POWERSHELL_EXE = Path(os.environ.get("SystemRoot", r"C:\Windows"),
    "System32", "WindowsPowerShell", "v1.0", "powershell.exe")
UAC_REQUEST_SCRIPT = Path(r"C:\FamilyDashboard\launcher\Request-FamilyDashboardUpdate.ps1")
RESUME_SCRIPT = Path(r"C:\FamilyDashboard\launcher\Resume-FamilyDashboard.ps1")
MAX_STATUS_BYTES = 8_192
V1_STATUS_KEYS = {
    "state", "updaterVersion", "installedVersion", "installedSequence",
    "lastCheckAt", "lastSuccessfulCheckAt", "updateAvailable",
    "availableVersion", "availableSequence", "stagedVersion", "stagedSequence",
    "signatureStatus", "hashStatus", "lastUpdateResult", "rollbackResult",
    "errorCategory", "updatedAt", "publicKeyFingerprint",
}
V1_STATUS_STATES = {
    "BOOTSTRAPPED", "CHECKING", "NO_UPDATE", "ALREADY_STAGED",
    "NEWER_ALREADY_STAGED", "PENDING_APPLY", "INSTALLED",
    "ROLLBACK_COMPLETE", "RECOVERY_REQUIRED", "ERROR",
}
VERSION_PATTERN = re.compile(r"[0-9A-Za-z][0-9A-Za-z.+-]{0,63}")
UTC_PATTERN = re.compile(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z")


class UpdateControlError(RuntimeError):
    pass


class NoPendingUpdate(UpdateControlError):
    pass


class ApplyAlreadyRequested(UpdateControlError):
    pass


class ApplyLaunchUnavailable(UpdateControlError):
    pass


class ApplyConsentCancelled(UpdateControlError):
    pass


def _without_duplicates(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON keys are forbidden")
        result[key] = value
    return result


def _strict_json_object(raw: bytes) -> dict[str, Any]:
    if raw.startswith(b"\xef\xbb\xbf"):
        raise ValueError("JSON BOM is forbidden")
    value = json.loads(raw.decode("utf-8", errors="strict"),
        object_pairs_hook=_without_duplicates,
        parse_constant=lambda _value: (_ for _ in ()).throw(ValueError("Non-finite JSON")))
    if not isinstance(value, dict):
        raise ValueError("JSON root must be an object")
    return value


def _version(value: Any) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str) or VERSION_PATTERN.fullmatch(value) is None:
        raise ValueError("Version is invalid")
    return value


def _sequence(value: Any) -> int | None:
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, int) or not 0 <= value <= 2**63 - 1:
        raise ValueError("Sequence is invalid")
    return value


def _timestamp(value: Any) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str) or UTC_PATTERN.fullmatch(value) is None:
        raise ValueError("Timestamp is invalid")
    dt.datetime.strptime(value, "%Y-%m-%dT%H:%M:%SZ")
    return value


def sanitize_v1_status(value: Mapping[str, Any], current_version: str) -> dict[str, Any]:
    if not set(value).issubset(V1_STATUS_KEYS):
        raise ValueError("Updater V1 status contains an unexpected field")
    if not {"state", "updaterVersion", "installedVersion", "installedSequence", "updatedAt"}.issubset(value):
        raise ValueError("Updater V1 status is missing a required field")
    if "updateAvailable" in value and type(value["updateAvailable"]) is not bool:
        raise ValueError("Updater V1 updateAvailable flag is invalid")
    updater_version = _version(value.get("updaterVersion"))
    installed_version = _version(value.get("installedVersion")) or current_version
    installed_sequence = _sequence(value.get("installedSequence"))
    staged_version = _version(value.get("stagedVersion"))
    staged_sequence = _sequence(value.get("stagedSequence"))
    if (staged_version is None) != (staged_sequence is None):
        raise ValueError("Updater V1 staged identity is incomplete")
    raw_state = value.get("state")
    if not isinstance(raw_state, str):
        raise ValueError("Updater V1 state is invalid")
    raw_state = raw_state if raw_state in V1_STATUS_STATES else "UNKNOWN"
    pending = staged_version is not None
    state = "PENDING_APPLY" if pending and raw_state in {
        "PENDING_APPLY", "ALREADY_STAGED", "NEWER_ALREADY_STAGED"} else raw_state
    last_result = value.get("lastUpdateResult")
    rollback = value.get("rollbackResult")
    if last_result is not None and not isinstance(last_result, str):
        raise ValueError("Updater V1 last result is invalid")
    if rollback is not None and not isinstance(rollback, str):
        raise ValueError("Updater V1 rollback result is invalid")
    return {
        "updaterInstalled": updater_version is not None,
        "updaterVersion": updater_version,
        "currentVersion": installed_version,
        "currentSequence": installed_sequence,
        "pending": pending, "stagedVersion": staged_version, "stagedSequence": staged_sequence,
        "state": state,
        "lastResult": last_result if last_result in {
            None, "PASS", "FAIL", "NO_PENDING_UPDATE", "NO_UPDATE", "INTERRUPTED_ROLLBACK"} else "UNKNOWN",
        "rollbackResult": rollback if rollback in {None, "PASS", "FAIL"} else "UNKNOWN",
        "updatedAt": _timestamp(value.get("updatedAt")),
    }


def unavailable_status(current_version: str, invalid: bool = False) -> dict[str, Any]:
    return {
        "updaterInstalled": False, "updaterVersion": None,
        "currentVersion": current_version, "currentSequence": None,
        "pending": False, "stagedVersion": None, "stagedSequence": None,
        "state": "ERROR" if invalid else "UNAVAILABLE",
        "lastResult": None, "rollbackResult": None, "updatedAt": None,
    }


def _default_uac_requester(argv: Sequence[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        tuple(argv), stdin=subprocess.DEVNULL, capture_output=True, text=True,
        encoding="ascii", errors="strict", shell=False, check=False, timeout=90,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )


def _default_resume_starter(argv: Sequence[str]) -> None:
    subprocess.Popen(
        tuple(argv), stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL, shell=False, close_fds=True,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )


class DashboardUpdateControl:
    """Read V1 status and launch exactly one fixed, consented V1 Apply."""

    def __init__(
        self,
        current_version: str,
        *,
        status_path: Path = V1_STATUS_PATH,
        uac_requester: Callable[[Sequence[str]], subprocess.CompletedProcess[str]] = _default_uac_requester,
        resume_starter: Callable[[Sequence[str]], None] = _default_resume_starter,
    ) -> None:
        if VERSION_PATTERN.fullmatch(current_version) is None:
            raise ValueError("Current Dashboard version is invalid")
        self._current_version = current_version
        self._status_path = status_path
        self._uac_requester = uac_requester
        self._resume_starter = resume_starter
        self._apply_lock = threading.Lock()
        self._apply_requested = False

    @staticmethod
    def _is_reparse_point(path: Path) -> bool:
        metadata = os.lstat(path)
        attributes = getattr(metadata, "st_file_attributes", 0)
        reparse_attribute = getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)
        return bool(attributes & reparse_attribute) or stat.S_ISLNK(metadata.st_mode)

    def read_status(self) -> dict[str, Any]:
        try:
            if self._is_reparse_point(self._status_path.parent):
                raise ValueError("Updater status directory cannot be a reparse point")
            if self._is_reparse_point(self._status_path):
                raise ValueError("Updater status cannot be a reparse point")
            metadata = self._status_path.stat()
            if not stat.S_ISREG(metadata.st_mode) or not 1 <= metadata.st_size <= MAX_STATUS_BYTES:
                raise ValueError("Updater status file metadata is invalid")
            raw = self._status_path.read_bytes()
            if len(raw) != metadata.st_size:
                raise ValueError("Updater status changed while it was read")
            return sanitize_v1_status(_strict_json_object(raw), self._current_version)
        except FileNotFoundError:
            return unavailable_status(self._current_version)
        except (OSError, ValueError):
            return unavailable_status(self._current_version, invalid=True)

    def request_apply(self) -> None:
        with self._apply_lock:
            if self._apply_requested:
                raise ApplyAlreadyRequested("An apply request is already in progress")
            status = self.read_status()
            if not status["updaterInstalled"]:
                raise ApplyLaunchUnavailable("Updater V1 is unavailable")
            if not status["pending"] or status["state"] != "PENDING_APPLY":
                raise NoPendingUpdate("There is no pending update ready to apply")
            current_sequence = status["currentSequence"]
            staged_sequence = status["stagedSequence"]
            if type(current_sequence) is not int or type(staged_sequence) is not int or staged_sequence <= current_sequence:
                raise NoPendingUpdate("The pending sequence is not newer than the installed sequence")

            request_argv = (
                str(POWERSHELL_EXE), "-NoLogo", "-NoProfile", "-NonInteractive",
                "-ExecutionPolicy", "Bypass", "-File", str(UAC_REQUEST_SCRIPT),
            )
            try:
                completed = self._uac_requester(request_argv)
            except (OSError, subprocess.SubprocessError, UnicodeError) as exc:
                raise ApplyLaunchUnavailable("The fixed UAC launcher could not run") from exc
            if completed.returncode == 5:
                raise ApplyConsentCancelled("UAC consent was cancelled")
            if completed.returncode != 0:
                raise ApplyLaunchUnavailable("The fixed UAC launcher rejected the request")
            process_text = completed.stdout.strip()
            if not process_text.isascii() or not process_text.isdecimal():
                raise ApplyLaunchUnavailable("The fixed UAC launcher returned an invalid process identity")
            update_process_id = int(process_text)
            if not 1 <= update_process_id <= 2**32 - 1:
                raise ApplyLaunchUnavailable("The fixed UAC launcher returned an invalid process identity")

            resume_argv = (
                str(POWERSHELL_EXE), "-NoLogo", "-NoProfile", "-NonInteractive",
                "-ExecutionPolicy", "Bypass", "-File", str(RESUME_SCRIPT),
                "-UpdateProcessId", str(update_process_id),
            )
            try:
                self._resume_starter(resume_argv)
            except (OSError, subprocess.SubprocessError) as exc:
                raise ApplyLaunchUnavailable("The non-elevated resume watcher could not start") from exc
            self._apply_requested = True
