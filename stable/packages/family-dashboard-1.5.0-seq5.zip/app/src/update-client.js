export const UPDATE_STATUS_ENDPOINT = '/api/update/status';
export const UPDATE_APPLY_ENDPOINT = '/api/update/apply';
const HEALTH_ENDPOINT = '/api/health';

const IN_PROGRESS_STATES = new Set([
  'APPLY_REQUESTED',
  'WAITING_FOR_DASHBOARD_STOP',
  'APPLYING',
  'SMOKE_TEST',
]);
const FAILED_STATES = new Set(['ROLLBACK_COMPLETE', 'RECOVERY_REQUIRED', 'ERROR']);

export function describeUpdateStatus(status) {
  const currentVersion = typeof status?.currentVersion === 'string' ? status.currentVersion : '--';
  const stagedVersion = typeof status?.stagedVersion === 'string' ? status.stagedVersion : null;
  const state = typeof status?.state === 'string' ? status.state : 'UNKNOWN';
  const updaterInstalled = status?.updaterInstalled === true;
  const pending = status?.pending === true;
  let statusText = 'Up to date';

  if (!updaterInstalled || state === 'UNAVAILABLE') {
    statusText = 'Updater unavailable';
  } else if (state === 'CHECKING') {
    statusText = 'Checking for updates...';
  } else if (state === 'UPDATE_AVAILABLE') {
    statusText = 'Update available';
  } else if (state === 'DOWNLOADING') {
    statusText = 'Downloading update...';
  } else if (state === 'VERIFYING') {
    statusText = 'Verifying update...';
  } else if (state === 'STAGING') {
    statusText = 'Staging update...';
  } else if (pending && state === 'PENDING_APPLY' && stagedVersion) {
    statusText = `Update ${stagedVersion} ready`;
  } else if (IN_PROGRESS_STATES.has(state)) {
    statusText = 'Update in progress...';
  } else if (state === 'ROLLBACK_COMPLETE') {
    statusText = 'Update failed; previous version restored.';
  } else if (state === 'RECOVERY_REQUIRED') {
    statusText = 'Updater maintenance required';
  } else if (state === 'ERROR' || state === 'UNKNOWN') {
    statusText = 'Update status unavailable';
  }

  return {
    currentVersion,
    stagedVersion,
    statusText,
    canApply: updaterInstalled && pending && state === 'PENDING_APPLY' && Boolean(stagedVersion),
  };
}

export async function requestUpdateApply(fetchImpl = window.fetch.bind(window)) {
  const response = await fetchImpl(UPDATE_APPLY_ENDPOINT, {
    method: 'POST',
    cache: 'no-store',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({}),
  });
  if (!response.ok) throw new Error(`Update request rejected (${response.status})`);
  const result = await response.json();
  if (result?.accepted !== true || result?.state !== 'APPLY_REQUESTED') {
    throw new Error('Update request response was invalid');
  }
  return result;
}

async function readJson(fetchImpl, endpoint) {
  const separator = endpoint.includes('?') ? '&' : '?';
  const response = await fetchImpl(`${endpoint}${separator}poll=${Date.now()}`, { cache: 'no-store' });
  if (!response.ok) throw new Error(`Local status unavailable (${response.status})`);
  return response.json();
}

function defaultWait(milliseconds) {
  return new Promise((resolve) => window.setTimeout(resolve, milliseconds));
}

export async function pollForDashboardRecovery({
  expectedVersion,
  previousVersion,
  fetchImpl = window.fetch.bind(window),
  wait = defaultWait,
  intervalMs = 2_000,
  maxAttempts = 360,
  onPhase = () => {},
} = {}) {
  let outageObserved = false;
  for (let attempt = 0; attempt < maxAttempts; attempt += 1) {
    try {
      const health = await readJson(fetchImpl, HEALTH_ENDPOINT);
      if (
        typeof expectedVersion === 'string'
        && health?.appVersion === expectedVersion
        && (outageObserved || expectedVersion !== previousVersion)
      ) {
        return { outcome: 'updated', version: expectedVersion, outageObserved };
      }
      if (outageObserved) {
        try {
          const status = await readJson(fetchImpl, UPDATE_STATUS_ENDPOINT);
          if (
            status?.state === 'ROLLBACK_COMPLETE'
            || status?.rollbackResult === 'PASS'
            || status?.lastResult === 'INTERRUPTED_ROLLBACK'
          ) {
            return { outcome: 'rolled_back', version: health?.appVersion || previousVersion };
          }
          if (FAILED_STATES.has(status?.state) || status?.lastResult === 'FAIL') {
            return { outcome: 'failed', version: health?.appVersion || previousVersion };
          }
        } catch {
          // The restored server may become healthy just before its status endpoint is ready.
        }
      }
      onPhase(outageObserved ? 'server_restored_waiting' : 'waiting_for_shutdown');
    } catch {
      outageObserved = true;
      onPhase('server_offline');
    }
    await wait(intervalMs);
  }
  return { outcome: 'timeout', outageObserved };
}
