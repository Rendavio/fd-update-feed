Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"

$script:InstallRoot = Split-Path -Parent $PSScriptRoot
$script:AppRoot = Join-Path $script:InstallRoot "app"
$script:RuntimeRoot = Join-Path $script:InstallRoot "runtime"
$script:PythonPath = Join-Path $script:RuntimeRoot "python.exe"
$script:ServerPath = Join-Path $script:AppRoot "server.py"
$script:HealthUrl = "http://127.0.0.1:3000/api/health"
$script:DiagnosticsUrl = "http://127.0.0.1:3000/diagnostics.html"
$script:ProductionUrl = "http://127.0.0.1:3000/?display=1&theme=auto&calendar=google&eew=production"
$script:MaintenanceUrl = "http://127.0.0.1:3000/?theme=auto&calendar=mock&eew=production"

function Test-FamilyDashboardAdministrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Get-FamilyDashboardEdgePath {
    $candidates = @()
    try {
        $appPath = (Get-ItemProperty -LiteralPath "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe" -ErrorAction Stop)."(default)"
        if ($appPath) { $candidates += $appPath }
    } catch {}
    try {
        $appPath32 = (Get-ItemProperty -LiteralPath "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe" -ErrorAction Stop)."(default)"
        if ($appPath32) { $candidates += $appPath32 }
    } catch {}
    if ($env:ProgramFiles) {
        $candidates += (Join-Path $env:ProgramFiles "Microsoft\Edge\Application\msedge.exe")
    }
    $programFilesX86 = [Environment]::GetEnvironmentVariable("ProgramFiles(x86)")
    if ($programFilesX86) {
        $candidates += (Join-Path $programFilesX86 "Microsoft\Edge\Application\msedge.exe")
    }
    foreach ($candidate in ($candidates | Select-Object -Unique)) {
        if ($candidate -and (Test-Path -LiteralPath $candidate -PathType Leaf)) {
            return (Resolve-Path -LiteralPath $candidate).Path
        }
    }
    return $null
}

function Get-FamilyDashboardHealth {
    try {
        return Invoke-RestMethod -Uri $script:HealthUrl -Method Get -TimeoutSec 3
    } catch {
        return $null
    }
}

function Test-Port3000Listening {
    try {
        return [bool](Get-NetTCPConnection -State Listen -LocalPort 3000 -ErrorAction Stop)
    } catch {
        $client = New-Object System.Net.Sockets.TcpClient
        try {
            $async = $client.BeginConnect("127.0.0.1", 3000, $null, $null)
            return $async.AsyncWaitHandle.WaitOne(500)
        } catch {
            return $false
        } finally {
            $client.Dispose()
        }
    }
}

function Get-FamilyDashboardProductionArguments {
    # Keep the historical Edge profile and InPrivate context.
    return @("--kiosk", $script:ProductionUrl, "--edge-kiosk-type=fullscreen", "--no-first-run")
}

function Test-FamilyDashboardOwnedEdgeIdentity {
    param([Parameter(Mandatory = $true)][object]$Candidate)
    try {
        $edgePath = Get-FamilyDashboardEdgePath
        if (-not $edgePath -or $null -eq $Candidate.CreationDate -or
            [string]$Candidate.ExecutablePath -ine $edgePath -or
            [int]$Candidate.SessionId -ne (Get-Process -Id $PID).SessionId) { return $false }
        $executable = [regex]::Escape($edgePath)
        $pattern = '^\s*(?i:"' + $executable + '"|' + $executable + ')'
        foreach ($argument in @(Get-FamilyDashboardProductionArguments)) {
            $token = [regex]::Escape($argument)
            $pattern += '\s+(?:"' + $token + '"|' + $token + ')'
        }
        $pattern += '\s*$'
        if (-not [regex]::IsMatch([string]$Candidate.CommandLine, $pattern)) { return $false }
        $owner = Invoke-CimMethod -InputObject $Candidate -MethodName GetOwnerSid -ErrorAction Stop
        return ($owner.ReturnValue -eq 0 -and
            [string]$owner.Sid -eq [Security.Principal.WindowsIdentity]::GetCurrent().User.Value)
    } catch { return $false }
}

function Get-FamilyDashboardOwnedEdge {
    foreach ($candidate in @(Get-CimInstance Win32_Process -Filter "Name='msedge.exe'" -ErrorAction Stop)) {
        if (Test-FamilyDashboardOwnedEdgeIdentity -Candidate $candidate) { $candidate }
    }
}

function Test-FamilyDashboardProductionEdge {
    return (@(Get-FamilyDashboardOwnedEdge).Count -eq 1)
}

function Assert-FamilyDashboardOwnedEdge {
    param([Parameter(Mandatory = $true)][object]$Candidate)
    $again = Get-CimInstance Win32_Process -Filter ("ProcessId=" + [int]$Candidate.ProcessId) -ErrorAction Stop
    if ($null -eq $again -or -not (Test-FamilyDashboardOwnedEdgeIdentity -Candidate $again) -or
        [string]$again.ExecutablePath -cne [string]$Candidate.ExecutablePath -or
        [string]$again.CommandLine -cne [string]$Candidate.CommandLine -or
        $again.CreationDate.ToUniversalTime().Ticks -ne $Candidate.CreationDate.ToUniversalTime().Ticks) {
        throw "The owned dashboard browser identity changed."
    }
    return $again
}

function Initialize-FamilyDashboardWindowFocus {
    if (-not ("FamilyDashboard.WindowFocus" -as [type])) {
        Add-Type -TypeDefinition @'
using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using Microsoft.Win32.SafeHandles;
namespace FamilyDashboard {
    public static class WindowFocus {
        [DllImport("kernel32.dll", SetLastError=true)]
        private static extern SafeProcessHandle OpenProcess(uint access, bool inherit, int processId);
        [DllImport("kernel32.dll", SetLastError=true)]
        private static extern bool GetProcessTimes(SafeProcessHandle process, out long creation, out long exit, out long kernel, out long user);
        [DllImport("kernel32.dll")]
        private static extern uint WaitForSingleObject(SafeProcessHandle process, uint milliseconds);
        private delegate bool WindowCallback(IntPtr window, IntPtr state);
        [DllImport("user32.dll")] private static extern bool EnumWindows(WindowCallback callback, IntPtr state);
        [DllImport("user32.dll")] private static extern bool IsWindowVisible(IntPtr window);
        [DllImport("user32.dll", CharSet=CharSet.Unicode)] private static extern int GetClassName(IntPtr window, StringBuilder name, int length);
        [DllImport("user32.dll")] private static extern bool IsWindow(IntPtr window);
        [DllImport("user32.dll")] private static extern bool ShowWindowAsync(IntPtr window, int command);
        [DllImport("user32.dll")] private static extern bool SetForegroundWindow(IntPtr window);
        [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
        [DllImport("user32.dll")] private static extern uint GetWindowThreadProcessId(IntPtr window, out uint processId);

        public static SafeProcessHandle Pin(int processId, long expectedCreationTicks) {
            SafeProcessHandle handle = OpenProcess(0x00101000, false, processId);
            if (handle.IsInvalid) {
                handle.Dispose();
                throw new Win32Exception("The dashboard browser process could not be held.");
            }
            long creation, exit, kernel, user;
            // CIM exposes creation time to microsecond precision.
            if (!GetProcessTimes(handle, out creation, out exit, out kernel, out user) ||
                DateTime.FromFileTimeUtc(creation).Ticks / 10 != expectedCreationTicks / 10) {
                handle.Dispose();
                throw new InvalidOperationException("The dashboard browser process identity changed.");
            }
            return handle;
        }

        private static bool OwnsWindow(SafeProcessHandle process, int processId, IntPtr window) {
            uint owner;
            return WaitForSingleObject(process, 0) == 258 && IsWindow(window) &&
                GetWindowThreadProcessId(window, out owner) != 0 && owner == (uint)processId;
        }

        public static IntPtr[] Windows(SafeProcessHandle process, int processId) {
            var result = new List<IntPtr>();
            if (WaitForSingleObject(process, 0) != 258) return result.ToArray();
            EnumWindows((window, state) => {
                uint owner;
                var name = new StringBuilder(64);
                GetClassName(window, name, name.Capacity);
                if (IsWindowVisible(window) && GetWindowThreadProcessId(window, out owner) != 0 &&
                    owner == (uint)processId && name.ToString() == "Chrome_WidgetWin_1") result.Add(window);
                return true;
            }, IntPtr.Zero);
            return result.ToArray();
        }

        public static bool Focus(SafeProcessHandle process, int processId, IntPtr window) {
            // The held kernel handle prevents PID reuse throughout the operation.
            if (!OwnsWindow(process, processId, window)) return false;
            ShowWindowAsync(window, 9);
            if (!OwnsWindow(process, processId, window)) return false;
            SetForegroundWindow(window);
            return OwnsWindow(process, processId, window) && GetForegroundWindow() == window;
        }
    }
}
'@
    }
}

function Get-FamilyDashboardOwnedEdgeWindow {
    param([Parameter(Mandatory = $true)][object]$Candidate)
    $again = Assert-FamilyDashboardOwnedEdge -Candidate $Candidate
    Initialize-FamilyDashboardWindowFocus
    $heldProcess = [FamilyDashboard.WindowFocus]::Pin(
        [int]$again.ProcessId, $again.CreationDate.ToUniversalTime().Ticks
    )
    try {
        [void](Assert-FamilyDashboardOwnedEdge -Candidate $Candidate)
        $windows = @([FamilyDashboard.WindowFocus]::Windows($heldProcess, [int]$again.ProcessId))
        if ($windows.Count -ne 1) {
            throw "The dashboard browser has ambiguous windows; no navigation was attempted."
        }
        # The caller retains this handle through navigation and foreground checks.
        return [PSCustomObject]@{ WindowHandle = $windows[0]; ProcessHandle = $heldProcess }
    } catch {
        $heldProcess.Dispose()
        throw
    }
}

function Show-FamilyDashboardOwnedEdge {
    param(
        [Parameter(Mandatory = $true)][object]$Candidate,
        [IntPtr]$WindowHandle = [IntPtr]::Zero
    )
    $again = Assert-FamilyDashboardOwnedEdge -Candidate $Candidate
    Initialize-FamilyDashboardWindowFocus
    $heldProcess = [FamilyDashboard.WindowFocus]::Pin(
        [int]$again.ProcessId, $again.CreationDate.ToUniversalTime().Ticks
    )
    try {
        # Recheck owner, executable and full tokens with the process held.
        [void](Assert-FamilyDashboardOwnedEdge -Candidate $Candidate)
        $acquireWindow = $WindowHandle -eq [IntPtr]::Zero
        for ($attempt = 0; $attempt -lt 40; $attempt++) {
            if ($acquireWindow) {
                $WindowHandle = [IntPtr]::Zero
                $windows = @([FamilyDashboard.WindowFocus]::Windows($heldProcess, [int]$again.ProcessId))
                if ($windows.Count -gt 1) { throw "The dashboard browser has ambiguous windows." }
                if ($windows.Count -eq 1) { $WindowHandle = $windows[0] }
            }
            if ($WindowHandle -ne [IntPtr]::Zero -and
                [FamilyDashboard.WindowFocus]::Focus($heldProcess, [int]$again.ProcessId, $WindowHandle)) { return }
            Start-Sleep -Milliseconds 250
        }
        throw "The owned dashboard browser could not be brought to the foreground."
    } finally {
        $heldProcess.Dispose()
    }
}

function Open-FamilyDashboardEdge {
    param(
        [Parameter(Mandatory = $true)]
        [ValidateSet("Production", "Maintenance", "Diagnostics")]
        [string]$Mode
    )
    $edgePath = Get-FamilyDashboardEdgePath
    if (-not $edgePath) {
        throw "Microsoft Edge Chromium was not found. No fallback browser will be installed or used."
    }
    if ($Mode -ne "Production") {
        $arguments = switch ($Mode) {
            "Maintenance" { @("--new-window", $script:MaintenanceUrl) }
            "Diagnostics" { @("--new-window", $script:DiagnosticsUrl) }
        }
        Start-Process -FilePath $edgePath -ArgumentList $arguments | Out-Null
        return
    }
    $health = Get-FamilyDashboardHealth
    if (-not $health -or $health.status -ne "ok" -or
        $health.appId -ne "family-dashboard" -or $health.mode -ne "production" -or
        $health.processIntegrity -ne "nonElevated") {
        throw "Production readiness was not confirmed; no browser recovery was attempted."
    }
    $owned = @(Get-FamilyDashboardOwnedEdge)
    if ($owned.Count -gt 1) { throw "Multiple matching dashboard browsers require local review." }
    $windowHandle = [IntPtr]::Zero
    $windowLease = $null
    if ($owned.Count -eq 1) {
        $windowLease = Get-FamilyDashboardOwnedEdgeWindow -Candidate $owned[0]
        $windowHandle = $windowLease.WindowHandle
    }
    try {
        $arguments = @(Get-FamilyDashboardProductionArguments | ForEach-Object { '"{0}"' -f $_ })
        $startedAt = [DateTime]::UtcNow
        # Same-profile URL handoff preserves the running kiosk's browser state.
        # No browser process or window is closed. A pre-existing second window
        # is ambiguous, so the guard above refuses before issuing this handoff.
        Start-Process -FilePath $edgePath -ArgumentList $arguments | Out-Null
        if ($owned.Count -eq 1) {
            Show-FamilyDashboardOwnedEdge -Candidate $owned[0] -WindowHandle $windowHandle
            return
        }
        for ($attempt = 0; $attempt -lt 40; $attempt++) {
            $owned = @(Get-FamilyDashboardOwnedEdge)
            if ($owned.Count -eq 1 -and $owned[0].CreationDate.ToUniversalTime() -ge $startedAt.AddSeconds(-1)) {
                Show-FamilyDashboardOwnedEdge -Candidate $owned[0]
                return
            }
            Start-Sleep -Milliseconds 250
        }
        throw "The production browser did not become ready."
    } finally {
        if ($null -ne $windowLease) { $windowLease.ProcessHandle.Dispose() }
    }
}

function Set-ChildEnvironment {
    param(
        [Parameter(Mandatory = $true)][string]$Mode,
        [Parameter(Mandatory = $true)][string]$DataRoot
    )
    $env:FAMILY_DASHBOARD_MODE = $Mode
    $env:FAMILY_DASHBOARD_HOME = $DataRoot
    $env:PYTHONUTF8 = "1"
    $env:PYTHONDONTWRITEBYTECODE = "1"
}
