"""Bounded behavioral facts and positive public projection; no OS queries."""
from __future__ import annotations
import hashlib
import hmac
import ipaddress
import json
import ntpath
import re
import uuid
from datetime import datetime, timezone
from security_events import base_case, instant
from security_health import safe_reason, safe_time

SECTIONS=('processes','network','persistence','security','integrity')
SECTION_FRESHNESS_SECONDS={'processes':300,'network':300,'persistence':1020,'security':1020,'integrity':1020}
RELEASE_MAP_PATH=ntpath.normcase(ntpath.normpath('C:/FamilyDashboard/app/behavior_release.json'))
EXPECTED_RELEASE_PATHS={ntpath.normcase(ntpath.normpath('C:/FamilyDashboard/'+name)) for name in (
 'app/server.py','app/app.js','app/security_health.py','app/security_configuration.py','app/security_events.py','app/security_monitor.py','app/security_windows.py',
 'app/behavior_events.py','app/behavior_monitor.py','app/behavior_windows.py','app/behavior_native.py','app/behavior_security.py',
 'app/src/security-alerts.js','app/src/behavior-alerts.js','app/src/production-bootstrap.js','app/security-alerts.css',
 'launcher/Read-BehaviorSecuritySnapshot.ps1','launcher/Read-DefenderSecuritySnapshot.ps1')}
RELEASE_EXPECTED_FILE_COUNT=len(EXPECTED_RELEASE_PATHS)
LIMITS={'processes':384,'network':512,'persistence':512,'security':2048,'integrity':RELEASE_EXPECTED_FILE_COUNT+1,'gateways':16,'stateBytes':1048576,'cases':16,'seenIdentities':1024,'flows':512}
COVERAGE={'OK','PARTIAL','UNAVAILABLE','NOT_COLLECTED'}
TRUST={'VALID_CACHE_ONLY','NO_EMBEDDED_SIGNATURE','INVALID_SIGNATURE','UNTRUSTED_CHAIN','UNKNOWN'}
PATH_CLASSES={'SYSTEM','PROGRAM_FILES','APP_CODE','USER_TEMP','USER_PROFILE','OTHER_LOCAL','UNKNOWN'}
DESTINATION_CLASSES={'LOOPBACK','UNSPECIFIED','MULTICAST','LINK_LOCAL','PRIVATE','GLOBAL','RESERVED','GATEWAY','UNKNOWN'}
CONNECTION_STATES={'Listen','SynSent','SynReceived','Established','FinWait1','FinWait2','CloseWait','Closing','LastAck','TimeWait','Closed','DeleteTCB','Bound','UNKNOWN'}
PERSISTENCE_KINDS={'RUN','RUNONCE','STARTUP','TASK','SERVICE'}
SECURITY_KINDS={'FIREWALL_PROFILE','FIREWALL_RULE','FIREWALL_APP_FILTER','FIREWALL_PORT_FILTER','FIREWALL_ADDRESS_FILTER','ADMIN_MEMBER','LOCAL_USER','RDP','SMB'}
ANOMALY_TYPES={'BASELINE_REVIEW','NEW_IMAGE','IMAGE_HASH_CHANGED','RISKY_EXECUTABLE','MASQUERADE_CANDIDATE','UNUSUAL_PARENT_CHILD','NEW_PEER','UNUSUAL_PORT','CONNECTION_SURGE','PERSISTENCE_CHANGED','PERSISTENCE_ACROSS_BOOT','SECURITY_CONFIG_CHANGED','INTEGRITY_MISMATCH','EXPECTED_APP_UPDATE','OS_VERSION_CHANGED','SOURCE_DEGRADED','STATE_INTEGRITY_FAILED','STATE_RECOVERED','STATE_WRITE_FAILED','CASE_OVERFLOW'}
DELTA_CODES={'INITIAL_OBSERVATION','ADDED','MODIFIED','REMOVED','ABSOLUTE_FACT','CONTEXT_ONLY','UNKNOWN'}
CHANGE_CODES={'ADDED','MODIFIED','REMOVED'}
SIGNAL_CODES=ANOMALY_TYPES|{'OUTBOUND_ATTEMPT','TCP_ESTABLISHED','SAME_IMAGE_PERSISTENCE','VERIFIED_PARENT_CHILD'}
OBSERVATION_SOURCES={'WIN32_PROCESS','NETTCPIP','PERSISTENCE_SNAPSHOT','SECURITY_CONFIG_SNAPSHOT','LOCAL_FILE_HASH'}
LIMITATION_CODES={'BASELINE_UNREVIEWED','IDENTITY_CAPACITY_REACHED','SAME_USER_SECRET_NOT_TAMPER_PROOF','DISK_IMAGE_NOT_MEMORY','CATALOG_SIGNATURE_NOT_CHECKED','CACHE_ONLY_REVOCATION_UNKNOWN','SOURCE_PARTIAL','SOURCE_UNAVAILABLE','SOURCE_NOT_COLLECTED','SOURCE_STALE','SOURCE_FUTURE','INVALID_SNAPSHOT','IDENTITY_UNVERIFIED','PID_REUSE_POSSIBLE','DIRECTION_UNKNOWN','TCP_CONTENT_UNKNOWN','SHORT_AND_UDP_TRAFFIC_MAY_BE_MISSED','ACTOR_UNKNOWN','TIME_WINDOW_ONLY','OPAQUE_PERSISTENCE_TARGET','NO_ROLE_ATTRIBUTION','LOCAL_MAP_NOT_RUNTIME_VERIFICATION','EVIDENCE_NOT_SAVED','STATE_RECOVERED','STATE_INTEGRITY_FAILED','SOURCE_ACCESS_DENIED','TRUNCATED','INSPECTION_BUDGET_EXHAUSTED','SIGNATURE_UNKNOWN','PROCESS_RACE','NETWORK_UNAVAILABLE','PERSISTENCE_UNAVAILABLE','SECURITY_UNAVAILABLE','INTEGRITY_UNAVAILABLE'}
MISSING_CODES={'PROCESS_START','PROCESS_IMAGE','CONNECTION_CREATION_TIME','VERIFIED_PROCESS_INSTANCE','CURRENT_SOURCE_CLOCK','COMPLETE_COVERAGE','FRESH_FILE_INSPECTION','EXPECTED_RELEASE_HASH','PERSISTENCE_TARGET','ACTOR_IDENTITY','EVIDENCE_NOT_SAVED','ORIGINAL_RAW_EVIDENCE','BASELINE_REVIEW'}
INVESTIGATION_CODES={'REVIEW_BASELINE','REVIEW_EXECUTABLE','REVIEW_NETWORK','REVIEW_PERSISTENCE','REVIEW_SECURITY_CONFIGURATION','VERIFY_RELEASE_FILES','CHECK_MONITOR_HEALTH','REVIEW_PRIVATE_EVIDENCE'}
ENUM_FIELDS={'BASELINE_DELTA':DELTA_CODES,'EXECUTABLE_TRUST':TRUST,'EXECUTABLE_PATH_CLASS':PATH_CLASSES,'NETWORK_DESTINATION_CLASS':DESTINATION_CLASSES,'CONNECTION_STATE':CONNECTION_STATES,'CONNECTION_DIRECTION':{'OUTBOUND_ATTEMPT','OUTBOUND_ATTEMPT_THEN_ESTABLISHED','NOT_VERIFIED'},'REACHABILITY':{'ATTEMPT_ONLY','TCP_ESTABLISHED_AT_SAMPLE','NOT_VERIFIED'},'PROCESS_NETWORK_CORRELATION':{'VERIFIED_INSTANCE_AND_TIME','PID_SNAPSHOT_ONLY','IDENTITY_MISMATCH','NOT_AVAILABLE'},'CONFIDENCE':{'OBSERVED_FACTS_ONLY','MULTI_SOURCE_IDENTITY_LINKED','IDENTITY_UNVERIFIED'},'BASELINE_TRUST':{'OBSERVED_UNREVIEWED','INTEGRITY_FAILED','NOT_AVAILABLE'},'UPDATE_CONTEXT':{'NOT_AVAILABLE','REPORT_ONLY','LOCAL_RELEASE_MAP_AND_REPORT'}}
LIST_ENUM_FIELDS={'ANOMALY_TYPE':ANOMALY_TYPES,'PERSISTENCE_CHANGE':CHANGE_CODES,'SECURITY_CONFIG_CHANGE':CHANGE_CODES,'CORRELATED_SIGNALS':SIGNAL_CODES,'LIMITATIONS':LIMITATION_CODES,'RECOMMENDED_INVESTIGATION':INVESTIGATION_CODES,'MISSING_EVIDENCE':MISSING_CODES,'OBSERVATION_SOURCE':OBSERVATION_SOURCES}

def _enum(value, allowed, default='UNKNOWN'):
 return value if isinstance(value,str) and value in allowed else default

def _token(value,prefix):
 return value if isinstance(value,str) and re.fullmatch(prefix+r'-[a-f0-9]{16}',value) else 'UNKNOWN'

def _hash(value):
 return value.lower() if isinstance(value,str) and re.fullmatch('[a-fA-F0-9]{64}',value) else 'UNKNOWN'

def _uuid(value):
 try:return str(uuid.UUID(value))
 except (ValueError,TypeError,AttributeError):return 'UNKNOWN'

def make_case(now, anomaly, **fields):
 c=base_case(now,'UNKNOWN');c.update(EVENT_SOURCE='BEHAVIOR_MONITOR',ANOMALY_TYPE=[anomaly],BASELINE_DELTA='ABSOLUTE_FACT',PROCESS_IDENTITY='UNKNOWN',IMAGE_IDENTITY='UNKNOWN',EXECUTABLE_TRUST='UNKNOWN',EXECUTABLE_PATH_CLASS='UNKNOWN',NETWORK_DESTINATION_CLASS='UNKNOWN',DESTINATION_PORT='UNKNOWN',CONNECTION_STATE='UNKNOWN',CONNECTION_DIRECTION='NOT_VERIFIED',REACHABILITY='NOT_VERIFIED',PROCESS_NETWORK_CORRELATION='NOT_AVAILABLE',PERSISTENCE_CHANGE=[],SECURITY_CONFIG_CHANGE=[],CORRELATED_SIGNALS=[anomaly],CONFIDENCE='OBSERVED_FACTS_ONLY',LIMITATIONS=['BASELINE_UNREVIEWED','SAME_USER_SECRET_NOT_TAMPER_PROOF'],RECOMMENDED_INVESTIGATION=['REVIEW_PRIVATE_EVIDENCE'],BASELINE_ID='UNKNOWN',BASELINE_TRUST='NOT_AVAILABLE',OBSERVED_AT=now.isoformat(),OBSERVATION_SOURCE=[],FACT_TIMELINE=[],BINARY_SHA256='UNKNOWN',SAMPLE_COUNT=1,UPDATE_CONTEXT='NOT_AVAILABLE');c.update(fields);return public_behavior_case(c)

def behavior_health_case(value):
 """Only fixed, fact-free source incidents may leave human-review counts."""
 if not isinstance(value,dict) or value.get('MONITOR_HEALTH_ONLY') is False:return False
 if value.get('EVENT_SOURCE')!='BEHAVIOR_MONITOR' or value.get('ALERT_LEVEL')!='WARNING' or value.get('ANOMALY_TYPE')!=['SOURCE_DEGRADED']:return False
 signals=value.get('CORRELATED_SIGNALS',[])
 if not isinstance(signals,list) or any(v!='SOURCE_DEGRADED' for v in signals):return False
 for key in ('FACT_TIMELINE','OBSERVATION_SOURCE','PERSISTENCE_CHANGE','SECURITY_CONFIG_CHANGE','RELATED_EVENTS','REASON_CODES','RESOURCE_HASHES','RESOURCE_TYPES'):
  if value.get(key,[])!=[]:return False
 unknown=('PROCESS_IDENTITY','IMAGE_IDENTITY','BINARY_SHA256','BASELINE_ID','DESTINATION_PORT','NEW_PEER_COUNT','EXECUTABLE_TRUST','EXECUTABLE_PATH_CLASS','NETWORK_DESTINATION_CLASS','CONNECTION_STATE','THREAT_ID','THREAT_NAME','THREAT_CATEGORY','DEFENDER_SEVERITY','DETECTION_SOURCE','DETECTION_METHOD','ACTION_ATTEMPTED','ACTION_RESULT','ERROR_CODE','EVENT_ID','RECORD_ID','SIGNATURE_VERSION','SIGNATURE_AGE','DEFENDER_CASE_ID')
 if any(value.get(key) not in (None,'UNKNOWN') for key in unknown):return False
 for key,default in (('BASELINE_DELTA','ABSOLUTE_FACT'),('BASELINE_TRUST','NOT_AVAILABLE'),('CONNECTION_DIRECTION','NOT_VERIFIED'),('REACHABILITY','NOT_VERIFIED'),('PROCESS_NETWORK_CORRELATION','NOT_AVAILABLE'),('CONFIDENCE','OBSERVED_FACTS_ONLY'),('UPDATE_CONTEXT','NOT_AVAILABLE'),('DEFENDER_REFERENCE','NOT_LINKED')):
  if value.get(key,default) not in (None,default):return False
 if value.get('RESOURCE_CLASS',[]) not in ([],['UNKNOWN']):return False
 protection=value.get('DEFENDER_PROTECTION_STATE',{})
 if not isinstance(protection,dict) or any(v!='UNKNOWN' for v in protection.values()):return False
 return True

def recovered_behavior_health(value):
 return behavior_health_case(value) and value.get('MONITOR_INCIDENT_STATUS')=='RECOVERED'

def public_behavior_case(value):
 if not isinstance(value,dict):raise ValueError('invalid case')
 at=instant(value.get('DETECTED_AT'))
 if at is None or _uuid(value.get('CASE_ID'))=='UNKNOWN':raise ValueError('invalid case identity')
 c=base_case(at,'UNKNOWN');c.update(CASE_ID=_uuid(value['CASE_ID']),EVENT_SOURCE='BEHAVIOR_MONITOR',ACKNOWLEDGED=value.get('ACKNOWLEDGED') is True)
 for field,allowed in ENUM_FIELDS.items():
  defaults={'CONNECTION_DIRECTION':'NOT_VERIFIED','REACHABILITY':'NOT_VERIFIED','PROCESS_NETWORK_CORRELATION':'NOT_AVAILABLE','CONFIDENCE':'IDENTITY_UNVERIFIED','BASELINE_TRUST':'NOT_AVAILABLE','UPDATE_CONTEXT':'NOT_AVAILABLE'}
  c[field]=_enum(value.get(field),allowed,defaults.get(field,'UNKNOWN'))
 for field,allowed in LIST_ENUM_FIELDS.items():
  raw=value.get(field);c[field]=list(dict.fromkeys(x for x in raw[:32] if isinstance(x,str) and x in allowed)) if isinstance(raw,list) else []
 c['PROCESS_IDENTITY']=_token(value.get('PROCESS_IDENTITY'),'P');c['IMAGE_IDENTITY']=_token(value.get('IMAGE_IDENTITY'),'I');c['BASELINE_ID']=_uuid(value.get('BASELINE_ID'));c['BINARY_SHA256']=_hash(value.get('BINARY_SHA256'))
 c['OBSERVED_AT']=(instant(value.get('OBSERVED_AT')) or at).isoformat()
 v=value.get('DESTINATION_PORT');c['DESTINATION_PORT']=v if type(v) is int and 0<=v<=65535 else 'UNKNOWN'
 v=value.get('SAMPLE_COUNT');c['SAMPLE_COUNT']=min(65535,max(1,v)) if type(v) is int else 1
 v=value.get('NEW_PEER_COUNT');c['NEW_PEER_COUNT']=min(1024,max(0,v)) if type(v) is int else 'UNKNOWN'
 c['FACT_TIMELINE']=[]
 for fact in value.get('FACT_TIMELINE',[])[:16] if isinstance(value.get('FACT_TIMELINE'),list) else []:
  if not isinstance(fact,dict):continue
  target=fact.get('TARGET');t=instant(fact.get('AT'))
  if t and _enum(fact.get('SOURCE'),OBSERVATION_SOURCES)!='UNKNOWN' and _enum(fact.get('SIGNAL'),SIGNAL_CODES)!='UNKNOWN' and isinstance(target,str) and re.fullmatch('[PI]-[a-f0-9]{16}',target):c['FACT_TIMELINE'].append({'AT':t.isoformat(),'SOURCE':fact['SOURCE'],'SIGNAL':fact['SIGNAL'],'TARGET':target})
 c['MONITOR_HEALTH_ONLY']=behavior_health_case(value) and behavior_health_case(c)
 if c['MONITOR_HEALTH_ONLY']:
  c['MONITOR_REASON']=safe_reason(value.get('MONITOR_REASON','UNKNOWN'))
  c['MONITOR_INCIDENT_STATUS']=_enum(value.get('MONITOR_INCIDENT_STATUS'),{'ACTIVE','RECOVERED'},'ACTIVE')
  c['MONITOR_RECOVERED_AT']=safe_time(value.get('MONITOR_RECOVERED_AT'))
  if c['MONITOR_INCIDENT_STATUS']=='RECOVERED':c['HUMAN_REVIEW_REQUIRED']=False
 return c

def _ip(value):
 if not isinstance(value,str) or len(value)>128:return None
 try:
  address=ipaddress.ip_address(value)
  return address.ipv4_mapped if isinstance(address,ipaddress.IPv6Address) and address.ipv4_mapped else address
 except (ValueError,TypeError):return None

def classify_destination(address, gateways=()):
 a=_ip(address)
 if a is None:return 'UNKNOWN'
 if a.is_unspecified:return 'UNSPECIFIED'
 if a.is_loopback:return 'LOOPBACK'
 if a.is_multicast:return 'MULTICAST'
 if a.is_link_local:return 'LINK_LOCAL'
 if a in {_ip(x) for x in gateways if isinstance(x,str)}:return 'GATEWAY'
 if a.is_reserved:return 'RESERVED'
 if a.is_private:return 'PRIVATE'
 if a.is_global:return 'GLOBAL'
 return 'RESERVED'

def canonical_path(value):
 if not isinstance(value,str) or not value or len(value)>1024 or '\x00' in value:return None
 if not re.match(r'^[A-Za-z]:[\\/]',value) or value.startswith(('\\\\','//')) or any(x in value for x in ('"','\n','\r')):return None
 if re.search(r'(?i)[.](?:exe|com|bat|cmd|ps1|py|dll)\s+[-/]',value):return None
 result=ntpath.normcase(ntpath.normpath(value))
 if ':' in result[2:]:return None
 return result

def _ident(key,prefix,*parts):
 data=json.dumps(parts,separators=(',',':'),ensure_ascii=True).encode();return prefix+'-'+hmac.new(key,data,hashlib.sha256).hexdigest()[:16]

def _time(value):
 if value is None:return None
 result=instant(value)
 if result is None:raise ValueError('invalid timestamp')
 return result.isoformat()

def _number(value,maximum=2**32-1,nullable=False):
 if value is None and nullable:return None
 if type(value) is not int or not 0<=value<=maximum:raise ValueError('invalid integer')
 return value

def _version(value):
 return value if isinstance(value,str) and re.fullmatch('[0-9]+(?:[.][0-9A-Za-z]+){0,5}',value) and len(value)<=64 else 'UNKNOWN'

def normalize_snapshot(snapshot,key,now):
 """Validate bounded input; persist only keyed identities, fixed enums and file hashes."""
 if not isinstance(key,bytes) or len(key)!=32:raise ValueError('invalid key')
 if not isinstance(snapshot,dict) or snapshot.get('schemaVersion')!=1:raise ValueError('invalid snapshot')
 raw=json.dumps(snapshot,ensure_ascii=True,separators=(',',':'),allow_nan=False).encode()
 if len(raw)>1048576:raise ValueError('oversized snapshot')
 def check(value,depth=0):
  if depth>8:raise ValueError('nested snapshot')
  if isinstance(value,str) and len(value)>1024:raise ValueError('oversized string')
  if isinstance(value,dict):
   if len(value)>64:raise ValueError('oversized object')
   for k,v in value.items():
    if not isinstance(k,str):raise ValueError('invalid key')
    check(k,depth+1);check(v,depth+1)
  elif isinstance(value,list):
   if len(value)>4096:raise ValueError('oversized array')
   for v in value:check(v,depth+1)
  elif value is not None and type(value) not in (str,int,bool):raise ValueError('invalid scalar')
 check(snapshot)
 at=_time(snapshot.get('observedAt'));clock=instant(at);fresh=clock is not None and -5<=(now-clock).total_seconds()<=300
 limitation=[x for x in snapshot.get('limitations',[]) if isinstance(x,str) and x in LIMITATION_CODES][:32]
 if not fresh:limitation.append('SOURCE_FUTURE' if clock and clock>now else 'SOURCE_STALE')
 coverage={};observed={};rows={}
 for section in SECTIONS:
  cov=snapshot.get('coverage',{}).get(section) if isinstance(snapshot.get('coverage'),dict) else None
  cov=_enum(cov,COVERAGE,'UNAVAILABLE');stamp=snapshot.get('observed',{}).get(section) if isinstance(snapshot.get('observed'),dict) else None
  observed[section]=_time(stamp);section_at=instant(observed[section]);arr=snapshot.get('connections' if section=='network' else section)
  if not isinstance(arr,list):arr=[];cov='UNAVAILABLE'
  if len(arr)>LIMITS[section]:arr=arr[:LIMITS[section]];cov='PARTIAL';limitation.append('TRUNCATED')
  if cov=='OK' and (not fresh or section_at is None or not -5<=(now-section_at).total_seconds()<=SECTION_FRESHNESS_SECONDS[section]):cov='PARTIAL'
  coverage[section]=cov;rows[section]=arr
 osinfo=snapshot.get('os',{});app=snapshot.get('app',{});osinfo=osinfo if isinstance(osinfo,dict) else {};app=app if isinstance(app,dict) else {}
 result={'at':at,'fresh':fresh,'coverage':coverage,'observed':observed,'limitations':list(dict.fromkeys(limitation)), 'osVersion':_version(osinfo.get('version')),'osBuild':_version(osinfo.get('build')),'boot':_time(osinfo.get('bootAt')),'appVersion':_version(app.get('version')),'appSequence':_number(app.get('sequence'),2**63-1,True),'processes':[],'network':[],'persistence':[],'security':[],'integrity':[]}
 for p in rows['processes']:
  if not isinstance(p,dict):raise ValueError('invalid process')
  pid=_number(p.get('pid'));parent=_number(p.get('parentPid'));start=_time(p.get('start'));path=canonical_path(p.get('path'));image=_ident(key,'I',path) if path else 'UNKNOWN';instance=_ident(key,'P',pid,start,path) if path and start else 'UNKNOWN';inspected=_time(p.get('inspectedAt'));trusted=p.get('identityVerified') is True and path is not None and start is not None and fresh and coverage['processes']=='OK' and instant(start)<=min(clock,instant(observed['processes']))
  name=p.get('name','');name=name.lower() if isinstance(name,str) else '';role='BROWSER' if name=='msedge.exe' else 'SHELL' if name in {'cmd.exe','powershell.exe','pwsh.exe','wscript.exe','cscript.exe'} else 'OTHER'
  system_names={'svchost.exe','lsass.exe','services.exe','winlogon.exe','csrss.exe','smss.exe','explorer.exe','msedge.exe'}
  system_roots=[ntpath.normcase(ntpath.join(root,'')) for root in ('C:/Windows/System32','C:/Windows/SysWOW64')]
  edge_roots=[ntpath.normcase(ntpath.join(root,'')) for root in ('C:/Program Files (x86)/Microsoft/Edge/Application','C:/Program Files/Microsoft/Edge/Application')]
  canonical_system=bool(path and (any(path.startswith(root) for root in system_roots) or (name=='explorer.exe' and path==ntpath.normcase('C:/Windows/explorer.exe')) or (name=='msedge.exe' and any(path.startswith(root) for root in edge_roots))))
  result['processes'].append({'pid':pid,'parent':parent,'start':start,'image':image,'instance':instance,'verified':trusted,'hash':_hash(p.get('sha256')),'trust':_enum(p.get('trust'),TRUST) if trusted and inspected and instant(start)<=instant(inspected)<=now else 'UNKNOWN','pathClass':_enum(p.get('pathClass'),PATH_CLASSES),'inspected':inspected,'freshHash':bool(trusted and inspected and instant(start)<=instant(inspected)<=now),'role':role,'masquerade':bool(name in system_names and path and not canonical_system)})
 gateways=snapshot.get('gateways',[]);gateways=gateways[:16] if isinstance(gateways,list) else []
 for c in rows['network']:
  if not isinstance(c,dict):raise ValueError('invalid connection')
  pid=_number(c.get('pid'));start=_time(c.get('processStart'));path=canonical_path(c.get('processPath'));created=_time(c.get('createdAt'));port=_number(c.get('remotePort'),65535);local_port=_number(c.get('localPort'),65535);remote=_ip(c.get('remoteAddress'));local=_ip(c.get('localAddress'));image=_ident(key,'I',path) if path else 'UNKNOWN';instance=_ident(key,'P',pid,start,path) if path and start else 'UNKNOWN'
  peer=_ident(key,'N',str(remote)) if remote else 'UNKNOWN';flow=_ident(key,'F',instance,str(local),local_port,str(remote),port,created) if instance!='UNKNOWN' and local and remote and created else 'UNKNOWN'
  candidates=[p for p in result['processes'] if p['pid']==pid];linked=bool(len(candidates)==1 and candidates[0]['verified'] and candidates[0]['instance']==instance and c.get('identityVerified') is True and created and start and fresh and coverage['network']=='OK' and instant(start)<=instant(created)<=min(clock,instant(observed['network'])))
  correlation='VERIFIED_INSTANCE_AND_TIME' if linked else 'IDENTITY_MISMATCH' if candidates and instance!='UNKNOWN' and candidates[0]['instance']!=instance else 'PID_SNAPSHOT_ONLY' if candidates else 'NOT_AVAILABLE'
  result['network'].append({'image':image,'instance':instance,'peer':peer,'flow':flow,'class':classify_destination(c.get('remoteAddress'),gateways),'port':port,'state':_enum(c.get('state'),CONNECTION_STATES),'linked':linked,'correlation':correlation,'created':created})
 for section,kinds in [('persistence',PERSISTENCE_KINDS),('security',SECURITY_KINDS)]:
  for row in rows[section]:
   if not isinstance(row,dict) or row.get('kind') not in kinds or not isinstance(row.get('key'),str) or _hash(row.get('digest'))=='UNKNOWN':raise ValueError('invalid configuration')
   target=canonical_path(row.get('target')) if section=='persistence' else None
   result[section].append({'id':_ident(key,'K',row['kind'],row['key']),'kind':row['kind'],'digest':_hash(row['digest']),'image':_ident(key,'I',target) if target else 'UNKNOWN'})
 for row in rows['integrity']:
  if not isinstance(row,dict):raise ValueError('invalid integrity')
  path=canonical_path(row.get('path'));actual=_hash(row.get('sha256'));expected=_hash(row.get('expectedSha256'));checked=_time(row.get('checkedAt'));file_fresh=bool(actual!='UNKNOWN' and checked and -5<=(now-instant(checked)).total_seconds()<=SECTION_FRESHNESS_SECONDS['integrity']);valid=bool(expected!='UNKNOWN' and file_fresh)
  result['integrity'].append({'image':_ident(key,'I',path) if path else 'UNKNOWN','hash':actual,'expected':expected,'match':actual==expected if valid else None,'isReleaseMap':path==RELEASE_MAP_PATH,'isExpectedReleaseFile':path in EXPECTED_RELEASE_PATHS,'fresh':file_fresh})
 update=snapshot.get('update',{});update=update if isinstance(update,dict) else {}
 required=[r for r in result['integrity'] if not r['isReleaseMap']]
 expected=bool(len(required)==RELEASE_EXPECTED_FILE_COUNT and len({r['image'] for r in required})==RELEASE_EXPECTED_FILE_COUNT and all(r['image']!='UNKNOWN' and r['isExpectedReleaseFile'] for r in required) and any(r['isReleaseMap'] and r['fresh'] for r in result['integrity']) and coverage['integrity']=='OK' and all(r['match'] is True for r in required) and update.get('source')=='UPDATER_V1_REPORT' and update.get('verification')=='REPORT_ONLY' and update.get('state')=='INSTALLED' and update.get('lastResult')=='PASS' and update.get('version')==app.get('version')==update.get('releaseMapVersion') and type(app.get('sequence')) is int and app.get('sequence')==update.get('sequence')==update.get('releaseMapSequence'))
 result['updateContext']='LOCAL_RELEASE_MAP_AND_REPORT' if expected else 'REPORT_ONLY' if update.get('source')=='UPDATER_V1_REPORT' else 'NOT_AVAILABLE'
 return result
