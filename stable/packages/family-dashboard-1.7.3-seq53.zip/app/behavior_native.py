"""Bounded local-file metadata worker. Cache-only trust; no network or writes."""
from __future__ import annotations
import ctypes,hashlib,json,ntpath,os,re,sys,uuid
from datetime import datetime,timezone
from pathlib import Path
if __name__=='__main__':sys.path.insert(0,str(Path(__file__).resolve().parent))
import eew_private_audio as private
CRITICAL_ARCHIVE_FILES=(
 'app/server.py','app/app.js','app/security_configuration.py','app/security_health.py','app/security_events.py','app/security_monitor.py','app/security_windows.py',
 'app/behavior_events.py','app/behavior_monitor.py','app/behavior_windows.py','app/behavior_native.py','app/behavior_security.py',
 'app/src/security-alerts.js','app/src/behavior-alerts.js','app/src/production-bootstrap.js','app/security-alerts.css',
 'launcher/Read-BehaviorSecuritySnapshot.ps1','launcher/Read-DefenderSecuritySnapshot.ps1','app/behavior_release.json')
MAX_SIGNATURE_INSPECTIONS=8
MAX_INSPECTION_REQUESTS=MAX_SIGNATURE_INSPECTIONS+len(CRITICAL_ARCHIVE_FILES)
HASH_PATHS={ntpath.normcase(ntpath.join(r'C:\FamilyDashboard',p.replace('/', '\\'))) for p in CRITICAL_ARCHIVE_FILES}
class Guid(ctypes.Structure):_fields_=[('raw',ctypes.c_ubyte*16)]
class WinTrustFileInfo(ctypes.Structure):
 _fields_=[('cbStruct',ctypes.c_uint32),('pcwszFilePath',ctypes.c_wchar_p),('hFile',ctypes.c_void_p),('pgKnownSubject',ctypes.c_void_p)]
class WinTrustData(ctypes.Structure):
 _fields_=[('cbStruct',ctypes.c_uint32),('pPolicyCallbackData',ctypes.c_void_p),('pSIPClientData',ctypes.c_void_p),('dwUIChoice',ctypes.c_uint32),('fdwRevocationChecks',ctypes.c_uint32),('dwUnionChoice',ctypes.c_uint32),('pFile',ctypes.c_void_p),('dwStateAction',ctypes.c_uint32),('hWVTStateData',ctypes.c_void_p),('pwszURLReference',ctypes.c_void_p),('dwProvFlags',ctypes.c_uint32),('dwUIContext',ctypes.c_uint32),('pSignatureSettings',ctypes.c_void_p)]
class OfflineWinTrust:
 def __init__(self,*,dll=None,handle_reader=None):
  self.dll=dll;self.handle_reader=handle_reader
 def __call__(self,path,stream):
  if self.dll is None:
   if sys.platform!='win32':return 'UNKNOWN'
   self.dll=ctypes.WinDLL('wintrust.dll',use_last_error=True)
   self.dll.WinVerifyTrust.argtypes=[ctypes.c_void_p,ctypes.POINTER(Guid),ctypes.POINTER(WinTrustData)]
   self.dll.WinVerifyTrust.restype=ctypes.c_int32
  if self.handle_reader is None:
   import msvcrt
   reader=lambda s:msvcrt.get_osfhandle(s.fileno())
  else:reader=self.handle_reader
  guid=Guid.from_buffer_copy(uuid.UUID('00aac56b-cd44-11d0-8cc2-00c04fc295ee').bytes_le)
  file=WinTrustFileInfo(ctypes.sizeof(WinTrustFileInfo),str(path),reader(stream),None)
  data=WinTrustData();data.cbStruct=ctypes.sizeof(data);data.dwUIChoice=2;data.fdwRevocationChecks=0;data.dwUnionChoice=1
  data.pFile=ctypes.cast(ctypes.pointer(file),ctypes.c_void_p);data.dwStateAction=1
  data.dwProvFlags=0x1000|0x10 # CACHE_ONLY_URL_RETRIEVAL, REVOCATION_CHECK_NONE.
  try:code=int(self.dll.WinVerifyTrust(None,ctypes.byref(guid),ctypes.byref(data)))&0xffffffff
  finally:
   data.dwStateAction=2
   self.dll.WinVerifyTrust(None,ctypes.byref(guid),ctypes.byref(data))
  return {0:'VALID_CACHE_ONLY',0x800B0100:'NO_EMBEDDED_SIGNATURE',0x80096010:'INVALID_SIGNATURE',0x800B0004:'UNTRUSTED_CHAIN',0x800B0109:'UNTRUSTED_CHAIN',0x800B010C:'UNTRUSTED_CHAIN'}.get(code,'UNKNOWN')
def _permitted(row,platform):
 if not isinstance(row,dict) or set(row)!={'path','signature'} or type(row['signature']) is not bool:return False
 path=row['path']
 if not isinstance(path,str) or not 1<=len(path)<=1024 or path.startswith(('\\\\','//')) or '\x00' in path:return False
 if '..' in Path(path).parts or '..' in ntpath.normpath(path).split('\\'):return False
 if not row['signature']:return ntpath.normcase(ntpath.normpath(path)) in HASH_PATHS
 if ntpath.splitext(path)[1].lower() not in {'.exe','.com','.dll'}:return False
 return Path(path).is_absolute() if platform=='test' else bool(re.match(r'^[A-Za-z]:[\\/]',path))
def inspect_requests(requests,*,verify=None,platform=None,file_limit=16*1024*1024,byte_limit=64*1024*1024):
 platform=platform or sys.platform;verify=verify or OfflineWinTrust()
 if not isinstance(requests,list) or len(requests)>MAX_INSPECTION_REQUESTS:return []
 result=[];used=0;signatures=0
 for index,row in enumerate(requests):
  out={'index':index,'trust':'UNKNOWN','sha256':'UNKNOWN','inspectedAt':None,'error':'NONE'};result.append(out)
  if not _permitted(row,platform):out['error']='UNSAFE_PATH';continue
  if row['signature']:
   signatures+=1
   if signatures>MAX_SIGNATURE_INSPECTIONS:out['error']='BYTE_BUDGET';continue
  try:
   # Existing helper pins every parent and the file, rejects UNC/reparse/nonfixed disks.
   with private.secure_file(Path(row['path'])) as stream:
    before=os.fstat(stream.fileno())
    if before.st_size>file_limit:out['error']='OVERSIZED';continue
    if used+before.st_size>byte_limit:out['error']='BYTE_BUDGET';continue
    digest=hashlib.sha256();count=0
    while True:
     remaining=min(65536,file_limit-count,byte_limit-used)
     if remaining<=0:break
     chunk=stream.read(remaining)
     if not chunk:break
     count+=len(chunk);used+=len(chunk)
     if count>file_limit or used>byte_limit:raise ValueError('budget')
     digest.update(chunk)
    after=os.fstat(stream.fileno())
    if (before.st_size,before.st_mtime_ns)!=(after.st_size,after.st_mtime_ns) or count!=before.st_size:raise ValueError('changed')
    out['sha256']=digest.hexdigest()
    if row['signature']:
     trust=verify(Path(row['path']),stream)
     out['trust']=trust if trust in {'VALID_CACHE_ONLY','NO_EMBEDDED_SIGNATURE','INVALID_SIGNATURE','UNTRUSTED_CHAIN','UNKNOWN'} else 'UNKNOWN'
    out['inspectedAt']=datetime.now(timezone.utc).isoformat()
  except private.PrivateAudioError:out['error']='UNSAFE_PATH'
  except (OSError,ValueError):out['error']='UNREADABLE'
  except Exception:out['error']='UNKNOWN'
 return result
def main():
 if sys.argv[1:]!=['--inspect']:return 2
 try:
  raw=sys.stdin.buffer.read(32769)
  if len(raw)>32768:raise ValueError()
  requests=json.loads(raw.decode('utf-8'))
  print(json.dumps(inspect_requests(requests),separators=(',',':')));return 0
 except Exception:
  print('[]');return 2
if __name__=='__main__':raise SystemExit(main())