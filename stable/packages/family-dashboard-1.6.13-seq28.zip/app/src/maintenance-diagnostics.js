import { describeUpdateStatus } from './update-client.js';

const VERSION_PATTERN = /^[0-9A-Za-z][0-9A-Za-z.+-]{0,63}$/;
const APPLY_PHASES = new Set([
  'UNKNOWN', 'REQUEST_ACCEPTED', 'UAC_APPROVED', 'COORDINATOR_STARTED',
  'SHUTDOWN_REQUESTED', 'SERVER_EXITED', 'PORT_CLOSED', 'UPDATER_STARTED',
  'UPDATER_FINISHED', 'WATCHER_RESTARTED', 'HEALTH_OK',
]);
const APPLY_RESULTS = new Set(['UNKNOWN', 'RUNNING', 'PASS', 'FAIL', 'TIMEOUT']);
const APPLY_ERRORS = new Set([
  'NONE', 'UAC_CANCELLED', 'COORDINATOR_NOT_STARTED', 'SERVER_EXIT_TIMEOUT',
  'PORT_CLOSE_TIMEOUT', 'UPDATER_NOT_STARTED', 'UPDATER_EXIT_NONZERO',
  'UPDATER_TIMEOUT', 'RESTART_TIMEOUT',
]);
const UPDATER_EXIT_CODES = new Set(['0', '2', '3', '5', '64', 'OTHER']);
const SWITCHBOT_ERRORS = new Set([
  'NONE', 'BATTERY_READ', 'SETUP_PARSE', 'API_TIMEOUT', 'API_DNS',
  'TLS_HOSTNAME', 'TLS_CERT_VERIFY', 'TLS_EOF', 'TLS_HANDSHAKE',
  'TLS_PROTOCOL', 'TLS_OTHER', 'API_CONNECT', 'API_TRANSPORT_OTHER', 'API_AUTH',
  'API_RESPONSE', 'TARGET_MATCH', 'DEVICE_TYPE', 'CLOUD_DISABLED',
  'STATUS_AUTH', 'STATUS_RESPONSE', 'STATUS_READ',
  'POWER_SCHEMA', 'CONFIG_WRITE', 'UNKNOWN',
]);

function version(value) {
  return typeof value === 'string' && VERSION_PATTERN.test(value) ? value : null;
}

function sequence(value) {
  return Number.isSafeInteger(value) && value >= 0 ? String(value) : null;
}

function lastUpdate(value) {
  if (value === 'PASS') return 'PASS';
  if (value === 'FAIL') return 'FAIL';
  return 'Unknown';
}

export function describeMaintenanceDiagnostics({ runtime = null, updateStatus = null } = {}) {
  const runtimeAvailable = runtime !== null && typeof runtime === 'object';
  const updateAvailable = updateStatus !== null && typeof updateStatus === 'object';
  const updateView = updateAvailable ? describeUpdateStatus(updateStatus) : null;
  const integrity = runtime?.processIntegrity;
  const apply = runtime?.lastApply;
  const applyPhase = APPLY_PHASES.has(apply?.phase) ? apply.phase : 'UNKNOWN';
  const applyResult = APPLY_RESULTS.has(apply?.result) ? apply.result : 'UNKNOWN';
  const applyError = APPLY_ERRORS.has(apply?.error) ? apply.error : 'NONE';
  const updaterExitCode = UPDATER_EXIT_CODES.has(apply?.updaterExitCode)
    ? apply.updaterExitCode
    : 'Unknown';
  const switchBot = runtime?.switchBot;
  const switchBotAvailable = switchBot !== null && typeof switchBot === 'object';
  const battery = switchBot?.batteryPercent;
  const plug = switchBot?.plug;
  const switchBotLastCheck = switchBot?.lastCheck;
  const switchBotError = switchBot?.error;

  return {
    dashboard: version(updateStatus?.currentVersion) || version(runtime?.appVersion) || 'Unknown',
    sequence: sequence(updateStatus?.currentSequence) || 'Unknown',
    updater: version(updateStatus?.updaterVersion) || 'Unknown',
    server: runtimeAvailable ? 'Running' : 'Unknown',
    integrity: integrity === 'nonElevated' || integrity === 'elevated' ? integrity : 'Unknown',
    update: updateView?.statusText || 'Unknown',
    lastUpdate: lastUpdate(updateStatus?.lastResult),
    lastApplyPhase: applyPhase,
    lastApplyResult: applyResult,
    lastApplyError: applyError,
    updaterExitCode,
    updaterFailureStage: 'UNKNOWN',
    switchBot: switchBotAvailable
      ? (switchBot.configured === true ? 'Configured' : 'Not configured')
      : 'Unknown',
    battery: Number.isSafeInteger(battery) && battery >= 0 && battery <= 100
      ? `${battery}%`
      : 'Unknown',
    plug: plug === 'ON' || plug === 'OFF' ? plug : 'Unknown',
    switchBotLastCheck: switchBotLastCheck === 'PASS' || switchBotLastCheck === 'FAIL'
      ? switchBotLastCheck
      : 'Unknown',
    switchBotError: SWITCHBOT_ERRORS.has(switchBotError) ? switchBotError : 'UNKNOWN',
  };
}
