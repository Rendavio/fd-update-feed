"""Bounded, fixed, read-only Defender acquisition for the console user."""
from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import sys

POWERSHELL = Path(r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe")
COLLECTOR = Path(r"C:\FamilyDashboard\launcher\Read-DefenderSecuritySnapshot.ps1")
MAX_SNAPSHOT_BYTES=524288
ERRORS={"NONE","ACCESS_DENIED","SOURCE_UNAVAILABLE","TIMEOUT","INVALID_SNAPSHOT"}
SOURCE_ERRORS={"EVENT_LOG_UNAVAILABLE","STATUS_UNAVAILABLE","THREATS_UNAVAILABLE",
               "DETECTIONS_UNAVAILABLE","SERVICE_UNAVAILABLE","TRUNCATED","LOG_RESET"}
HEALTH_REASONS={"NONE","UNKNOWN","MONITOR_WORKER_NOT_RUNNING","DEFENDER_STATUS_QUERY_TIMEOUT",
    "DEFENDER_STATUS_QUERY_FAILED","DEFENDER_SERVICE_QUERY_FAILED","DEFENDER_SERVICE_STOPPED",
    "REALTIME_PROTECTION_OFF","DEFENDER_EVENT_LOG_UNAVAILABLE","DEFENDER_EVENT_LOG_DISABLED",
    "DEFENDER_EVENT_LOG_ACCESS_DENIED","EVENT_LOG_RESET_OR_ROLLOVER","CHECKPOINT_INVALID",
    "POLL_TIMEOUT","INVALID_SNAPSHOT","SOURCE_PARTIAL"}
HEALTH_CHECKS={"serviceRunning","realtimeProtection","eventLogExists","eventLogEnabled","eventLogReadable"}
HEALTH_RECORDS={"oldestRecordId","newestRecordId"}
HEALTH_KEYS=HEALTH_CHECKS | HEALTH_RECORDS | {"reason"}
STAGE_MARKERS={"DEFENDER_STAGE:"+stage for stage in
    ("EVENT_LOG","STATUS","SERVICE","THREATS","DETECTIONS","COMPLETE")}
KEYS={"available","error","watermark","logReset","events","threats","detections","protection","sourceErrors"}

def _unavailable(code, reason=None):
    if reason is None:
        reason={"INVALID_SNAPSHOT":"INVALID_SNAPSHOT","TIMEOUT":"POLL_TIMEOUT"}.get(code,"UNKNOWN")
    health={key:None for key in HEALTH_CHECKS | HEALTH_RECORDS}
    health["reason"]=reason
    return {"available":False,"error":code,"watermark":None,"logReset":False,
            "events":[],"threats":[],"detections":[],"protection":{},"sourceErrors":[],"health":health}

def _pairs(pairs):
    result={}
    for key,value in pairs:
        if key in result: raise ValueError("Duplicate field")
        result[key]=value
    return result

def _validate_health(health):
    if not isinstance(health,dict) or set(health)!=HEALTH_KEYS: raise ValueError()
    if not isinstance(health["reason"],str) or health["reason"] not in HEALTH_REASONS: raise ValueError()
    for field in HEALTH_CHECKS:
        if health[field] is not None and type(health[field]) is not bool: raise ValueError()
    for field in HEALTH_RECORDS:
        value=health[field]
        if value is not None and (type(value) is not int or not 1<=value<2**63): raise ValueError()
    oldest,newest=health["oldestRecordId"],health["newestRecordId"]
    if oldest is not None and newest is not None and oldest>newest: raise ValueError()

def _timeout_reason(stderr):
    # Only this fixed, exact protocol is consumed; diagnostics never leave the process boundary.
    if isinstance(stderr,bytes): stderr=stderr.decode("ascii",errors="replace")
    if not isinstance(stderr,str): return "POLL_TIMEOUT"
    if len(stderr)>8192:
        # A sliced partial line cannot become an authenticated stage marker.
        partial=stderr[-8193] not in "\r\n"
        stderr=stderr[-8192:]
        if partial: stderr=stderr.partition("\n")[2]
    stages=[line for line in stderr.splitlines() if line in STAGE_MARKERS]
    return "DEFENDER_STATUS_QUERY_TIMEOUT" if stages and stages[-1]=="DEFENDER_STAGE:STATUS" else "POLL_TIMEOUT"

class WindowsDefenderSource:
    def __init__(self, *, runner=None, platform=None, collector=COLLECTOR):
        self._run=runner or subprocess.run
        self._platform=sys.platform if platform is None else platform
        self._collector=Path(collector)

    def resync_checkpoint(self):
        return self.collect(None,recent_window=True)

    def collect(self, after_record_id, *, recent_window=False):
        if type(recent_window) is not bool: return _unavailable("INVALID_SNAPSHOT")
        if after_record_id is not None and (type(after_record_id) is not int or not 0<=after_record_id<2**63):
            return _unavailable("INVALID_SNAPSHOT","CHECKPOINT_INVALID")
        if self._platform!="win32": return _unavailable("SOURCE_UNAVAILABLE")
        argv=[str(POWERSHELL),"-NoLogo","-NoProfile","-NonInteractive",
              "-ExecutionPolicy","Bypass","-File",str(self._collector)]
        if after_record_id is not None: argv+=["-AfterRecordId",str(after_record_id)]
        if recent_window: argv+=["-RecentWindow"]
        env=dict(os.environ)
        env["PSModulePath"]=r"C:\Windows\System32\WindowsPowerShell\v1.0\Modules;C:\Program Files\WindowsPowerShell\Modules"
        env["PATH"]=r"C:\Windows\System32;C:\Windows"
        try:
            completed=self._run(argv,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,shell=False,timeout=15,env=env,
                creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
            if completed.returncode:
                return _unavailable("ACCESS_DENIED" if completed.returncode==5 else "SOURCE_UNAVAILABLE")
            raw=completed.stdout
            if not isinstance(raw,bytes) or not 1<=len(raw)<=MAX_SNAPSHOT_BYTES:
                return _unavailable("INVALID_SNAPSHOT")
            value=json.loads(raw.decode("utf-8-sig"),object_pairs_hook=_pairs,
                parse_constant=lambda _x: (_ for _ in ()).throw(ValueError("Invalid JSON")))
            if not isinstance(value,dict) or set(value) not in (KEYS,KEYS | {"health"}): raise ValueError()
            if "health" in value: _validate_health(value["health"])
            if type(value["available"]) is not bool or type(value["logReset"]) is not bool: raise ValueError()
            if value["error"] not in ERRORS: raise ValueError()
            watermark=value["watermark"]
            if watermark is not None and (type(watermark) is not int or not 0<=watermark<2**63): raise ValueError()
            if value["available"] and watermark is None: raise ValueError()
            for field,maximum in [("events",32),("threats",32),("detections",64)]:
                if not isinstance(value[field],list) or len(value[field])>maximum or not all(isinstance(x,dict) for x in value[field]):
                    raise ValueError()
            if not isinstance(value["protection"],dict) or len(value["protection"])>24: raise ValueError()
            if (not isinstance(value["sourceErrors"],list) or len(value["sourceErrors"])>8 or
                any(x not in SOURCE_ERRORS for x in value["sourceErrors"])): raise ValueError()
            return value
        except subprocess.TimeoutExpired as exc: return _unavailable("TIMEOUT",_timeout_reason(exc.stderr))
        except PermissionError: return _unavailable("ACCESS_DENIED")
        except (OSError,ValueError,UnicodeError,TypeError,AttributeError):
            return _unavailable("INVALID_SNAPSHOT")
