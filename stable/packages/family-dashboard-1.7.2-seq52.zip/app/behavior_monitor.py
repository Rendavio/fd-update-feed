"""Independent, private WARNING-only behavioral monitor.

Local HMAC detects accidental damage and changes without the local key. A same-user
or OS attacker can replace both: this is not remote attestation or a clean baseline.
"""
from __future__ import annotations
import copy
import hashlib
import hmac
import json
import os
import threading
import time
import uuid
from datetime import datetime, timezone
from security_events import instant
from security_health import public_monitor_health, safe_reason
from security_monitor import PrivateMonitorStore, _reject_duplicates
import eew_private_audio as private
from behavior_events import (normalize_snapshot,make_case,public_behavior_case,LIMITS,SECTIONS,behavior_health_case,recovered_behavior_health)

MAX_STATE_BYTES=1048576
MAX_CASES=16

def _encoded(value):return json.dumps(value,ensure_ascii=True,separators=(',',':'),sort_keys=True,allow_nan=False).encode()

# Retain the immutable comparison facts, not transient PID/flow source columns twice.
_BASE_PROCESS=('image','hash','freshHash')
_BASE_NETWORK=('image','peer','port')
_CONFIG=('id','kind','digest','image')

def _baseline(n):
 b={k:copy.deepcopy(n[k]) for k in ('at','coverage','observed','osVersion','osBuild','boot','appVersion','appSequence','integrity','updateContext')}
 b['processes']=[{k:p[k] for k in _BASE_PROCESS} for p in n['processes']]
 b['network']=[{k:c[k] for k in _BASE_NETWORK} for c in n['network']]
 for section in ('persistence','security'):b[section]=copy.deepcopy(n[section])
 return b

def _previous(n):
 return {'coverage':{k:n['coverage'][k] for k in ('persistence','security')},'observed':{k:n['observed'][k] for k in ('persistence','security')},'persistence':copy.deepcopy(n['persistence']),'security':copy.deepcopy(n['security'])}

def _pack_state(state):
 # Column tables eliminate repeated field names while preserving every comparison row.
 result=copy.deepcopy(state)
 for role in ('baseline','previous'):
  snapshot=result.get(role)
  if not isinstance(snapshot,dict):continue
  for section,columns in [('processes',_BASE_PROCESS),('network',_BASE_NETWORK),('persistence',_CONFIG),('security',_CONFIG)]:
   rows=snapshot.get(section)
   if isinstance(rows,list):snapshot[section]={'columns':list(columns),'rows':[[row.get(k) for k in columns] for row in rows]}
 return result

def _unpack_state(state):
 for role in ('baseline','previous'):
  snapshot=state.get(role)
  if not isinstance(snapshot,dict):continue
  for section,columns in [('processes',_BASE_PROCESS),('network',_BASE_NETWORK),('persistence',_CONFIG),('security',_CONFIG)]:
   table=snapshot.get(section)
   if isinstance(table,dict):
    rows=table.get('rows')
    if table.get('columns')!=list(columns) or not isinstance(rows,list) or len(rows)>LIMITS[section] or any(not isinstance(r,list) or len(r)!=len(columns) for r in rows):raise ValueError('invalid comparison table')
    snapshot[section]=[dict(zip(columns,row)) for row in rows]
 return state

def _empty():
 return {'schema':1,'baseline':None,'baselineId':'UNKNOWN','baselineTrust':'NOT_AVAILABLE','cases':[],'fingerprints':{},'previous':None,'flows':[],'seen':[],'peerHistoryIncomplete':False,'stableObservations':0,'monitorState':'STARTING','lastCheckedAt':None,'coverage':{k:'NOT_COLLECTED' for k in SECTIONS},'sectionObservedAt':{k:None for k in SECTIONS},'osVersion':'UNKNOWN','appVersion':'UNKNOWN','baselineQuality':'NOT_AVAILABLE'}

class BehaviorMonitorStore(PrivateMonitorStore):
 """Independent files, existing path/ACL/atomic protections and bounded HMAC seal."""
 def __init__(self,data_root):
  super().__init__(data_root);self.directory=self.root/'behavior-monitor';self.path=self.directory/'state.json';self.previous=self.directory/'state.previous.json';self.keypath=self.directory/'key.bin';self.key=None;self.locked=False
 def _decode(self,raw):
  if len(raw)>MAX_STATE_BYTES:raise ValueError('oversized state')
  envelope=json.loads(raw.decode(),object_pairs_hook=_reject_duplicates,parse_constant=lambda _:(_ for _ in ()).throw(ValueError('invalid number')))
  if not isinstance(envelope,dict) or not isinstance(envelope.get('payload'),dict) or not isinstance(envelope.get('mac'),str):raise ValueError('invalid envelope')
  payload=envelope['payload'];mac=hmac.new(self.key,_encoded(payload),hashlib.sha256).hexdigest()
  if not hmac.compare_digest(mac,envelope['mac']):raise ValueError('invalid seal')
  if payload.get('schema')!=1 or not isinstance(payload.get('cases'),list) or len(payload['cases'])>16 or not isinstance(payload.get('fingerprints'),dict) or len(payload['fingerprints'])>1024 or not isinstance(payload.get('seen'),list) or len(payload['seen'])>1024 or not isinstance(payload.get('flows'),list) or len(payload['flows'])>512:raise ValueError('invalid state')
  if type(payload.get('peerHistoryIncomplete',False)) is not bool:raise ValueError('invalid peer history flag')
  payload=_unpack_state(payload)
  payload['cases']=[public_behavior_case(c) for c in payload['cases']]
  payload['behaviorHealth']=public_monitor_health(payload.get('behaviorHealth'))
  if isinstance(payload.get('sourceIncident'),dict):payload['sourceIncident']=public_behavior_case(payload['sourceIncident'])
  if len({c['CASE_ID'] for c in payload['cases']})!=len(payload['cases']):raise ValueError('duplicate case identity')
  if payload.get('baseline') is not None:
   uuid.UUID(payload.get('baselineId',''))
   if payload.get('baselineTrust')!='OBSERVED_UNREVIEWED' or not isinstance(payload['baseline'],dict):raise ValueError('invalid baseline')
  return payload
 def load(self):
  # Existence must not bypass the protected reader. Missing primary still tries previous.
  try:self.key=self._read(self.keypath,32)
  except FileNotFoundError:
   artifacts=self.directory.exists()
   if artifacts:self.locked=True;return None,'FAILED'
   self.key=os.urandom(32);return None,'NEW'
  except Exception:self.locked=True;return None,'FAILED'
  if len(self.key)!=32:self.locked=True;return None,'FAILED'
  for index,path in enumerate((self.path,self.previous)):
   try:return self._decode(self._read(path,MAX_STATE_BYTES)),'OK' if index==0 else 'RECOVERED'
   except Exception:pass
  self.locked=True;return None,'FAILED'
 def _serialize(self,state):
  payload=_pack_state(state)
  return _encoded({'payload':payload,'mac':hmac.new(self.key,_encoded(payload),hashlib.sha256).hexdigest()})
 def save(self,state):
  if self.locked:raise ValueError('learning locked')
  raw=self._serialize(state)
  self._decode(raw);self._ensure()
  with private.locked_chain(self.directory,private_base=self.directory):
   try:
    oldkey=self._read(self.keypath,32)
    if not hmac.compare_digest(oldkey,self.key):raise ValueError('key changed')
   except FileNotFoundError:self._atomic(self.keypath,self.key)
   try:old=self._read(self.path,MAX_STATE_BYTES);self._decode(old)
   except FileNotFoundError:old=None
   except ValueError:old=None
   if old is not None:self._atomic(self.previous,old)
   self._atomic(self.path,raw)

class BehaviorMonitor:
 def __init__(self,data_root,source,clock=None,interval_seconds=120,full_interval_seconds=900):
  self.source=source;self.clock=clock or (lambda:datetime.now(timezone.utc));self.interval_seconds=max(1,float(interval_seconds));self.full_interval_seconds=max(self.interval_seconds,float(full_interval_seconds));self._lock=threading.RLock();self._poll_lock=threading.Lock();self._stop=threading.Event();self._thread=None;self.store=BehaviorMonitorStore(data_root);loaded,status=self.store.load();self._state=loaded or _empty();self._durable=copy.deepcopy(self._state);self._unsaved=False;self._pending=None;self._last_write=None;self._last_full=None;self._supervisor=None;self._worker_restart_used=False;self._poll_started=None
  self._state['behaviorHealth']=public_monitor_health(self._state.get('behaviorHealth'))
  if status=='FAILED':self._state.update(baselineTrust='INTEGRITY_FAILED',monitorState='DEGRADED',baselineQuality='INTEGRITY_FAILED');self._add(self._state,'integrity',make_case(self._now(),'STATE_INTEGRITY_FAILED',BASELINE_TRUST='INTEGRITY_FAILED',LIMITATIONS=['STATE_INTEGRITY_FAILED','SAME_USER_SECRET_NOT_TAMPER_PROOF'],RECOMMENDED_INVESTIGATION=['CHECK_MONITOR_HEALTH']))
  elif status=='RECOVERED':self._add(self._state,'recovered',make_case(self._now(),'STATE_RECOVERED',LIMITATIONS=['STATE_RECOVERED'],RECOMMENDED_INVESTIGATION=['CHECK_MONITOR_HEALTH']))
 def _now(self):
  now=self.clock()
  if not isinstance(now,datetime) or now.tzinfo is None:raise ValueError('aware UTC clock required')
  return now.astimezone(timezone.utc)
 def _launch_worker(self):
  self._thread=threading.Thread(target=self._run,name='BehaviorMonitor',daemon=True);self._thread.start()
 def start(self):
  with self._lock:
   if self._thread and self._thread.is_alive():return
   self._stop.clear();self._launch_worker()
   if not self._supervisor or not self._supervisor.is_alive():
    self._supervisor=threading.Thread(target=self._supervise,name='BehaviorMonitorSupervisor',daemon=True);self._supervisor.start()
 def _health(self,state,reason,now,retries=0,recovery_reason=None,attempt=True):
  h=public_monitor_health(state.get('behaviorHealth'));prior_reason=h['reason'] if h['status']=='MONITOR_UNAVAILABLE' else None;h.update(reason=safe_reason(reason),retryCount=retries,workerAlive=bool(self._thread and self._thread.is_alive()))
  if attempt:h['lastAttemptAt']=now.isoformat()
  if reason!='NONE':h.update(status='MONITOR_UNAVAILABLE',lastReason=safe_reason(reason),recoveryResult='STILL_UNAVAILABLE')
  else:
   previous=recovery_reason or prior_reason or (h['lastReason'] if h['status']=='MONITOR_UNAVAILABLE' else None)
   h.update(status='MONITOR_OK',lastSuccessfulPollAt=now.isoformat())
   if previous and previous!='NONE':h.update(lastReason=safe_reason(previous),lastRecovery='AUTOMATIC',lastRecoveryAt=now.isoformat(),recoveryResult='RECOVERED_AUTOMATICALLY')
  state['behaviorHealth']=h
 def _source_health(self,state,reason,now,limitations=()):
  active=[c for c in state['cases'] if behavior_health_case(c) and not recovered_behavior_health(c)]
  detached=state.get('sourceIncident')
  if isinstance(detached,dict) and not recovered_behavior_health(detached):active.append(detached)
  if reason=='NONE':
   for case in active:case.update(MONITOR_INCIDENT_STATUS='RECOVERED',MONITOR_RECOVERED_AT=now.isoformat(),HUMAN_REVIEW_REQUIRED=False)
   return bool(active)
  if active:
   case=active[-1];changed=case.get('MONITOR_REASON')!=reason
   case.update(MONITOR_REASON=reason,OBSERVED_AT=now.isoformat(),SAMPLE_COUNT=min(65535,case['SAMPLE_COUNT']+1),LIMITATIONS=list(dict.fromkeys(limitations))[:32]);return changed
  case=make_case(now,'SOURCE_DEGRADED',MONITOR_REASON=reason,MONITOR_INCIDENT_STATUS='ACTIVE',LIMITATIONS=list(limitations),MISSING_EVIDENCE=['COMPLETE_COVERAGE'],RECOMMENDED_INVESTIGATION=['CHECK_MONITOR_HEALTH'])
  if len(state['cases'])<MAX_CASES:state['cases'].append(case)
  else:state['sourceIncident']=case
  return True
 def supervise_once(self):
  if self._stop.is_set():return
  with self._lock:
   alive=bool(self._thread and self._thread.is_alive())
   if alive and (self._poll_started is None or time.monotonic()-self._poll_started<=75):return
   reason='BEHAVIOR_POLL_TIMEOUT' if alive else 'BEHAVIOR_WORKER_NOT_RUNNING'
   self._state['monitorState']='DEGRADED';self._health(self._state,reason,self._now(),attempt=False);self._source_health(self._state,reason,self._now())
   # Never start a replacement while a collector is alive or after one failed restart.
   if not alive and not self._worker_restart_used:
    self._worker_restart_used=True
    try:self._launch_worker()
    except Exception:pass
 def _supervise(self):
  while not self._stop.wait(min(5,self.interval_seconds)):
   try:self.supervise_once()
   except Exception:pass
 def _run(self):
  while not self._stop.is_set():
   try:self.poll_once()
   except Exception:
    with self._lock:
     self._state['monitorState']='DEGRADED';self._health(self._state,'BEHAVIOR_INVALID_SNAPSHOT',self._now())
   self._stop.wait(self.interval_seconds)
 def stop(self):
  self._stop.set()
  for worker in (self._thread,self._supervisor):
   if worker and worker is not threading.current_thread():worker.join(timeout=2)
 def _add(self,state,fingerprint,case):
  # Fingerprints never contain raw source identifiers; retained even after overflow.
  key=hashlib.sha256(fingerprint.encode()).hexdigest();oldid=state['fingerprints'].get(key);old=next((c for c in state['cases'] if c['CASE_ID']==oldid),None)
  if old:
   changed=any(old.get(k)!=case.get(k) for k in ('CONNECTION_DIRECTION','REACHABILITY','CORRELATED_SIGNALS','CONFIDENCE','NEW_PEER_COUNT'))
   count=min(65535,old['SAMPLE_COUNT']+1);ack=old['ACKNOWLEDGED'];cid=old['CASE_ID'];detected=old['DETECTED_AT']
   if changed:old.update(case);old.update(CASE_ID=cid,DETECTED_AT=detected,ACKNOWLEDGED=False)
   else:old['ACKNOWLEDGED']=ack
   old['SAMPLE_COUNT']=count;old['OBSERVED_AT']=case['OBSERVED_AT'];return changed
  if oldid:return False
  urgent=bool(set(case['ANOMALY_TYPE'])&{'STATE_WRITE_FAILED','SOURCE_DEGRADED','STATE_INTEGRITY_FAILED'})
  if urgent and len(state['cases'])>=15:
   overflow=next((c for c in state['cases'] if 'CASE_OVERFLOW' in c['ANOMALY_TYPE']),None)
   if overflow is None:overflow=make_case(self._now(),'CASE_OVERFLOW');state['cases'].append(overflow)
   changed=False
   for field in ('ANOMALY_TYPE','CORRELATED_SIGNALS','LIMITATIONS','MISSING_EVIDENCE','RECOMMENDED_INVESTIGATION'):
    merged=list(dict.fromkeys(overflow[field]+case[field]))[:32];changed=changed or merged!=overflow[field];overflow[field]=merged
   overflow['ACKNOWLEDGED']=False;return changed
  if len(state['fingerprints'])>=1024:
   overflow=next((c for c in state['cases'] if 'CASE_OVERFLOW' in c['ANOMALY_TYPE']),None)
   if overflow and 'IDENTITY_CAPACITY_REACHED' not in overflow['LIMITATIONS']:
    overflow['LIMITATIONS'].append('IDENTITY_CAPACITY_REACHED');overflow['ACKNOWLEDGED']=False;return True
   return False
  if len(state['fingerprints'])<1024:state['fingerprints'][key]=case['CASE_ID']
  if len(state['cases'])>=15:
   acknowledged=next((c for c in state['cases'] if c['ACKNOWLEDGED'] and 'CASE_OVERFLOW' not in c['ANOMALY_TYPE']),None)
   if acknowledged:state['cases'].remove(acknowledged)
   else:
    overflow=next((c for c in state['cases'] if 'CASE_OVERFLOW' in c['ANOMALY_TYPE']),None)
    if overflow:overflow['SAMPLE_COUNT']=min(65535,overflow['SAMPLE_COUNT']+1);overflow['ACKNOWLEDGED']=False
    else:state['cases'].append(make_case(self._now(),'CASE_OVERFLOW',RECOMMENDED_INVESTIGATION=['REVIEW_PRIVATE_EVIDENCE']))
    return True
  state['cases'].append(case);return True
 def _case(self,s,n,anomaly,source=None,target='UNKNOWN',**fields):
  section={'WIN32_PROCESS':'processes','NETTCPIP':'network','PERSISTENCE_SNAPSHOT':'persistence','SECURITY_CONFIG_SNAPSHOT':'security','LOCAL_FILE_HASH':'integrity'}.get(source)
  observed=n['observed'].get(section) or n['at']
  fields.update(BASELINE_ID=s['baselineId'],BASELINE_TRUST=s['baselineTrust'],OBSERVED_AT=observed,UPDATE_CONTEXT=n['updateContext'])
  if source:
   fields['OBSERVATION_SOURCE']=list(dict.fromkeys(fields.get('OBSERVATION_SOURCE',[])+[source]))
   facts=fields.get('FACT_TIMELINE',[])
   if target!='UNKNOWN':
    fact={'AT':observed,'SOURCE':source,'SIGNAL':anomaly,'TARGET':target}
    if fact not in facts:facts.append(fact)
   fields['FACT_TIMELINE']=facts
  return make_case(instant(n['at']) or self._now(),anomaly,**fields)
 def _crossboot(self,s,n,emit):
  # Every image carries the boot of its own complete process/hash/persistence facts.
  # A partial postboot sample or failed inspection cannot overwrite another boot.
  boot=instant(n.get('boot'));process_at=instant(n['observed'].get('processes'));persistence_at=instant(n['observed'].get('persistence'))
  if not boot or n['coverage']['processes']!='OK' or n['coverage']['persistence']!='OK' or not process_at or not persistence_at or min(process_at,persistence_at)<boot:return
  retained={entry['image']:entry for entry in s.get('crossboot',[])}
  baseline=s.get('baseline') or {};baseline_images={p['image'] for p in baseline.get('processes',[])};baseline_persistence={r['id']:r for r in baseline.get('persistence',[])}
  for p in n['processes']:
   if not p['verified'] or not p['freshHash'] or p['hash']=='UNKNOWN' or not p['start'] or instant(p['start'])<boot:continue
   relations=sorted({hashlib.sha256((r['id']+':'+r['digest']).encode()).hexdigest() for r in n['persistence'] if r['image']==p['image']})
   if not relations:continue
   old=retained.get(p['image'])
   new_image=baseline.get('coverage',{}).get('processes')=='OK' and p['image'] not in baseline_images
   changed_persistence=baseline.get('coverage',{}).get('persistence')=='OK' and any(r['image']==p['image'] and (r['id'] not in baseline_persistence or r['digest']!=baseline_persistence[r['id']]['digest']) for r in n['persistence'])
   if (new_image or changed_persistence) and old and old['boot']!=n['boot'] and old['hash']==p['hash'] and set(old['relations'])&set(relations):
    emit('crossboot:'+p['image']+':'+n['boot'],'PERSISTENCE_ACROSS_BOOT','PERSISTENCE_SNAPSHOT',p['image'],IMAGE_IDENTITY=p['image'],BINARY_SHA256=p['hash'],CORRELATED_SIGNALS=['PERSISTENCE_ACROSS_BOOT','SAME_IMAGE_PERSISTENCE'],CONFIDENCE='MULTI_SOURCE_IDENTITY_LINKED',LIMITATIONS=['DISK_IMAGE_NOT_MEMORY'])
   retained.pop(p['image'],None);retained[p['image']]={'image':p['image'],'hash':p['hash'],'boot':n['boot'],'relations':relations}
  while len(retained)>384 or sum(len(entry['relations']) for entry in retained.values())>512:retained.pop(next(iter(retained)))
  s['crossboot']=list(retained.values())
 def _detect(self,s,n,initial):
  changed=False;b=s['baseline'] or n;previous=s.get('previous') or b
  def emit(key,anomaly,source=None,target='UNKNOWN',**fields):
   nonlocal changed
   changed=self._add(s,key,self._case(s,n,anomaly,source,target,**fields)) or changed
  baseline_images={p['image']:p for p in b['processes'] if p['image']!='UNKNOWN'};parents={p['pid']:p for p in n['processes']}
  map_row=next((r for r in n['integrity'] if r.get('isReleaseMap') and r.get('fresh') and r['hash']!='UNKNOWN'),None)
  release_tampered=False
  if map_row and n['coverage']['integrity']=='OK':
   anchor=s.get('releaseMapObservation')
   if anchor and anchor['hash']!=map_row['hash']:
    advancing=bool(n['appVersion']!=anchor['version'] and n['appSequence'] is not None and anchor['sequence'] is not None and n['appSequence']>anchor['sequence'] and n['updateContext']=='LOCAL_RELEASE_MAP_AND_REPORT')
    release_tampered=not advancing
    emit('release-map:'+map_row['hash'],'EXPECTED_APP_UPDATE' if advancing else 'INTEGRITY_MISMATCH','LOCAL_FILE_HASH',map_row['image'],IMAGE_IDENTITY=map_row['image'],BINARY_SHA256=map_row['hash'],BASELINE_DELTA='CONTEXT_ONLY' if advancing else 'MODIFIED',LIMITATIONS=['LOCAL_MAP_NOT_RUNTIME_VERIFICATION'],RECOMMENDED_INVESTIGATION=['VERIFY_RELEASE_FILES'])
    if advancing:s['releaseMapObservation']={'hash':map_row['hash'],'version':n['appVersion'],'sequence':n['appSequence']}
   elif anchor is None:s['releaseMapObservation']={'hash':map_row['hash'],'version':n['appVersion'],'sequence':n['appSequence']}
  is_new=lambda image:not initial and image!='UNKNOWN' and image not in baseline_images and n['coverage']['processes']=='OK' and b['coverage']['processes']=='OK'

  for p in n['processes']:
   image=p['image'];base=baseline_images.get(image);common={'IMAGE_IDENTITY':image,'PROCESS_IDENTITY':p['instance'],'BINARY_SHA256':p['hash'] if p['freshHash'] else 'UNKNOWN','EXECUTABLE_TRUST':p['trust'],'EXECUTABLE_PATH_CLASS':p['pathClass'],'LIMITATIONS':['BASELINE_UNREVIEWED','DISK_IMAGE_NOT_MEMORY','CATALOG_SIGNATURE_NOT_CHECKED','CACHE_ONLY_REVOCATION_UNKNOWN']}
   if not initial and image!='UNKNOWN' and image not in baseline_images and n['coverage']['processes']=='OK' and b['coverage']['processes']=='OK':emit('new:'+image,'NEW_IMAGE','WIN32_PROCESS',image,BASELINE_DELTA='ADDED',**common)
   if base and not initial and p['freshHash'] and base['freshHash'] and p['hash']!='UNKNOWN' and p['hash']!=base['hash']:
    expected=not release_tampered and n['updateContext']=='LOCAL_RELEASE_MAP_AND_REPORT' and p['pathClass']=='APP_CODE' and n['appVersion']!=b['appVersion'] and n['appSequence'] is not None and b['appSequence'] is not None and n['appSequence']>b['appSequence'] and any(r['image']==image and r['hash']==p['hash'] and r['match'] is True for r in n['integrity'])
    emit('hash:'+image+':'+p['hash'],'EXPECTED_APP_UPDATE' if expected else 'IMAGE_HASH_CHANGED','LOCAL_FILE_HASH',image,BASELINE_DELTA='MODIFIED',**common)
   if p['trust'] in {'NO_EMBEDDED_SIGNATURE','INVALID_SIGNATURE','UNTRUSTED_CHAIN'} and p['pathClass'] in {'USER_TEMP','USER_PROFILE'}:emit('risk:'+image,'RISKY_EXECUTABLE','WIN32_PROCESS',image,**common)
   if p['masquerade']:emit('masquerade:'+image,'MASQUERADE_CANDIDATE','WIN32_PROCESS',image,**common)
   parent=parents.get(p['parent'])
   if parent and p['role']=='SHELL' and parent['role']=='BROWSER' and p['verified'] and parent['verified'] and parent['start'] and p['start'] and instant(parent['start'])<=instant(p['start']):emit('parent:'+parent['image']+':'+image,'UNUSUAL_PARENT_CHILD','WIN32_PROCESS',image,CONFIDENCE='MULTI_SOURCE_IDENTITY_LINKED',CORRELATED_SIGNALS=['UNUSUAL_PARENT_CHILD','VERIFIED_PARENT_CHILD'],**common)
  base_peers={(x['image'],x['peer'],x['port']) for x in b['network']};groups={};prior_attempts=set(s.get('flows',[]));attempts=set(prior_attempts)
  for c in n['network']:
   if c['state']=='SynSent' and c['linked'] and c['flow']!='UNKNOWN':attempts.add(c['flow'])
   if c['class'] in {'LOOPBACK','UNSPECIFIED','MULTICAST','UNKNOWN'} or initial or b['coverage']['network']!='OK' or n['coverage']['network']!='OK':continue
   if (c['image'],c['peer'],c['port']) in base_peers:continue
   group=(c['image'] if c['linked'] else 'UNKNOWN',c['class'],c['port']);groups.setdefault(group,[]).append(c)
  for group,connections in groups.items():
   group_id=hashlib.sha256(repr(group).encode()).hexdigest()
   for connection in connections:
    identity=group_id+':'+connection['peer']
    if identity not in s['seen'] and len(s['seen'])<1024:s['seen'].append(identity)
   peer_count=sum(identity.startswith(group_id+':') for identity in s['seen'])
   lost_peer=any(group_id+':'+connection['peer'] not in s['seen'] for connection in connections)
   if lost_peer and not s.get('peerHistoryIncomplete',False):s['peerHistoryIncomplete']=True;changed=True
   peer_count_incomplete=s.get('peerHistoryIncomplete',False)
   if peer_count_incomplete:peer_count='UNKNOWN'
   c=max(connections,key=lambda c:2 if c['state']=='Established' and c['linked'] and c['flow'] in prior_attempts else 1 if c['state']=='SynSent' else 0)
   direction='OUTBOUND_ATTEMPT' if c['state']=='SynSent' else 'OUTBOUND_ATTEMPT_THEN_ESTABLISHED' if c['state']=='Established' and c['linked'] and c['flow'] in prior_attempts else 'NOT_VERIFIED'
   reach='ATTEMPT_ONLY' if c['state']=='SynSent' else 'TCP_ESTABLISHED_AT_SAMPLE' if c['state']=='Established' else 'NOT_VERIFIED'
   matched=next((p for p in n['processes'] if c['linked'] and p['verified'] and p['instance']==c['instance'] and p['image']==c['image']),None)
   signals=['NEW_PEER'];facts=[];sources=['NETTCPIP'];executable={}
   if matched:
    executable={'EXECUTABLE_TRUST':matched['trust'],'EXECUTABLE_PATH_CLASS':matched['pathClass'],'BINARY_SHA256':matched['hash'] if matched['freshHash'] else 'UNKNOWN'}
    sources.append('WIN32_PROCESS')
    if is_new(matched['image']):signals.insert(0,'NEW_IMAGE');facts.append({'AT':n['observed']['processes'],'SOURCE':'WIN32_PROCESS','SIGNAL':'NEW_IMAGE','TARGET':matched['instance']})
   tcp_signal='OUTBOUND_ATTEMPT' if c['state']=='SynSent' else 'TCP_ESTABLISHED' if c['state']=='Established' else None
   if tcp_signal:signals.append(tcp_signal)
   if matched and tcp_signal:facts.append({'AT':n['observed']['network'],'SOURCE':'NETTCPIP','SIGNAL':tcp_signal,'TARGET':matched['instance']})
   emit('peer:'+repr(group),'NEW_PEER','NETTCPIP',c['instance'] if c['linked'] else 'UNKNOWN',IMAGE_IDENTITY=group[0],PROCESS_IDENTITY=c['instance'] if c['linked'] else 'UNKNOWN',NETWORK_DESTINATION_CLASS=c['class'],NEW_PEER_COUNT=peer_count,DESTINATION_PORT=c['port'],CONNECTION_STATE=c['state'],CONNECTION_DIRECTION=direction,REACHABILITY=reach,PROCESS_NETWORK_CORRELATION=c['correlation'],CONFIDENCE='MULTI_SOURCE_IDENTITY_LINKED' if c['linked'] else 'IDENTITY_UNVERIFIED',LIMITATIONS=['TCP_CONTENT_UNKNOWN','SHORT_AND_UDP_TRAFFIC_MAY_BE_MISSED','NO_ROLE_ATTRIBUTION']+([] if direction!='NOT_VERIFIED' else ['DIRECTION_UNKNOWN'])+(['IDENTITY_CAPACITY_REACHED'] if peer_count_incomplete else []),MISSING_EVIDENCE=[] if c['linked'] else ['VERIFIED_PROCESS_INSTANCE'],CORRELATED_SIGNALS=signals,OBSERVATION_SOURCE=sources,FACT_TIMELINE=facts,**executable)
   if c['port'] not in {53,80,123,443,853} and not any(x['image']==group[0] and x['port']==c['port'] for x in b['network']):emit('port:'+repr(group),'UNUSUAL_PORT','NETTCPIP',DESTINATION_PORT=c['port'],NETWORK_DESTINATION_CLASS=c['class'])
  s['flows']=list(dict.fromkeys(c['flow'] for c in n['network'] if c['linked'] and c['flow']!='UNKNOWN' and (c['state']=='SynSent' or c['flow'] in attempts)))[:512]
  # Sustained surge requires two samples, while normal fluctuations remain quiet.
  base_count=len(b['network']);surge=len(n['network'])>=max(20,base_count*3+10) and n['coverage']['network']=='OK'
  streak=min(2,s.get('surgeStreak',0)+1) if surge else 0;s['surgeStreak']=streak
  if streak==2:emit('surge','CONNECTION_SURGE','NETTCPIP')
  for section,anomaly,source,field in [('persistence','PERSISTENCE_CHANGED','PERSISTENCE_SNAPSHOT','PERSISTENCE_CHANGE'),('security','SECURITY_CONFIG_CHANGED','SECURITY_CONFIG_SNAPSHOT','SECURITY_CONFIG_CHANGE')]:
   if initial or n['coverage'][section]!='OK' or previous['coverage'][section]!='OK':continue
   old={x['id']:x for x in previous[section]};current={x['id']:x for x in n[section]}
   for identity in old.keys()|current.keys():
    before=old.get(identity);after=current.get(identity);change='ADDED' if before is None else 'REMOVED' if after is None else 'MODIFIED' if before['digest']!=after['digest'] else None
    if not change:continue
    row=after or before;image=row['image'];linked=section=='persistence' and image!='UNKNOWN' and any(p['image']==image and p['verified'] for p in n['processes']);extra={field:[change],'BASELINE_DELTA':change,'IMAGE_IDENTITY':image if linked else 'UNKNOWN','CONFIDENCE':'MULTI_SOURCE_IDENTITY_LINKED' if linked else 'OBSERVED_FACTS_ONLY','LIMITATIONS':['ACTOR_UNKNOWN','TIME_WINDOW_ONLY'] if section=='security' else [] if linked else ['OPAQUE_PERSISTENCE_TARGET'],'MISSING_EVIDENCE':['ACTOR_IDENTITY'] if section=='security' else [] if linked else ['PERSISTENCE_TARGET']}
    if linked:
     extra['CORRELATED_SIGNALS']=['PERSISTENCE_CHANGED','SAME_IMAGE_PERSISTENCE']
     p=next(p for p in n['processes'] if p['image']==image and p['verified'])
     extra.update(PROCESS_IDENTITY=p['instance'],EXECUTABLE_TRUST=p['trust'],EXECUTABLE_PATH_CLASS=p['pathClass'],BINARY_SHA256=p['hash'] if p['freshHash'] else 'UNKNOWN')
     if is_new(image):extra['CORRELATED_SIGNALS'].append('NEW_IMAGE');extra['OBSERVATION_SOURCE']=['WIN32_PROCESS'];extra['FACT_TIMELINE']=[{'AT':n['observed']['processes'],'SOURCE':'WIN32_PROCESS','SIGNAL':'NEW_IMAGE','TARGET':p['instance']}]

    emit(section+':'+identity+':'+change+':'+row['digest'],anomaly,source,image if linked else 'UNKNOWN',**extra)
  self._crossboot(s,n,emit)
  for r in n['integrity']:
   if r['match'] is False:emit('file:'+r['image']+':'+r['hash'],'INTEGRITY_MISMATCH','LOCAL_FILE_HASH',r['image'],IMAGE_IDENTITY=r['image'],BINARY_SHA256=r['hash'],RECOMMENDED_INVESTIGATION=['VERIFY_RELEASE_FILES'])
  if not initial and n['osVersion']!='UNKNOWN' and b['osVersion']!='UNKNOWN' and (n['osVersion'],n['osBuild'])!=(b['osVersion'],b['osBuild']):emit('os:'+n['osVersion']+':'+n['osBuild'],'OS_VERSION_CHANGED',BASELINE_DELTA='CONTEXT_ONLY')
  return changed
 def _fit_budget(self,s,now):
  # Bound the complete sealed envelope before any evidence/state write. Baseline
  # and pending case history are immutable here; trim only latest comparison rows.
  truncated=False
  for section in ('security','persistence'):
   while len(self.store._serialize(s))>MAX_STATE_BYTES and s.get('previous',{}).get(section):
    rows=s['previous'][section];s['previous'][section]=rows[:len(rows)//2]
    s['previous']['coverage'][section]='PARTIAL';s['coverage'][section]='PARTIAL';s['monitorState']='DEGRADED';truncated=True
  changed=False
  if truncated:
   changed=self._source_health(s,'BEHAVIOR_COVERAGE_PARTIAL',now,['TRUNCATED','SOURCE_PARTIAL'])
   # At full capacity keep telemetry separate, while the existing overflow still
   # explains that comparison rows were trimmed; never convert it to health.
   overflow=next((c for c in s['cases'] if 'CASE_OVERFLOW' in c['ANOMALY_TYPE']),None)
   if overflow is not None:overflow['LIMITATIONS']=list(dict.fromkeys(overflow['LIMITATIONS']+['TRUNCATED','SOURCE_PARTIAL']))[:32]
  # Adding the warning also consumes bytes; reserve it before the final bound.
  for section in ('security','persistence'):
   while len(self.store._serialize(s))>MAX_STATE_BYTES and s.get('previous',{}).get(section):
    rows=s['previous'][section];s['previous'][section]=rows[:len(rows)//2];s['previous']['coverage'][section]='PARTIAL';s['coverage'][section]='PARTIAL';s['monitorState']='DEGRADED'
  if len(self.store._serialize(s))>MAX_STATE_BYTES:raise ValueError('state budget exhausted')
  return changed
 def _collect(self,full):
  try:
   raw=self.source.collect(full=full);now=self._now();normalized=normalize_snapshot(raw,self.store.key,now)
   reason=safe_reason(raw.get('healthReason','NONE'))
   if reason not in {'NONE','BEHAVIOR_QUERY_TIMEOUT','BEHAVIOR_SOURCE_ACCESS_DENIED','BEHAVIOR_SOURCE_UNAVAILABLE','BEHAVIOR_INVALID_SNAPSHOT'}:reason='BEHAVIOR_INVALID_SNAPSHOT'
   if reason=='NONE':
    if not normalized['fresh']:reason='BEHAVIOR_DATA_STALE'
    elif 'SOURCE_ACCESS_DENIED' in normalized['limitations']:reason='BEHAVIOR_SOURCE_ACCESS_DENIED'
    elif all(c=='UNAVAILABLE' for c in normalized['coverage'].values()):reason='BEHAVIOR_SOURCE_UNAVAILABLE'
    elif not all(c=='OK' for c in normalized['coverage'].values()):reason='BEHAVIOR_COVERAGE_PARTIAL'
   return raw,normalized,reason,now
  except (TimeoutError,):return None,None,'BEHAVIOR_QUERY_TIMEOUT',self._now()
  except PermissionError:return None,None,'BEHAVIOR_SOURCE_ACCESS_DENIED',self._now()
  except OSError:return None,None,'BEHAVIOR_SOURCE_UNAVAILABLE',self._now()
  except Exception:return None,None,'BEHAVIOR_INVALID_SNAPSHOT',self._now()
 def poll_once(self):
  if not self._poll_lock.acquire(blocking=False):return
  try:
   self._poll_started=time.monotonic()
   now=self._now();full=self._last_full is None or (now-self._last_full).total_seconds()>=self.full_interval_seconds
   raw,normalized,reason,now=self._collect(full);retries=0;recovery_reason=None
   if reason in {'BEHAVIOR_QUERY_TIMEOUT','BEHAVIOR_SOURCE_UNAVAILABLE','BEHAVIOR_INVALID_SNAPSHOT'} and not self._stop.is_set():
    recovery_reason=reason;retries=1;raw,normalized,reason,now=self._collect(full)
   # A failed full observation must retry slow sections on the next existing cycle.
   if full and reason=='NONE':self._last_full=now
   with self._lock:s=copy.deepcopy(self._pending or self._state)
   changed=False;s['lastCheckedAt']=now.isoformat();s['monitorState']='OK'
   if self.store.locked:s['monitorState']='DEGRADED';s['baselineTrust']='INTEGRITY_FAILED'
   elif normalized is None:
    s['monitorState']='DEGRADED';s['coverage']={k:'UNAVAILABLE' for k in SECTIONS};changed=self._source_health(s,reason,now,['INVALID_SNAPSHOT'])
   else:
    n=normalized;s.update(coverage=n['coverage'],sectionObservedAt=n['observed'],osVersion=n['osVersion'],appVersion=n['appVersion']);initial=s['baseline'] is None
    complete=all(c=='OK' for c in n['coverage'].values()) and n['fresh']
    if not complete:
     s['monitorState']='DEGRADED';changed=self._source_health(s,reason,now,n['limitations']+['SOURCE_PARTIAL']) or changed
    quality_complete=complete and all(p['verified'] and p['freshHash'] and p['hash']!='UNKNOWN' and p['trust']!='UNKNOWN' and p['pathClass']!='UNKNOWN' for p in n['processes']) and all(c['linked'] and c['flow']!='UNKNOWN' for c in n['network']) and all(r.get('fresh') and (r.get('isReleaseMap') or r['match'] is not None) for r in n['integrity'])
    if initial and n['fresh'] and any(c=='OK' for c in n['coverage'].values()):
     s.update(baseline=_baseline(n),baselineId=str(uuid.uuid4()),baselineTrust='OBSERVED_UNREVIEWED',baselineQuality='COMPLETE_UNREVIEWED' if quality_complete else 'PARTIAL_UNREVIEWED');changed=True
     self._add(s,'baseline',self._case(s,n,'BASELINE_REVIEW',BASELINE_DELTA='INITIAL_OBSERVATION',MISSING_EVIDENCE=['BASELINE_REVIEW'],RECOMMENDED_INVESTIGATION=['REVIEW_BASELINE']))
    changed=self._detect(s,n,initial) or changed
    # Keep last complete sections across partial or intentionally skipped polls.
    prev=copy.deepcopy(s.get('previous') or _previous(n))
    for section in ('persistence','security'):
     if n['coverage'][section]=='OK':prev[section]=copy.deepcopy(n[section]);prev['coverage'][section]='OK';prev['observed'][section]=n['observed'][section]
    s['previous']=prev;s['stableObservations']=min(65535,s['stableObservations']+1) if not changed and complete else 0
   if self.store.locked:reason='BEHAVIOR_STATE_INTEGRITY_FAILED'
   elif s['baseline'] is None and reason=='NONE':reason='BEHAVIOR_BASELINE_UNAVAILABLE'
   if not self.store.locked:
    try:changed=self._fit_budget(s,now) or changed
    except ValueError:pass # The guarded save exposes an unsaved WARNING without advancing baseline.
   if reason=='NONE' and s['monitorState']=='DEGRADED':reason='BEHAVIOR_COVERAGE_PARTIAL'
   if reason=='NONE':changed=self._source_health(s,'NONE',now) or changed
   self._health(s,reason,now,retries,recovery_reason)
   changed=changed or s['monitorState']!=self._state['monitorState'] or s['coverage']!=self._state['coverage']
   due=self._last_write is None or (now-self._last_write).total_seconds()>=1800
   if not self.store.locked and (changed or due or self._unsaved):
    try:
     # Raw evidence is bounded and written only for meaningful changes, never PID jitter.
     if changed and raw is not None:self.store.evidence(raw)
     self.store.save(s);self._durable=copy.deepcopy(s);self._last_write=now;self._unsaved=False;self._pending=None
    except Exception:
     # Preserve durable baseline/history, but expose new unsaved evidence immediately.
     self._pending=copy.deepcopy(s)
     visible=copy.deepcopy(self._state);visible.update(lastCheckedAt=s['lastCheckedAt'],coverage=s['coverage'],sectionObservedAt=s['sectionObservedAt'],monitorState='DEGRADED')
     for case in s['cases']:
      c=copy.deepcopy(case);existing=next((item for item in visible['cases'] if item['CASE_ID']==c['CASE_ID']),None)
      durable=next((item for item in self._durable['cases'] if item['CASE_ID']==c['CASE_ID']),None)
      if durable!=case:c['MISSING_EVIDENCE']=list(dict.fromkeys(c['MISSING_EVIDENCE']+['EVIDENCE_NOT_SAVED','ORIGINAL_RAW_EVIDENCE']))
      if existing:existing.update(c)
      else:self._add(visible,'unsaved:'+c['CASE_ID'],c)
     self._health(visible,'BEHAVIOR_STATE_WRITE_FAILED',now,retries);self._add(visible,'write-failed',make_case(now,'STATE_WRITE_FAILED',MISSING_EVIDENCE=['EVIDENCE_NOT_SAVED'],LIMITATIONS=['EVIDENCE_NOT_SAVED'],RECOMMENDED_INVESTIGATION=['CHECK_MONITOR_HEALTH']));s=visible;self._unsaved=True
   with self._lock:
    self._state=s
    if reason=='NONE':self._worker_restart_used=False
  finally:self._poll_started=None;self._poll_lock.release()
 def snapshot(self):
  with self._lock:
   s=self._state;cases=[public_behavior_case(c) for c in s['cases']];b=s['baseline'];metadata={k:copy.deepcopy(s[k]) for k in ('monitorState','lastCheckedAt','baselineId','baselineTrust','osVersion','appVersion','coverage','sectionObservedAt','stableObservations','baselineQuality')};metadata.update(baselineObservedAt=b['at'] if b else None,limits=copy.deepcopy(LIMITS))
   return {'schemaVersion':1,'mode':'MONITOR_ONLY','autoIsolationEnabled':False,'wifiState':'UNKNOWN','monitorState':s['monitorState'],'lastCheckedAt':s['lastCheckedAt'],'cases':cases,'unacknowledgedCount':sum(not c['ACKNOWLEDGED'] and not recovered_behavior_health(c) for c in cases),'behavior':metadata,'behaviorHealth':public_monitor_health(dict(s.get('behaviorHealth',{}),workerAlive=bool(self._thread and self._thread.is_alive())))}
 def acknowledge(self,case_id):
  # Serialize against collection/commit without holding the snapshot state lock on I/O.
  if not self._poll_lock.acquire(blocking=False):return False
  try:
   with self._lock:
    if self._unsaved or self.store.locked:return False
    s=copy.deepcopy(self._state);case=next((c for c in s['cases'] if c['CASE_ID']==case_id),None)
    if not case or not any(c['CASE_ID']==case_id for c in self._durable['cases']):return False
    case['ACKNOWLEDGED']=True
   try:self.store.save(s)
   except Exception:
    with self._lock:
     self._unsaved=True;self._state['monitorState']='DEGRADED';self._add(self._state,'write-failed',make_case(self._now(),'STATE_WRITE_FAILED',MISSING_EVIDENCE=['EVIDENCE_NOT_SAVED']))
    return False
   with self._lock:self._state=s;self._durable=copy.deepcopy(s)
   return True
  finally:self._poll_lock.release()
