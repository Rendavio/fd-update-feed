import {projectBehaviorCase,projectBehaviorMetadata,buildBehaviorPages,isPureBehaviorTelemetryCase} from './behavior-alerts.js';
/** Positive public projection plus a monitor-only, offline-readable alert surface. */
const UNKNOWN = 'UNKNOWN';
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
const ISO = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?(?:Z|[+-]\d{2}:\d{2})$/;
const WIFI = ['ON', 'OFF', UNKNOWN, 'NOT_AVAILABLE'];
const RESULTS = ['SUCCEEDED', 'FAILED', 'NOT_REMEDIATED', UNKNOWN];
const REASONS = ['THREAT_DETECTED','REMEDIATION_REPORTED','REMEDIATION_ERROR','CRITICAL_REMEDIATION_CONFIRMED','PROTECTION_DISABLED','PROTECTION_DISABLED_ACTIVE_SEVERE','CONFIGURATION_CHANGED','ENGINE_ERROR','MONITOR_UNAVAILABLE','PROTECTION_UNHEALTHY','PROTECTION_UNKNOWN','SOURCE_PARTIAL','STATE_CORRUPT','STATE_WRITE_FAILED','LOG_RESET','INVALID_SNAPSHOT','CASE_OVERFLOW'];
export const MONITOR_REASONS = Object.freeze(['NONE','UNKNOWN','MONITOR_WORKER_NOT_RUNNING','DEFENDER_STATUS_QUERY_TIMEOUT','DEFENDER_STATUS_QUERY_FAILED','DEFENDER_SERVICE_QUERY_FAILED','DEFENDER_SERVICE_STOPPED','REALTIME_PROTECTION_OFF','DEFENDER_EVENT_LOG_UNAVAILABLE','DEFENDER_EVENT_LOG_DISABLED','DEFENDER_EVENT_LOG_ACCESS_DENIED','EVENT_LOG_RESET_OR_ROLLOVER','CHECKPOINT_INVALID','POLL_TIMEOUT','INVALID_SNAPSHOT','SOURCE_PARTIAL','STATE_WRITE_FAILED','BEHAVIOR_QUERY_TIMEOUT','BEHAVIOR_SOURCE_ACCESS_DENIED','BEHAVIOR_SOURCE_UNAVAILABLE','BEHAVIOR_INVALID_SNAPSHOT','BEHAVIOR_COVERAGE_PARTIAL','BEHAVIOR_DATA_STALE','BEHAVIOR_WORKER_NOT_RUNNING','BEHAVIOR_STATE_WRITE_FAILED','BEHAVIOR_STATE_INTEGRITY_FAILED','BEHAVIOR_BASELINE_UNAVAILABLE','BEHAVIOR_INITIALIZATION_FAILED','BEHAVIOR_START_FAILED','BEHAVIOR_POLL_TIMEOUT','BEHAVIOR_PROTECTION_OFF','IOAV_PROTECTION_OFF','NETWORK_INSPECTION_OFF','ANTIVIRUS_PROTECTION_OFF','ANTIMALWARE_SERVICE_OFF']);
const SOURCE_STATES = ['OK','DEGRADED','STARTING','NOT_AVAILABLE'];
const MISSING = ['MATCHING_DETECTION','MATCHING_ACTIVE_THREAT','EXPLICIT_SEVERITY','ACTION_SUCCESS','PROTECTION_STATE','EVENT_TIME','THREAT_ID','DETECTION_ID','CURRENT_EVIDENCE','MONITOR_SOURCE','EVIDENCE_NOT_SAVED','ORIGINAL_RAW_EVIDENCE'];
const PROTECTION = ['SERVICE_STATUS','REAL_TIME_PROTECTION','ANTIMALWARE_SERVICE','ANTIVIRUS','BEHAVIOR_MONITOR','IOAV_PROTECTION','NETWORK_INSPECTION'];
const TAXONOMY = /^(?:Trojan|Virus|Worm|Backdoor|Exploit|Behavior|PUA|PWS|Ransom|HackTool|Adware|Spyware|SoftwareBundler|BrowserModifier|DDoS|DoS|TrojanDownloader|TrojanDropper|TrojanSpy|TrojanClicker|MonitoringTool|RemoteAccess|SettingsModifier|Vulnerability|VirTool):[A-Za-z0-9]{1,20}\/[A-Za-z0-9][A-Za-z0-9.!_-]{0,80}$/;
const object = v => v !== null && typeof v === 'object' && !Array.isArray(v);
const enumValue = (v, allowed) => typeof v === 'string' && allowed.includes(v) ? v : UNKNOWN;
const timestamp = v => typeof v === 'string' && ISO.test(v) && Number.isFinite(Date.parse(v)) ? v : UNKNOWN;
function integer(v) {
  if (typeof v === 'number') return Number.isSafeInteger(v) && v >= 0 ? v : UNKNOWN;
  if (typeof v === 'string' && /^[0-9]{1,19}$/.test(v) && BigInt(v) <= 9223372036854775807n) return v;
  return UNKNOWN;
}
const optionalTime = value => timestamp(value) === UNKNOWN ? null : value;
const HEALTH_REASONS = ['MONITOR_UNAVAILABLE','PROTECTION_UNHEALTHY','PROTECTION_UNKNOWN','SOURCE_PARTIAL','STATE_CORRUPT','STATE_WRITE_FAILED','LOG_RESET','INVALID_SNAPSHOT'];
const noThreatEvidence = c => !c.RESOURCE_HASHES?.length && [c.THREAT_ID,c.THREAT_NAME,c.THREAT_CATEGORY,c.DEFENDER_SEVERITY,c.DETECTION_SOURCE,c.DETECTION_METHOD,c.ACTION_ATTEMPTED,c.ACTION_RESULT].every(v => v === undefined || v === UNKNOWN) && !(c.RELATED_EVENTS || []).some(e => ['1116','1117','1118','1119','5001','5008'].includes(String(e.EVENT_ID)));
const isMonitorCase = c => {
  if (!object(c) || c.EVENT_SOURCE !== 'SECURITY_MONITOR' || c.ALERT_LEVEL !== 'WARNING' || c.MONITOR_HEALTH_ONLY === false || !Array.isArray(c.REASON_CODES) || !c.REASON_CODES.length || c.REASON_CODES.some(code => !HEALTH_REASONS.includes(code))) return false;
  for (const key of ['EVENT_ID','RECORD_ID','THREAT_ID','THREAT_NAME','THREAT_CATEGORY','DEFENDER_SEVERITY','DETECTION_SOURCE','DETECTION_METHOD','ACTION_ATTEMPTED','ACTION_RESULT']) if (c[key] !== undefined && c[key] !== UNKNOWN) return false;
  for (const key of ['RELATED_EVENTS','RESOURCE_TYPES','RESOURCE_HASHES']) if (c[key] !== undefined && (!Array.isArray(c[key]) || c[key].length)) return false;
  if (c.RESOURCE_CLASS !== undefined && (!Array.isArray(c.RESOURCE_CLASS) || c.RESOURCE_CLASS.length > 1 || c.RESOURCE_CLASS.some(v => v !== UNKNOWN))) return false;
  return c.ISOLATION_RESULT === undefined || c.ISOLATION_RESULT === 'DISABLED';
};
const isBehaviorHealthCase = c => isPureBehaviorTelemetryCase(c);
const recoveredMonitor = c => (isMonitorCase(c) || isBehaviorHealthCase(c)) && c.MONITOR_INCIDENT_STATUS === 'RECOVERED';
const supersededConfiguration = c => c?.EVENT_SOURCE === 'MICROSOFT_DEFENDER' && c.ALERT_LEVEL === 'WARNING' && c.EVENT_ID === 5007 && c.CONFIGURATION_STATUS === 'SUPERSEDED_CONFIGURATION_CHANGE' && c.CONFIGURATION_CLASSIFICATION === 'CONFIGURATION_CHANGE_ONLY' && ['AV_SIGNATURE_VERSION','AS_SIGNATURE_VERSION','ENGINE_VERSION'].includes(c.CONFIGURATION_SETTING) && c.CONFIGURATION_CLASSIFIER_VERSION === 1 && timestamp(c.CONFIGURATION_REVIEWED_AT) !== UNKNOWN && timestamp(c.CONFIGURATION_LAST_SEEN_AT) !== UNKNOWN && Date.parse(c.DETECTED_AT) <= Date.parse(c.CONFIGURATION_LAST_SEEN_AT) && Date.parse(c.CONFIGURATION_LAST_SEEN_AT) <= Date.parse(c.CONFIGURATION_REVIEWED_AT) && Number.isSafeInteger(c.CONFIGURATION_SAMPLE_COUNT) && c.CONFIGURATION_SAMPLE_COUNT >= 1 && c.HUMAN_REVIEW_REQUIRED === false && c.REASON_CODES.length === 1 && c.REASON_CODES[0] === 'CONFIGURATION_CHANGED' && noThreatEvidence(c) && c.ERROR_CODE === UNKNOWN && c.RESOURCE_CLASS.every(v => v === UNKNOWN) && !c.RESOURCE_TYPES.length && c.RELATED_EVENTS.every(e => e.EVENT_ID === 5007) && c.ISOLATION_RESULT === 'DISABLED' && !c.MISSING_EVIDENCE.some(v => ['EVIDENCE_NOT_SAVED','ORIGINAL_RAW_EVIDENCE'].includes(v));
const pendingCase = c => !c.ACKNOWLEDGED && !recoveredMonitor(c) && !supersededConfiguration(c);
const pendingSecurityCase = c => pendingCase(c) && !isMonitorCase(c) && !isBehaviorHealthCase(c);
export function projectMonitorHealth(raw) {
  if (!object(raw)) return null;
  const result = {
    status: enumValue(raw.status, ['MONITOR_OK','MONITOR_UNAVAILABLE','STARTING']),
    reason: enumValue(raw.reason, MONITOR_REASONS), lastReason: enumValue(raw.lastReason, MONITOR_REASONS),
    lastSuccessfulPollAt: optionalTime(raw.lastSuccessfulPollAt), lastAttemptAt: optionalTime(raw.lastAttemptAt), workerAlive: raw.workerAlive === true,
    retryCount: raw.retryCount === 1 ? 1 : 0,
    lastRecovery: raw.lastRecovery === 'AUTOMATIC' ? 'AUTOMATIC' : 'NONE',
    lastRecoveryAt: optionalTime(raw.lastRecoveryAt),
    recoveryResult: enumValue(raw.recoveryResult, ['NONE','RECOVERED_AUTOMATICALLY','STILL_UNAVAILABLE']),
  };
  if (result.status === UNKNOWN) result.status = 'MONITOR_UNAVAILABLE';
  if (result.recoveryResult === UNKNOWN) result.recoveryResult = 'NONE';
  for (const key of ['serviceRunning','realtimeProtection','behaviorMonitoring','antimalwareService','antivirus','ioavProtection','networkInspection','eventLogExists','eventLogEnabled','eventLogReadable']) result[key] = typeof raw[key] === 'boolean' ? raw[key] : null;
  for (const key of ['oldestRecordId','newestRecordId','checkpoint']) result[key] = Number.isSafeInteger(raw[key]) && raw[key] >= 0 ? raw[key] : null;
  return result;
}
const monitorTime = s => s.monitorHealth ? s.monitorHealth.lastSuccessfulPollAt : s.sourceCheckedAt?.defender ?? s.lastCheckedAt;
function sourceWarnings(s, nowMs = Date.now()) {
  const warnings = [];
  const h = s.monitorHealth;
  if (h ? h.status === 'MONITOR_UNAVAILABLE' : (s.sourceStates?.defender ?? s.monitorState) !== 'OK') warnings.push('MONITOR_UNAVAILABLE');
  if (h?.status === 'STARTING') warnings.push('MONITOR_STARTING');
  const behavior = s.behaviorHealth;
  if (behavior) {
    if (behavior.status === 'MONITOR_UNAVAILABLE') warnings.push('BEHAVIOR_TELEMETRY_UNAVAILABLE');
    else if (behavior.status === 'STARTING') warnings.push('BEHAVIOR_TELEMETRY_STARTING');
    if (behavior.status !== 'STARTING' && behavior.lastSuccessfulPollAt && nowMs - Date.parse(behavior.lastSuccessfulPollAt) > 300000) warnings.push('BEHAVIOR_TELEMETRY_STALE');
  } else if (s.sourceStates) {
    const state = s.sourceStates.behavior;
    if (state !== 'OK' && state !== 'STARTING') warnings.push('BEHAVIOR_TELEMETRY_UNAVAILABLE');
    else if (state === 'STARTING') warnings.push('BEHAVIOR_TELEMETRY_STARTING');
    if (s.sourceCheckedAt && state !== 'STARTING') {
      const time = s.sourceCheckedAt.behavior;
      if (!time) warnings.push('BEHAVIOR_TELEMETRY_UNAVAILABLE');
      else if (Date.parse(time) > nowMs) warnings.push('BEHAVIOR_TELEMETRY_CLOCK_SKEW');
      else if (nowMs - Date.parse(time) > 300000) warnings.push('BEHAVIOR_TELEMETRY_STALE');
    }
  }
  if (s.currentProtection?.BEHAVIOR_MONITOR === 'OFF' || h?.behaviorMonitoring === false) warnings.push('BEHAVIOR_PROTECTION_OFF');
  return warnings;
}
function errorCode(v) {
  if (typeof v === 'number') return Number.isSafeInteger(v) && v >= -2147483648 ? v : UNKNOWN;
  return typeof v === 'string' && /^(?:0[xX][0-9A-Fa-f]{1,16}|-?[0-9]{1,20})$/.test(v) ? v : UNKNOWN;
}
const qualified = (v, source, allowed = []) => enumValue(v, allowed) !== UNKNOWN ? v : typeof v === 'string' && v.startsWith(`${source}:`) && integer(v.slice(source.length + 1)) !== UNKNOWN ? v : UNKNOWN;
const list = (v, allowed, limit = 32) => Array.isArray(v) ? v.slice(0, limit).filter(item => typeof item === 'string' && allowed.includes(item)) : [];
function projectCase(raw) {
  if (!object(raw)) throw new TypeError('Invalid security case');
  if(raw.EVENT_SOURCE==='BEHAVIOR_MONITOR')return projectBehaviorCase(raw);
  const c = {
    CASE_ID: typeof raw.CASE_ID === 'string' && UUID.test(raw.CASE_ID) ? raw.CASE_ID : UNKNOWN,
    DETECTED_AT: timestamp(raw.DETECTED_AT),
    ALERT_LEVEL: enumValue(raw.ALERT_LEVEL, ['WARNING','CRITICAL']),
    EVENT_SOURCE: enumValue(raw.EVENT_SOURCE, ['MICROSOFT_DEFENDER','SECURITY_MONITOR']),
    EVENT_ID: integer(raw.EVENT_ID), RECORD_ID: integer(raw.RECORD_ID), THREAT_ID: integer(raw.THREAT_ID),
    THREAT_NAME: typeof raw.THREAT_NAME === 'string' && TAXONOMY.test(raw.THREAT_NAME) && !/(?:\d{1,3}\.){3}\d{1,3}/.test(raw.THREAT_NAME) ? raw.THREAT_NAME : UNKNOWN,
    THREAT_CATEGORY: qualified(raw.THREAT_CATEGORY, 'CIM.CategoryID'),
    DEFENDER_SEVERITY: qualified(raw.DEFENDER_SEVERITY, 'CIM.SeverityID', ['LOW','MODERATE','HIGH','SEVERE']),
    DETECTION_SOURCE: qualified(raw.DETECTION_SOURCE, 'CIM.DetectionSourceTypeID'),
    DETECTION_METHOD: qualified(raw.DETECTION_METHOD, 'CIM.DetectionTypeID'),
    ACTION_ATTEMPTED: qualified(raw.ACTION_ATTEMPTED, 'CIM.CleaningActionID', ['QUARANTINE','REMOVE','CLEAN','BLOCK','ALLOW','NONE']),
    ACTION_RESULT: enumValue(raw.ACTION_RESULT, RESULTS), ERROR_CODE: errorCode(raw.ERROR_CODE),
    DEFENDER_PROTECTION_STATE: {},
    SIGNATURE_VERSION: typeof raw.SIGNATURE_VERSION === 'string' && raw.SIGNATURE_VERSION.length <= 64 && /^[0-9]+(?:\.[0-9]+){1,5}$/.test(raw.SIGNATURE_VERSION) ? raw.SIGNATURE_VERSION : UNKNOWN,
    SIGNATURE_AGE: Number.isSafeInteger(raw.SIGNATURE_AGE) && raw.SIGNATURE_AGE >= 0 && raw.SIGNATURE_AGE <= 315576000 ? raw.SIGNATURE_AGE : UNKNOWN,
    RELATED_EVENTS: [], WIFI_STATE: enumValue(raw.WIFI_STATE, WIFI),
    ISOLATION_RESULT: enumValue(raw.ISOLATION_RESULT, ['DISABLED','PREPARED','OFF_VERIFIED','ISOLATION_FAILED',UNKNOWN]),
    HUMAN_REVIEW_REQUIRED: typeof raw.HUMAN_REVIEW_REQUIRED === 'boolean' ? raw.HUMAN_REVIEW_REQUIRED : UNKNOWN,
    ACKNOWLEDGED: raw.ACKNOWLEDGED === true,
    REASON_CODES: list(raw.REASON_CODES, REASONS), MISSING_EVIDENCE: list(raw.MISSING_EVIDENCE, MISSING),
    RESOURCE_CLASS: list(raw.RESOURCE_CLASS, ['FILE','REGISTRY','PROCESS','WEB',UNKNOWN], 16),
    RESOURCE_TYPES: list(raw.RESOURCE_TYPES, ['.exe','.dll','.ps1','.bat','.cmd','.js','.vbs','.scr','.msi','.zip','.rar','.7z','.pdf','.doc','.docx','.xls','.xlsx','.txt','.png','.jpg','.jpeg'], 16),
    RESOURCE_HASHES: Array.isArray(raw.RESOURCE_HASHES) ? raw.RESOURCE_HASHES.slice(0, 8).filter(v => typeof v === 'string' && /^(?:[a-f0-9]{32}|[a-f0-9]{40}|[a-f0-9]{64})$/.test(v)) : [],
  };
  for (const key of PROTECTION) c.DEFENDER_PROTECTION_STATE[key] = enumValue(object(raw.DEFENDER_PROTECTION_STATE) ? raw.DEFENDER_PROTECTION_STATE[key] : null, key === 'SERVICE_STATUS' ? ['RUNNING','STOPPED',UNKNOWN] : ['ON','OFF',UNKNOWN]);
  for (const event of Array.isArray(raw.RELATED_EVENTS) ? raw.RELATED_EVENTS.slice(0, 16) : []) {
    if (object(event)) c.RELATED_EVENTS.push({ EVENT_ID: integer(event.EVENT_ID), RECORD_ID: integer(event.RECORD_ID), AT: timestamp(event.AT), ACTION_RESULT: enumValue(event.ACTION_RESULT, RESULTS) });
  }
  if ('ISOLATION_ERROR_CODE' in raw) c.ISOLATION_ERROR_CODE = enumValue(raw.ISOLATION_ERROR_CODE, ['NONE','RADIO_UNAVAILABLE','INVALID_RADIO_STATE','EVIDENCE_NOT_SAVED','EVIDENCE_WRITE_FAILED']) !== UNKNOWN ? raw.ISOLATION_ERROR_CODE : errorCode(raw.ISOLATION_ERROR_CODE);
  if ('OVERFLOW_COUNT' in raw) c.OVERFLOW_COUNT = integer(raw.OVERFLOW_COUNT);
  if (Array.isArray(raw.REASON_CODES) && raw.REASON_CODES.some(v => !REASONS.includes(v))) c.REASON_CODES.push(UNKNOWN);
  if (String(c.EVENT_ID) === '5007') {
    for (const [key, values] of Object.entries({CONFIGURATION_CLASSIFICATION:['CONFIGURATION_CHANGE_ONLY','SECURITY_SENSITIVE','THREAT_CORRELATED','INSUFFICIENT_EVIDENCE'],CONFIGURATION_SETTING:['AV_SIGNATURE_VERSION','AS_SIGNATURE_VERSION','ENGINE_VERSION','SECURITY_POLICY',UNKNOWN],CONFIGURATION_STATUS:['REVIEW_REQUIRED','SUPERSEDED_CONFIGURATION_CHANGE']})) c[key] = enumValue(raw[key],values);
    c.CONFIGURATION_SAMPLE_COUNT = Number.isSafeInteger(raw.CONFIGURATION_SAMPLE_COUNT) && raw.CONFIGURATION_SAMPLE_COUNT >= 0 ? raw.CONFIGURATION_SAMPLE_COUNT : null;
    c.CONFIGURATION_LAST_SEEN_AT = optionalTime(raw.CONFIGURATION_LAST_SEEN_AT);
    c.CONFIGURATION_REVIEWED_AT = optionalTime(raw.CONFIGURATION_REVIEWED_AT);
    c.CONFIGURATION_CLASSIFIER_VERSION = raw.CONFIGURATION_CLASSIFIER_VERSION === 1 ? 1 : null;
  }
  if (c.EVENT_SOURCE === 'SECURITY_MONITOR') {
    if (raw.ISOLATION_RESULT === undefined) c.ISOLATION_RESULT = 'DISABLED';
    c.MONITOR_HEALTH_ONLY = isMonitorCase(raw) && isMonitorCase(c);
  }
  if (isMonitorCase(c)) {
    c.MONITOR_REASON = enumValue(raw.MONITOR_REASON, MONITOR_REASONS);
    c.MONITOR_INCIDENT_STATUS = raw.MONITOR_INCIDENT_STATUS === 'RECOVERED' ? 'RECOVERED' : 'ACTIVE';
    c.MONITOR_RECOVERED_AT = optionalTime(raw.MONITOR_RECOVERED_AT);
    c.MONITOR_TIMELINE = Array.isArray(raw.MONITOR_TIMELINE) ? raw.MONITOR_TIMELINE.slice(0,16).filter(e => object(e) && timestamp(e.at) !== UNKNOWN && MONITOR_REASONS.includes(e.reason) && ['OPENED','REASON_CHANGED','RECOVERED'].includes(e.transition)).map(e => ({at:e.at,reason:e.reason,transition:e.transition})) : [];
  }
  return c;
}
export function projectSecuritySnapshot(raw) {
  if (!object(raw) || raw.schemaVersion !== 1 || raw.mode !== 'MONITOR_ONLY' || raw.autoIsolationEnabled !== false || !['OK','DEGRADED','STARTING','NOT_AVAILABLE'].includes(raw.monitorState) || !WIFI.includes(raw.wifiState) || !Number.isSafeInteger(raw.unacknowledgedCount) || raw.unacknowledgedCount < 0 || !Array.isArray(raw.cases) || raw.cases.length > 48 || !(raw.lastCheckedAt === null || timestamp(raw.lastCheckedAt) !== UNKNOWN)) throw new TypeError('Invalid security snapshot');
  const cases = raw.cases.map(projectCase);
  if (new Set(cases.map(c => c.CASE_ID)).size !== cases.length) throw new TypeError('Invalid security cases');
  const projected = { schemaVersion: 1, mode: 'MONITOR_ONLY', monitorState: raw.monitorState, autoIsolationEnabled: false, lastCheckedAt: raw.lastCheckedAt, wifiState: raw.wifiState, unacknowledgedCount: cases.filter(pendingCase).length, cases, behavior:projectBehaviorMetadata(raw.behavior) };
  if (object(raw.monitorHealth)) projected.monitorHealth = projectMonitorHealth(raw.monitorHealth);
  if (object(raw.sourceStates)) projected.sourceStates = Object.fromEntries(['defender','behavior'].map(key => [key, SOURCE_STATES.includes(raw.sourceStates[key]) ? raw.sourceStates[key] : 'NOT_AVAILABLE']));
  if (object(raw.sourceCheckedAt)) projected.sourceCheckedAt = Object.fromEntries(['defender','behavior'].map(key => [key, optionalTime(raw.sourceCheckedAt[key])]));
  if (object(raw.behaviorHealth)) projected.behaviorHealth = projectMonitorHealth(raw.behaviorHealth);
  if (object(raw.currentProtection)) projected.currentProtection = Object.fromEntries(PROTECTION.map(key => [key,enumValue(raw.currentProtection[key],key === 'SERVICE_STATUS' ? ['RUNNING','STOPPED',UNKNOWN] : ['ON','OFF',UNKNOWN])]));
  projected.currentProtectionObservedAt = optionalTime(raw.currentProtectionObservedAt);
  projected.pendingCaseCount = cases.filter(pendingSecurityCase).length;
  projected.monitorHealthCount = [projected.monitorHealth,projected.behaviorHealth].filter(h => h && h.status !== 'MONITOR_OK').length;
  return projected;
}
/** Photo triage is a view of public facts, never a second detector. */
const NA = 'NOT_AVAILABLE';
const NV = 'NOT_VERIFIED';
const marker = value => /^(?:UNKNOWN|NOT_AVAILABLE|NOT_VERIFIED)(?:$|[ @])/.test(String(value));
const eventMeaning = id => ({1116:'THREAT_DETECTED',1117:'ACTION_REPORTED',1118:'REMEDIATION_ERROR',1119:'CRITICAL_REMEDIATION_ERROR',5001:'PROTECTION_DISABLED',5007:'CONFIGURATION_CHANGED',5008:'ENGINE_ERROR'}[id] || UNKNOWN);
function eventOrder(a,b) {
  const av=Date.parse(a.AT),bv=Date.parse(b.AT);
  const at=Number.isFinite(av)?av:-Infinity,bt=Number.isFinite(bv)?bv:-Infinity;
  if(at!==bt)return at<bt?-1:1;
  const ar=integer(a.RECORD_ID),br=integer(b.RECORD_ID);
  return ar!==UNKNOWN && br!==UNKNOWN ? BigInt(ar)<BigInt(br)?-1:BigInt(ar)>BigInt(br)?1:0 : 0;
}
function publicTimeline(c) {
  if (!c) return [];
  const all = [{EVENT_ID:c.EVENT_ID,RECORD_ID:c.RECORD_ID,AT:c.DETECTED_AT,ACTION_RESULT:UNKNOWN,primary:true}, ...c.RELATED_EVENTS];
  const seen = new Set();
  return all.filter(e => { const key = `${e.EVENT_ID}/${e.RECORD_ID}/${e.AT}`; if (seen.has(key)) return false; seen.add(key); return true; })
    .sort(eventOrder);
}
function timelineText(e, semantic = true) {
  return `${e.AT} | EID=${e.EVENT_ID} RID=${e.RECORD_ID} | ${semantic ? `${eventMeaning(e.EVENT_ID)}${e.primary?' [ANCHOR]':` RESULT=${e.ACTION_RESULT}`}` : `RESULT=${e.ACTION_RESULT}`}`;
}
function buildMonitorPages(c, s, {nowMs, transportUnavailable}) {
  const h = s.monitorHealth;
  const rows = [], detail = [];
  const add = (label,value,group='monitorHealth',out=rows) => out.push({label,value:typeof value === 'boolean' ? String(value).toUpperCase() : String(value ?? NA),group});
  const time = monitorTime(s), age = time ? nowMs - Date.parse(time) : null;
  const status = transportUnavailable || h?.status === 'MONITOR_UNAVAILABLE' ? 'MONITOR_UNAVAILABLE' : age !== null && age < 0 ? 'MONITOR_CLOCK_SKEW' : age === null || age > 180000 ? 'MONITOR_STALE' : h?.status ?? (s.monitorState === 'OK' ? 'MONITOR_OK' : 'MONITOR_UNAVAILABLE');
  const reason = c ? c.MONITOR_REASON ?? UNKNOWN : h?.reason ?? UNKNOWN;
  const result = recoveredMonitor(c) || h?.recoveryResult === 'RECOVERED_AUTOMATICALLY' ? 'Recovered automatically' : h?.recoveryResult === 'STILL_UNAVAILABLE' || h?.status === 'MONITOR_UNAVAILABLE' ? `Still unavailable: ${h?.reason ?? reason}` : 'NONE';
  add('Status',status);if (!c) add('Current status',status);add('Reason',reason);add('Recovery result',result);
  add('Last successful poll',h ? h.lastSuccessfulPollAt : s.lastCheckedAt);add('Last attempt',h?.lastAttemptAt);add('Worker alive',h?.workerAlive);
  add('Last automatic recovery',h?.lastRecovery === 'AUTOMATIC' ? h.lastRecoveryAt : null);add('Last reason',h?.lastReason ?? reason);
  add('Recovery retry',h?.retryCount);add('Defender service',s.currentProtection?.SERVICE_STATUS ?? h?.serviceRunning);add('Realtime protection',s.currentProtection?.REAL_TIME_PROTECTION ?? h?.realtimeProtection);add('Behavior protection',s.currentProtection?.BEHAVIOR_MONITOR === 'OFF' || h?.behaviorMonitoring === false ? 'BEHAVIOR_PROTECTION_OFF' : s.currentProtection?.BEHAVIOR_MONITOR ?? h?.behaviorMonitoring); 
  for (const [label,key,healthKey] of [['Antimalware service','ANTIMALWARE_SERVICE','antimalwareService'],['Antivirus protection','ANTIVIRUS','antivirus'],['IOAV protection','IOAV_PROTECTION','ioavProtection'],['Network inspection','NETWORK_INSPECTION','networkInspection']]) add(label,s.currentProtection?.[key] ?? h?.[healthKey]);
  add('Event log exists',h?.eventLogExists);add('Event log enabled',h?.eventLogEnabled);add('Event log readable',h?.eventLogReadable);
  if (!c && s.currentProtectionObservedAt) add('Protection observed at',s.currentProtectionObservedAt);
  add('Event log range',`${h?.oldestRecordId ?? NA} .. ${h?.newestRecordId ?? NA}`);add('Checkpoint',h?.checkpoint);
  if (c) { add('CASE_ID',c.CASE_ID);add('Incident status',c.MONITOR_INCIDENT_STATUS);add('Detected at',c.DETECTED_AT);add('Recovered at',c.MONITOR_RECOVERED_AT); }
  const other = sourceWarnings(s,nowMs).filter(v => v.startsWith('BEHAVIOR_'));
  if (other.length) add('Behavior telemetry',other.join(' · '));
  if (!c && s.behaviorHealth) {
    const b = s.behaviorHealth, group = 'behaviorHealth';
    add('Behavior current status',b.status,group);add('Behavior reason',b.reason,group);
    add('Behavior last successful poll',b.lastSuccessfulPollAt,group);add('Behavior last attempt',b.lastAttemptAt,group);
    add('Behavior recovery result',b.recoveryResult === 'RECOVERED_AUTOMATICALLY' ? 'Recovered automatically' : b.recoveryResult === 'STILL_UNAVAILABLE' ? 'Still unavailable' : 'NONE',group);
    add('Behavior recovery retry',b.retryCount,group);add('Behavior worker alive',b.workerAlive,group);
    add('Behavior last recovery',b.lastRecoveryAt,group);add('Behavior last reason',b.lastReason,group);
  }
  add('Mode','MONITOR_ONLY · AUTO_ISOLATION OFF');
  const timeline = c?.MONITOR_TIMELINE ?? [];
  for (const [i,e] of timeline.slice(-4).entries()) add(`T${i+1}`,`${e.at} | ${e.transition} | ${e.reason}`,'monitorTimeline');
  if (timeline.length > 4) {
    for (const [i,e] of timeline.entries()) add(`T${i+1}`,`${e.at} | ${e.transition} | ${e.reason}`,'monitorTimeline',detail);
  }
  return detail.length ? [rows,detail] : [rows];
}
export function buildSecurityPages(value, rawSnapshot, {nowMs = Date.now(), transportUnavailable = false} = {}) {
  if(value?.EVENT_SOURCE==='BEHAVIOR_MONITOR')return buildBehaviorPages(value,rawSnapshot,{nowMs,transportUnavailable});
  const c = value ? projectCase(value) : null;
  const s = projectSecuritySnapshot(rawSnapshot);
  if (isMonitorCase(c) || (!c && s.monitorHealth)) return buildMonitorPages(c,s,{nowMs,transportUnavailable});
  const first = [], detail = [];
  const add = (label,value,group,target=first) => target.push({label,value:typeof value === 'boolean' ? String(value).toUpperCase() : String(value ?? NA),group});
  const at = Date.parse(monitorTime(s)); const age = Number.isFinite(at) ? Math.floor((nowMs-at)/1000) : null;
  const eventAge = c && timestamp(c.DETECTED_AT)!==UNKNOWN ? Math.floor((nowMs-Date.parse(c.DETECTED_AT))/1000) : null;
  const freshness = transportUnavailable ? 'MONITOR_UNAVAILABLE' : age===null ? 'MONITOR_TIME_UNKNOWN' : age<0 ? 'CLOCK_SKEW' : age>180 ? 'MONITOR_STALE' : 'MONITOR_RECENT';
  const effectiveMonitor = transportUnavailable ? 'UNAVAILABLE' : freshness==='MONITOR_STALE' ? 'STALE' : freshness==='CLOCK_SKEW' ? 'CLOCK_SKEW' : s.monitorState;
  const missingPriority=['EVIDENCE_NOT_SAVED','ORIGINAL_RAW_EVIDENCE','CURRENT_EVIDENCE','PROTECTION_STATE','MATCHING_ACTIVE_THREAT','MATCHING_DETECTION','EVENT_TIME','ACTION_SUCCESS','THREAT_ID','DETECTION_ID','EXPLICIT_SEVERITY','MONITOR_SOURCE'];
  const missing=[...(c?.MISSING_EVIDENCE||[])].sort((a,b)=>missingPriority.indexOf(a)-missingPriority.indexOf(b));
  const reasons = c?.REASON_CODES || [];
  const correlation = reasons.some(x=>['CRITICAL_REMEDIATION_CONFIRMED','PROTECTION_DISABLED_ACTIVE_SEVERE'].includes(x)) ? 'SERVER_CORROBORATED' : NV;
  const remediation = ({SUCCEEDED:'SUCCESS_REPORTED',FAILED:'FAILURE_REPORTED',NOT_REMEDIATED:'NOT_REMEDIATED'})[c?.ACTION_RESULT] || NV;
  const events = publicTimeline(c);
  const primary = events.find(e=>e.primary);
  const latest = events.filter(e=>e!==primary).slice(-3);
  const primaryEvents = (events.length<=4 ? [...events] : [primary,...latest].filter(Boolean)).sort(eventOrder);
  const knownHashes = c?.RESOURCE_HASHES || [];
  const unknown = [];
  const needsDetail = events.length>4 || missing.length>3 || reasons.length>2 || knownHashes.length>1 || (c?.RESOURCE_TYPES.length||0)>5;
  for(const key of ['CASE_ID','ALERT_LEVEL','DETECTED_AT']) add(key,c?.[key]??NA,'identity');
  add('INCIDENT_STATUS',c ? c.ACKNOWLEDGED?'ACKNOWLEDGED':'UNACKNOWLEDGED' : 'NO_CASE','identity');
  add('HUMAN_REVIEW_REQUIRED',c?.HUMAN_REVIEW_REQUIRED??NA,'identity');
  if (c?.CONFIGURATION_CLASSIFICATION && c.CONFIGURATION_CLASSIFICATION !== UNKNOWN) {
    for (const key of ['CONFIGURATION_CLASSIFICATION','CONFIGURATION_STATUS','CONFIGURATION_SETTING']) add(key,c[key],'configuration');
    add('CONFIGURATION_SAMPLES',c.CONFIGURATION_SAMPLE_COUNT,'configuration');
    add('CONFIGURATION_LAST_SEEN_AT',c.CONFIGURATION_LAST_SEEN_AT,'configuration');
    add('CONFIGURATION_REVIEWED_AT',c.CONFIGURATION_REVIEWED_AT,'configuration');
  }
  add('THREAT_NAME',c?.THREAT_NAME??NA,'threatName');
  for(const key of ['THREAT_ID','THREAT_CATEGORY','DEFENDER_SEVERITY','DETECTION_SOURCE','DETECTION_METHOD']) add(key,c?.[key]??NA,'threat');
  add('IS_ACTIVE',NA,'threat');
  add('RELATED_DETECTION_ID',NA,'threat');
  add('EVENT_SOURCE',c?.EVENT_SOURCE??NA,'threat');
  for(const key of ['EVENT_ID','RECORD_ID','ACTION_ATTEMPTED','ACTION_RESULT','ERROR_CODE']) {
    add(key,c?.[key]??NA,'remediation');
    if(key==='RECORD_ID')add('EVENT_ROLE','INCIDENT_ANCHOR','remediation');
    if(key==='ACTION_RESULT')add('ACTION_RESULT_SCOPE','CORRELATED_CASE','remediation');
  }
  add('REMEDIATION_STATUS',remediation,'remediation');
  add('CORRELATION_STATUS',correlation,'remediation');
  add('CORRELATION_AT',NA,'remediation');
  add('CORRELATION_BASIS',(reasons.includes('CRITICAL_REMEDIATION_CONFIRMED')?'FAILURE_RELATED:':'')+(reasons.slice(0,2).join(',')||'NONE_REPORTED'),'qualityWide');
  add('DEFENDER_SERVICE',`${c?.DEFENDER_PROTECTION_STATE.SERVICE_STATUS??NA} @CASE`,'current');
  add('REALTIME_PROTECTION',`${c?.DEFENDER_PROTECTION_STATE.REAL_TIME_PROTECTION??NA} @CASE`,'current');
  add('SIGNATURE_AGE',`${c?.SIGNATURE_AGE??NA}${typeof c?.SIGNATURE_AGE==='number'?'s':''} @CASE`,'current');
  add('SIGNATURE_VERSION',c?.SIGNATURE_VERSION??NA,'current');
  add('CASE_STATE_AT',NA,'current');
  add('LIVE_PROTECTION',NA,'current');
  add('MONITOR_STATUS',effectiveMonitor,'current');
  add('LAST_CHECKED_AT',s.lastCheckedAt||NA,'current');
  add('WIFI_STATE',s.wifiState,'current');
  add('AUTO_ISOLATION','OFF','current');
  add('ISOLATION_RESULT',c?.ISOLATION_RESULT??NA,'current');
  if(c?.ISOLATION_ERROR_CODE!==undefined) add('ISOLATION_ERROR_CODE',c.ISOLATION_ERROR_CODE,'current');
  for(const key of PROTECTION.slice(2)) add(key,c?.DEFENDER_PROTECTION_STATE[key]??NA,'otherProtection');
  for(const row of first) if(marker(row.value)) unknown.push(row.label);
  add('EVIDENCE_SAVED',missing.includes('EVIDENCE_NOT_SAVED')?'NO':NV,'quality');
  add('UNKNOWN_FIELDS',`${unknown.length}_FIELDS_MARKED`,'quality');
  add('INFECTION_STATUS',NV,'scope');
  add('RECONNECT_SAFETY',NV,'scope');
  add('DATA_FRESHNESS',`${freshness}; CHECK_AGE_SEC=${age??UNKNOWN}; EVENT_AGE_SEC=${eventAge??UNKNOWN}; CASE_STATE_TIME=${NA}`,'qualityWide');
  add('MISSING_EVIDENCE',missing.slice(0,3).join(',')+(missing.length>3?` +${missing.length-3}_ON_PAGE_2`:missing.length?'':'NONE_REPORTED'),'qualityWide');
  add('FACT_SCOPE','CASE=PROTECTION/SIGNATURE; CHECK=MONITOR/WIFI','scope');
  add('TIMELINE_COVERAGE',`${primaryEvents.length}/${events.length}_PUBLIC; LATEST_KNOWN_TIMES; UNDATED=${events.filter(e=>timestamp(e.AT)===UNKNOWN).length}; RAW_HISTORY=LOCAL_ONLY`,'timelineHeader');
  for(const [i,e] of primaryEvents.entries()) add(`T${i+1}`,timelineText(e),'timeline');
  add('RESOURCE_CLASS',c?.RESOURCE_CLASS.join(',')||NA,'resources');
  add('RESOURCE_TYPES',c?.RESOURCE_TYPES.slice(0,5).join(',')||NA,'resources');
  if(knownHashes.length===1) add('RESOURCE_HASH',knownHashes[0],'resources');
  if(c?.OVERFLOW_COUNT!==undefined) add('OVERFLOW_COUNT',c.OVERFLOW_COUNT,'resources');
  add('SUPPLEMENT',needsDetail?`PAGE_2; EXTRA_EVENTS=${Math.max(0,events.length-primaryEvents.length)}; HASHES=${knownHashes.length}`:'NONE','resources');
  if(needsDetail){
    add('DETAIL_SCOPE','PUBLIC_SUBSET; ORIGINAL_RAW=LOCAL_ONLY; NO_NEW_COLLECTION','detailMeta',detail);
    add('CASE_WIFI_AT_CAPTURE',c?.WIFI_STATE??NA,'detailMeta',detail);
    add('UNKNOWN_FIELDS_ALL',unknown.join(',')||'NONE','detailMeta',detail);
    add('MISSING_EVIDENCE_ALL',missing.join(',')||'NONE_REPORTED','detailMeta',detail);
    add('REASON_CODES_ALL',reasons.join(',')||'NONE_REPORTED','detailMeta',detail);
    add('RESOURCE_TYPES_ALL',c?.RESOURCE_TYPES.join(',')||NA,'detailMeta',detail);
    for(const [i,h] of knownHashes.slice(0,2).entries()) add(`RESOURCE_HASH_${i+1}`,h,'detailMeta',detail);
    add('HASH_COVERAGE',`${Math.min(2,knownHashes.length)}/${knownHashes.length}; REMAINDER=LOCAL_ONLY`,'detailMeta',detail);
    const detailEvents=events.slice(-10);
    add('DETAIL_TIMELINE',`${detailEvents.length}/${events.length}_PUBLIC; NOT_SHOWN=${events.length-detailEvents.length}; RAW_HISTORY=LOCAL_ONLY`,'detailTimelineHeader',detail);
    for(const [i,e] of detailEvents.entries()) add(`D${i+1}`,timelineText(e,false),'detailTimeline',detail);
  }
  return needsDetail?[first,detail]:[first];
}
export function bindSecurityAlerts({ document = globalThis.document, fetchImpl = globalThis.fetch?.bind(globalThis), onExit = () => {}, setIntervalImpl = globalThis.setInterval?.bind(globalThis), clearIntervalImpl = globalThis.clearInterval?.bind(globalThis), setTimeoutImpl = globalThis.setTimeout?.bind(globalThis), clearTimeoutImpl = globalThis.clearTimeout?.bind(globalThis) } = {}) {
  const make = (tag, id, text, parent) => { const el = document.createElement(tag); if (id) el.id = id; if (text) el.textContent = text; if (parent) parent.appendChild(el); return el; };
  const layer = make('section', 'securityAlertLayer', '', document.body);
  layer.setAttribute('aria-label', 'Security monitor');
  const badge = make('button', 'securityAlertBadge', '', layer); badge.type = 'button'; badge.hidden = true;
  const healthBadge = make('button', 'securityHealthBadge', '', layer); healthBadge.type = 'button'; healthBadge.hidden = true;
  const panel = make('section', 'securityAlertPanel', '', layer); panel.hidden = true; panel.setAttribute('role', 'dialog'); panel.setAttribute('aria-modal', 'true'); panel.setAttribute('aria-labelledby', 'securityAlertHeading');
  const header = make('header', 'securityAlertHeader', '', panel);
  const heading = make('h1', 'securityAlertHeading', 'SECURITY REVIEW — PHOTO FIRST', header);
  const status = make('p', 'securityMonitorStatus', '', header); status.setAttribute('role', 'status');
  const instructions = make('p', 'securityPhotoInstructions', 'Photograph every page. Human review required. PIN EXIT opens Windows exit controls.', header);
  const positions = make('div', 'securityPositions', '', header);
  const casePosition = make('span', 'securityCasePosition', '', positions);
  const pagePosition = make('span', 'securityPagePosition', '', positions);
  const identity = make('p', 'securityCaseIdentity', '', panel);
  const grid = make('div', 'securityEvidenceGrid', '', panel);
  const footer = make('div', 'securityFooter', '', panel);
  const navigation = make('nav', 'securityNavigation', '', footer); navigation.setAttribute('aria-label', 'Security evidence navigation');
  const button = (id, text, parent, fn) => { const el = make('button', id, text, parent); el.type = 'button'; el.addEventListener('click', fn); return el; };
  let snapshot = { schemaVersion: 1, mode: 'MONITOR_ONLY', monitorState: 'NOT_AVAILABLE', autoIsolationEnabled: false, lastCheckedAt: null, wifiState: UNKNOWN, unacknowledgedCount: 0, cases: [] };
  let warning = '', disabled = true, expanded = false, eewActive = false, pinActive = false, disposed = false, inflight = null, ackBusy = false;
  let selected = 0, page = 0, keypadOpen = false, needsReconcile = false, acknowledgementEpoch = 0, monitorOnlyView = false;
  const locallyAcknowledged = new Set();
  let cancelStatus = null;
  const pending = () => snapshot.cases.filter(pendingSecurityCase);
  const critical = () => pending().some(c => c.ALERT_LEVEL === 'CRITICAL');
  const visibleCases = () => [...pending().filter(c => c.ALERT_LEVEL === 'CRITICAL'), ...pending().filter(c => c.ALERT_LEVEL !== 'CRITICAL'), ...snapshot.cases.filter(c => !pendingSecurityCase(c))];
  const prevCase = button('securityPreviousCase', 'CASE ◀', navigation, () => { const n = visibleCases().length; selected = (selected - 1 + n) % (n || 1); page = 0; keypadOpen = false; pin.value = ''; ackMessage.textContent = ''; render(); });
  const nextCase = button('securityNextCase', 'CASE ▶', navigation, () => { selected = (selected + 1) % (visibleCases().length || 1); page = 0; keypadOpen = false; pin.value = ''; ackMessage.textContent = ''; render(); });
  const prevPage = button('securityPreviousPage', 'SUMMARY', navigation, () => { page--; render(); });
  const nextPage = button('securityNextPage', 'DETAILS', navigation, () => { page++; render(); });
  const actions = make('div', 'securityActions', '', footer);
  const history = button('securityCaseHistory', 'CASE HISTORY', actions, () => { monitorOnlyView = false; selected = 0; page = 0; expanded = true; render(); });
  const exit = button('securityPinExit', 'PIN EXIT', actions, () => { pinActive = true; pin.value = ''; keypadOpen = false; render(); try { onExit(); } catch { pinActive = false; render(); } });
  const close = button('securityCloseDetails', 'CLOSE DETAILS', actions, () => { if (!critical()) { expanded = false; render(); } });
  const ackForm = make('form', 'securityAckForm', '', actions);
  const pinLabel = make('label', '', 'PIN', ackForm); pinLabel.setAttribute('for', 'securityAckPin');
  const pin = make('input', 'securityAckPin', '', ackForm); pin.type = 'password'; pin.inputMode = 'numeric'; pin.maxLength = 4; pin.autocomplete = 'off'; pin.setAttribute('pattern', '[0-9]{4}'); pin.setAttribute('aria-label', 'Existing four digit PIN for acknowledgement');
  button('securityOpenKeypad', 'KEYPAD', ackForm, () => { keypadOpen = true; render(); });
  const ack = button('securityAcknowledge', 'ACKNOWLEDGE', ackForm, acknowledge);
  const keypad = make('section', 'securityKeypadPanel', '', panel); keypad.hidden = true; keypad.setAttribute('aria-label', 'Acknowledgement PIN keypad');
  make('h2', '', 'ACKNOWLEDGEMENT PIN', keypad);
  const indicator = make('p', 'securityPinIndicator', '', keypad); indicator.setAttribute('aria-live', 'polite');
  const keyGrid = make('div', 'securityPinKeyGrid', '', keypad);
  const addDigit = digit => { if (/^[0-9]{0,3}$/.test(pin.value)) pin.value += digit; render(); };
  for (const digit of '123456789') button(`securityPinDigit${digit}`, digit, keyGrid, () => addDigit(digit));
  button('securityPinClear', 'CLEAR', keyGrid, () => { pin.value = ''; render(); });
  button('securityPinDigit0', '0', keyGrid, () => addDigit('0'));
  button('securityPinBackspace', 'DELETE', keyGrid, () => { pin.value = pin.value.slice(0, -1); render(); });
  button('securityKeypadCancel', 'CANCEL', keypad, () => { keypadOpen = false; pin.value = ''; render(); });
  button('securityKeypadAcknowledge', 'ACKNOWLEDGE', keypad, acknowledge);
  pin.addEventListener('click', () => { keypadOpen = true; render(); });
  pin.addEventListener('input', () => { pin.value = pin.value.replace(/[^0-9]/g, '').slice(0, 4); render(); });
  const ackMessage = make('p', 'securityAckStatus', '', panel); ackMessage.setAttribute('role', 'status');
  ackForm.addEventListener('submit', event => { event.preventDefault(); return acknowledge(); });
  badge.addEventListener('click', () => { monitorOnlyView = false; const cases = visibleCases(); if (!cases[selected] || !pendingCase(cases[selected])) { selected = 0; page = 0; } expanded = true; render(); });
  healthBadge.addEventListener('click', () => openDiagnostic());
  function openDiagnostic() { monitorOnlyView = !critical(); expanded = true; page = 0; keypadOpen = false; pin.value = ''; render(); }
  document.getElementById?.('openSecurityDiagnostic')?.addEventListener('click', openDiagnostic);
  function render() {
    if (disposed) return;
    if (critical()) monitorOnlyView = false;
    const cases = visibleCases(); selected = Math.max(0, Math.min(selected, cases.length - 1));
    const current = monitorOnlyView ? null : cases[selected] || null;
    const checkedAt = monitorTime(snapshot);
    const stale = !disabled && (!checkedAt || Date.now() - Date.parse(checkedAt) > 180000);
    const clockSkew = !disabled && checkedAt && Date.parse(checkedAt) > Date.now();
    const monitorWarning = [...new Set([warning, stale ? 'MONITOR_STALE' : '', clockSkew ? 'MONITOR_CLOCK_SKEW' : '', ...(!disabled ? sourceWarnings(snapshot) : [])].filter(Boolean))].join(' · ');
    const persistent = critical();
    layer.hidden = pinActive || eewActive;
    badge.hidden = disabled || !pending().length;
    healthBadge.hidden = disabled || !monitorWarning;
    healthBadge.textContent = `HEALTH ${snapshot.monitorHealthCount || (monitorWarning ? 1 : 0)} · ${monitorWarning}`;
    history.hidden = !monitorOnlyView || !cases.length;
    badge.textContent = `${persistent ? 'CRITICAL' : 'WARNING'} SECURITY ${pending().length} PENDING CASES`;
    panel.hidden = !(persistent || expanded) || (disabled && !monitorOnlyView);
    panel.setAttribute('data-alert-level', persistent ? 'CRITICAL' : 'WARNING');
    heading.textContent = persistent ? 'CRITICAL_PENDING' : 'SECURITY_DIAGNOSTIC';
    status.textContent = `${monitorWarning || 'MONITOR_OK'} · MONITOR_ONLY · AUTO_ISOLATION OFF`;
    instructions.hidden = true;
    close.hidden = persistent;
    const viewSnapshot = { ...snapshot, cases: [], unacknowledgedCount: 0 };
    const options = { nowMs: Date.now(), transportUnavailable: Boolean(warning) };
    const pages = monitorOnlyView ? buildMonitorPages(current,viewSnapshot,options) : buildSecurityPages(current,viewSnapshot,options); page = Math.max(0, Math.min(page, pages.length - 1));
    const healthRows = buildMonitorPages(null,viewSnapshot,options)[0];
    for (const [id,label] of Object.entries({diagnosticSecurityStatus:'Status',diagnosticSecurityReason:'Reason',diagnosticSecurityRecovery:'Recovery result',diagnosticSecurityLastRecovery:'Last automatic recovery',diagnosticSecurityLastReason:'Last reason'})) {
      const element = document.getElementById?.(id);
      if (element) element.textContent = disabled && label === 'Status' ? 'NOT_AVAILABLE' : healthRows.find(row => row.label === label)?.value ?? NA;
    }
    identity.textContent = monitorOnlyView ? 'CURRENT HEALTH · READ ONLY' : `CASE_ID: ${current?.CASE_ID || UNKNOWN}`;
    casePosition.textContent = monitorOnlyView ? 'CURRENT HEALTH' : `CASE ${cases.length ? selected + 1 : 0}/${cases.length}`;
    pagePosition.textContent = `PAGE ${page + 1}/${pages.length}`;
    grid.replaceChildren();
    const groups = new Map();
    const titles = {threat:'THREAT / SOURCE',remediation:'REMEDIATION / BASIS',current:'SECURITY STATE',detailTimeline:'LATEST PUBLIC TIMELINE'};
    const groupOrder=['monitorHealth','behaviorHealth','monitorTimeline','behaviorLine','configuration','identity','threatName','threat','quality','remediation','current','otherProtection','scope','qualityWide','timelineHeader','timeline','resources','detailMeta','detailTimelineHeader','detailTimeline'];
    const orderedRows=[...pages[page]].sort((a,b)=>groupOrder.indexOf(a.group)-groupOrder.indexOf(b.group));
    for (const row of orderedRows) {
      if (row.label === 'CASE_ID') continue;
      const group = row.group || 'detailMeta';
      let list = groups.get(group);
      if (!list) {
        const section = make('section', '', '', group === 'quality' && groups.has('threat') ? groups.get('threat').parentNode : grid);
        section.setAttribute('data-group',group === 'behaviorHealth' ? 'behaviorHealth' : group.startsWith('monitor') ? 'monitorHealth' : group);
        if (titles[group]) make('h2','',titles[group],section);
        list=make('dl','','',section);groups.set(group,list);
      }
      const cell=make('div','','',list);cell.className='securityFact';cell.setAttribute('data-key',row.label);
      make('dt','',`${row.label}${(group.startsWith('monitor') || group === 'behaviorHealth')?': ':'='}`,cell);make('dd','',row.value,cell);
    }
    prevCase.hidden = nextCase.hidden = monitorOnlyView || cases.length < 2;
    prevPage.hidden = nextPage.hidden = pages.length < 2;
    ackMessage.hidden = !ackMessage.textContent;
    prevCase.disabled = nextCase.disabled = cases.length < 2;
    prevPage.disabled = page === 0; nextPage.disabled = page === pages.length - 1;
    ackForm.hidden = monitorOnlyView || !current || !pendingSecurityCase(current);
    ack.disabled = monitorOnlyView || ackBusy || needsReconcile || !current || current.CASE_ID === UNKNOWN;
    keypad.hidden = monitorOnlyView || !keypadOpen || pinActive || eewActive || !current || !pendingSecurityCase(current);
    indicator.textContent = Array.from({ length: 4 }, (_, i) => i < pin.value.length ? '●' : '○').join(' ');
    exit.disabled = false;
  }
  // One deadline covers both response headers and the complete JSON body. The
  // race releases single-flight even when a fetch implementation ignores abort.
  async function readStatus() {
    const controller = new AbortController();
    let timeout;
    const deadline = new Promise((_, reject) => {
      cancelStatus = () => { controller.abort(); reject(new Error('Status unavailable')); };
      timeout = setTimeoutImpl(cancelStatus, 10000);
    });
    try {
      return await Promise.race([deadline, (async () => {
        const response = await fetchImpl('/api/security/status', { cache: 'no-store', signal: controller.signal });
        return { response, payload: response.ok ? await response.json() : null };
      })()]);
    } finally { clearTimeoutImpl(timeout); cancelStatus = null; }
  }
  function refresh() {
    if (disposed) return Promise.resolve();
    if (inflight) return inflight;
    const epochAtRead = acknowledgementEpoch;
    const run = async () => {
      try {
        const { response, payload } = await readStatus();
        if (disposed) return;
        if (response.status === 404 && !snapshot.cases.length) { disabled = true; warning = ''; expanded = false; render(); return; }
        if (!response.ok) throw new Error();
        const next = projectSecuritySnapshot(payload);
        if (disposed) return;
        // Preserve observed critical evidence until acknowledgement, including malformed downgrades.
        let invalidCriticalUpdate = false;
        const recoveredAt = next.monitorHealth?.lastSuccessfulPollAt;
        const recoveryAge = recoveredAt ? Date.now() - Date.parse(recoveredAt) : null;
        const freshRecovery = next.monitorHealth?.status === 'MONITOR_OK' && recoveryAge !== null && recoveryAge >= 0 && recoveryAge <= 180000;
        for (const old of snapshot.cases) {
          if (old.ACKNOWLEDGED || recoveredMonitor(old) || locallyAcknowledged.has(old.CASE_ID)) continue;
          const index = next.cases.findIndex(c => c.CASE_ID === old.CASE_ID);
          if (index < 0) { next.cases.push(isMonitorCase(old) && freshRecovery ? { ...old, MONITOR_INCIDENT_STATUS:'RECOVERED', MONITOR_RECOVERED_AT:recoveredAt, HUMAN_REVIEW_REQUIRED:false } : old); continue; }
          const updated = next.cases[index];
          if (old.ALERT_LEVEL === 'CRITICAL' && !updated.ACKNOWLEDGED) {
            invalidCriticalUpdate ||= updated.ALERT_LEVEL === UNKNOWN;
            next.cases[index] = { ...old, MISSING_EVIDENCE: updated.ALERT_LEVEL === 'CRITICAL' ? updated.MISSING_EVIDENCE : old.MISSING_EVIDENCE, ISOLATION_RESULT: updated.ISOLATION_RESULT === UNKNOWN ? old.ISOLATION_RESULT : updated.ISOLATION_RESULT };
            if (updated.ISOLATION_ERROR_CODE !== undefined && updated.ISOLATION_ERROR_CODE !== UNKNOWN) next.cases[index].ISOLATION_ERROR_CODE = updated.ISOLATION_ERROR_CODE;
          }
        }
        for (const c of next.cases) if (locallyAcknowledged.has(c.CASE_ID)) c.ACKNOWLEDGED = true;
        const selectedId = visibleCases()[selected]?.CASE_ID;
        const hadCritical = critical(); snapshot = next; disabled = false; warning = invalidCriticalUpdate ? 'MONITOR_UNAVAILABLE' : '';
        if (epochAtRead === acknowledgementEpoch) needsReconcile = false;
        const newIndex = visibleCases().findIndex(c => c.CASE_ID === selectedId);
        if (newIndex >= 0) selected = newIndex;
        if (!hadCritical && critical()) { selected = 0; page = 0; expanded = false; }
      } catch { if (!disposed) { disabled = false; warning = 'MONITOR_UNAVAILABLE'; } }
      render();
    };
    inflight = run().finally(() => { inflight = null; });
    return inflight;
  }
  async function acknowledge() {
    if (disposed || ackBusy || monitorOnlyView) return;
    if (needsReconcile) { pin.value = ''; ackMessage.textContent = 'RECONCILING: REFRESH BEFORE RETRY'; await refresh(); return; }
    const current = visibleCases()[selected];
    let enteredPin = pin.value; pin.value = '';
    if (!current || !pendingSecurityCase(current) || !UUID.test(current.CASE_ID) || !/^[0-9]{4}$/.test(enteredPin)) { keypadOpen = true; ackMessage.textContent = 'PIN_REQUIRED: ENTER EXISTING 4-DIGIT PIN'; render(); return; }
    ackBusy = true; keypadOpen = false; acknowledgementEpoch++; needsReconcile = true; ackMessage.textContent = 'ACKNOWLEDGEMENT_PENDING'; render();
    try {
      const request = { method: 'POST', cache: 'no-store', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ caseId: current.CASE_ID, pin: enteredPin }) };
      enteredPin = '';
      const response = await fetchImpl('/api/security/acknowledge', request);
      if (disposed) return;
      if (!response.ok) { if (response.status === 403 || response.status === 429 || response.status === 400) needsReconcile = false; else await refresh(); ackMessage.textContent = response.status === 403 ? 'PIN_REJECTED' : response.status === 429 ? 'PIN_LOCKED: RETRY LATER' : 'ACKNOWLEDGEMENT_UNAVAILABLE'; return; }
      const result = await response.json();
      if (!object(result) || result.accepted !== true) throw new Error();
      needsReconcile = false; locallyAcknowledged.add(current.CASE_ID); current.ACKNOWLEDGED = true;
      expanded = false; selected = 0; page = 0; ackMessage.textContent = 'ACKNOWLEDGED';
      await refresh();
    } catch { if (!disposed) { ackMessage.textContent = 'ACKNOWLEDGEMENT_UNAVAILABLE: REFRESH BEFORE RETRY'; if (inflight) await inflight; await refresh(); } }
    finally { enteredPin = ''; ackBusy = false; render(); }
  }
  render();
  const timer = setIntervalImpl(() => { render(); void refresh(); }, 15000);
  void refresh();
  return { refresh, openDiagnostic, setEewActive(active) { eewActive = Boolean(active); if (eewActive) { pin.value = ''; keypadOpen = false; } render(); }, setPinActive(active) { pinActive = Boolean(active); if (pinActive) { pin.value = ''; keypadOpen = false; } render(); }, dispose() { disposed = true; pin.value = ''; cancelStatus?.(); clearIntervalImpl(timer); layer.remove(); } };
}
