"""Conservative Defender evidence correlation and positive public projection.

Numeric CIM enums remain source-qualified. This module never executes queries.
"""
from __future__ import annotations
import re
import uuid
from security_health import safe_reason, safe_time, monitor_case
from security_configuration import (classify_configuration_event, superseded_configuration_case,
    CONFIGURATION_CLASSIFICATIONS, CONFIGURATION_SETTINGS, CONFIGURATION_STATUSES)
from datetime import datetime, timezone

EVENT_IDS = {1116, 1117, 1118, 1119, 5001, 5007, 5008}
WIFI_STATES = {'ON','OFF','UNKNOWN','NOT_AVAILABLE'}
REASON_CODES = {'THREAT_DETECTED','REMEDIATION_REPORTED','REMEDIATION_ERROR','CRITICAL_REMEDIATION_CONFIRMED','PROTECTION_DISABLED','PROTECTION_DISABLED_ACTIVE_SEVERE','CONFIGURATION_CHANGED','ENGINE_ERROR','MONITOR_UNAVAILABLE','PROTECTION_UNHEALTHY','PROTECTION_UNKNOWN','SOURCE_PARTIAL','STATE_CORRUPT','STATE_WRITE_FAILED','LOG_RESET','INVALID_SNAPSHOT','CASE_OVERFLOW'}
MISSING_CODES = {'MATCHING_DETECTION','MATCHING_ACTIVE_THREAT','EXPLICIT_SEVERITY','ACTION_SUCCESS','PROTECTION_STATE','EVENT_TIME','THREAT_ID','DETECTION_ID','CURRENT_EVIDENCE','MONITOR_SOURCE','EVIDENCE_NOT_SAVED','ORIGINAL_RAW_EVIDENCE'}


def instant(value):
    if not isinstance(value,str) or len(value)>64: return None
    try:
        result=datetime.fromisoformat(value.replace('Z','+00:00'))
        return result.astimezone(timezone.utc) if result.tzinfo else None
    except (ValueError,OverflowError): return None


def integer(value):
    if type(value) is int and 0<=value<=2**63-1:return value
    if isinstance(value,str) and re.fullmatch(r'[0-9]{1,19}',value):
        number=int(value)
        if number<=2**63-1:return number
    return 'UNKNOWN'


def error_code(value):
    if type(value) is int and -(2**31)<=value<=2**64-1:return value
    if isinstance(value,str) and re.fullmatch(r'(?:0[xX][0-9A-Fa-f]{1,16}|-?[0-9]{1,20})',value):return value
    return 'UNKNOWN'


def field(data,*keys):
    if not isinstance(data,dict):return None
    wanted={re.sub(r'[^a-z0-9]','',key.lower()) for key in keys}
    for key,value in data.items():
        if isinstance(key,str) and re.sub(r'[^a-z0-9]','',key.lower()) in wanted:return value
    return None


def token_id(value):
    if type(value) is int:return str(value)
    if isinstance(value,str) and re.fullmatch(r'[A-Za-z0-9{}-]{1,80}',value):return value.casefold()
    return None


def taxonomy(value):
    if isinstance(value,str) and not re.search(r'(?:[0-9]{1,3}\.){3}[0-9]{1,3}',value) and re.fullmatch(r'(?:Trojan|Virus|Worm|Backdoor|Exploit|Behavior|PUA|PWS|Ransom|HackTool|Adware|Spyware|SoftwareBundler|BrowserModifier|DDoS|DoS|TrojanDownloader|TrojanDropper|TrojanSpy|TrojanClicker|MonitoringTool|RemoteAccess|SettingsModifier|Vulnerability|VirTool):[A-Za-z0-9]{1,20}/[A-Za-z0-9][A-Za-z0-9.!_-]{0,80}',value):return value
    return 'UNKNOWN'


def qualified(value,source):
    number=integer(value)
    return source+':'+str(number) if number!='UNKNOWN' else 'UNKNOWN'


def protection_state(raw):
    raw=raw if isinstance(raw,dict) else {}
    result={'SERVICE_STATUS':raw.get('serviceStatus') if raw.get('serviceStatus') in {'RUNNING','STOPPED','UNKNOWN'} else 'UNKNOWN'}
    for source,target in [('RealTimeProtectionEnabled','REAL_TIME_PROTECTION'),('AMServiceEnabled','ANTIMALWARE_SERVICE'),('AntivirusEnabled','ANTIVIRUS'),('BehaviorMonitorEnabled','BEHAVIOR_MONITOR'),('IoavProtectionEnabled','IOAV_PROTECTION'),('NISEnabled','NETWORK_INSPECTION')]:
        result[target]='ON' if raw.get(source) is True else 'OFF' if raw.get(source) is False else 'UNKNOWN'
    return result


def healthy(raw):
    p=protection_state(raw)
    return p['SERVICE_STATUS']=='RUNNING' and p['REAL_TIME_PROTECTION']=='ON' and p['ANTIMALWARE_SERVICE']=='ON'


def resource_projection(resources):
    kinds=set();extensions=set();hashes=set()
    if not isinstance(resources,list):resources=[]
    for item in resources[:64]:
        if not isinstance(item,str) or len(item)>8192:continue
        lower=item.lower()
        if lower.startswith(('file:','containerfile:')) or re.match(r'^[a-z]:\\',lower): kinds.add('FILE')
        elif lower.startswith(('regkey:','regvalue:')):kinds.add('REGISTRY')
        elif lower.startswith('process:'):kinds.add('PROCESS')
        elif lower.startswith(('web:','url:')):kinds.add('WEB')
        else:kinds.add('UNKNOWN')
        match=re.search(r'\.(exe|dll|ps1|bat|cmd|js|vbs|scr|msi|zip|rar|7z|pdf|docx?|xlsx?|txt|png|jpg|jpeg)(?:$|[;!])',lower)
        if match:extensions.add('.'+match.group(1))
        match=re.fullmatch(r'(?:sha256:|sha1:|md5:)([a-fA-F0-9]{32}|[a-fA-F0-9]{40}|[a-fA-F0-9]{64})',item)
        if match:hashes.add(match.group(1).lower())
    return sorted(kinds)[:8] or ['UNKNOWN'],sorted(extensions)[:16],sorted(hashes)[:8]


def base_case(now,wifi):
    return {'CASE_ID':str(uuid.uuid4()),'DETECTED_AT':now.isoformat(),'ALERT_LEVEL':'WARNING','EVENT_SOURCE':'MICROSOFT_DEFENDER','EVENT_ID':'UNKNOWN','RECORD_ID':'UNKNOWN','THREAT_NAME':'UNKNOWN','THREAT_ID':'UNKNOWN','THREAT_CATEGORY':'UNKNOWN','DEFENDER_SEVERITY':'UNKNOWN','DETECTION_SOURCE':'UNKNOWN','DETECTION_METHOD':'UNKNOWN','ACTION_ATTEMPTED':'UNKNOWN','ACTION_RESULT':'UNKNOWN','ERROR_CODE':'UNKNOWN','DEFENDER_PROTECTION_STATE':protection_state({}),'SIGNATURE_VERSION':'UNKNOWN','SIGNATURE_AGE':'UNKNOWN','RELATED_EVENTS':[],'WIFI_STATE':wifi if wifi in WIFI_STATES else 'UNKNOWN','ISOLATION_RESULT':'DISABLED','HUMAN_REVIEW_REQUIRED':True,'ACKNOWLEDGED':False,'REASON_CODES':[],'MISSING_EVIDENCE':[],'RESOURCE_CLASS':['UNKNOWN'],'RESOURCE_TYPES':[],'RESOURCE_HASHES':[]}


def health_case(reason,now,wifi,error='UNKNOWN'):
    c=base_case(now,wifi);c.update(EVENT_SOURCE='SECURITY_MONITOR',REASON_CODES=[reason if reason in REASON_CODES else 'MONITOR_UNAVAILABLE'],MISSING_EVIDENCE=['MONITOR_SOURCE'],ERROR_CODE=error_code(error));return c


def _action(event,detection):
    data=event.get('data',{});name=field(data,'Action Name','Action','Action Attempted')
    action=str(name).strip().casefold() if isinstance(name,str) else ''
    names={'quarantine':'QUARANTINE','remove':'REMOVE','clean':'CLEAN','block':'BLOCK','allow':'ALLOW','none':'NONE','no action':'NONE'}
    attempted=names.get(action,'UNKNOWN')
    if attempted in {'ALLOW','NONE'}:return attempted,'NOT_REMEDIATED'
    success=field(data,'Action Success','ActionSuccess')
    if type(success) is not bool:success=detection.get('ActionSuccess')
    if success is False or event.get('eventId') in {1118,1119}:return attempted,'FAILED'
    if success is True and attempted in {'QUARANTINE','REMOVE','CLEAN','BLOCK'}:return attempted,'SUCCEEDED'
    return attempted,'UNKNOWN'


def _same(event,other):
    a=token_id(field(event.get('data',{}),'DetectionID'));b=token_id(field(other.get('data',{}),'DetectionID'))
    if not a or a!=b:return False
    ta=integer(field(event.get('data',{}),'ThreatID'));tb=integer(field(other.get('data',{}),'ThreatID'))
    ea=instant(event.get('at'));eb=instant(other.get('at'))
    return ta!='UNKNOWN' and ta==tb and ea is not None and eb is not None and 0<=(eb-ea).total_seconds()<=600


def correlate_snapshot(snapshot,now,wifi='UNKNOWN',disabled_since=None):
    """Return sanitized cases for caller-provided fresh events, without side effects."""
    events=[e for e in snapshot.get('events',[])[:2048] if isinstance(e,dict) and e.get('eventId') in EVENT_IDS]
    events.sort(key=lambda e: (instant(e.get('at')) or datetime.min.replace(tzinfo=timezone.utc), integer(e.get('recordId')) if integer(e.get('recordId'))!='UNKNOWN' else -1))
    detections=[d for d in snapshot.get('detections',[])[:1024] if isinstance(d,dict)]
    threats=[t for t in snapshot.get('threats',[])[:1024] if isinstance(t,dict)]
    protection=snapshot.get('protection',{});protection=protection if isinstance(protection,dict) else {}
    result=[];consumed=set()
    for index,event in enumerate(events):
        if index in consumed:continue
        eid=event['eventId'];data=event.get('data',{});at=instant(event.get('at'))
        configuration=classify_configuration_event(event,snapshot,now) if eid==5007 else None
        if configuration and configuration['classification']=='CONFIGURATION_CHANGE_ONLY':continue
        did=token_id(field(data,'DetectionID'));tid=integer(field(data,'ThreatID'))
        matching=[]
        for detection in detections:
            if not did or token_id(detection.get('DetectionID'))!=did or tid=='UNKNOWN' or integer(detection.get('ThreatID'))!=tid or at is None:continue
            detected=instant(detection.get('InitialDetectionTime'));changed=instant(detection.get('LastThreatStatusChangeTime'))
            # Initial detection must precede this event, and current status cannot be in the future.
            if detected is None or not 0<=(at-detected).total_seconds()<=600 or (changed is not None and changed>now):continue
            matching.append(detection)
        detection=matching[0] if len(matching)==1 else {}
        same_threat=[t for t in threats if tid!='UNKNOWN' and integer(t.get('ThreatID'))==tid]
        threat=same_threat[0] if len(same_threat)==1 else {}
        related=[(j,e) for j,e in enumerate(events) if j>index and _same(event,e)]
        # Fold only facts at or before the collection clock. An earlier successful
        # action cannot erase a newer corroborated critical remediation failure.
        group=[event]+[e for _,e in related]
        current=[e for e in group if instant(e.get('at')) is not None and instant(e['at'])<=now]
        recovery_index=-1;critical_index=-1;outcome_event=None
        for position,item in enumerate(current):
            inactive=field(item.get('data',{}),'IsActive') is False
            action_result=_action(item,{})[1]
            if item.get('eventId')==1119:critical_index=position
            if inactive or (item.get('eventId')==1117 and action_result=='SUCCEEDED'):recovery_index=position
            if inactive or action_result!='UNKNOWN':outcome_event=item
        recovered=recovery_index>=0 and recovery_index>critical_index
        c=base_case(at or now,wifi);c.update(EVENT_ID=eid,RECORD_ID=integer(event.get('recordId')),DEFENDER_PROTECTION_STATE=protection_state(protection),THREAT_ID=tid,THREAT_NAME=taxonomy(threat.get('ThreatName') or field(data,'Threat Name')),THREAT_CATEGORY=qualified(threat.get('CategoryID'),'CIM.CategoryID'))
        severity=threat.get('SeverityName') or field(data,'Severity Name')
        c['DEFENDER_SEVERITY']=severity.upper() if isinstance(severity,str) and severity.upper() in {'LOW','MODERATE','HIGH','SEVERE','UNKNOWN'} else qualified(threat.get('SeverityID'),'CIM.SeverityID')
        c['DETECTION_SOURCE']=qualified(detection.get('DetectionSourceTypeID'),'CIM.DetectionSourceTypeID');c['DETECTION_METHOD']=qualified(detection.get('DetectionTypeID'),'CIM.DetectionTypeID')
        c['ACTION_ATTEMPTED'],c['ACTION_RESULT']=_action(outcome_event or event,detection)
        if c['ACTION_ATTEMPTED']=='UNKNOWN':c['ACTION_ATTEMPTED']=qualified(detection.get('CleaningActionID'),'CIM.CleaningActionID')
        c['ERROR_CODE']=error_code(detection.get('ThreatStatusErrorCode',field(data,'Error Code')))
        c['RESOURCE_CLASS'],c['RESOURCE_TYPES'],c['RESOURCE_HASHES']=resource_projection(detection.get('Resources'))
        version=protection.get('AntivirusSignatureVersion');c['SIGNATURE_VERSION']=version if isinstance(version,str) and re.fullmatch(r'[0-9]+(?:\.[0-9]+){1,5}',version) and len(version)<=64 else 'UNKNOWN'
        updated=instant(protection.get('AntivirusSignatureLastUpdated'))
        if updated and 0<=(now-updated).total_seconds()<=315576000:c['SIGNATURE_AGE']=int((now-updated).total_seconds())
        if not detection:c['MISSING_EVIDENCE'].append('MATCHING_DETECTION')
        if threat.get('IsActive') is not True:c['MISSING_EVIDENCE'].append('MATCHING_ACTIVE_THREAT')
        if at is None:c['MISSING_EVIDENCE'].append('EVENT_TIME')
        if any(instant(e.get('at')) is None or instant(e['at'])>now for e in group):c['MISSING_EVIDENCE'].append('CURRENT_EVIDENCE')
        reason={1116:'THREAT_DETECTED',1117:'REMEDIATION_REPORTED',1118:'REMEDIATION_ERROR',1119:'REMEDIATION_ERROR',5001:'PROTECTION_DISABLED',5007:'CONFIGURATION_CHANGED',5008:'ENGINE_ERROR'}[eid]
        c['REASON_CODES']=[reason]
        if configuration:
            c.update(CONFIGURATION_CLASSIFICATION=configuration['classification'],
                CONFIGURATION_SETTING=configuration['setting'],CONFIGURATION_STATUS='REVIEW_REQUIRED',
                CONFIGURATION_SAMPLE_COUNT=1,CONFIGURATION_LAST_SEEN_AT=(at or now).isoformat(),
                CONFIGURATION_REVIEWED_AT=None,CONFIGURATION_CLASSIFIER_VERSION=1)
        active=threat.get('IsActive') is True
        current_failure=detection.get('ActionSuccess') is False
        # Never infer severity or remediation success from incompatible numeric enums.
        group_failure=critical_index>=0 and critical_index>recovery_index
        failure_at=instant(current[critical_index].get('at')) if critical_index>=0 else at
        changed=instant(detection.get('LastThreatStatusChangeTime'))
        # A current aggregate ThreatID may describe a different detection. Require
        # this detection's status to corroborate a recent, nonfuture failure.
        current_evidence=bool(failure_at and changed and 0<=(now-failure_at).total_seconds()<=180 and 0<=(now-changed).total_seconds()<=180 and changed>=failure_at)
        if not current_evidence and 'CURRENT_EVIDENCE' not in c['MISSING_EVIDENCE']:c['MISSING_EVIDENCE'].append('CURRENT_EVIDENCE')
        if group_failure and detection and active and current_failure and current_evidence:
            c['ALERT_LEVEL']='CRITICAL';c['REASON_CODES']=['CRITICAL_REMEDIATION_CONFIRMED']
        if eid==5001 and current_evidence and at is not None and 0<=(now-at).total_seconds()<=180 and protection.get('RealTimeProtectionEnabled') is False and disabled_since and (now-disabled_since).total_seconds()>=180 and detection and active and c['DEFENDER_SEVERITY'] in {'HIGH','SEVERE'}:
            c['ALERT_LEVEL']='CRITICAL';c['REASON_CODES']=['PROTECTION_DISABLED_ACTIVE_SEVERE']
        if recovered:
            c['ALERT_LEVEL']='WARNING'
        for j,e in related[:16]:
            consumed.add(j);c['RELATED_EVENTS'].append({'EVENT_ID':e['eventId'],'RECORD_ID':integer(e.get('recordId')),'AT':(instant(e.get('at')) or now).isoformat(),'ACTION_RESULT':_action(e,{})[1]})
        result.append(c)
    return result


def public_case(value):
    """Validate persisted cases by exact schema and positive enum projection."""
    if not isinstance(value,dict):raise ValueError('invalid case')
    c=base_case(datetime.now(timezone.utc),'UNKNOWN')
    uuid.UUID(value.get('CASE_ID',''))
    at=instant(value.get('DETECTED_AT'))
    if not at:raise ValueError('invalid time')
    c.update(CASE_ID=value['CASE_ID'],DETECTED_AT=at.isoformat())
    for key,allowed in {'ALERT_LEVEL':{'WARNING','CRITICAL'},'EVENT_SOURCE':{'MICROSOFT_DEFENDER','SECURITY_MONITOR'},'ACTION_RESULT':{'SUCCEEDED','FAILED','NOT_REMEDIATED','UNKNOWN'},'ISOLATION_RESULT':{'DISABLED','PREPARED','OFF_VERIFIED','ISOLATION_FAILED','UNKNOWN'},'WIFI_STATE':WIFI_STATES}.items():c[key]=value.get(key) if value.get(key) in allowed else c[key]
    for key in ('EVENT_ID','RECORD_ID','THREAT_ID'):c[key]=integer(value.get(key))
    c['THREAT_NAME']=taxonomy(value.get('THREAT_NAME'))
    for key in ('THREAT_CATEGORY','DEFENDER_SEVERITY','DETECTION_SOURCE','DETECTION_METHOD','ACTION_ATTEMPTED'):
        v=value.get(key)
        if isinstance(v,str) and (v in {'UNKNOWN','LOW','MODERATE','HIGH','SEVERE','QUARANTINE','REMOVE','CLEAN','BLOCK','ALLOW','NONE'} or re.fullmatch(r'CIM\.(?:CategoryID|SeverityID|DetectionSourceTypeID|DetectionTypeID|CleaningActionID):[0-9]{1,19}',v)):c[key]=v
    c['ERROR_CODE']=error_code(value.get('ERROR_CODE'))
    p=value.get('DEFENDER_PROTECTION_STATE',{})
    for key in c['DEFENDER_PROTECTION_STATE']:
        allowed={'RUNNING','STOPPED','UNKNOWN'} if key=='SERVICE_STATUS' else {'ON','OFF','UNKNOWN'}
        if isinstance(p,dict) and p.get(key) in allowed:c['DEFENDER_PROTECTION_STATE'][key]=p[key]
    v=value.get('SIGNATURE_VERSION')
    if isinstance(v,str) and len(v)<=64 and re.fullmatch(r'[0-9]+(?:\.[0-9]+){1,5}',v):c['SIGNATURE_VERSION']=v
    age=value.get('SIGNATURE_AGE')
    if type(age) is int and 0<=age<=315576000:c['SIGNATURE_AGE']=age
    c['ACKNOWLEDGED']=value.get('ACKNOWLEDGED') is True
    for key,allowed in [('REASON_CODES',REASON_CODES),('MISSING_EVIDENCE',MISSING_CODES)]:
        c[key]=[v for v in value.get(key,[])[:32] if isinstance(v,str) and v in allowed] if isinstance(value.get(key),list) else []
    for key,allowed in [('RESOURCE_CLASS',{'FILE','REGISTRY','PROCESS','WEB','UNKNOWN'}),('RESOURCE_TYPES',{'.exe','.dll','.ps1','.bat','.cmd','.js','.vbs','.scr','.msi','.zip','.rar','.7z','.pdf','.doc','.docx','.xls','.xlsx','.txt','.png','.jpg','.jpeg'})]:
        c[key]=[v for v in value.get(key,[])[:16] if v in allowed] if isinstance(value.get(key),list) else []
    c['RESOURCE_HASHES']=[v for v in value.get('RESOURCE_HASHES',[])[:8] if isinstance(v,str) and re.fullmatch(r'(?:[a-f0-9]{32}|[a-f0-9]{40}|[a-f0-9]{64})',v)] if isinstance(value.get('RESOURCE_HASHES'),list) else []
    for e in value.get('RELATED_EVENTS',[])[:16] if isinstance(value.get('RELATED_EVENTS'),list) else []:
        if isinstance(e,dict) and instant(e.get('AT')):c['RELATED_EVENTS'].append({'EVENT_ID':integer(e.get('EVENT_ID')),'RECORD_ID':integer(e.get('RECORD_ID')),'AT':instant(e['AT']).isoformat(),'ACTION_RESULT':e.get('ACTION_RESULT') if e.get('ACTION_RESULT') in {'SUCCEEDED','FAILED','NOT_REMEDIATED','UNKNOWN'} else 'UNKNOWN'})
    isolation_error=value.get('ISOLATION_ERROR_CODE')
    if isolation_error is not None:
        c['ISOLATION_ERROR_CODE']=isolation_error if isolation_error in {'NONE','RADIO_UNAVAILABLE','INVALID_RADIO_STATE','EVIDENCE_NOT_SAVED','EVIDENCE_WRITE_FAILED'} else error_code(isolation_error)
    if c['EVENT_SOURCE']=='MICROSOFT_DEFENDER' and c['EVENT_ID']==5007:
        c['CONFIGURATION_CLASSIFICATION']=value.get('CONFIGURATION_CLASSIFICATION') if isinstance(value.get('CONFIGURATION_CLASSIFICATION'),str) and value.get('CONFIGURATION_CLASSIFICATION') in CONFIGURATION_CLASSIFICATIONS else 'INSUFFICIENT_EVIDENCE'
        c['CONFIGURATION_SETTING']=value.get('CONFIGURATION_SETTING') if isinstance(value.get('CONFIGURATION_SETTING'),str) and value.get('CONFIGURATION_SETTING') in CONFIGURATION_SETTINGS else 'UNKNOWN'
        c['CONFIGURATION_STATUS']=value.get('CONFIGURATION_STATUS') if isinstance(value.get('CONFIGURATION_STATUS'),str) and value.get('CONFIGURATION_STATUS') in CONFIGURATION_STATUSES else 'REVIEW_REQUIRED'
        count=value.get('CONFIGURATION_SAMPLE_COUNT')
        c['CONFIGURATION_SAMPLE_COUNT']=min(count,2**63-1) if type(count) is int and count>=1 else 1
        c['CONFIGURATION_LAST_SEEN_AT']=safe_time(value.get('CONFIGURATION_LAST_SEEN_AT')) or c['DETECTED_AT']
        c['CONFIGURATION_REVIEWED_AT']=safe_time(value.get('CONFIGURATION_REVIEWED_AT'))
        version=value.get('CONFIGURATION_CLASSIFIER_VERSION')
        c['CONFIGURATION_CLASSIFIER_VERSION']=1 if type(version) is int and version==1 else 0
        if superseded_configuration_case(value) and superseded_configuration_case(c):c['HUMAN_REVIEW_REQUIRED']=False
        else:c['CONFIGURATION_STATUS']='REVIEW_REQUIRED'
    if c['EVENT_SOURCE']=='SECURITY_MONITOR':
        c['MONITOR_HEALTH_ONLY']=monitor_case(value) and monitor_case(c)
    if monitor_case(c):
        c['MONITOR_REASON']=safe_reason(value.get('MONITOR_REASON','UNKNOWN'))
        c['MONITOR_INCIDENT_STATUS']='RECOVERED' if value.get('MONITOR_INCIDENT_STATUS')=='RECOVERED' else 'ACTIVE'
        c['MONITOR_RECOVERED_AT']=safe_time(value.get('MONITOR_RECOVERED_AT'))
        c['MONITOR_TIMELINE']=[]
        rows=value.get('MONITOR_TIMELINE',[])
        for row in rows[-16:] if isinstance(rows,list) else []:
            if isinstance(row,dict) and safe_time(row.get('at')) and row.get('transition') in ('OPENED','REASON_CHANGED','RECOVERED'):
                c['MONITOR_TIMELINE'].append({'at':safe_time(row['at']),'reason':safe_reason(row.get('reason')),'transition':row['transition']})
        if c['MONITOR_INCIDENT_STATUS']=='RECOVERED':c['HUMAN_REVIEW_REQUIRED']=False
    count=value.get('OVERFLOW_COUNT')
    if type(count) is int and count>=0:c['OVERFLOW_COUNT']=min(count,2**63-1)
    return c


