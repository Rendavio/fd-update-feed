#requires -Version 5.1
[CmdletBinding()]
param([ValidateRange(-1,9223372036854775807)][long]$AfterRecordId=-1,[switch]$RecentWindow)

function Convert-SecurityUtc($Value) {
    if($null -eq $Value){return $null}
    try { return ([datetimeoffset]$Value).ToUniversalTime().ToString('o') }
    catch { return $null }
}
function Get-SecurityProperty($Item,[string]$Name) {
    $property=$Item.PSObject.Properties[$Name]
    if($null -eq $property){return $null}
    return $property.Value
}
function Convert-SecurityScalar($Value) {
    if($null -eq $Value){return $null}
    if($Value -is [bool]){return $Value}
    if($Value -is [datetime] -or $Value -is [datetimeoffset]){return Convert-SecurityUtc $Value}
    if($Value -is [byte] -or $Value -is [int] -or $Value -is [long] -or
       $Value -is [uint32] -or $Value -is [uint64]){return $Value}
    $text=[string]$Value
    if($text.Length -gt 512){$text=$text.Substring(0,512)}
    return $text
}
function Select-SecurityProperties($Item,[string[]]$Names) {
    $result=[ordered]@{}
    foreach($name in $Names) {
        $value=Get-SecurityProperty $Item $name
        if($name -eq 'Resources') {
            $result[$name]=@($value | Select-Object -First 8 | ForEach-Object {Convert-SecurityScalar $_})
        } else { $result[$name]=Convert-SecurityScalar $value }
    }
    return $result
}
function Test-NoSecurityEvents($ErrorRecord) {
    return ([string]$ErrorRecord.FullyQualifiedErrorId -like 'NoMatchingEventsFound*')
}
function Test-SecurityAccessDenied($ErrorRecord) {
    if($ErrorRecord.CategoryInfo.Category -eq [Management.Automation.ErrorCategory]::PermissionDenied){return $true}
    $exception=$ErrorRecord.Exception
    for($depth=0;$depth -lt 8 -and $null -ne $exception;$depth++) {
        if($exception -is [UnauthorizedAccessException] -or $exception -is [System.Security.SecurityException] -or
            $exception.HResult -eq -2147024891 -or
            ($exception -is [ComponentModel.Win32Exception] -and $exception.NativeErrorCode -eq 5)){return $true}
        $exception=$exception.InnerException
    }
    return $false
}
function Set-SecurityLogFailure($Result,$Errors,$ErrorRecord) {
    $denied=Test-SecurityAccessDenied $ErrorRecord
    $Result.available=$false
    $Result.error=if($denied){'ACCESS_DENIED'}else{'SOURCE_UNAVAILABLE'}
    $Result.health.eventLogReadable=$false
    $Result.health.reason=if($denied){'DEFENDER_EVENT_LOG_ACCESS_DENIED'}else{'DEFENDER_EVENT_LOG_UNAVAILABLE'}
    if([string]$ErrorRecord.FullyQualifiedErrorId -like 'NoMatchingLogsFound*'){$Result.health.eventLogExists=$false}
    if(-not $Errors.Contains('EVENT_LOG_UNAVAILABLE')){$Errors.Add('EVENT_LOG_UNAVAILABLE')}
}
function Get-DefenderSecuritySnapshot {
    param([ValidateRange(-1,9223372036854775807)][long]$AfterRecordId=-1,[switch]$RecentWindow)
    if($RecentWindow){$AfterRecordId=-1}
    $latestLimit=if($RecentWindow){32}else{1}
    $log='Microsoft-Windows-Windows Defender/Operational'
    $errors=New-Object 'Collections.Generic.List[string]'
    $result=[ordered]@{available=$true;error='NONE';watermark=$null;logReset=$false;
        events=@();threats=@();detections=@();protection=[ordered]@{};sourceErrors=@();
        health=[ordered]@{reason='NONE';serviceRunning=$null;realtimeProtection=$null;
            eventLogExists=$null;eventLogEnabled=$null;eventLogReadable=$null;
            oldestRecordId=$null;newestRecordId=$null}}
    $latest=0L
    [Console]::Error.WriteLine('DEFENDER_STAGE:EVENT_LOG')
    try {
        $metadata=@(Get-WinEvent -ListLog $log -ErrorAction Stop)
        if($metadata.Count -ne 1) {
            $result.health.eventLogExists=$false
            throw 'Missing event log metadata'
        }
        $result.health.eventLogExists=$true
        $enabled=Get-SecurityProperty $metadata[0] 'IsEnabled'
        if($enabled -isnot [bool]){throw 'Invalid event log metadata'}
        $result.health.eventLogEnabled=$enabled
        if(-not $enabled) {
            $result.available=$false;$result.error='SOURCE_UNAVAILABLE'
            $result.health.reason='DEFENDER_EVENT_LOG_DISABLED'
            $errors.Add('EVENT_LOG_UNAVAILABLE')
        } else {
            $entry=@()
            try {
                # Recovery samples only record IDs/time; event contents never enter the baseline.
                $entry=@(Get-WinEvent -LogName $log -MaxEvents $latestLimit -ErrorAction Stop |
                    Select-Object -First $latestLimit -Property RecordId,TimeCreated)
            }
            catch {if(-not (Test-NoSecurityEvents $_)){throw}}
            if($entry.Count -gt 0) {
                $latest=[long]$entry[0].RecordId
                if($latest -le 0){throw 'Invalid latest event ID'}
                $result.health.newestRecordId=$latest
                $oldest=@(Get-WinEvent -LogName $log -Oldest -MaxEvents 1 -ErrorAction Stop)
                if($oldest.Count -ne 1 -or [long]$oldest[0].RecordId -le 0){throw 'Invalid oldest event ID'}
                $first=[long]$oldest[0].RecordId
                if($first -gt $latest){throw 'Event log changed during metadata read'}
                $result.health.oldestRecordId=$first
            }
            $result.health.eventLogReadable=$true
        }
    } catch { Set-SecurityLogFailure $result $errors $_ }
    if($result.available) {
        $result.watermark=$latest
        if($AfterRecordId -ge 0 -and ($latest -lt $AfterRecordId -or
            ($null -ne $result.health.oldestRecordId -and $AfterRecordId -lt ($result.health.oldestRecordId-1)))) {
            # A reset or overwritten interval is a fresh baseline, never historical malware replay.
            $result.logReset=$true;$result.health.reason='EVENT_LOG_RESET_OR_ROLLOVER';$errors.Add('LOG_RESET')
        } elseif($AfterRecordId -ge 0 -and $latest -gt $AfterRecordId) {
            $xpath="*[System[(EventRecordID > $AfterRecordId and EventRecordID <= $latest) and (EventID=1116 or EventID=1117 or EventID=1118 or EventID=1119 or EventID=5001 or EventID=5007 or EventID=5008)]]"
            $entries=@()
            try { $entries=@(Get-WinEvent -LogName $log -FilterXPath $xpath -Oldest -MaxEvents 32 -ErrorAction Stop) }
            catch {
                if(-not (Test-NoSecurityEvents $_)){
                    Set-SecurityLogFailure $result $errors $_
                    $result.watermark=$AfterRecordId
                }
            }
            foreach($entry in $entries) {
                try {
                    if($entry.ProviderName -cne 'Microsoft-Windows-Windows Defender'){throw 'Unexpected provider'}
                    $raw=[string]$entry.ToXml()
                    if($raw.Length -gt 65536){throw 'Oversized event'}
                    $settings=New-Object System.Xml.XmlReaderSettings
                    $settings.DtdProcessing=[System.Xml.DtdProcessing]::Prohibit
                    $settings.XmlResolver=$null;$settings.MaxCharactersInDocument=65536
                    $reader=[System.Xml.XmlReader]::Create((New-Object IO.StringReader($raw)),$settings)
                    try {
                        $doc=New-Object System.Xml.XmlDocument;$doc.XmlResolver=$null;$doc.Load($reader)
                    } finally { $reader.Dispose() }
                    $fields=[ordered]@{}
                    foreach($node in @($doc.SelectNodes("//*[local-name()='EventData']/*[local-name()='Data']") | Select-Object -First 64)) {
                        $name=[string]$node.GetAttribute('Name')
                        if(-not $name -or $name.Length -gt 96){continue}
                        $text=[string]$node.InnerText
                        if($text.Length -gt 512){$text=$text.Substring(0,512);if(-not $errors.Contains('TRUNCATED')){$errors.Add('TRUNCATED')}}
                        if($fields.Contains($name)){throw 'Duplicate event field'}
                        $fields[$name]=$text
                    }
                    $result.events+=@{eventId=[int]$entry.Id;recordId=[long]$entry.RecordId;
                        at=(Convert-SecurityUtc $entry.TimeCreated);version=[int]$entry.Version;data=$fields}
                } catch {
                    if(-not $errors.Contains('TRUNCATED')){$errors.Add('TRUNCATED')}
                }
            }
            if($entries.Count -eq 32){$result.watermark=[long]$entries[-1].RecordId}
        }
    }
    [Console]::Error.WriteLine('DEFENDER_STAGE:STATUS')
    try {
        $status=Get-MpComputerStatus -ErrorAction Stop
        $names=@('AMServiceEnabled','AntivirusEnabled','RealTimeProtectionEnabled',
            'OnAccessProtectionEnabled','BehaviorMonitorEnabled','IoavProtectionEnabled','NISEnabled','AntivirusSignatureVersion',
            'AntivirusSignatureLastUpdated','AntivirusSignatureAge','AMEngineVersion')
        $result.protection=Select-SecurityProperties $status $names
        $realtime=Get-SecurityProperty $status 'RealTimeProtectionEnabled'
        if($realtime -isnot [bool]){throw 'Invalid Defender status'}
        $result.health.realtimeProtection=$realtime
    } catch { $errors.Add('STATUS_UNAVAILABLE') }
    [Console]::Error.WriteLine('DEFENDER_STAGE:SERVICE')
    try {
        $service=Get-Service -Name WinDefend -ErrorAction Stop
        $state=([string]$service.Status).ToUpperInvariant()
        $result.protection['serviceStatus']=if(@('RUNNING','STOPPED') -ccontains $state){$state}else{'UNKNOWN'}
        if($state -ceq 'RUNNING'){$result.health.serviceRunning=$true}
        elseif($state -ceq 'STOPPED'){$result.health.serviceRunning=$false}
        else {$errors.Add('SERVICE_UNAVAILABLE')}
    } catch {
        $result.protection['serviceStatus']='UNKNOWN';$errors.Add('SERVICE_UNAVAILABLE')
    }
    # History queries are only needed for fresh events or currently unhealthy protection.
    $needsThreats=@($result.events).Count -gt 0 -or
        $result.protection['RealTimeProtectionEnabled'] -eq $false -or
        $result.protection['AMServiceEnabled'] -eq $false
    if($needsThreats) {
        $targetIds=New-Object 'Collections.Generic.HashSet[long]'
        foreach($event in @($result.events)) {
            foreach($key in @('Threat ID','ThreatID')) {
                $value=$event.data[$key];$number=0L
                if($null -ne $value -and [long]::TryParse([string]$value,[ref]$number) -and $number -ge 0) {
                    [void]$targetIds.Add($number)
                }
            }
        }
        [Console]::Error.WriteLine('DEFENDER_STAGE:THREATS')
        try {
            $names=@('ThreatID','ThreatName','SeverityID','CategoryID','DidThreatExecute','IsActive','Resources')
            $result.threats=@(Get-MpThreat -ErrorAction Stop |
                Where-Object {$targetIds.Count -eq 0 -or $targetIds.Contains([long](Get-SecurityProperty $_ 'ThreatID'))} |
                Select-Object -First 32 |
                ForEach-Object {Select-SecurityProperties $_ $names})
        } catch {$errors.Add('THREATS_UNAVAILABLE')}
        [Console]::Error.WriteLine('DEFENDER_STAGE:DETECTIONS')
        try {
            $names=@('DetectionID','ThreatID','InitialDetectionTime','LastThreatStatusChangeTime',
                'RemediationTime','ActionSuccess','CleaningActionID','ThreatStatusID',
                'ThreatStatusErrorCode','CurrentThreatExecutionStatusID','DetectionSourceTypeID',
                'AdditionalActionsBitMask','Resources')
            $result.detections=@(Get-MpThreatDetection -ErrorAction Stop |
                Where-Object {$targetIds.Count -eq 0 -or $targetIds.Contains([long](Get-SecurityProperty $_ 'ThreatID'))} |
                Sort-Object -Property InitialDetectionTime -Descending |
                Select-Object -First 64 |
                ForEach-Object {Select-SecurityProperties $_ $names})
        } catch {$errors.Add('DETECTIONS_UNAVAILABLE')}
    }
    $result.sourceErrors=@($errors | Select-Object -Unique)
    if($result.health.serviceRunning -eq $false){$result.health.reason='DEFENDER_SERVICE_STOPPED'}
    elseif($result.health.realtimeProtection -eq $false){$result.health.reason='REALTIME_PROTECTION_OFF'}
    elseif($errors.Contains('STATUS_UNAVAILABLE')){$result.health.reason='DEFENDER_STATUS_QUERY_FAILED'}
    elseif($errors.Contains('SERVICE_UNAVAILABLE')){$result.health.reason='DEFENDER_SERVICE_QUERY_FAILED'}
    elseif($result.health.reason -ceq 'NONE' -and $result.sourceErrors.Count -gt 0){$result.health.reason='SOURCE_PARTIAL'}
    [Console]::Error.WriteLine('DEFENDER_STAGE:COMPLETE')
    return $result
}
if($MyInvocation.InvocationName -ne '.') {
    $ErrorActionPreference='Stop'
    [Console]::OutputEncoding=New-Object Text.UTF8Encoding($false)
    $OutputEncoding=New-Object Text.UTF8Encoding($false)
    try {
        $snapshot=Get-DefenderSecuritySnapshot -AfterRecordId $AfterRecordId -RecentWindow:$RecentWindow
        $json=ConvertTo-Json -InputObject $snapshot -Depth 12 -Compress
        if([Text.Encoding]::UTF8.GetByteCount($json) -gt 524288) {
            $json='{"available":false,"error":"INVALID_SNAPSHOT","watermark":null,"logReset":false,"events":[],"threats":[],"detections":[],"protection":{},"sourceErrors":["TRUNCATED"],"health":{"reason":"INVALID_SNAPSHOT","serviceRunning":null,"realtimeProtection":null,"eventLogExists":null,"eventLogEnabled":null,"eventLogReadable":null,"oldestRecordId":null,"newestRecordId":null}}'
        }
        [Console]::WriteLine($json)
    } catch {
        [Console]::WriteLine('{"available":false,"error":"SOURCE_UNAVAILABLE","watermark":null,"logReset":false,"events":[],"threats":[],"detections":[],"protection":{},"sourceErrors":[],"health":{"reason":"UNKNOWN","serviceRunning":null,"realtimeProtection":null,"eventLogExists":null,"eventLogEnabled":null,"eventLogReadable":null,"oldestRecordId":null,"newestRecordId":null}}')
    }
}
