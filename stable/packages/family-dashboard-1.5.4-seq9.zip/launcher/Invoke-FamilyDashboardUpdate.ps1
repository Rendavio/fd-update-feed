#requires -Version 5.1
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidatePattern('^[0-9a-f]{32}$')]
    [string]$RequestId,

    [Parameter(Mandatory = $true)]
    [ValidateRange(1, 4294967295)]
    [int64]$ServerProcessId
)
Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"

function Test-IsAdministrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

if (-not (Test-IsAdministrator)) { exit 5 }
if ([Environment]::UserName -ine "DashboardAdmin") { exit 5 }

function Test-Port3000Listening {
    $client = New-Object Net.Sockets.TcpClient
    try {
        $async = $client.BeginConnect("127.0.0.1", 3000, $null, $null)
        $completed = $async.AsyncWaitHandle.WaitOne(250)
        if (-not $completed) { return $false }
        $client.EndConnect($async)
        return $client.Connected
    } catch {
        return $false
    } finally {
        $client.Dispose()
    }
}

$serverRunning = $true
$listening = $true
for ($attempt = 0; $attempt -lt 60; $attempt++) {
    $serverRunning = $null -ne (Get-Process -Id $ServerProcessId -ErrorAction SilentlyContinue)
    $listening = Test-Port3000Listening
    if (-not $serverRunning -and -not $listening) { break }
    Start-Sleep -Milliseconds 500
}
if ($serverRunning -or $listening) { exit 7 }
$root = "C:\ProgramData\FamilyDashboardUpdater"
$python = Join-Path $root "runtime\python.exe"
$apply = Join-Path $root "program\apply_update.py"
if (-not (Test-Path -LiteralPath $python -PathType Leaf) -or
    -not (Test-Path -LiteralPath $apply -PathType Leaf)) { exit 8 }
$arguments = @("-I", "-s", "-B", "-X", "utf8", ('"{0}"' -f $apply))
try {
    $applyProcess = Start-Process -FilePath $python -ArgumentList $arguments `
        -WorkingDirectory $root -WindowStyle Hidden -PassThru
} catch {
    exit 8
}
for ($second = 0; $second -lt 600; $second++) {
    if ($applyProcess.HasExited) { break }
    Start-Sleep -Seconds 1
    $applyProcess.Refresh()
}
if (-not $applyProcess.HasExited) {
    # This is the exact child created above, not a discovered/arbitrary process.
    Stop-Process -Id $applyProcess.Id -Force -ErrorAction SilentlyContinue
    try { $applyProcess.WaitForExit(5000) } catch {}
    exit 9
}
exit $applyProcess.ExitCode
