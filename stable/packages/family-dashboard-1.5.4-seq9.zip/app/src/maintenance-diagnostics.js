import { describeUpdateStatus } from './update-client.js';

const VERSION_PATTERN = /^[0-9A-Za-z][0-9A-Za-z.+-]{0,63}$/;

function version(value) {
  return typeof value === 'string' && VERSION_PATTERN.test(value) ? value : null;
}

function sequence(value) {
  return Number.isSafeInteger(value) && value >= 0 ? String(value) : null;
}

function lastUpdate(value) {
  if (value === 'PASS') return 'PASS';
  if (value === 'FAIL') return 'FAIL';
  return 'Unknown';
}

export function describeMaintenanceDiagnostics({ runtime = null, updateStatus = null } = {}) {
  const runtimeAvailable = runtime !== null && typeof runtime === 'object';
  const updateAvailable = updateStatus !== null && typeof updateStatus === 'object';
  const updateView = updateAvailable ? describeUpdateStatus(updateStatus) : null;
  const integrity = runtime?.processIntegrity;

  return {
    dashboard: version(updateStatus?.currentVersion) || version(runtime?.appVersion) || 'Unknown',
    sequence: sequence(updateStatus?.currentSequence) || 'Unknown',
    updater: version(updateStatus?.updaterVersion) || 'Unknown',
    server: runtimeAvailable ? 'Running' : 'Unknown',
    integrity: integrity === 'nonElevated' || integrity === 'elevated' ? integrity : 'Unknown',
    update: updateView?.statusText || 'Unknown',
    lastUpdate: lastUpdate(updateStatus?.lastResult),
  };
}
