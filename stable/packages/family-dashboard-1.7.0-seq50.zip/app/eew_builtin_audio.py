"""Fixed licensed public asset readiness. Never reads private audio or accesses AOSP."""
import hashlib
import os
from pathlib import Path
from eew_private_audio import PrivateAudioError,secure_file

BUILTIN_PATH=Path('assets/eew/etws_earthquake.ogg')
BUILTIN_SHA256='D4CB01BA2FA34044AB37D824A222CB9580E17BE2808274CCA35B51F877C6B7A7'
BUILTIN_SIZE=106833

def read_builtin_sound(root):
    with secure_file(Path(root)/BUILTIN_PATH) as stream:
        if os.fstat(stream.fileno()).st_size!=BUILTIN_SIZE:raise ValueError('invalid_builtin')
        raw=stream.read(BUILTIN_SIZE+1)
    if hashlib.sha256(raw).hexdigest().upper()!=BUILTIN_SHA256:raise ValueError('invalid_builtin')
    return raw

def builtin_sound_status(root):
    try:
        read_builtin_sound(root)
        return 'READY'
    except FileNotFoundError:return 'MISSING'
    except PrivateAudioError as exc:return 'MISSING' if exc.category=='missing' else 'INVALID'
    except (OSError,ValueError):return 'INVALID'
