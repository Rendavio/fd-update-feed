"""Private, durable, monitor-only Defender journal. No device controls or HTTP queries."""
from __future__ import annotations
import copy
import json
import os
import stat
import tempfile
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path
import eew_private_audio as private
from security_events import (correlate_snapshot,health_case,public_case,instant,integer,error_code,protection_state,WIFI_STATES)

MAX_STATE_BYTES=1024*1024
MAX_EVIDENCE_BYTES=1024*1024
MAX_CASES=32
SOURCE_ERRORS={'NONE','ACCESS_DENIED','SOURCE_UNAVAILABLE','TIMEOUT','INVALID_SNAPSHOT'}
ISOLATION_ERRORS={'NONE','RADIO_UNAVAILABLE','INVALID_RADIO_STATE','EVIDENCE_NOT_SAVED','EVIDENCE_WRITE_FAILED'}


def _reject_duplicates(pairs):
    result={}
    for key,value in pairs:
        if key in result:raise ValueError('duplicate key')
        result[key]=value
    return result


class PrivateMonitorStore:
    """Bounded files with pinned parent handles and existing protected ACL helpers."""
    def __init__(self,data_root):
        self.root=Path(data_root).absolute();self.directory=self.root/'security-monitor'
        if self.root==Path(__file__).absolute().parent or Path(__file__).absolute().parent in self.root.parents:
            raise ValueError('unsafe data root')
        self.path=self.directory/'state.json';self.previous=self.directory/'state.previous.json'

    def _safe(self,path):
        if not path.is_absolute() or '..' in path.parts or str(path).startswith(('\\\\','//')):raise ValueError('unsafe path')
        for part in reversed((path,*path.parents)):
            try:info=part.lstat()
            except FileNotFoundError:continue
            if stat.S_ISLNK(info.st_mode) or getattr(info,'st_file_attributes',0)&0x400:raise ValueError('unsafe path')
            if part!=path and not stat.S_ISDIR(info.st_mode):raise ValueError('unsafe path')

    def _read(self,path,limit):
        self._safe(path)
        try:
            with private.secure_file(path,private_base=self.directory) as stream:
                if os.fstat(stream.fileno()).st_size>limit:raise ValueError('oversized')
                raw=stream.read(limit+1)
        except private.PrivateAudioError as exc:
            # Windows locked_chain reports absent paths with this explicit category.
            # Permission, reparse and unsafe ACL errors must continue to fail closed.
            if exc.category=='missing':raise FileNotFoundError('missing private journal') from None
            raise
        if len(raw)>limit:raise ValueError('oversized')
        return raw
    def _decode(self,raw):
        s=json.loads(raw.decode('utf-8'),object_pairs_hook=_reject_duplicates,parse_constant=lambda _: (_ for _ in ()).throw(ValueError('nonfinite')))
        if not isinstance(s,dict) or s.get('schema')!=1 or type(s.get('initialized')) is not bool:raise ValueError('invalid state')
        uuid.UUID(s.get('epoch',''))
        if s.get('cursor') is not None and type(s.get('cursor')) is not int:raise ValueError('invalid cursor')
        if s.get('cursor') is not None and integer(s['cursor'])=='UNKNOWN':raise ValueError('invalid cursor')
        if not isinstance(s.get('cases'),list) or len(s['cases'])>MAX_CASES:raise ValueError('invalid cases')
        s['cases']=[public_case(c) for c in s['cases']]
        if len({c['CASE_ID'] for c in s['cases']})!=len(s['cases']):raise ValueError('duplicate cases')
        fingerprints=s.get('health',{})
        if not isinstance(fingerprints,dict) or len(fingerprints)>32:raise ValueError('invalid health')
        s['health']={k:v for k,v in fingerprints.items() if k in {'MONITOR_UNAVAILABLE','PROTECTION_UNHEALTHY','PROTECTION_UNKNOWN','SOURCE_PARTIAL','STATE_CORRUPT','STATE_WRITE_FAILED','LOG_RESET','INVALID_SNAPSHOT','CASE_OVERFLOW'} and isinstance(v,str)}
        s['lastCheckedAt']=(instant(s.get('lastCheckedAt')).isoformat() if instant(s.get('lastCheckedAt')) else None)
        s['disabledSince']=(instant(s.get('disabledSince')).isoformat() if instant(s.get('disabledSince')) else None)
        s['wifiState']=s.get('wifiState') if s.get('wifiState') in WIFI_STATES else 'UNKNOWN'
        s['monitorState']=s.get('monitorState') if s.get('monitorState') in {'STARTING','OK','DEGRADED','NOT_AVAILABLE'} else 'DEGRADED'
        return s

    def load(self):
        try:return self._decode(self._read(self.path,MAX_STATE_BYTES)),False
        except FileNotFoundError:return None,False
        except Exception:
            try:return self._decode(self._read(self.previous,MAX_STATE_BYTES)),True
            except Exception:return None,True

    def _ensure(self):
        self._safe(self.root);self._safe(self.directory)
        self.root.mkdir(parents=True,exist_ok=True)
        with private.locked_chain(self.root) as root_handle:
            if os.name=='nt':private._check_acl(root_handle,protected=False)
            if not self.directory.exists():self.directory.mkdir()
            self._safe(self.directory)
            with private.locked_chain(self.directory):private._set_private_acl(self.directory)

    def _atomic(self,path,raw):
        self._safe(path)
        if path.exists():
            with private.secure_file(path,private_base=self.directory):pass
        fd,name=tempfile.mkstemp(prefix='journal-',suffix='.tmp',dir=self.directory);temp=Path(name)
        try:
            private._set_private_acl(temp)
            with os.fdopen(fd,'wb') as stream:
                fd=None;stream.write(raw);stream.flush();os.fsync(stream.fileno())
            with private.secure_file(temp,private_base=self.directory) as stream:
                if stream.read(len(raw)+1)!=raw:raise OSError('verification failed')
            os.replace(temp,path)
            if os.name!='nt':
                parent=os.open(self.directory,os.O_RDONLY)
                try:os.fsync(parent)
                finally:os.close(parent)
        finally:
            if fd is not None:os.close(fd)
            temp.unlink(missing_ok=True)

    def save(self,state):
        raw=json.dumps(state,ensure_ascii=True,separators=(',',':'),allow_nan=False).encode('utf-8')
        if len(raw)>MAX_STATE_BYTES:raise ValueError('oversized state')
        self._decode(raw);self._ensure()
        with private.locked_chain(self.directory,private_base=self.directory):
            try:
                old=self._read(self.path,MAX_STATE_BYTES);self._decode(old)
            except FileNotFoundError:old=None
            except ValueError:old=None
            if old is not None:self._atomic(self.previous,old)
            self._atomic(self.path,raw)

    def evidence(self,snapshot):
        # Raw source evidence stays private; no personal file reads or hashing.
        raw=json.dumps(snapshot,ensure_ascii=True,separators=(',',':'),allow_nan=False).encode('utf-8')+b'\n'
        if len(raw)>MAX_EVIDENCE_BYTES:
            raw=b'{"truncated":true,"error":"EVIDENCE_OVERSIZED"}\n'
        self._ensure()
        with private.locked_chain(self.directory,private_base=self.directory):
            current=self.directory/'evidence-0.jsonl'
            try:previous=self._read(current,MAX_EVIDENCE_BYTES)
            except FileNotFoundError:previous=b''
            # The checked existing file, not an in-memory cache, is authoritative.
            if previous.endswith(b'\n') and previous.rsplit(b'\n',2)[-2]+b'\n'==raw:return
            if len(previous)+len(raw)>MAX_EVIDENCE_BYTES:
                for index in (3,2,1):
                    prior=self.directory/('evidence-'+str(index-1)+'.jsonl')
                    destination=self.directory/('evidence-'+str(index)+'.jsonl')
                    try:old=self._read(prior,MAX_EVIDENCE_BYTES)
                    except FileNotFoundError:continue
                    self._atomic(destination,old)
                previous=b''
            self._atomic(current,previous+raw)

class SecurityMonitor:
    def __init__(self,data_root,source,wifi_query=None,clock=None,interval_seconds=60):
        self.source=source;self.wifi_query=wifi_query;self.clock=clock or (lambda:datetime.now(timezone.utc))
        self.interval_seconds=max(1,float(interval_seconds));self._lock=threading.RLock();self._poll_lock=threading.Lock();self._stop=threading.Event();self._thread=None
        self.store=PrivateMonitorStore(data_root);state,corrupt=self.store.load()
        self._state=state or {'schema':1,'initialized':False,'epoch':str(uuid.uuid4()),'cursor':None,'cases':[],'health':{},'lastCheckedAt':None,'disabledSince':None,'wifiState':'UNKNOWN','monitorState':'STARTING'}
        self._ephemeral=[];self._ephemeral_seen=set()
        if corrupt:
            self._state['initialized']=False;self._state['cursor']=None;self._state['epoch']=str(uuid.uuid4());self._state['monitorState']='DEGRADED'
            self._health(self._state,'STATE_CORRUPT',self._now(),'UNKNOWN')

    def _now(self):
        now=self.clock()
        if not isinstance(now,datetime) or now.tzinfo is None:raise ValueError('clock must be aware')
        return now.astimezone(timezone.utc)

    @staticmethod
    def _case_key(case):
        return (case['EVENT_SOURCE'],case['EVENT_ID'],case['RECORD_ID'],case['DETECTED_AT'])

    def _add(self,state,case):
        case=public_case(case)
        if 'CASE_OVERFLOW' in case['REASON_CODES'] and len(state['cases'])<MAX_CASES and not any('CASE_OVERFLOW' in c['REASON_CODES'] for c in state['cases']):
            state['cases'].append(case);return case['CASE_ID']
        if case['EVENT_SOURCE']=='MICROSOFT_DEFENDER':
            existing=next((c for c in state['cases'] if self._case_key(c)==self._case_key(case)),None)
            if existing:return existing['CASE_ID']
        if len(state['cases'])<MAX_CASES-1:state['cases'].append(case);return case['CASE_ID']
        acknowledged=next((c for c in state['cases'] if c['ACKNOWLEDGED'] and 'CASE_OVERFLOW' not in c['REASON_CODES']),None)
        if acknowledged:
            state['cases'].remove(acknowledged);state['cases'].append(case);return case['CASE_ID']
        overflow=next((c for c in state['cases'] if 'CASE_OVERFLOW' in c['REASON_CODES']),None)
        if overflow is None:
            overflow=health_case('CASE_OVERFLOW',self._now(),state['wifiState']);overflow['OVERFLOW_COUNT']=0;state['cases'].append(overflow)
        overflow['OVERFLOW_COUNT']=min(overflow.get('OVERFLOW_COUNT',0)+1,2**63-1)
        if case['ALERT_LEVEL']=='CRITICAL':overflow['ALERT_LEVEL']='CRITICAL'
        overflow['ACKNOWLEDGED']=False
        return overflow['CASE_ID']

    def _health(self,state,reason,now,wifi):
        cid=state['health'].get(reason)
        existing=next((c for c in state['cases'] if c['CASE_ID']==cid),None)
        if existing:return
        state['health'][reason]=self._add(state,health_case(reason,now,wifi))

    def _commit(self,state):
        self.store.save(state);self._state=state;self._ephemeral=[];self._ephemeral_seen.clear()

    def _failed(self,candidate=None,critical_keys=(),original_evidence_saved=False):
        # _state remains the last durable state/cursor. This bounded overlay is
        # display-only until a later evidence write and state commit both succeed.
        visible=copy.deepcopy(self._state)
        if self._ephemeral:visible['cases']=copy.deepcopy(self._ephemeral)
        durable={c['CASE_ID']:c for c in self._state['cases']}
        for case in candidate['cases'] if candidate else []:
            if case['ALERT_LEVEL']!='CRITICAL' or case['ACKNOWLEDGED']:continue
            if durable.get(case['CASE_ID'])==case:continue
            retained=public_case(case)
            for code in ('EVIDENCE_NOT_SAVED',)+(() if original_evidence_saved else ('ORIGINAL_RAW_EVIDENCE',)):
                if code not in retained['MISSING_EVIDENCE']:retained['MISSING_EVIDENCE'].append(code)
            existing=next((c for c in visible['cases'] if c['CASE_ID']==retained['CASE_ID']),None)
            if existing is not None:visible['cases'][visible['cases'].index(existing)]=retained
            else:self._add(visible,retained)
        warning=next((c for c in visible['cases'] if 'STATE_WRITE_FAILED' in c['REASON_CODES']),None)
        if warning is None:
            cid=self._add(visible,health_case('STATE_WRITE_FAILED',self._now(),self._state['wifiState']))
            warning=next(c for c in visible['cases'] if c['CASE_ID']==cid)
            if 'STATE_WRITE_FAILED' not in warning['REASON_CODES']:warning['REASON_CODES'].append('STATE_WRITE_FAILED')
        warning['ACKNOWLEDGED']=False
        self._ephemeral=[public_case(c) for c in visible['cases']]
        # Source batches are capped at 2048; aggregate overflow remains bounded
        # and visible even once exact replay identities reach this memory cap.
        for key in critical_keys:
            if len(self._ephemeral_seen)<2048:self._ephemeral_seen.add(key)
        self._state['monitorState']='DEGRADED'

    def start(self):
        with self._lock:
            if self._thread and self._thread.is_alive():return
            self._stop.clear();self._thread=threading.Thread(target=self._run,name='SecurityMonitor',daemon=True);self._thread.start()

    def _run(self):
        while not self._stop.is_set():
            try:self.poll_once()
            except Exception:
                with self._lock:self._failed()
            self._stop.wait(self.interval_seconds)

    def stop(self):
        self._stop.set()
        if self._thread and self._thread is not threading.current_thread():self._thread.join(timeout=2)

    def poll_once(self):
        # A single collector may be active; snapshots only take the short state lock.
        if not self._poll_lock.acquire(blocking=False):return
        try:
            with self._lock:cursor=self._state['cursor'] if self._state['initialized'] else None
            try:snapshot=self.source.collect(cursor)
            except Exception:snapshot={'available':False,'error':'SOURCE_UNAVAILABLE'}
            now=self._now();wifi='UNKNOWN'
            if self.wifi_query:
                try:
                    value=self.wifi_query();wifi=value if value in WIFI_STATES else 'UNKNOWN'
                except Exception:pass
            with self._lock:
                s=copy.deepcopy(self._state);s.update(lastCheckedAt=now.isoformat(),wifiState=wifi,monitorState='OK')
                if self._ephemeral:s['cases']=copy.deepcopy(self._ephemeral)
                critical_keys=[]
                if not isinstance(snapshot,dict) or type(snapshot.get('available')) is not bool:
                    snapshot={'available':False,'error':'INVALID_SNAPSHOT'}
                if not snapshot.get('available'):
                    s['monitorState']='DEGRADED';self._health(s,'MONITOR_UNAVAILABLE',now,wifi)
                elif not self._valid_snapshot(snapshot):
                    s['monitorState']='DEGRADED';self._health(s,'INVALID_SNAPSHOT',now,wifi)
                else:
                    p=snapshot['protection'];safe_protection=protection_state(p)
                    disabled=p.get('RealTimeProtectionEnabled') is False
                    if disabled and not s['disabledSince']:s['disabledSince']=now.isoformat()
                    elif not disabled:s['disabledSince']=None
                    issues=[]
                    if safe_protection['SERVICE_STATUS']=='STOPPED' or disabled:issues.append('PROTECTION_UNHEALTHY')
                    if safe_protection['SERVICE_STATUS']=='UNKNOWN' or safe_protection['REAL_TIME_PROTECTION']=='UNKNOWN':issues.append('PROTECTION_UNKNOWN')
                    if snapshot.get('sourceErrors') or snapshot['watermark'] is None:issues.append('SOURCE_PARTIAL')
                    for reason in issues:self._health(s,reason,now,wifi)
                    if issues:s['monitorState']='DEGRADED'
                    reset=snapshot.get('logReset') is True or (cursor is not None and snapshot['watermark'] is not None and snapshot['watermark']<cursor)
                    if reset:
                        s['epoch']=str(uuid.uuid4());s['monitorState']='DEGRADED';self._health(s,'LOG_RESET',now,wifi)
                    if s['initialized'] and not reset and snapshot['watermark'] is not None:
                        fresh=[e for e in snapshot['events'] if integer(e.get('recordId'))!='UNKNOWN' and (cursor is None or integer(e['recordId'])>cursor)]
                        # Deduplicate repeated record IDs even when a source returns them twice.
                        unique={e['recordId']:e for e in fresh}
                        batch=dict(snapshot,events=list(unique.values()))
                        for case in correlate_snapshot(batch,now,wifi,instant(s['disabledSince'])):
                            key=self._case_key(case)
                            if key in self._ephemeral_seen:continue
                            self._add(s,case)
                            if case['ALERT_LEVEL']=='CRITICAL':critical_keys.append(key)
                    if snapshot['watermark'] is not None:
                        s['initialized']=True;s['cursor']=snapshot['watermark']
                    elif reset:
                        s['initialized']=False;s['cursor']=None
                    # A proven healthy interval rearms runtime health warnings. Existing
                    # cases remain saved; a continuous outage retains its fingerprint.
                    if s['monitorState']=='OK':
                        for reason in ('MONITOR_UNAVAILABLE','INVALID_SNAPSHOT','PROTECTION_UNHEALTHY','PROTECTION_UNKNOWN','SOURCE_PARTIAL','STATE_CORRUPT','LOG_RESET'):
                            s['health'].pop(reason,None)
                original_evidence_saved=False
                try:
                    self.store.evidence(snapshot);original_evidence_saved=True
                    recovered=[public_case(c) for c in s['cases'] if 'EVIDENCE_NOT_SAVED' in c['MISSING_EVIDENCE']]
                    if recovered:
                        # Public facts can be recovered even when the original raw
                        # collection was lost. Its separate missing marker remains.
                        self.store.evidence({'recoveredSanitizedCases':recovered})
                        for case in s['cases']:
                            case['MISSING_EVIDENCE']=[code for code in case['MISSING_EVIDENCE'] if code!='EVIDENCE_NOT_SAVED']
                    self._commit(s)
                except Exception:self._failed(s,critical_keys,original_evidence_saved)
        finally:self._poll_lock.release()

    @staticmethod
    def _valid_snapshot(s):
        if not isinstance(s.get('error'),str) or s.get('error') not in SOURCE_ERRORS or type(s.get('logReset')) is not bool:return False
        if s.get('watermark') is not None and (type(s.get('watermark')) is not int or integer(s.get('watermark'))=='UNKNOWN'):return False
        if not isinstance(s.get('protection'),dict):return False
        scalar=(str,int,float,bool,type(None))
        if any(not isinstance(k,str) or not isinstance(v,scalar) for k,v in s['protection'].items()):return False
        if not all(isinstance(s.get(k),list) for k in ('events','threats','detections','sourceErrors')):return False
        if len(s['events'])>2048 or len(s['threats'])>1024 or len(s['detections'])>1024:return False
        allowed_errors={'EVENT_LOG_UNAVAILABLE','STATUS_UNAVAILABLE','THREATS_UNAVAILABLE','DETECTIONS_UNAVAILABLE','SERVICE_UNAVAILABLE','TRUNCATED','LOG_RESET'}
        if len(s['sourceErrors'])>8 or any(not isinstance(e,str) or e not in allowed_errors for e in s['sourceErrors']):return False
        for row in s['threats']+s['detections']:
            if not isinstance(row,dict):return False
            for key,value in row.items():
                if not isinstance(key,str):return False
                if key=='Resources':
                    if not isinstance(value,list) or len(value)>256 or any(not isinstance(v,str) for v in value):return False
                elif not isinstance(value,scalar):return False
        for event in s['events']:
            if not isinstance(event,dict) or type(event.get('eventId')) is not int or type(event.get('recordId')) is not int or integer(event.get('recordId'))=='UNKNOWN' or not isinstance(event.get('data'),dict):return False
            if any(not isinstance(k,str) or not isinstance(v,scalar) for k,v in event['data'].items()):return False
            if s['watermark'] is not None and event['recordId']>s['watermark']:return False
        return True

    def snapshot(self):
        with self._lock:
            cases=[public_case(c) for c in (self._ephemeral or self._state['cases'])]
            return {'schemaVersion':1,'mode':'MONITOR_ONLY','monitorState':self._state['monitorState'],'autoIsolationEnabled':False,'lastCheckedAt':self._state['lastCheckedAt'],'wifiState':self._state['wifiState'],'unacknowledgedCount':sum(not c['ACKNOWLEDGED'] for c in cases),'cases':cases}

    def acknowledge(self,case_id):
        with self._lock:
            if self._ephemeral:return False
            s=copy.deepcopy(self._state);case=next((c for c in s['cases'] if c['CASE_ID']==case_id),None)
            if not case:return False
            case['ACKNOWLEDGED']=True
            try:self._commit(s);return True
            except Exception:self._failed();return False

    def prepare_isolation(self,case_id):
        with self._lock:
            if self._ephemeral:return False
            s=copy.deepcopy(self._state);case=next((c for c in s['cases'] if c['CASE_ID']==case_id),None)
            if not case or case['ACKNOWLEDGED'] or case['ALERT_LEVEL']!='CRITICAL' or case['ISOLATION_RESULT']!='DISABLED':return False
            # Aggregated overflow is visible but lacks a unique actionable evidence identity.
            if 'CASE_OVERFLOW' in case['REASON_CODES']:return False
            case['ISOLATION_RESULT']='PREPARED'
            try:self._commit(s);return True
            except Exception:
                self._failed();raise OSError('EVIDENCE_NOT_SAVED') from None

    def finish_isolation(self,case_id,result,wifi_state,error_code='NONE'):
        with self._lock:
            if self._ephemeral:raise OSError('EVIDENCE_WRITE_FAILED')
            s=copy.deepcopy(self._state);case=next((c for c in s['cases'] if c['CASE_ID']==case_id),None)
            if not case or case['ISOLATION_RESULT']=='DISABLED':return
            case['ISOLATION_RESULT']=result if result in {'OFF_VERIFIED','ISOLATION_FAILED','UNKNOWN'} else 'UNKNOWN'
            case['WIFI_STATE']=wifi_state if wifi_state in WIFI_STATES else 'UNKNOWN'
            if case['ISOLATION_RESULT']=='OFF_VERIFIED' and case['WIFI_STATE']!='OFF':case['ISOLATION_RESULT']='UNKNOWN'
            safe=error_code if error_code in ISOLATION_ERRORS else globals()['error_code'](error_code)
            # Keep remediation error independent of isolation, and expose only fixed enums.
            case['ISOLATION_ERROR_CODE']=safe
            s['wifiState']=case['WIFI_STATE']
            try:self._commit(s)
            except Exception:
                self._failed();raise OSError('EVIDENCE_WRITE_FAILED') from None






