# AOSP CellBroadcastReceiver ETWS earthquake sound
Android Open Source Project / CellBroadcastReceiver.
Source repository: platform/packages/apps/CellBroadcastReceiver.
Source commit: e7de1a7cb4655bcda5669782fd60d51de7a95068
Original path: res/raw-ja/etws_earthquake.ogg
Original SHA-256: D4CB01BA2FA34044AB37D824A222CB9580E17BE2808274CCA35B51F877C6B7A7
Original size: 106833 bytes.
Acquired (UTC): 2026-10-24T19:19:34+00:00
License: Apache License 2.0 (Apache-2.0).
Source: https://android.googlesource.com/platform/packages/apps/CellBroadcastReceiver/+/e7de1a7cb4655bcda5669782fd60d51de7a95068/res/raw-ja/etws_earthquake.ogg
The OGG is distributed byte-for-byte without modification or conversion.
NOTICE is the verbatim upstream NOTICE at that commit. LICENSE is a copy of the same upstream document, which contains the complete Apache License 2.0 and AOSP copyright attribution. MODULE_LICENSE_APACHE2 in that commit confirms the module license.
Family Dashboard is an independent application; AOSP/Android attribution describes the asset source and does not imply endorsement or an official Android product.
The asset is installed at app/assets/eew/etws_earthquake.ogg; no runtime AOSP access is used.
