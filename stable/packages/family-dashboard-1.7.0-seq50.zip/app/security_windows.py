"""Bounded, fixed, read-only Defender acquisition for the console user."""
from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import sys

POWERSHELL = Path(r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe")
COLLECTOR = Path(r"C:\FamilyDashboard\launcher\Read-DefenderSecuritySnapshot.ps1")
MAX_SNAPSHOT_BYTES=524288
ERRORS={"NONE","ACCESS_DENIED","SOURCE_UNAVAILABLE","TIMEOUT","INVALID_SNAPSHOT"}
SOURCE_ERRORS={"EVENT_LOG_UNAVAILABLE","STATUS_UNAVAILABLE","THREATS_UNAVAILABLE",
               "DETECTIONS_UNAVAILABLE","SERVICE_UNAVAILABLE","TRUNCATED","LOG_RESET"}
KEYS={"available","error","watermark","logReset","events","threats","detections","protection","sourceErrors"}

def _unavailable(code):
    return {"available":False,"error":code,"watermark":None,"logReset":False,
            "events":[],"threats":[],"detections":[],"protection":{},"sourceErrors":[]}

def _pairs(pairs):
    result={}
    for key,value in pairs:
        if key in result: raise ValueError("Duplicate field")
        result[key]=value
    return result

class WindowsDefenderSource:
    def __init__(self, *, runner=None, platform=None, collector=COLLECTOR):
        self._run=runner or subprocess.run
        self._platform=sys.platform if platform is None else platform
        self._collector=Path(collector)

    def collect(self, after_record_id):
        if after_record_id is not None and (type(after_record_id) is not int or not 0<=after_record_id<2**63):
            return _unavailable("INVALID_SNAPSHOT")
        if self._platform!="win32": return _unavailable("SOURCE_UNAVAILABLE")
        argv=[str(POWERSHELL),"-NoLogo","-NoProfile","-NonInteractive",
              "-ExecutionPolicy","Bypass","-File",str(self._collector)]
        if after_record_id is not None: argv+=["-AfterRecordId",str(after_record_id)]
        env=dict(os.environ)
        env["PSModulePath"]=r"C:\Windows\System32\WindowsPowerShell\v1.0\Modules;C:\Program Files\WindowsPowerShell\Modules"
        env["PATH"]=r"C:\Windows\System32;C:\Windows"
        try:
            completed=self._run(argv,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,shell=False,timeout=15,env=env,
                creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
            if completed.returncode:
                return _unavailable("ACCESS_DENIED" if completed.returncode==5 else "SOURCE_UNAVAILABLE")
            raw=completed.stdout
            if not isinstance(raw,bytes) or not 1<=len(raw)<=MAX_SNAPSHOT_BYTES:
                return _unavailable("INVALID_SNAPSHOT")
            value=json.loads(raw.decode("utf-8-sig"),object_pairs_hook=_pairs,
                parse_constant=lambda _x: (_ for _ in ()).throw(ValueError("Invalid JSON")))
            if not isinstance(value,dict) or set(value)!=KEYS: raise ValueError()
            if type(value["available"]) is not bool or type(value["logReset"]) is not bool: raise ValueError()
            if value["error"] not in ERRORS: raise ValueError()
            watermark=value["watermark"]
            if watermark is not None and (type(watermark) is not int or not 0<=watermark<2**63): raise ValueError()
            if value["available"] and watermark is None: raise ValueError()
            for field,maximum in [("events",32),("threats",32),("detections",64)]:
                if not isinstance(value[field],list) or len(value[field])>maximum or not all(isinstance(x,dict) for x in value[field]):
                    raise ValueError()
            if not isinstance(value["protection"],dict) or len(value["protection"])>24: raise ValueError()
            if (not isinstance(value["sourceErrors"],list) or len(value["sourceErrors"])>8 or
                any(x not in SOURCE_ERRORS for x in value["sourceErrors"])): raise ValueError()
            return value
        except subprocess.TimeoutExpired: return _unavailable("TIMEOUT")
        except PermissionError: return _unavailable("ACCESS_DENIED")
        except (OSError,ValueError,UnicodeError,TypeError,AttributeError):
            return _unavailable("INVALID_SNAPSHOT")
