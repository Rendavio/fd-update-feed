"""Native Wi-Fi software radio control; production containment remains disabled.

No radio handles are opened on import/construction. No ON operation, adapter
disable, shell, task, elevation or remote control is implemented here.
"""
from __future__ import annotations

import contextlib
import ctypes
import sys
from typing import Any

AUTO_ISOLATION_ENABLED = False
DEVICE_RECOVERY_VALIDATED = False
MAX_INTERFACES = 16
MAX_PHYS = 64

class RadioUnavailable(RuntimeError):
    def __init__(self, code="RADIO_UNAVAILABLE"):
        self.code = code
        super().__init__("Native Wi-Fi operation unavailable")

def _error_code(exc):
    code = getattr(exc, "winerror", None) or getattr(exc, "errno", None)
    if type(code) is int and 0 <= code <= 0xFFFFFFFF:
        return f"0x{code:08X}"
    code = getattr(exc, "code", None)
    return code if code in {"RADIO_UNAVAILABLE","INVALID_RADIO_STATE"} else "RADIO_UNAVAILABLE"

class _Guid(ctypes.Structure):
    _fields_ = [("bytes", ctypes.c_ubyte * 16)]

class _InterfaceInfo(ctypes.Structure):
    _fields_ = [("guid", _Guid), ("description", ctypes.c_wchar * 256),
                ("state", ctypes.c_uint32)]

class _PhyState(ctypes.Structure):
    _fields_ = [("index", ctypes.c_uint32), ("software", ctypes.c_uint32),
                ("hardware", ctypes.c_uint32)]

class CtypesWlanBackend:
    """Fixed Native Wifi calls, no interface names/addresses exposed publicly."""
    def __init__(self):
        if sys.platform != "win32":
            raise RadioUnavailable()
        self.dll = ctypes.WinDLL("wlanapi.dll", use_last_error=True)
        d, p = ctypes.c_uint32, ctypes.c_void_p
        signatures = {
            "WlanOpenHandle": ([d,p,ctypes.POINTER(d),ctypes.POINTER(p)],d),
            "WlanCloseHandle": ([p,p],d),
            "WlanEnumInterfaces": ([p,p,ctypes.POINTER(p)],d),
            "WlanQueryInterface": ([p,ctypes.POINTER(_Guid),d,p,ctypes.POINTER(d),ctypes.POINTER(p),p],d),
            "WlanSetInterface": ([p,ctypes.POINTER(_Guid),d,d,p,p],d),
            "WlanFreeMemory": ([p],None),
        }
        for name,(args,result) in signatures.items():
            func = getattr(self.dll,name); func.argtypes=args; func.restype=result

    @contextlib.contextmanager
    def _handle(self):
        handle=ctypes.c_void_p(); version=ctypes.c_uint32()
        code=self.dll.WlanOpenHandle(2,None,ctypes.byref(version),ctypes.byref(handle))
        if code: raise OSError(code,"Native Wifi unavailable")
        try: yield handle
        finally: self.dll.WlanCloseHandle(handle,None)

    @staticmethod
    def _guid(value):
        if not isinstance(value,bytes) or len(value)!=16:
            raise RadioUnavailable("INVALID_RADIO_STATE")
        return _Guid.from_buffer_copy(value)

    def enumerate_interfaces(self):
        with self._handle() as handle:
            data=ctypes.c_void_p()
            code=self.dll.WlanEnumInterfaces(handle,None,ctypes.byref(data))
            if code: raise OSError(code,"Native Wifi unavailable")
            try:
                if not data: raise RadioUnavailable()
                count=ctypes.c_uint32.from_address(data.value).value
                if not 1<=count<=MAX_INTERFACES: raise RadioUnavailable("INVALID_RADIO_STATE")
                return [bytes(_InterfaceInfo.from_address(data.value+8+i*ctypes.sizeof(_InterfaceInfo)).guid)
                        for i in range(count)]
            finally:
                if data: self.dll.WlanFreeMemory(data)

    def query_radio(self, interface):
        guid=self._guid(interface)
        with self._handle() as handle:
            size=ctypes.c_uint32(); data=ctypes.c_void_p()
            # WLAN_INTF_OPCODE radio_state == 4.
            code=self.dll.WlanQueryInterface(handle,ctypes.byref(guid),4,None,
                ctypes.byref(size),ctypes.byref(data),None)
            if code: raise OSError(code,"Native Wifi unavailable")
            try:
                if not data or size.value<4: raise RadioUnavailable("INVALID_RADIO_STATE")
                count=ctypes.c_uint32.from_address(data.value).value
                if not 1<=count<=MAX_PHYS or size.value<4+count*ctypes.sizeof(_PhyState):
                    raise RadioUnavailable("INVALID_RADIO_STATE")
                values={0:"UNKNOWN",1:"ON",2:"OFF"}
                rows=[]
                for i in range(count):
                    phy=_PhyState.from_address(data.value+4+i*ctypes.sizeof(_PhyState))
                    rows.append({"phyIndex":phy.index,"softwareState":values.get(phy.software,"UNKNOWN"),
                                 "hardwareState":values.get(phy.hardware,"UNKNOWN")})
                return rows
            finally:
                if data: self.dll.WlanFreeMemory(data)

    def set_software_off(self, interface, phy_index):
        guid=self._guid(interface)
        if type(phy_index) is not int or not 0<=phy_index<MAX_PHYS:
            raise RadioUnavailable("INVALID_RADIO_STATE")
        state=_PhyState(phy_index,2,0)  # hardware member ignored by the API.
        with self._handle() as handle:
            code=self.dll.WlanSetInterface(handle,ctypes.byref(guid),4,
                ctypes.sizeof(state),ctypes.byref(state),None)
            if code: raise OSError(code,"Native Wifi unavailable")

class NativeWifiRadio:
    def __init__(self, backend=None):
        self._backend=backend

    def _api(self):
        if self._backend is None: self._backend=CtypesWlanBackend()
        return self._backend

    def _snapshot(self):
        api=self._api()
        interfaces=api.enumerate_interfaces()
        if not isinstance(interfaces,list) or not 1<=len(interfaces)<=MAX_INTERFACES:
            raise RadioUnavailable("INVALID_RADIO_STATE")
        result=[]
        for interface in interfaces:
            phys=api.query_radio(interface)
            if not isinstance(phys,list) or not 1<=len(phys)<=MAX_PHYS:
                raise RadioUnavailable("INVALID_RADIO_STATE")
            seen=set()
            for row in phys:
                if (not isinstance(row,dict) or type(row.get("phyIndex")) is not int or
                    not 0<=row["phyIndex"]<MAX_PHYS or row["phyIndex"] in seen or
                    row.get("softwareState") not in {"ON","OFF","UNKNOWN"} or
                    row.get("hardwareState") not in {"ON","OFF","UNKNOWN"}):
                    raise RadioUnavailable("INVALID_RADIO_STATE")
                seen.add(row["phyIndex"])
            result.append((interface,phys))
        return result

    @staticmethod
    def _state(snapshot):
        states=[p for _,rows in snapshot for p in rows]
        if all(p["softwareState"]=="OFF" or p["hardwareState"]=="OFF" for p in states):
            return "OFF"
        if any(p["softwareState"]=="ON" and p["hardwareState"]=="ON" for p in states):
            return "ON"
        return "UNKNOWN"

    def query_state(self):
        try: return self._state(self._snapshot())
        except Exception: return "UNKNOWN"

    def software_off(self):
        """Only a gated coordinator may call; never invoked by the server."""
        try:
            before=self._snapshot()
            if any(p["softwareState"]=="UNKNOWN" for _,rows in before for p in rows):
                raise RadioUnavailable("INVALID_RADIO_STATE")
            error="NONE"
            for interface,phys in before:
                for phy in phys:
                    if phy["softwareState"]=="OFF": continue
                    try: self._api().set_software_off(interface,phy["phyIndex"])
                    except Exception as exc: error=_error_code(exc)
            after=self._snapshot()
            # Interface/PHY disappearance is not evidence of successful OFF.
            identity=lambda rows: [(i,tuple(p["phyIndex"] for p in ps)) for i,ps in rows]
            verified=(identity(before)==identity(after) and
                all(p["softwareState"]=="OFF" for _,ps in after for p in ps))
            return {"result":"OFF_VERIFIED" if verified else "ISOLATION_FAILED",
                    "wifiState":self._state(after),
                    "errorCode":"NONE" if verified else (error if error!="NONE" else "INVALID_RADIO_STATE")}
        except Exception as exc:
            return {"result":"ISOLATION_FAILED","wifiState":"UNKNOWN","errorCode":_error_code(exc)}

class IsolationCoordinator:
    """Fixed OFF-only operation, with two gates and durable one-attempt claim.

    Production does not instantiate an enabled coordinator. Constructor overrides
    exist for mock tests and a future separately reviewed device integration.
    """
    def __init__(self, store, radio, *, enabled=AUTO_ISOLATION_ENABLED,
                 recovery_validated=DEVICE_RECOVERY_VALIDATED):
        self.store=store; self.radio=radio
        self.enabled=enabled is True and recovery_validated is True

    def isolate(self, case_id):
        if not self.enabled:
            return {"result":"DISABLED","wifiState":"UNKNOWN","errorCode":"NONE"}
        try:
            if not self.store.prepare_isolation(case_id):
                return {"result":"NOT_REQUESTED","wifiState":"UNKNOWN","errorCode":"NONE"}
        except Exception:
            return {"result":"ISOLATION_FAILED","wifiState":"UNKNOWN","errorCode":"EVIDENCE_NOT_SAVED"}
        try: result=self.radio.software_off()
        except Exception as exc:
            result={"result":"ISOLATION_FAILED","wifiState":"UNKNOWN","errorCode":_error_code(exc)}
        if (not isinstance(result,dict) or result.get("result") not in {"OFF_VERIFIED","ISOLATION_FAILED"} or
                result.get("wifiState") not in {"ON","OFF","UNKNOWN"}):
            result={"result":"ISOLATION_FAILED","wifiState":"UNKNOWN","errorCode":"INVALID_RADIO_STATE"}
        try:
            self.store.finish_isolation(case_id,result["result"],result["wifiState"],result.get("errorCode","NONE"))
        except Exception:
            return {"result":"ISOLATION_FAILED","wifiState":result["wifiState"],"errorCode":"EVIDENCE_WRITE_FAILED"}
        return result
