"""Independent source facade. No collection, commands or containment in API reads."""
import re,uuid
from datetime import datetime,timezone
from security_events import instant,public_case
from behavior_events import public_behavior_case,make_case,LIMITS
def _metadata(value):
 value=value if isinstance(value,dict) else {};result={}
 for key,allowed in [('monitorState',{'OK','DEGRADED','STARTING','NOT_AVAILABLE'}),('baselineTrust',{'OBSERVED_UNREVIEWED','INTEGRITY_FAILED','NOT_AVAILABLE'}),('baselineQuality',{'COMPLETE_UNREVIEWED','PARTIAL_UNREVIEWED','INTEGRITY_FAILED','NOT_AVAILABLE'})]:
  v=value.get(key);result[key]=v if isinstance(v,str) and v in allowed else 'NOT_AVAILABLE'
 for key in ('lastCheckedAt','baselineObservedAt'):
  v=instant(value.get(key));result[key]=v.isoformat() if v else None
 try:result['baselineId']=str(uuid.UUID(value.get('baselineId')))
 except Exception:result['baselineId']='UNKNOWN'
 for key in ('osVersion','appVersion'):
  v=value.get(key);result[key]=v if isinstance(v,str) and len(v)<=64 and re.fullmatch(r'[0-9]+(?:[.][0-9A-Za-z]+){0,5}',v) else 'UNKNOWN'
 result['coverage']={};result['sectionObservedAt']={}
 for key in ('processes','network','persistence','security','integrity'):
  cov=value.get('coverage',{});v=cov.get(key) if isinstance(cov,dict) else None;result['coverage'][key]=v if isinstance(v,str) and v in {'OK','PARTIAL','UNAVAILABLE','NOT_COLLECTED'} else 'UNAVAILABLE'
  times=value.get('sectionObservedAt',{});at=instant(times.get(key)) if isinstance(times,dict) else None;result['sectionObservedAt'][key]=at.isoformat() if at else None
 count=value.get('stableObservations');result['stableObservations']=min(65535,max(0,count)) if type(count) is int else 0;result['limits']=dict(LIMITS);return result

class UnifiedSecurityMonitor:
 def __init__(self,defender,behavior):self.defender=defender;self.behavior=behavior;self.failed=set();self.start_failed=set();self.health_cases={}
 def start(self):
  for name,monitor in [('defender',self.defender),('behavior',self.behavior)]:
   try:monitor.start()
   except Exception:self.start_failed.add(name)
 def stop(self):
  for monitor in (self.defender,self.behavior):
   try:monitor.stop()
   except Exception:pass
 def _read(self,name,monitor):
  try:
   value=monitor.snapshot();cap=32 if name=='defender' else 16
   if not isinstance(value,dict) or value.get('monitorState') not in ('OK','DEGRADED','STARTING','NOT_AVAILABLE') or not isinstance(value.get('cases'),list) or len(value['cases'])>cap:raise ValueError()
   if value.get('lastCheckedAt') is not None and instant(value.get('lastCheckedAt')) is None:raise ValueError()
   for case in value['cases']:
    if not isinstance(case,dict) or str(uuid.UUID(case.get('CASE_ID')))!=case.get('CASE_ID') or not instant(case.get('DETECTED_AT')):raise ValueError()
   value=dict(value);value['cases']=[public_case(c) if name=='defender' else public_behavior_case(c) for c in value['cases']]
   if name=='behavior':value['behavior']=_metadata(value.get('behavior'))
   self.failed.discard(name);self.health_cases.pop(name,None);return value
  except Exception:
   self.failed.add(name)
   if name=='behavior' and name not in self.health_cases:self.health_cases[name]=make_case(datetime.now(timezone.utc),'SOURCE_DEGRADED',LIMITATIONS=['SOURCE_UNAVAILABLE'],MISSING_EVIDENCE=['EVIDENCE_NOT_SAVED','ORIGINAL_RAW_EVIDENCE'],RECOMMENDED_INVESTIGATION=['CHECK_MONITOR_HEALTH'])
   return {'cases':[self.health_cases[name]] if name in self.health_cases else [],'monitorState':'NOT_AVAILABLE','lastCheckedAt':None}
 def snapshot(self):
  d=self._read('defender',self.defender);b=self._read('behavior',self.behavior)
  dc=d.get('cases',[])[:32];bc=[public_behavior_case(c) for c in b.get('cases',[])[:16]]
  for c in bc:
   c['DEFENDER_REFERENCE']='NOT_LINKED';c['DEFENDER_CASE_ID']='UNKNOWN';sha=c.get('BINARY_SHA256');at=instant(c.get('OBSERVED_AT'))
   if sha!='UNKNOWN' and at:
    matches=[x for x in dc if sha in x.get('RESOURCE_HASHES',[]) and instant(x.get('DETECTED_AT')) and abs((at-instant(x['DETECTED_AT'])).total_seconds())<=300]
    if matches:c['DEFENDER_REFERENCE']='SAME_SHA256_TIME_WINDOW';c['DEFENDER_CASE_ID']=matches[-1]['CASE_ID']
  def priority(c):
   if c.get('ALERT_LEVEL')=='CRITICAL':return 0
   if c.get('EVENT_SOURCE')!='BEHAVIOR_MONITOR':return 1
   if c.get('CONFIDENCE')=='MULTI_SOURCE_IDENTITY_LINKED':return 2
   if 'BASELINE_REVIEW' in c.get('ANOMALY_TYPE',[]):return 5
   if set(c.get('ANOMALY_TYPE',[]))&{'SOURCE_DEGRADED','STATE_WRITE_FAILED','STATE_INTEGRITY_FAILED','STATE_RECOVERED','CASE_OVERFLOW'}:return 4
   return 3
  cases=sorted(dc+bc,key=priority)
  times=[instant(x.get('lastCheckedAt')) for x in (d,b)];checked=min(times).isoformat() if all(times) else None
  state='DEGRADED' if self.failed or self.start_failed or any(x.get('monitorState') not in ('OK','STARTING') for x in (d,b)) else 'STARTING' if any(x.get('monitorState')=='STARTING' for x in (d,b)) else 'OK'
  return {'schemaVersion':1,'mode':'MONITOR_ONLY','autoIsolationEnabled':False,'monitorState':state,'lastCheckedAt':checked,'wifiState':d.get('wifiState','UNKNOWN'),'cases':cases,'unacknowledgedCount':sum(not c.get('ACKNOWLEDGED') for c in cases),'behavior':b.get('behavior',{}),'sourceStates':{'defender':d.get('monitorState','NOT_AVAILABLE'),'behavior':b.get('monitorState','NOT_AVAILABLE')}}
 def acknowledge(self,case_id):
  for name,monitor in [('defender',self.defender),('behavior',self.behavior)]:
   s=self._read(name,monitor)
   if any(c.get('CASE_ID')==case_id for c in s.get('cases',[])):
    try:return monitor.acknowledge(case_id)
    except Exception:return False
  return False
