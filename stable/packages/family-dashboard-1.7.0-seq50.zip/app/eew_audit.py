"""Bounded private EEW metadata. The caller supplies a private app-data root.

No request payload, exception detail, network address or arbitrary text is retained.
I/O errors deliberately propagate for the API boundary to handle without breaking EEW.
"""
import json
import os
import re
import tempfile
import threading
import uuid
from collections import Counter, deque
from datetime import datetime, timedelta, timezone
from pathlib import Path

MAX_FILE_BYTES = 1024 * 1024
MAX_BATCH_ROWS = 32
MAX_ROW_BYTES = 4096
TTL_SECONDS = 600
DELAY_SECONDS = 45
JST = timezone(timedelta(hours=9))
_LOCK = threading.RLock()
_ENUMS = {
    "soundRole": {"production", "training", "development"},
    "audioBackend": {"private_asset", "builtin_asset", "existing_tone"},
    "audioPhase": {"requested", "asset", "fallback", "resume", "scheduled", "cancelled", "completed"},
    "assetError": {"none", "missing", "unreadable", "invalid", "unsafe_path", "fetch_failed", "decode_failed", "asset_timeout"},
    "cancelReason": {"eew_cancel", "stop_test", "auto_cancel", "superseded", "unattended_cancel", "stale"},
    "kind": {"websocket", "message", "decision", "overlay", "audio", "test"},
    "source": {"p2p", "maintenance_click", "maintenance_unattended", "development"},
    "audioResult": {"played", "blocked", "failed", "cancelled", "timeout", "unsupported"},
    "audioError": {"none", "timeout", "blocked", "cancelled", "unsupported", "failed", "stale"},
    "contextBefore": {"running", "suspended", "closed", "interrupted", "unknown"},
    "contextAfter": {"running", "suspended", "closed", "interrupted", "unknown"},
    "overlay": {"requested", "shown", "cleared", "not_shown"},
    "websocket": {"connected", "disconnected", "reconnecting", "connecting"},
    "reconnectResult": {"pending", "connected", "failed"},
}
_FLAGS = {"cancelled", "tokyo23Matched", "duplicateSuppressed", "audioRequested", "userActivation"}
_FIELDS = set(_ENUMS) | _FLAGS | {"eventId", "serial", "reconnectAttempt"}
_STAMPS = {"receivedAtUtc", "receivedAtJst"}
_EVENT_ID = re.compile(r"(?:[0-9]{14}|TEST-[A-Z0-9_-]{1,75})", re.ASCII)
_SERIAL = re.compile(r"[0-9]{1,6}", re.ASCII)


def _safe_row(row):
    if type(row) is not dict or not {"kind", "source"} <= row.keys() or not row.keys() <= _FIELDS:
        raise ValueError("Invalid EEW audit row")
    for key, value in row.items():
        if key in _ENUMS:
            valid = type(value) is str and value in _ENUMS[key]
        elif key in _FLAGS:
            valid = type(value) is bool
        elif key == "eventId":
            valid = type(value) is str and len(value) <= 80 and _EVENT_ID.fullmatch(value) is not None
        elif key == "serial":
            valid = type(value) is str and _SERIAL.fullmatch(value) is not None
        else:
            valid = type(value) is int and 0 <= value <= 10000
        if not valid:
            raise ValueError("Invalid EEW audit field")
    return dict(row)


def _utcnow():
    return datetime.now(timezone.utc)


def _stamp(now):
    return {"receivedAtUtc": now.isoformat(), "receivedAtJst": now.astimezone(JST).isoformat()}


def _recovered_row(raw):
    if type(raw) is not dict or not _STAMPS <= raw.keys() or not raw.keys() <= _FIELDS | _STAMPS:
        raise ValueError("Invalid EEW audit record")
    row = _safe_row({key: value for key, value in raw.items() if key not in _STAMPS})
    utc = datetime.fromisoformat(raw["receivedAtUtc"])
    jst = datetime.fromisoformat(raw["receivedAtJst"])
    if utc.utcoffset() != timedelta(0) or jst.utcoffset() != timedelta(hours=9) or utc != jst:
        raise ValueError("Invalid EEW audit timestamp")
    row.update(_stamp(utc))
    return row



def _update_source_summary(by_source, pending_activation, row):
    source = row["source"]
    kind = row["kind"]
    event_id = row.get("eventId")
    if kind == "test" and "userActivation" in row and event_id is None:
        pending_activation[source] = row
        return
    if event_id is None or kind not in {"message", "decision", "overlay", "audio", "test"}:
        return
    current = by_source[source]
    if kind == "message" or not current:
        if current.get("eventId") != event_id:
            current = {"eventId": event_id}
            by_source[source] = current
    if current.get("eventId") != event_id:
        # Late audio/overlay completion for a previous event cannot pollute this event.
        return
    if kind == "message" and source in pending_activation:
        current["activation"] = pending_activation.pop(source)
    if kind in {"message", "decision", "overlay", "audio"}:
        current[kind] = row
    if kind == "audio" and row.get("audioPhase") == "fallback":
        current["fallback"] = row
    if kind == "test" and "userActivation" in row:
        current["activation"] = row
    if (
        kind in {"message", "decision"}
        and "tokyo23Matched" in row
        and not row.get("cancelled", False)
        and not current.get("message", {}).get("cancelled", False)
    ):
        current["target"] = row


class EewAuditStore:
    def __init__(self, root):
        self.directory = Path(root) / "eew"
        self._active = self.directory / "audit.jsonl"
        self._state = self.directory / "unattended.json"

    def _paths(self):
        return [self._active] + [self.directory / ("audit." + str(i) + ".jsonl") for i in range(1, 4)]

    def _mkdir(self):
        self.directory.mkdir(parents=True, exist_ok=True, mode=0o700)

    def _rotate(self):
        paths = self._paths()
        paths[-1].unlink(missing_ok=True)
        for index in range(2, -1, -1):
            if paths[index].exists():
                os.replace(paths[index], paths[index + 1])

    def append_many(self, rows):
        if type(rows) is not list or len(rows) > MAX_BATCH_ROWS:
            raise ValueError("Invalid EEW audit batch")
        safe = [_safe_row(row) for row in rows]
        with _LOCK:
            if not safe:
                return {"accepted": 0}
            self._mkdir()
            now = _utcnow()
            for row in safe:
                row.update(_stamp(now))
                line = (json.dumps(row, ensure_ascii=True, separators=(",", ":")) + "\n").encode("ascii")
                if len(line) > MAX_FILE_BYTES:
                    raise ValueError("EEW audit record too large")
                size = self._active.stat().st_size if self._active.exists() else 0
                if size + len(line) > MAX_FILE_BYTES:
                    self._rotate()
                with self._active.open("ab") as stream:
                    stream.write(line)
            return {"accepted": len(safe)}

    def _records(self):
        # Read at most four capped files, never unbounded lines or arbitrary filenames.
        for path in reversed(self._paths()):
            try:
                with path.open("rb") as stream:
                    data = stream.read(MAX_FILE_BYTES)
            except FileNotFoundError:
                continue
            # A partial final line (crash/truncation/cap) is never accepted.
            for line in data.split(b"\n")[:-1]:
                if not line or len(line) > MAX_ROW_BYTES:
                    continue
                try:
                    yield _recovered_row(json.loads(line))
                except (ValueError, TypeError, OverflowError, RecursionError):
                    continue

    def summary(self, limit=20):
        if type(limit) is not int or not 0 <= limit <= 100:
            raise ValueError("Invalid EEW summary limit")
        with _LOCK:
            entries = deque(maxlen=limit)
            counts = Counter()
            latest = {}
            by_source = {source: {} for source in sorted(_ENUMS["source"])}
            pending_activation = {}
            for row in self._records():
                _update_source_summary(by_source, pending_activation, row)
                entries.append(row)
                counts[row["kind"]] += 1
                if row["kind"] in {"websocket", "audio"}:
                    latest[row["kind"]] = row
                if row.get("websocket") == "connected":
                    latest["connected"] = row
                if row["source"] == "p2p" and row["kind"] != "websocket":
                    latest["real"] = row
                elif row["source"] in {"maintenance_click", "maintenance_unattended"}:
                    latest["test"] = row
            stored = 0
            for path in self._paths():
                try:
                    stored += path.stat().st_size
                except FileNotFoundError:
                    pass
            state = self._read_state()
            return {
                "entries": list(reversed(entries)),
                "counts": dict(counts),
                "latest": latest,
                "bySource": by_source,
                "storedBytes": stored,
                "maxBytes": MAX_FILE_BYTES * 4,
                "unattended": state or {"armed": False, "expiresAtUtc": None},
            }

    def _state_result(self, data):
        if type(data) is not dict or set(data) != {"issuedAtUtc", "expiresAtUtc", "testId"}:
            return None
        try:
            if type(data["testId"]) is not str or str(uuid.UUID(data["testId"])) != data["testId"]:
                return None
            issued = datetime.fromisoformat(data["issuedAtUtc"])
            expires = datetime.fromisoformat(data["expiresAtUtc"])
            now = _utcnow()
            if issued.utcoffset() != timedelta(0) or expires.utcoffset() != timedelta(0):
                return None
            if not issued <= now < expires or expires - issued != timedelta(seconds=TTL_SECONDS):
                return None
            return {"armed": True, "delaySeconds": DELAY_SECONDS, "expiresAtUtc": expires.isoformat(), "testId": data["testId"]}
        except (ValueError, TypeError, OverflowError):
            return None

    def _read_state(self, consume=False):
        try:
            with self._state.open("rb") as stream:
                raw = stream.read(MAX_ROW_BYTES + 1)
        except FileNotFoundError:
            return None
        if consume:
            # A second process that read the same file loses its claim here.
            try:
                self._state.unlink()
            except FileNotFoundError:
                return None
        if len(raw) > MAX_ROW_BYTES:
            return None
        try:
            return self._state_result(json.loads(raw))
        except (ValueError, TypeError, RecursionError):
            return None

    def arm_unattended(self):
        with _LOCK:
            self._mkdir()
            now = _utcnow()
            data = {"issuedAtUtc": now.isoformat(), "expiresAtUtc": (now + timedelta(seconds=TTL_SECONDS)).isoformat(), "testId": str(uuid.uuid4())}
            fd, temporary = tempfile.mkstemp(prefix="unattended-", suffix=".tmp", dir=self.directory)
            try:
                with os.fdopen(fd, "w", encoding="ascii") as stream:
                    json.dump(data, stream, separators=(",", ":"))
                    stream.flush()
                    os.fsync(stream.fileno())
                os.replace(temporary, self._state)
            finally:
                Path(temporary).unlink(missing_ok=True)
            return {"armed": True, "delaySeconds": DELAY_SECONDS, "expiresAtUtc": data["expiresAtUtc"], "testId": data["testId"]}

    def consume_unattended(self):
        with _LOCK:
            return self._read_state(consume=True)



    def cancel_unattended(self, test_id):
        if type(test_id) is not str:
            raise ValueError("Invalid test identity")
        try:
            if str(uuid.UUID(test_id)) != test_id:
                raise ValueError()
        except (ValueError, AttributeError):
            raise ValueError("Invalid test identity") from None
        with _LOCK:
            state = self._read_state()
            if not state or state["testId"] != test_id:
                return False
            self._state.unlink(missing_ok=True)
            return True

