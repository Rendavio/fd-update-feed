#requires -Version 5.1
[CmdletBinding()]
param([ValidateRange(-1,9223372036854775807)][long]$AfterRecordId=-1)

function Convert-SecurityUtc($Value) {
    if($null -eq $Value){return $null}
    try { return ([datetimeoffset]$Value).ToUniversalTime().ToString('o') }
    catch { return $null }
}
function Get-SecurityProperty($Item,[string]$Name) {
    $property=$Item.PSObject.Properties[$Name]
    if($null -eq $property){return $null}
    return $property.Value
}
function Convert-SecurityScalar($Value) {
    if($null -eq $Value){return $null}
    if($Value -is [bool]){return $Value}
    if($Value -is [datetime] -or $Value -is [datetimeoffset]){return Convert-SecurityUtc $Value}
    if($Value -is [byte] -or $Value -is [int] -or $Value -is [long] -or
       $Value -is [uint32] -or $Value -is [uint64]){return $Value}
    $text=[string]$Value
    if($text.Length -gt 512){$text=$text.Substring(0,512)}
    return $text
}
function Select-SecurityProperties($Item,[string[]]$Names) {
    $result=[ordered]@{}
    foreach($name in $Names) {
        $value=Get-SecurityProperty $Item $name
        if($name -eq 'Resources') {
            $result[$name]=@($value | Select-Object -First 8 | ForEach-Object {Convert-SecurityScalar $_})
        } else { $result[$name]=Convert-SecurityScalar $value }
    }
    return $result
}
function Test-NoSecurityEvents($ErrorRecord) {
    return ([string]$ErrorRecord.FullyQualifiedErrorId -like 'NoMatchingEventsFound*')
}
function Get-DefenderSecuritySnapshot {
    param([ValidateRange(-1,9223372036854775807)][long]$AfterRecordId=-1)
    $log='Microsoft-Windows-Windows Defender/Operational'
    $errors=New-Object 'Collections.Generic.List[string]'
    $result=[ordered]@{available=$true;error='NONE';watermark=$null;logReset=$false;
        events=@();threats=@();detections=@();protection=[ordered]@{};sourceErrors=@()}
    $latest=0L
    try {
        $entry=@(Get-WinEvent -LogName $log -MaxEvents 1 -ErrorAction Stop)
        if($entry.Count -gt 0){$latest=[long]$entry[0].RecordId}
    } catch {
        if(-not (Test-NoSecurityEvents $_)) {
            $result.available=$false
            $result.error=if($_.Exception -is [UnauthorizedAccessException]){'ACCESS_DENIED'}else{'SOURCE_UNAVAILABLE'}
            $errors.Add('EVENT_LOG_UNAVAILABLE')
        }
    }
    if($result.available) {
        $result.watermark=$latest
        if($AfterRecordId -ge 0 -and $latest -lt $AfterRecordId) {
            $result.logReset=$true; $errors.Add('LOG_RESET')
        } elseif($AfterRecordId -ge 0 -and $latest -gt $AfterRecordId) {
            $xpath="*[System[(EventRecordID > $AfterRecordId and EventRecordID <= $latest) and (EventID=1116 or EventID=1117 or EventID=1118 or EventID=1119 or EventID=5001 or EventID=5007 or EventID=5008)]]"
            $entries=@()
            try { $entries=@(Get-WinEvent -LogName $log -FilterXPath $xpath -Oldest -MaxEvents 32 -ErrorAction Stop) }
            catch {
                if(-not (Test-NoSecurityEvents $_)){
                    $result.available=$false;$result.error='SOURCE_UNAVAILABLE';$result.watermark=$AfterRecordId
                    $errors.Add('EVENT_LOG_UNAVAILABLE')
                }
            }
            foreach($entry in $entries) {
                try {
                    if($entry.ProviderName -cne 'Microsoft-Windows-Windows Defender'){throw 'Unexpected provider'}
                    $raw=[string]$entry.ToXml()
                    if($raw.Length -gt 65536){throw 'Oversized event'}
                    $settings=New-Object System.Xml.XmlReaderSettings
                    $settings.DtdProcessing=[System.Xml.DtdProcessing]::Prohibit
                    $settings.XmlResolver=$null;$settings.MaxCharactersInDocument=65536
                    $reader=[System.Xml.XmlReader]::Create((New-Object IO.StringReader($raw)),$settings)
                    try {
                        $doc=New-Object System.Xml.XmlDocument;$doc.XmlResolver=$null;$doc.Load($reader)
                    } finally { $reader.Dispose() }
                    $fields=[ordered]@{}
                    foreach($node in @($doc.SelectNodes("//*[local-name()='EventData']/*[local-name()='Data']") | Select-Object -First 64)) {
                        $name=[string]$node.GetAttribute('Name')
                        if(-not $name -or $name.Length -gt 96){continue}
                        $text=[string]$node.InnerText
                        if($text.Length -gt 512){$text=$text.Substring(0,512);if(-not $errors.Contains('TRUNCATED')){$errors.Add('TRUNCATED')}}
                        if($fields.Contains($name)){throw 'Duplicate event field'}
                        $fields[$name]=$text
                    }
                    $result.events+=@{eventId=[int]$entry.Id;recordId=[long]$entry.RecordId;
                        at=(Convert-SecurityUtc $entry.TimeCreated);version=[int]$entry.Version;data=$fields}
                } catch {
                    if(-not $errors.Contains('TRUNCATED')){$errors.Add('TRUNCATED')}
                }
            }
            if($entries.Count -eq 32){$result.watermark=[long]$entries[-1].RecordId}
        }
    }
    try {
        $status=Get-MpComputerStatus -ErrorAction Stop
        $names=@('AMServiceEnabled','AntivirusEnabled','RealTimeProtectionEnabled',
            'OnAccessProtectionEnabled','BehaviorMonitorEnabled','IoavProtectionEnabled','NISEnabled','AntivirusSignatureVersion',
            'AntivirusSignatureLastUpdated','AntivirusSignatureAge','AMEngineVersion')
        $result.protection=Select-SecurityProperties $status $names
    } catch { $errors.Add('STATUS_UNAVAILABLE') }
    try {
        $service=Get-Service -Name WinDefend -ErrorAction Stop
        $state=([string]$service.Status).ToUpperInvariant()
        $result.protection['serviceStatus']=if(@('RUNNING','STOPPED') -ccontains $state){$state}else{'UNKNOWN'}
    } catch {
        $result.protection['serviceStatus']='UNKNOWN';$errors.Add('SERVICE_UNAVAILABLE')
    }
    # History queries are only needed for fresh events or currently unhealthy protection.
    $needsThreats=@($result.events).Count -gt 0 -or
        $result.protection['RealTimeProtectionEnabled'] -eq $false -or
        $result.protection['AMServiceEnabled'] -eq $false
    if($needsThreats) {
        $targetIds=New-Object 'Collections.Generic.HashSet[long]'
        foreach($event in @($result.events)) {
            foreach($key in @('Threat ID','ThreatID')) {
                $value=$event.data[$key];$number=0L
                if($null -ne $value -and [long]::TryParse([string]$value,[ref]$number) -and $number -ge 0) {
                    [void]$targetIds.Add($number)
                }
            }
        }
        try {
            $names=@('ThreatID','ThreatName','SeverityID','CategoryID','DidThreatExecute','IsActive','Resources')
            $result.threats=@(Get-MpThreat -ErrorAction Stop |
                Where-Object {$targetIds.Count -eq 0 -or $targetIds.Contains([long](Get-SecurityProperty $_ 'ThreatID'))} |
                Select-Object -First 32 |
                ForEach-Object {Select-SecurityProperties $_ $names})
        } catch {$errors.Add('THREATS_UNAVAILABLE')}
        try {
            $names=@('DetectionID','ThreatID','InitialDetectionTime','LastThreatStatusChangeTime',
                'RemediationTime','ActionSuccess','CleaningActionID','ThreatStatusID',
                'ThreatStatusErrorCode','CurrentThreatExecutionStatusID','DetectionSourceTypeID',
                'AdditionalActionsBitMask','Resources')
            $result.detections=@(Get-MpThreatDetection -ErrorAction Stop |
                Where-Object {$targetIds.Count -eq 0 -or $targetIds.Contains([long](Get-SecurityProperty $_ 'ThreatID'))} |
                Sort-Object -Property InitialDetectionTime -Descending |
                Select-Object -First 64 |
                ForEach-Object {Select-SecurityProperties $_ $names})
        } catch {$errors.Add('DETECTIONS_UNAVAILABLE')}
    }
    $result.sourceErrors=@($errors | Select-Object -Unique)
    return $result
}
if($MyInvocation.InvocationName -ne '.') {
    $ErrorActionPreference='Stop'
    [Console]::OutputEncoding=New-Object Text.UTF8Encoding($false)
    $OutputEncoding=New-Object Text.UTF8Encoding($false)
    try {
        $snapshot=Get-DefenderSecuritySnapshot -AfterRecordId $AfterRecordId
        $json=ConvertTo-Json -InputObject $snapshot -Depth 12 -Compress
        if([Text.Encoding]::UTF8.GetByteCount($json) -gt 524288) {
            $json='{"available":false,"error":"INVALID_SNAPSHOT","watermark":null,"logReset":false,"events":[],"threats":[],"detections":[],"protection":{},"sourceErrors":["TRUNCATED"]}'
        }
        [Console]::WriteLine($json)
    } catch {
        [Console]::WriteLine('{"available":false,"error":"SOURCE_UNAVAILABLE","watermark":null,"logReset":false,"events":[],"threats":[],"detections":[],"protection":{},"sourceErrors":[]}')
    }
}
