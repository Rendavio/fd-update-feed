import { classifyPerson } from './person-classifier.js?v=20260906-1';

const PUBLIC_DEMO_PERSON_RULES = Object.freeze([
  Object.freeze({
    id: 'person1',
    displayRole: 'person1',
    aliases: Object.freeze(['人物A']),
  }),
  Object.freeze({
    id: 'person2',
    displayRole: 'person2',
    aliases: Object.freeze(['人物B']),
  }),
]);

const OWNER_ROLES = new Set(['person1', 'person2', 'joint', 'neutral']);
const HISTORY_DAY_OFFSETS = [
  [-4, '4日前'],
  [-3, '3日前'],
  [-2, '2日前'],
  [-1, '昨日'],
  [0, '本日'],
];

export class WeatherProvider {
  async getWeather() {
    throw new Error('WeatherProvider.getWeather() must be implemented');
  }
}

export class LocalJmaWeatherProvider extends WeatherProvider {
  constructor(endpoint = '/api/weather') {
    super();
    this.endpoint = endpoint;
  }

  async getWeather() {
    const response = await fetch(this.endpoint, { cache: 'no-store' });
    if (!response.ok) throw new Error(`Weather request failed: ${response.status}`);
    const data = await response.json();
    if (!data || data.schemaVersion !== 1 || !Array.isArray(data.days) || data.days.length !== 7) {
      throw new Error('Weather response schema is invalid');
    }
    return data;
  }
}

export class CalendarProvider {
  constructor(calendarId) {
    this.calendarId = calendarId;
  }

  assertAllowedCalendarId(calendarId) {
    if (!calendarId || calendarId === 'primary' || calendarId !== this.calendarId) {
      throw new Error('CalendarProvider rejected an unconfigured calendar ID');
    }
  }

  async getEvents() {
    throw new Error('CalendarProvider.getEvents() must be implemented');
  }
}

const BASE_EVENTS = [
  [
    { time: '終日', summary: '家族の予定を確認', allDay: true },
    { time: '10:30', summary: '人物A 歯科' },
    { time: '18:30', summary: '人物A・人物B 夕食' },
  ],
  [
    { time: '09:00', summary: '人物B 美容院' },
    { time: '19:00', summary: '家族で買い物' },
  ],
  [],
  [
    { time: '終日', summary: '燃えるごみ', allDay: true },
    { time: '15:30', summary: '人物A：銀行の手続き' },
  ],
  [{ time: '18:00', summary: '人物B：買い物' }],
  [{ time: '11:00', summary: '人物A 打ち合わせ' }],
  [{ time: '終日', summary: '家族の日', allDay: true }],
];

function cloneEvents() {
  return BASE_EVENTS.map((events) => events.map((event) => ({ ...event })));
}

function eventsForScenario(scenario) {
  const result = cloneEvents();

  if (scenario === 'many') {
    result[0] = [
      { time: '終日', summary: '資源ごみの日', allDay: true },
      { time: '08:30', summary: '人物A 定期検査' },
      { time: '10:00', summary: '人物B 美容院' },
      { time: '12:30', summary: '家族で昼食' },
      { time: '15:00', summary: '人物A・人物B 買い出し' },
      { time: '17:30', summary: '荷物の受け取り' },
      { time: '19:00', summary: 'オンライン打ち合わせ' },
      { time: '20:30', summary: '明日の準備' },
    ];
    result[1] = [
      { time: '終日', summary: '振替休日', allDay: true },
      { time: '09:00', summary: '人物A 通院' },
      { time: '11:30', summary: '人物B 買い物' },
      { time: '14:00', summary: '家族の用事' },
      { time: '18:00', summary: '夕食' },
    ];
  }

  if (scenario === 'long') {
    result[0][1].summary = '人物A 区役所で住所変更に必要な書類を受け取る';
    result[1][0].summary = '人物B 美容院のあと駅前で日用品と夕食の買い物';
    result[3][1].summary = '人物A：銀行窓口で各種手続きと口座の確認をする';
  }

  if (scenario === 'joint') {
    result[0] = [
      { time: '終日', summary: '人物A・人物B 記念日', allDay: true },
      { time: '11:30', summary: '人物A・人物B ランチ' },
      { time: '16:00', summary: '家族で家具を見に行く' },
      { time: '19:00', summary: '人物A・人物B 映画' },
    ];
    result[4] = [{ time: '18:30', summary: '人物A・人物B 夕食' }];
  }

  return result;
}

function addDays(isoDate, offset) {
  const date = new Date(`${isoDate}T00:00:00Z`);
  date.setUTCDate(date.getUTCDate() + offset);
  return date.toISOString().slice(0, 10);
}

function makeMockHistory(startDate, activeOffsets = []) {
  const active = new Set(activeOffsets);
  return HISTORY_DAY_OFFSETS.map(([offset, label]) => ({
    date: addDays(startDate, offset),
    label,
    occurred: active.has(offset),
  }));
}

function makeCountFixture(count, label) {
  return Array.from({ length: count }, (_, index) => ({
    time: `${String(8 + index).padStart(2, '0')}:00`,
    summary: `${index % 2 === 0 ? '人物A' : '人物B'} ${label}${index + 1}`,
  }));
}

function appendMultiDayFixture(days, startDate, {
  id,
  summary,
  startDayIndex,
  endDayIndexExclusive,
}) {
  const event = {
    id,
    summary,
    time: '終日',
    allDay: true,
    start: addDays(startDate, startDayIndex),
    end: addDays(startDate, endDayIndexExclusive),
  };
  for (let index = Math.max(0, startDayIndex); index < Math.min(days.length, endDayIndexExclusive); index += 1) {
    days[index].push({ ...event });
  }
}

function applyLayoutFixture(days, startDate, fixture) {
  const countMatch = /^(today|future)(0|1|3|5|6|8|12)$/.exec(fixture || '');
  if (countMatch) {
    const [, target, countText] = countMatch;
    days[target === 'today' ? 0 : 1] = makeCountFixture(Number(countText), target === 'today' ? '本日の予定' : '未来の予定');
  }
  const boardCounts = { board3: 0, board2: 8, board1: 8, boardHide: 12 };
  if (Object.hasOwn(boardCounts, fixture)) {
    days[1] = makeCountFixture(boardCounts[fixture], '未来の予定');
  }
  if (fixture === 'board1') {
    appendMultiDayFixture(days, startDate, {
      id: 'mock-board-density-spacer',
      summary: '掲示板高さ確認用の連続予定',
      startDayIndex: 1,
      endDayIndexExclusive: 3,
    });
  }

  if (fixture === 'multi1' || fixture === 'multi3') {
    appendMultiDayFixture(days, startDate, {
      id: 'mock-multiday-1',
      summary: '人物A 3日間の宿泊予定',
      startDayIndex: 1,
      endDayIndexExclusive: 4,
    });
  }
  if (fixture === 'multi3') {
    appendMultiDayFixture(days, startDate, {
      id: 'mock-multiday-2',
      summary: '人物B 連続する終日予定',
      startDayIndex: 2,
      endDayIndexExclusive: 5,
    });
    appendMultiDayFixture(days, startDate, {
      id: 'mock-multiday-3',
      summary: '人物A・人物B 重なる終日予定',
      startDayIndex: 2,
      endDayIndexExclusive: 6,
    });
  }
  if (fixture === 'multi2') {
    appendMultiDayFixture(days, startDate, {
      id: 'mock-two-day',
      summary: '人物A 2日間の予定',
      startDayIndex: 3,
      endDayIndexExclusive: 5,
    });
  }
  if (fixture === 'multiClipStart') {
    appendMultiDayFixture(days, startDate, {
      id: 'mock-clip-start',
      summary: '人物B 表示前から続く予定',
      startDayIndex: -2,
      endDayIndexExclusive: 3,
    });
  }
  if (fixture === 'multiClipEnd') {
    appendMultiDayFixture(days, startDate, {
      id: 'mock-clip-end',
      summary: '人物A 表示後まで続く予定',
      startDayIndex: 5,
      endDayIndexExclusive: 10,
    });
  }
  if (fixture === 'multiTwo' || fixture === 'multiDense') {
    appendMultiDayFixture(days, startDate, {
      id: 'mock-stacked-1',
      summary: '人物A 連続予定A',
      startDayIndex: 1,
      endDayIndexExclusive: 4,
    });
    appendMultiDayFixture(days, startDate, {
      id: 'mock-stacked-2',
      summary: '人物B 連続予定B',
      startDayIndex: 2,
      endDayIndexExclusive: 5,
    });
  }
  if (fixture === 'multiDense') {
    days[1].push(...makeCountFixture(10, '未来の予定'));
  }
  return days;
}

function materializeMockEvent(event, startDate, dayIndex, eventIndex) {
  const eventDate = addDays(startDate, dayIndex);
  const allDay = Boolean(event.allDay);
  return {
    id: event.id || `mock-${dayIndex}-${eventIndex}`,
    summary: event.summary,
    start: event.start || (allDay ? eventDate : `${eventDate}T${event.time}:00+09:00`),
    end: event.end || (allDay ? addDays(eventDate, 1) : `${eventDate}T${event.time}:00+09:00`),
    time: event.time,
    allDay,
    owner: classifyPerson(event.summary, PUBLIC_DEMO_PERSON_RULES),
  };
}

function validHistory(history) {
  return Array.isArray(history)
    && history.length === HISTORY_DAY_OFFSETS.length
    && history.every((item) => (
      item
      && typeof item.date === 'string'
      && typeof item.label === 'string'
      && typeof item.occurred === 'boolean'
    ));
}

function copyHistory(history) {
  return history.map((item) => ({
    date: item.date,
    label: item.label,
    occurred: Boolean(item.occurred),
  }));
}

export class MockCalendarProvider extends CalendarProvider {
  async getEvents({ calendarId, startDate, days = 7, scenario = 'normal', fixture = null }) {
    this.assertAllowedCalendarId(calendarId);
    const scenarioEvents = applyLayoutFixture(eventsForScenario(scenario), startDate, fixture);
    return {
      calendarId,
      headacheHistory: makeMockHistory(startDate, [-1]),
      aerobicHistory: makeMockHistory(startDate, [-4, 0]),
      strengthHistory: makeMockHistory(startDate, [-3]),
      boardNotices: /^board(?:3|2|1|Hide)$/.test(fixture || '')
        ? ['掲示一', '掲示二', '掲示三']
        : [],
      days: Array.from({ length: days }, (_, index) => ({
        date: addDays(startDate, index),
        events: (scenarioEvents[index] ?? []).map((event, eventIndex) => (
          materializeMockEvent(event, startDate, index, eventIndex)
        )),
      })),
    };
  }
}

export class GoogleCalendarProvider extends CalendarProvider {
  constructor(endpoint = '/api/calendar', fetchImpl = globalThis.fetch.bind(globalThis)) {
    super(null);
    this.endpoint = endpoint;
    this.fetchImpl = fetchImpl;
  }

  async getEvents() {
    const response = await this.fetchImpl(this.endpoint, { cache: 'no-store' });
    const data = await response.json();
    if (!response.ok) {
      const error = new Error(data?.error || `Google Calendar request failed: ${response.status}`);
      error.kind = data?.errorType || 'unknown';
      throw error;
    }
    if (
      !data
      || data.schemaVersion !== 2
      || data.provider !== 'google'
      || !Array.isArray(data.days)
      || data.days.length !== 7
      || !Array.isArray(data.headacheHistory)
      || !validHistory(data.headacheHistory)
      || !validHistory(data.aerobicHistory)
      || !validHistory(data.strengthHistory)
      || !Array.isArray(data.boardNotices)
      || data.boardNotices.length > 3
      || data.boardNotices.some((item) => typeof item !== 'string' || !item || item.length > 1024)
    ) {
      throw new Error('Google Calendar response schema is invalid');
    }
    return {
      calendarId: null,
      stale: Boolean(data.stale),
      cacheState: data.cacheState,
      lastSuccessAt: data.lastSuccessAt,
      errorType: data.errorType,
      headacheHistory: copyHistory(data.headacheHistory),
      aerobicHistory: copyHistory(data.aerobicHistory),
      strengthHistory: copyHistory(data.strengthHistory),
      boardNotices: data.boardNotices.slice(0, 3),
      days: data.days.map((day) => ({
        date: day.date,
        events: day.events.map((event) => ({
          id: event.id,
          summary: event.summary,
          start: event.start,
          end: event.end,
          time: event.time,
          allDay: Boolean(event.allDay),
          owner: OWNER_ROLES.has(event.owner) ? event.owner : 'neutral',
        })),
      })),
    };
  }
}

export class EarthquakeProvider {
  subscribe() {
    throw new Error('EarthquakeProvider.subscribe() must be implemented');
  }
}

export class MockEarthquakeProvider extends EarthquakeProvider {
  constructor() {
    super();
    this.listeners = new Set();
  }

  subscribe(listener) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  triggerTokyo23() {
    const event = {
      type: 'warning',
      region: '東京都23区',
      headline: '緊急地震速報',
      instruction: '強い揺れに警戒してください',
      issuedAt: new Date().toISOString(),
      mock: true,
    };
    this.listeners.forEach((listener) => listener(event));
  }

  clear() {
    this.listeners.forEach((listener) => listener(null));
  }
}

export class BatteryProvider {
  async getBattery() {
    throw new Error('BatteryProvider.getBattery() must be implemented');
  }
}

export class MockBatteryProvider extends BatteryProvider {
  async getBattery() {
    return { level: 62, acConnected: true, charging: false, mock: true };
  }
}

export class PowerPlugProvider {
  async getState() {
    throw new Error('PowerPlugProvider.getState() must be implemented');
  }
}

export class MockPowerPlugProvider extends PowerPlugProvider {
  constructor() {
    super();
    this.power = 'off';
  }

  async getState() {
    return { power: this.power, mock: true };
  }

  async setPower(power) {
    if (!['on', 'off'].includes(power)) throw new Error('Unsupported mock power state');
    this.power = power;
    return this.getState();
  }
}

export const MOCK_CALENDAR_ID = 'mock-family-calendar';

export function createProviders() {
  const mockCalendar = new MockCalendarProvider(MOCK_CALENDAR_ID);
  const googleCalendar = new GoogleCalendarProvider();
  return {
    weather: new LocalJmaWeatherProvider(),
    calendar: mockCalendar,
    calendars: {
      mock: mockCalendar,
      google: googleCalendar,
    },
    earthquake: new MockEarthquakeProvider(),
    battery: new MockBatteryProvider(),
    powerPlug: new MockPowerPlugProvider(),
  };
}
