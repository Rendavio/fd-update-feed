export function installAutoThemeRefresh({ win, doc, getThemeMode, refresh }) {
  const refreshIfAuto = () => {
    if (getThemeMode() === 'auto') refresh();
  };

  refreshIfAuto();
  win.setInterval(refreshIfAuto, 60_000);
  doc.addEventListener('visibilitychange', () => {
    if (doc.visibilityState === 'visible') refreshIfAuto();
  });
}

