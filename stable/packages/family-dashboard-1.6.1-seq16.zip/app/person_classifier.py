from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass
from typing import Any, Iterable, Sequence


PERSON_IDS = ("person1", "person2")
NEUTRAL_OWNER = "neutral"
JOINT_OWNER = "joint"
_SEPARATORS = r"\s\u3000:：/／・･\-‐‑‒–—―_＿,，、;；()（）\[\]［］{}｛｝【】「」『』〈〉《》〔〕<>＜＞"
_LEADING_SEPARATORS = re.compile(rf"^[{_SEPARATORS}]+")
_ANY_SEPARATOR = re.compile(rf"[{_SEPARATORS}]")


class PersonRulesError(ValueError):
    pass


@dataclass(frozen=True)
class AliasRule:
    value: str
    folded: str


@dataclass(frozen=True)
class PersonRule:
    person_id: str
    aliases: tuple[AliasRule, ...]


def normalize_event_summary(summary: Any) -> str:
    return unicodedata.normalize("NFKC", str(summary or "")).strip()


def _contains_control(value: str) -> bool:
    return any(unicodedata.category(character) in {"Cc", "Cf"} for character in value)


def _is_han(character: str) -> bool:
    codepoint = ord(character)
    return (
        0x3400 <= codepoint <= 0x4DBF
        or 0x4E00 <= codepoint <= 0x9FFF
        or 0xF900 <= codepoint <= 0xFAFF
        or 0x20000 <= codepoint <= 0x2FA1F
    )


def validate_person_rules(value: Any) -> tuple[PersonRule, ...]:
    if not isinstance(value, list) or len(value) != len(PERSON_IDS):
        raise PersonRulesError("people must contain exactly two roles")

    result: list[PersonRule] = []
    seen_people: set[str] = set()
    seen_aliases: set[str] = set()
    for person in value:
        if not isinstance(person, dict) or set(person) != {"id", "displayRole", "aliases"}:
            raise PersonRulesError("person fields do not match the schema")
        person_id = person.get("id")
        if person_id not in PERSON_IDS or person.get("displayRole") != person_id:
            raise PersonRulesError("person role is unsupported")
        if person_id in seen_people:
            raise PersonRulesError("person role is duplicated")
        seen_people.add(person_id)

        raw_aliases = person.get("aliases")
        if not isinstance(raw_aliases, list) or not 1 <= len(raw_aliases) <= 32:
            raise PersonRulesError("aliases must be a bounded non-empty list")
        aliases: list[AliasRule] = []
        for raw_alias in raw_aliases:
            if not isinstance(raw_alias, str):
                raise PersonRulesError("alias must be a string")
            alias = unicodedata.normalize("NFKC", raw_alias).strip()
            if (
                not 1 <= len(alias) <= 32
                or _contains_control(alias)
                or _ANY_SEPARATOR.search(alias)
            ):
                raise PersonRulesError("alias has an unsafe format")
            folded = alias.casefold()
            if len(folded) != len(alias) or folded in seen_aliases:
                raise PersonRulesError("alias is ambiguous or duplicated")
            seen_aliases.add(folded)
            aliases.append(AliasRule(alias, folded))
        aliases.sort(key=lambda item: len(item.value), reverse=True)
        result.append(PersonRule(person_id, tuple(aliases)))

    if seen_people != set(PERSON_IDS):
        raise PersonRulesError("both supported person roles are required")
    result.sort(key=lambda item: PERSON_IDS.index(item.person_id))
    return tuple(result)


def _flatten(
    people: Sequence[PersonRule],
    allowed: set[str] | None = None,
) -> list[tuple[PersonRule, AliasRule]]:
    result = [
        (person, alias)
        for person in people
        if allowed is None or person.person_id in allowed
        for alias in person.aliases
    ]
    result.sort(key=lambda item: len(item[1].value), reverse=True)
    return result


def _strip_leading_separators(value: str) -> str:
    return _LEADING_SEPARATORS.sub("", value)


def _starts_with_other_alias(
    remainder: str,
    people: Sequence[PersonRule],
    person_id: str,
) -> bool:
    folded = remainder.casefold()
    return any(
        folded.startswith(alias.folded)
        for person, alias in _flatten(people)
        if person.person_id != person_id
    )


def _safe_continuation(
    alias: AliasRule,
    remainder: str,
    people: Sequence[PersonRule],
    person_id: str,
) -> bool:
    if not remainder or _LEADING_SEPARATORS.match(remainder):
        return True
    if _starts_with_other_alias(remainder, people, person_id):
        return True
    # One-codepoint aliases are delimiter-only. Longer aliases may attach only
    # to a Han-led event phrase, avoiding ordinary kana-word continuations.
    return len(alias.value) >= 2 and _is_han(remainder[0])


def _match_prefix(
    value: str,
    people: Sequence[PersonRule],
    allowed: set[str] | None = None,
) -> tuple[PersonRule, AliasRule, str] | None:
    folded = value.casefold()
    for person, alias in _flatten(people, allowed):
        if not folded.startswith(alias.folded):
            continue
        remainder = value[len(alias.value):]
        if _safe_continuation(alias, remainder, people, person.person_id):
            return person, alias, remainder
    return None


def classify_person(summary: Any, people: Iterable[PersonRule] | Any) -> str:
    try:
        compiled = (
            tuple(people)
            if isinstance(people, (list, tuple))
            and all(isinstance(item, PersonRule) for item in people)
            else validate_person_rules(people)
        )
    except (PersonRulesError, TypeError):
        return NEUTRAL_OWNER

    value = _strip_leading_separators(normalize_event_summary(summary))
    if not value:
        return NEUTRAL_OWNER
    first = _match_prefix(value, compiled)
    if first is None:
        return NEUTRAL_OWNER
    first_person, _first_alias, remainder = first

    second_value = _strip_leading_separators(remainder)
    if second_value:
        other_ids = set(PERSON_IDS) - {first_person.person_id}
        second = _match_prefix(second_value, compiled, other_ids)
        if second is not None:
            return JOINT_OWNER
    return first_person.person_id
