﻿#requires -Version 5.1
# Local interactive file selection only. No playback, download, volume or API.
$ErrorActionPreference = 'Stop'
try {
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    . (Join-Path $PSScriptRoot 'FamilyDashboard.Common.ps1')
    if (Test-FamilyDashboardAdministrator) { throw 'invalid' }
    if ([Environment]::UserName -ine 'DashboardAdmin') { throw 'invalid' }
    $reader = Join-Path $script:AppRoot 'eew_private_audio.py'
    function Invoke-PrivateAudioHelper($Role, $Source) {
        $info = New-Object Diagnostics.ProcessStartInfo
        $info.FileName = $script:PythonPath
        $mode = if ($Role) { '--import-private' } else { '--status-private' }
        $info.Arguments = '-I -s -B -X utf8 "' + $reader + '" ' + $mode
        $info.UseShellExecute = $false
        $info.CreateNoWindow = $true
        $info.RedirectStandardInput = $true
        $info.RedirectStandardOutput = $true
        $info.RedirectStandardError = $true
        $process = New-Object Diagnostics.Process
        $process.StartInfo = $info
        [void]$process.Start()
        if ($Role) {
            $inputJson = @{role=$Role;source=$Source} | ConvertTo-Json -Compress
            $inputBytes = (New-Object Text.UTF8Encoding($false)).GetBytes($inputJson)
            $process.StandardInput.BaseStream.Write($inputBytes, 0, $inputBytes.Length)
        }
        $process.StandardInput.Close()
        $output = $process.StandardOutput.ReadToEnd()
        [void]$process.StandardError.ReadToEnd()
        $process.WaitForExit()
        if ($process.ExitCode -ne 0) { throw 'invalid' }
        $result = $output | ConvertFrom-Json
        foreach ($key in @('production','training')) {
            if ($result.$key -notin @('READY','MISSING','INVALID')) { throw 'invalid' }
        }
        return $result
    }
    $form = New-Object Windows.Forms.Form
    $form.Text = 'EEW private sound registration'
    $form.Size = New-Object Drawing.Size(650,420)
    $form.StartPosition = 'CenterScreen'
    $form.Font = New-Object Drawing.Font('Yu Gothic UI',12)
    $form.FormBorderStyle = 'FixedDialog'
    $form.MaximizeBox = $false
    $intro = New-Object Windows.Forms.Label
    $intro.SetBounds(20,15,600,65)
    $intro.Text = '本番用と訓練用は別の音源です。選択する役割を確認してください。登録時に音は再生しません。'
    $form.Controls.Add($intro)
    $status = New-Object Windows.Forms.Label
    $status.SetBounds(20,245,600,75)
    function Update-PrivateAudioStatus {
        $r = Invoke-PrivateAudioHelper $null $null
        $status.Text = 'Production sound: ' + $r.production + [Environment]::NewLine + 'Training sound: ' + $r.training
    }
    foreach ($choice in @(@('production','本番EEWチャイムを登録','本物の緊急地震速報でだけ使用します。TESTでは使いません。',85),@('training','訓練EEWチャイムを登録','Maintenance TESTとunattended TESTでだけ使用します。',165))) {
        $button = New-Object Windows.Forms.Button
        $button.SetBounds(20,[int]$choice[3],580,43)
        $button.Text = $choice[1]
        $button.Tag = @{Role=$choice[0];Title=$choice[1]}
        $button.Add_Click({
            $role = $this.Tag.Role
            $title = $this.Tag.Title
            $dialog = New-Object Windows.Forms.OpenFileDialog
            $dialog.Title = $title + ' — ユーザーが用意したPCM WAVを選択'
            $dialog.Filter = 'PCM WAV (*.wav)|*.wav'
            $dialog.CheckFileExists = $true
            $dialog.Multiselect = $false
            if ($dialog.ShowDialog() -ne [Windows.Forms.DialogResult]::OK) { return }
            $answer = [Windows.Forms.MessageBox]::Show(
                $title + [Environment]::NewLine + 'この役割の音源であることと、利用権限を確認しました。既存の同じ役割の音源は置換されます。',
                $title,[Windows.Forms.MessageBoxButtons]::OKCancel,[Windows.Forms.MessageBoxIcon]::Warning)
            if ($answer -ne [Windows.Forms.DialogResult]::OK) { return }
            try {
                [void](Invoke-PrivateAudioHelper $role $dialog.FileName)
                Update-PrivateAudioStatus
            } catch { $status.Text = 'Registration: INVALID' }
            finally { $dialog.Dispose() }
        })
        $form.Controls.Add($button)
        $label = New-Object Windows.Forms.Label
        $label.SetBounds(25,([int]$choice[3]+45),580,30)
        $label.Text = $choice[2]
        $form.Controls.Add($label)
    }
    $form.Controls.Add($status)
    Update-PrivateAudioStatus
    [void]$form.ShowDialog()
} catch {
    [void][Windows.Forms.MessageBox]::Show('Registration: INVALID','EEW private sound registration')
}

