"""One-shot, fixed-path Power Forensics request and sanitized status boundary."""

from __future__ import annotations

import json
import ctypes
import os
import re
import stat
import subprocess
import threading
import time
from pathlib import Path


REQUEST_SCRIPT = Path(r"C:\FamilyDashboard\launcher\Request-FamilyDashboardPowerForensics.ps1")
POWERSHELL = Path(r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe")
STATUS_FILE = Path(r"C:\ProgramData\FamilyDashboardForensics\status\latest.json")
CASE_ID = re.compile(r"case-\d{8}-\d{6}-[0-9a-f]{8}\Z")
REQUEST_TIMEOUT_SECONDS = 120
COLLECTION_DEADLINE_SECONDS = 930
RUNNER_MUTEX = r"Global\FamilyDashboardPowerForensics"


def _runner_active() -> bool:
    """Fail closed if the fixed elevated runner's named mutex exists or is inaccessible."""
    if os.name != "nt":
        return True
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.OpenMutexW.argtypes = [ctypes.c_uint32, ctypes.c_int, ctypes.c_wchar_p]
    kernel.OpenMutexW.restype = ctypes.c_void_p
    kernel.CloseHandle.argtypes = [ctypes.c_void_p]
    handle = kernel.OpenMutexW(0x00100000, 0, RUNNER_MUTEX)
    if handle:
        kernel.CloseHandle(handle)
        return True
    return ctypes.get_last_error() != 2


class AlreadyRunning(Exception):
    pass


class ConsentCancelled(Exception):
    pass


class LaunchUnavailable(Exception):
    pass


def _fixed_request_exit_code() -> int:
    try:
        completed = subprocess.run(
            [
                str(POWERSHELL),
                "-NoLogo", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
                "-File", str(REQUEST_SCRIPT),
            ],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=REQUEST_TIMEOUT_SECONDS,
            check=False,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
    except (OSError, subprocess.TimeoutExpired):
        return 30
    return completed.returncode if completed.returncode in (0, 20) else 30


def _has_reparse_component(path: Path) -> bool:
    for component in (path, *path.parents):
        try:
            attributes = component.lstat().st_file_attributes
        except (OSError, AttributeError):
            continue
        if attributes & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400):
            return True
    return False


def _trusted_status_owner(path: Path) -> bool:
    """Require protected, non-user-writable security on the fixed status chain."""
    if os.name != "nt":
        return False
    if os.path.normcase(str(path)) != os.path.normcase(str(STATUS_FILE)):
        return False
    root = STATUS_FILE.parent.parent
    return all(_trusted_status_acl(item) for item in (root, STATUS_FILE.parent, path))


def _trusted_status_acl(path: Path) -> bool:
    owner = ctypes.c_void_p()
    dacl = ctypes.c_void_p()
    descriptor = ctypes.c_void_p()
    sid_text = ctypes.c_void_p()
    advapi = ctypes.WinDLL("advapi32", use_last_error=True)
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    advapi.GetNamedSecurityInfoW.argtypes = [
        ctypes.c_wchar_p, ctypes.c_int, ctypes.c_uint32,
        ctypes.POINTER(ctypes.c_void_p), ctypes.c_void_p, ctypes.POINTER(ctypes.c_void_p),
        ctypes.c_void_p, ctypes.POINTER(ctypes.c_void_p),
    ]
    advapi.GetNamedSecurityInfoW.restype = ctypes.c_uint32
    advapi.ConvertSidToStringSidW.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_void_p)]
    advapi.ConvertSidToStringSidW.restype = ctypes.c_int
    advapi.GetSecurityDescriptorControl.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_uint16), ctypes.POINTER(ctypes.c_uint32)]
    advapi.GetSecurityDescriptorControl.restype = ctypes.c_int
    advapi.GetAce.argtypes = [ctypes.c_void_p, ctypes.c_uint32, ctypes.POINTER(ctypes.c_void_p)]
    advapi.GetAce.restype = ctypes.c_int
    kernel.LocalFree.argtypes = [ctypes.c_void_p]
    try:
        result = advapi.GetNamedSecurityInfoW(
            str(path), 1, 5, ctypes.byref(owner), None, ctypes.byref(dacl), None,
            ctypes.byref(descriptor),
        )
        if result != 0 or not owner.value or not dacl.value or not descriptor.value:
            return False
        if not advapi.ConvertSidToStringSidW(owner, ctypes.byref(sid_text)):
            return False
        if ctypes.wstring_at(sid_text.value) not in {"S-1-5-18", "S-1-5-32-544"}:
            return False
        control = ctypes.c_uint16()
        revision = ctypes.c_uint32()
        if not advapi.GetSecurityDescriptorControl(descriptor, ctypes.byref(control), ctypes.byref(revision)):
            return False
        if not control.value & 0x1000:  # SE_DACL_PROTECTED
            return False
        ace_count = ctypes.c_uint16.from_address(dacl.value + 4).value
        if not 0 < ace_count <= 16:
            return False
        for index in range(ace_count):
            ace = ctypes.c_void_p()
            if not advapi.GetAce(dacl, index, ctypes.byref(ace)) or not ace.value:
                return False
            if ctypes.c_uint8.from_address(ace.value).value != 0:  # only simple ACCESS_ALLOWED_ACE
                return False
            mask = ctypes.c_uint32.from_address(ace.value + 4).value
            ace_sid_text = ctypes.c_void_p()
            try:
                if not advapi.ConvertSidToStringSidW(ctypes.c_void_p(ace.value + 8), ctypes.byref(ace_sid_text)):
                    return False
                sid = ctypes.wstring_at(ace_sid_text.value)
            finally:
                if ace_sid_text.value:
                    kernel.LocalFree(ace_sid_text)
            if sid not in {"S-1-5-18", "S-1-5-32-544"} and mask & ~0x001200A9:
                return False
        return True
    except (OSError, ValueError, AttributeError):
        return False
    finally:
        if sid_text.value:
            kernel.LocalFree(sid_text)
        if descriptor.value:
            kernel.LocalFree(descriptor)


class PowerForensicsControl:
    def __init__(self, *, run_request=None, status_path: Path | None = None,
                 status_owner_check=None, runner_active=None):
        self._run_request = run_request or _fixed_request_exit_code
        self._status_path = status_path or STATUS_FILE
        self._status_owner_check = status_owner_check or _trusted_status_owner
        self._runner_active = runner_active or _runner_active
        self._lock = threading.Lock()
        self._running = False
        self._started_ns = 0
        self._accepted_ns = None
        self._last_result = {"status": "FAIL", "caseId": None, "sanitizedSharePath": None}

    def _trusted_result(self) -> dict | None:
        try:
            if _has_reparse_component(self._status_path) or not self._status_owner_check(self._status_path):
                return None
            info = self._status_path.stat()
            if info.st_size > 512 or info.st_mtime_ns < self._started_ns:
                return None
            data = json.loads(self._status_path.read_text(encoding="utf-8"))
        except (OSError, UnicodeError, ValueError):
            return None
        if type(data) is not dict or set(data) != {"status", "caseId", "sanitizedSharePath"}:
            return None
        if data["status"] not in ("PASS", "PARTIAL", "FAIL"):
            return None
        case_id = data["caseId"]
        if data["status"] == "FAIL" and case_id is None and data["sanitizedSharePath"] is None:
            return data
        if not isinstance(case_id, str) or not CASE_ID.fullmatch(case_id):
            return None
        expected = rf"C:\ProgramData\FamilyDashboardForensics\{case_id}\sanitized-share"
        if not isinstance(data["sanitizedSharePath"], str) or (
            os.path.normcase(data["sanitizedSharePath"]) != os.path.normcase(expected)
        ):
            return None
        return data

    def _current_status(self) -> dict:
        if not self._running:
            return self._last_result.copy()
        if self._accepted_ns is None:
            return {"status": "RUNNING", "caseId": None, "sanitizedSharePath": None}
        result = self._trusted_result()
        if result is not None:
            self._running = False
            self._last_result = result
            return result
        if (self._accepted_ns is not None and
                time.monotonic_ns() - self._accepted_ns > COLLECTION_DEADLINE_SECONDS * 1_000_000_000):
            self._running = False
            self._last_result = {"status": "FAIL", "caseId": None, "sanitizedSharePath": None}
            return self._last_result.copy()
        return {"status": "RUNNING", "caseId": None, "sanitizedSharePath": None}

    def request_collection(self) -> None:
        with self._lock:
            self._current_status()
            if self._running:
                raise AlreadyRunning()
            if self._runner_active():
                raise AlreadyRunning()
            self._running = True
            self._started_ns = time.time_ns()
            self._accepted_ns = None
            self._last_result = {"status": "FAIL", "caseId": None, "sanitizedSharePath": None}
        try:
            code = self._run_request()
        except Exception:
            code = 30
        if code == 0:
            with self._lock:
                self._accepted_ns = time.monotonic_ns()
            return
        with self._lock:
            self._running = False
        if code == 20:
            raise ConsentCancelled()
        raise LaunchUnavailable()

    def read_status(self) -> dict:
        with self._lock:
            return self._current_status()
