import { describeUpdateStatus } from './update-client.js';

const VERSION_PATTERN = /^[0-9A-Za-z][0-9A-Za-z.+-]{0,63}$/;
const APPLY_PHASES = new Set([
  'UNKNOWN', 'REQUEST_ACCEPTED', 'UAC_APPROVED', 'COORDINATOR_STARTED',
  'SHUTDOWN_REQUESTED', 'SERVER_EXITED', 'PORT_CLOSED', 'UPDATER_STARTED',
  'UPDATER_FINISHED', 'WATCHER_RESTARTED', 'HEALTH_OK',
]);
const APPLY_RESULTS = new Set(['UNKNOWN', 'RUNNING', 'PASS', 'FAIL', 'TIMEOUT']);
const APPLY_ERRORS = new Set([
  'NONE', 'UAC_CANCELLED', 'COORDINATOR_NOT_STARTED', 'SERVER_EXIT_TIMEOUT',
  'PORT_CLOSE_TIMEOUT', 'UPDATER_NOT_STARTED', 'UPDATER_EXIT_NONZERO',
  'UPDATER_TIMEOUT', 'RESTART_TIMEOUT',
]);
const UPDATER_EXIT_CODES = new Set(['0', '2', '3', '5', '64', 'OTHER']);
const TLS_CERT_VERIFY_CODES = Object.freeze([
  2, 3, 9, 10, 18, 19, 20, 21, 23, 24, 25, 26, 27, 28,
  30, 47, 48, 49, 50, 66, 67, 68, 76, 77, 78, 79,
]);
const SWITCHBOT_ERRORS = new Set([
  'NONE', 'BATTERY_READ', 'SETUP_PARSE', 'API_TIMEOUT', 'API_DNS',
  'TLS_HOSTNAME', 'TLS_CERT_VERIFY_OTHER', 'TLS_EOF', 'TLS_HANDSHAKE',
  'TLS_PROTOCOL', 'TLS_OTHER', 'API_CONNECT', 'API_TRANSPORT_OTHER', 'API_AUTH',
  'API_RESPONSE', 'TARGET_MATCH', 'DEVICE_TYPE', 'CLOUD_DISABLED',
  'STATUS_AUTH', 'STATUS_RESPONSE', 'STATUS_READ',
  'POWER_SCHEMA', 'CONFIG_WRITE', 'UNKNOWN',
  ...TLS_CERT_VERIFY_CODES.map((code) => `TLS_CERT_VERIFY_${code}`),
]);

function version(value) {
  return typeof value === 'string' && VERSION_PATTERN.test(value) ? value : null;
}

function sequence(value) {
  return Number.isSafeInteger(value) && value >= 0 ? String(value) : null;
}

function tlsCode(value) {
  if (value === 'TLS_HOSTNAME') return '62';
  if (value === 'TLS_CERT_VERIFY_OTHER') return 'OTHER';
  if (typeof value !== 'string') return 'Unknown';
  const match = /^TLS_CERT_VERIFY_([0-9]+)$/.exec(value);
  if (!match) return 'Unknown';
  const code = Number(match[1]);
  return TLS_CERT_VERIFY_CODES.includes(code) ? String(code) : 'OTHER';
}

function lastUpdate(value) {
  if (value === 'PASS') return 'PASS';
  if (value === 'FAIL') return 'FAIL';
  return 'Unknown';
}

export function describeMaintenanceDiagnostics({ runtime = null, updateStatus = null } = {}) {
  const runtimeAvailable = runtime !== null && typeof runtime === 'object';
  const updateAvailable = updateStatus !== null && typeof updateStatus === 'object';
  const updateView = updateAvailable ? describeUpdateStatus(updateStatus) : null;
  const integrity = runtime?.processIntegrity;
  const apply = runtime?.lastApply;
  const applyPhase = APPLY_PHASES.has(apply?.phase) ? apply.phase : 'UNKNOWN';
  const applyResult = APPLY_RESULTS.has(apply?.result) ? apply.result : 'UNKNOWN';
  const applyError = APPLY_ERRORS.has(apply?.error) ? apply.error : 'NONE';
  const updaterExitCode = UPDATER_EXIT_CODES.has(apply?.updaterExitCode)
    ? apply.updaterExitCode
    : 'Unknown';
  const switchBot = runtime?.switchBot;
  const switchBotAvailable = switchBot !== null && typeof switchBot === 'object';
  const battery = switchBot?.batteryPercent;
  const plug = switchBot?.plug;
  const switchBotLastCheck = switchBot?.lastCheck;
  const switchBotError = switchBot?.error;

  return {
    dashboard: version(updateStatus?.currentVersion) || version(runtime?.appVersion) || 'Unknown',
    sequence: sequence(updateStatus?.currentSequence) || 'Unknown',
    updater: version(updateStatus?.updaterVersion) || 'Unknown',
    server: runtimeAvailable ? 'Running' : 'Unknown',
    integrity: integrity === 'nonElevated' || integrity === 'elevated' ? integrity : 'Unknown',
    update: updateView?.statusText || 'Unknown',
    lastUpdate: lastUpdate(updateStatus?.lastResult),
    lastApplyPhase: applyPhase,
    lastApplyResult: applyResult,
    lastApplyError: applyError,
    updaterExitCode,
    updaterFailureStage: 'UNKNOWN',
    switchBot: switchBotAvailable
      ? (switchBot.configured === true ? 'Configured' : 'Not configured')
      : 'Unknown',
    battery: Number.isSafeInteger(battery) && battery >= 0 && battery <= 100
      ? `${battery}%`
      : 'Unknown',
    plug: plug === 'ON' || plug === 'OFF' ? plug : 'Unknown',
    switchBotLastCheck: switchBotLastCheck === 'PASS' || switchBotLastCheck === 'FAIL'
      ? switchBotLastCheck
      : 'Unknown',
    switchBotError: SWITCHBOT_ERRORS.has(switchBotError) ? switchBotError : 'UNKNOWN',
    tlsCode: tlsCode(switchBotError),
  };
}

export async function requestPowerForensics(fetcher = fetch) {
  const response = await fetcher('/api/maintenance/power-diagnostics', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: '{}',
    cache: 'no-store',
    credentials: 'same-origin',
  });
  if (response.ok && response.status === 202) return;
  let code = null;
  try { code = (await response.json()).error; } catch { /* fixed safe fallback */ }
  if (!['uac_cancelled', 'diagnostics_already_running', 'diagnostics_unavailable'].includes(code)) {
    code = 'diagnostics_unavailable';
  }
  throw new Error(code);
}

export function describePowerForensicsStatus(value) {
  const status = ['RUNNING', 'PASS', 'PARTIAL', 'FAIL'].includes(value?.status)
    ? value.status : 'FAIL';
  if (status === 'RUNNING') return 'RUNNING';
  const caseId = typeof value?.caseId === 'string' &&
    /^case-\d{8}-\d{6}-[0-9a-f]{8}$/.test(value.caseId) ? value.caseId : null;
  const path = ['C:', 'ProgramData', 'FamilyDashboardForensics', caseId, 'sanitized-share']
    .join(String.fromCharCode(92));
  if (!caseId || typeof value?.sanitizedSharePath !== 'string' ||
      value.sanitizedSharePath.toLowerCase() !== path.toLowerCase()) return status;
  return `${status} · ${caseId} · ${path}`;
}
