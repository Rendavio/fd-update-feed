#requires -Version 5.1
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

function Set-FixedForensicEnvironment {
    $env:PSModulePath = 'C:\Windows\System32\WindowsPowerShell\v1.0\Modules;C:\Program Files\WindowsPowerShell\Modules'
    $env:PATH = 'C:\Windows\System32;C:\Windows'
    [Environment]::CurrentDirectory = 'C:\Windows\System32'
}
Set-FixedForensicEnvironment

function Assert-NoForensicReparse([string]$Path) {
    $current = [IO.Path]::GetFullPath($Path)
    while ($current) {
        if (Test-Path -LiteralPath $current) {
            $item = Get-Item -LiteralPath $current -Force -ErrorAction Stop
            if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
                throw 'UNSAFE_PATH'
            }
        }
        $parent = [IO.Directory]::GetParent($current)
        if ($null -eq $parent) { break }
        $current = $parent.FullName
    }
}

function Test-FixedForensicAcl([Security.AccessControl.FileSystemSecurity]$Acl,
        [string]$DashboardSid, [string]$StandardDashboardSid = '') {
    $owner = $Acl.GetOwner([Security.Principal.SecurityIdentifier]).Value
    if (@('S-1-5-18','S-1-5-32-544') -cnotcontains $owner) {
        return $false
    }
    $dangerous = [Security.AccessControl.FileSystemRights]::WriteData -bor
        [Security.AccessControl.FileSystemRights]::AppendData -bor
        [Security.AccessControl.FileSystemRights]::CreateFiles -bor
        [Security.AccessControl.FileSystemRights]::CreateDirectories -bor
        [Security.AccessControl.FileSystemRights]::WriteExtendedAttributes -bor
        [Security.AccessControl.FileSystemRights]::WriteAttributes -bor
        [Security.AccessControl.FileSystemRights]::Delete -bor
        [Security.AccessControl.FileSystemRights]::DeleteSubdirectoriesAndFiles -bor
        [Security.AccessControl.FileSystemRights]::ChangePermissions -bor
        [Security.AccessControl.FileSystemRights]::TakeOwnership
    $fullControl = New-Object 'Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
    foreach ($rule in $Acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier])) {
        if ($rule.AccessControlType -ne [Security.AccessControl.AccessControlType]::Allow) { return $false }
        $sid = $rule.IdentityReference.Value
        if (@('S-1-5-18','S-1-5-32-544',$DashboardSid,$StandardDashboardSid) -cnotcontains $sid) { return $false }
        if (($rule.FileSystemRights -band $dangerous) -ne 0 -and
            @('S-1-5-18','S-1-5-32-544') -cnotcontains $sid) { return $false }
        if (($rule.FileSystemRights -band [Security.AccessControl.FileSystemRights]::FullControl) -eq
                [Security.AccessControl.FileSystemRights]::FullControl) {
            [void]$fullControl.Add($sid)
        }
    }
    return $fullControl.Contains('S-1-5-18') -and $fullControl.Contains('S-1-5-32-544')
}

function Assert-ForensicAcl([string]$Path, [string]$DashboardSid,
        [string]$StandardDashboardSid = '') {
    $acl = Get-Acl -LiteralPath $Path -ErrorAction Stop
    if (-not (Test-FixedForensicAcl $acl $DashboardSid $StandardDashboardSid)) {
        throw 'UNSAFE_ACL_OR_OWNER'
    }
}

function Assert-FixedCollector([string]$Path, [string]$ExpectedHash) {
    Assert-NoForensicReparse $Path
    $item = Get-Item -LiteralPath $Path -Force -ErrorAction Stop
    if ($item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
        throw 'UNSAFE_COLLECTOR'
    }
    if ((Get-FileHash -Algorithm SHA256 -LiteralPath $Path).Hash -cne $ExpectedHash) {
        throw 'COLLECTOR_HASH_MISMATCH'
    }
}

function Test-SafeForensicStatus([hashtable]$Record) {
    if ($null -eq $Record -or $Record.Count -ne 3) { return $false }
    $missing = @(@('status','caseId','sanitizedSharePath') |
        Where-Object { -not $Record.ContainsKey($_) })
    if ($missing.Count -ne 0) { return $false }
    if (@('PASS','PARTIAL','FAIL') -cnotcontains [string]$Record.status) { return $false }
    if ($Record.status -ceq 'FAIL' -and $null -eq $Record.caseId -and
        $null -eq $Record.sanitizedSharePath) { return $true }
    if ([string]$Record.caseId -cnotmatch '^case-\d{8}-\d{6}-[0-9a-f]{8}$') { return $false }
    $expected = 'C:\ProgramData\FamilyDashboardForensics\' + [string]$Record.caseId + '\sanitized-share'
    return [string]::Equals([string]$Record.sanitizedSharePath, $expected,
        [StringComparison]::OrdinalIgnoreCase)
}

function New-ForensicStatusFileSecurity([string]$DashboardSid) {
    $security = New-Object Security.AccessControl.FileSecurity
    $security.SetAccessRuleProtection($true,$false)
    $admin = New-Object Security.Principal.SecurityIdentifier('S-1-5-32-544')
    $security.SetOwner($admin)
    foreach ($sidText in @('S-1-5-18','S-1-5-32-544')) {
        $sid = New-Object Security.Principal.SecurityIdentifier($sidText)
        $rule = New-Object Security.AccessControl.FileSystemAccessRule($sid,
            [Security.AccessControl.FileSystemRights]::FullControl,
            [Security.AccessControl.AccessControlType]::Allow)
        $security.AddAccessRule($rule)
    }
    $dashboard = New-Object Security.Principal.SecurityIdentifier($DashboardSid)
    $readRule = New-Object Security.AccessControl.FileSystemAccessRule($dashboard,
        [Security.AccessControl.FileSystemRights]::Read,
        [Security.AccessControl.AccessControlType]::Allow)
    $security.AddAccessRule($readRule)
    return $security
}

function Assert-ForensicStatusFile([string]$Path, [string]$DashboardSid) {
    Assert-NoForensicReparse $Path
    Assert-ForensicAcl $Path $DashboardSid
    $owner = (Get-Acl -LiteralPath $Path).GetOwner([Security.Principal.SecurityIdentifier]).Value
    if (@('S-1-5-18','S-1-5-32-544') -cnotcontains $owner) { throw 'UNSAFE_STATUS_OWNER' }
}

function Write-ForensicStatus([hashtable]$Record, [string]$StatusDirectory,
        [string]$PrivateStatusDirectory, [string]$DashboardSid) {
    if (-not (Test-SafeForensicStatus $Record)) { throw 'INVALID_STATUS' }
    Assert-NoForensicReparse $StatusDirectory
    Assert-NoForensicReparse $PrivateStatusDirectory
    $target = Join-Path $StatusDirectory 'latest.json'
    $temp = Join-Path $PrivateStatusDirectory ('latest-' + [Guid]::NewGuid().ToString('N') + '.tmp')
    $json = ConvertTo-Json -InputObject $Record -Compress
    [IO.File]::WriteAllText($temp, $json, (New-Object Text.UTF8Encoding($false)))
    try {
        [IO.File]::SetAccessControl($temp,(New-ForensicStatusFileSecurity $DashboardSid))
        if ([IO.File]::ReadAllText($temp) -cne $json) { throw 'STATUS_WRITE_RACE' }
        if (Test-Path -LiteralPath $target) {
            Assert-ForensicStatusFile $target $DashboardSid
            [IO.File]::Replace($temp,$target,$null)
        } else { [IO.File]::Move($temp,$target) }
        Assert-ForensicStatusFile $target $DashboardSid
    } finally {
        if (Test-Path -LiteralPath $temp) { Remove-Item -LiteralPath $temp -Force }
    }
}

function Archive-PriorForensicStatus([string]$StatusDirectory, [string]$PrivateStatusDirectory,
        [string]$DashboardSid) {
    Assert-NoForensicReparse $StatusDirectory
    Assert-NoForensicReparse $PrivateStatusDirectory
    $previous = Join-Path $StatusDirectory 'latest.json'
    if (-not (Test-Path -LiteralPath $previous)) { return }
    Assert-ForensicStatusFile $previous $DashboardSid
    $archive = Join-Path $PrivateStatusDirectory ('previous-' + [Guid]::NewGuid().ToString('N') + '.json')
    [IO.File]::Move($previous,$archive)
    Assert-ForensicStatusFile $archive $DashboardSid
}

function Write-FixedLaunchAck([string]$StatusDirectory, [string]$PrivateStatusDirectory,
        [string]$DashboardSid) {
    Assert-NoForensicReparse $StatusDirectory
    Assert-NoForensicReparse $PrivateStatusDirectory
    $target = Join-Path $StatusDirectory 'launch.pid'
    $temp = Join-Path $PrivateStatusDirectory ('launch-' + [Guid]::NewGuid().ToString('N') + '.tmp')
    $value = [string]$PID
    [IO.File]::WriteAllText($temp,$value,(New-Object Text.UTF8Encoding($false)))
    try {
        [IO.File]::SetAccessControl($temp,(New-ForensicStatusFileSecurity $DashboardSid))
        if (Test-Path -LiteralPath $target) {
            Assert-ForensicStatusFile $target $DashboardSid
            [IO.File]::Replace($temp,$target,$null)
        } else { [IO.File]::Move($temp,$target) }
        Assert-ForensicStatusFile $target $DashboardSid
    } finally {
        if (Test-Path -LiteralPath $temp) { Remove-Item -LiteralPath $temp -Force }
    }
}

function New-ForensicDirectory([string]$Path, [string]$DashboardSid, [bool]$ReadableByDashboard) {
    Assert-NoForensicReparse $Path
    if (Test-Path -LiteralPath $Path) {
        Assert-ForensicAcl $Path $DashboardSid
        return
    }
    $security = New-Object Security.AccessControl.DirectorySecurity
    $security.SetAccessRuleProtection($true,$false)
    $admin = New-Object Security.Principal.SecurityIdentifier('S-1-5-32-544')
    $security.SetOwner($admin)
    $inherit = [Security.AccessControl.InheritanceFlags]::ContainerInherit -bor
        [Security.AccessControl.InheritanceFlags]::ObjectInherit
    foreach ($sidText in @('S-1-5-18','S-1-5-32-544')) {
        $sid = New-Object Security.Principal.SecurityIdentifier($sidText)
        $rule = New-Object Security.AccessControl.FileSystemAccessRule($sid,
            [Security.AccessControl.FileSystemRights]::FullControl,$inherit,
            [Security.AccessControl.PropagationFlags]::None,
            [Security.AccessControl.AccessControlType]::Allow)
        $security.AddAccessRule($rule)
    }
    if ($ReadableByDashboard) {
        $sid = New-Object Security.Principal.SecurityIdentifier($DashboardSid)
        $rule = New-Object Security.AccessControl.FileSystemAccessRule($sid,
            [Security.AccessControl.FileSystemRights]::ReadAndExecute,$inherit,
            [Security.AccessControl.PropagationFlags]::None,
            [Security.AccessControl.AccessControlType]::Allow)
        $security.AddAccessRule($rule)
    }
    [void][IO.Directory]::CreateDirectory($Path,$security)
    Assert-ForensicAcl $Path $DashboardSid
}

function Wait-FixedCollector([Diagnostics.Process]$Process, [int]$TimeoutMs) {
    if ($TimeoutMs -le 0 -or $TimeoutMs -gt 900000) { throw 'INVALID_TIMEOUT' }
    if (-not $Process.WaitForExit($TimeoutMs)) {
        & 'C:\Windows\System32\taskkill.exe' /PID $Process.Id /T /F 2>$null | Out-Null
        if (-not $Process.WaitForExit(10000)) { throw 'COLLECTOR_KILL_FAILED' }
        return 'TIMEOUT'
    }
    if ($Process.ExitCode -ne 0) { return 'FAIL' }
    return 'COMPLETE'
}

$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator) -or
    [Environment]::UserName -ine 'DashboardAdmin') { exit 30 }
$dashboardSid = $identity.User.Value
$standardUser = Get-LocalUser -Name 'Dashboard' -ErrorAction SilentlyContinue
if ($null -eq $standardUser -or -not $standardUser.SID.Value) { exit 30 }
$standardDashboardSid = $standardUser.SID.Value
$collector = 'C:\FamilyDashboard\launcher\Collect-CHUWIPowerForensics.ps1'
$expectedHash = '0A4E34C6446AF5AA5C86780ABC486DBE932E62718C87994DE13CF03A44397167'
$powershell = 'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe'
$root = 'C:\ProgramData\FamilyDashboardForensics'
$statusDirectory = Join-Path $root 'status'
$privateStatusDirectory = Join-Path $root 'status-private'
$mutex = New-Object Threading.Mutex($false,'Global\FamilyDashboardPowerForensics')
$lockHeld = $false
$statusReady = $false
try {
    $lockHeld = $mutex.WaitOne(0)
    if (-not $lockHeld) { exit 31 }
    New-ForensicDirectory $root $dashboardSid $true
    New-ForensicDirectory $statusDirectory $dashboardSid $true
    New-ForensicDirectory $privateStatusDirectory $dashboardSid $false
    $statusReady = $true
    Archive-PriorForensicStatus $statusDirectory $privateStatusDirectory $dashboardSid
    Write-FixedLaunchAck $statusDirectory $privateStatusDirectory $dashboardSid
    Assert-NoForensicReparse 'C:\FamilyDashboard\launcher'
    Assert-ForensicAcl 'C:\FamilyDashboard' $dashboardSid $standardDashboardSid
    Assert-ForensicAcl 'C:\FamilyDashboard\launcher' $dashboardSid $standardDashboardSid
    Assert-FixedCollector $collector $expectedHash
    Assert-ForensicAcl $collector $dashboardSid $standardDashboardSid
    if (-not (Test-Path -LiteralPath $powershell -PathType Leaf)) { throw 'POWERSHELL_MISSING' }
    $startedAt = Get-Date
    $process = Start-Process -FilePath $powershell -WindowStyle Hidden -PassThru `
        -WorkingDirectory 'C:\FamilyDashboard\launcher' `
        -ArgumentList @('-NoLogo','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass',
            '-File', ('"{0}"' -f $collector)) -ErrorAction Stop
    $exitState = Wait-FixedCollector $process 900000
    $result = if ($exitState -eq 'COMPLETE') { $null } else { 'FAIL' }
    $cases = @(Get-ChildItem -LiteralPath $root -Directory -Filter 'case-*' -ErrorAction Stop |
        Where-Object { $_.CreationTime -ge $startedAt.AddSeconds(-2) })
    if ($cases.Count -ne 1) {
        Write-ForensicStatus @{status='FAIL';caseId=$null;sanitizedSharePath=$null} `
            $statusDirectory $privateStatusDirectory $dashboardSid
        exit 32
    }
    $case = $cases[0]
    Assert-NoForensicReparse $case.FullName
    $summaryPath = Join-Path $case.FullName 'sanitized-share\summary.json'
    Assert-NoForensicReparse $summaryPath
    if (-not $result) {
        $summary = Get-Content -LiteralPath $summaryPath -Raw -ErrorAction Stop | ConvertFrom-Json
        $result = [string]$summary.collectionStatus
    }
    $record = @{ status=$result; caseId=$case.Name;
        sanitizedSharePath=(Join-Path $case.FullName 'sanitized-share') }
    Write-ForensicStatus $record $statusDirectory $privateStatusDirectory $dashboardSid
    exit 0
} catch {
    if ($statusReady) {
        try {
            Write-ForensicStatus @{status='FAIL';caseId=$null;sanitizedSharePath=$null} `
                $statusDirectory $privateStatusDirectory $dashboardSid
        } catch {}
    }
    exit 32
} finally {
    if ($lockHeld) { $mutex.ReleaseMutex() }
    $mutex.Dispose()
}
