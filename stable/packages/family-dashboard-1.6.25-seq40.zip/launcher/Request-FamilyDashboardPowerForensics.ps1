#requires -Version 5.1
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

function Set-FixedForensicEnvironment {
    $env:PSModulePath = 'C:\Windows\System32\WindowsPowerShell\v1.0\Modules;C:\Program Files\WindowsPowerShell\Modules'
    $env:PATH = 'C:\Windows\System32;C:\Windows'
    [Environment]::CurrentDirectory = 'C:\Windows\System32'
}
Set-FixedForensicEnvironment

function Convert-FixedUacFailure([Exception]$ErrorValue) {
    if ($ErrorValue -is [System.ComponentModel.Win32Exception] -and
        $ErrorValue.NativeErrorCode -eq 1223) { return 20 }
    return 30
}

function Assert-NoRequestReparse([string]$Path) {
    $current = [IO.Path]::GetFullPath($Path)
    while ($current) {
        if (Test-Path -LiteralPath $current) {
            $item = Get-Item -LiteralPath $current -Force -ErrorAction Stop
            if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'UNSAFE_PATH' }
        }
        $parent = [IO.Directory]::GetParent($current)
        if ($null -eq $parent) { break }
        $current = $parent.FullName
    }
}

function Assert-RequestSafeAcl([string]$Path, [string]$DashboardSid,
        [string]$StandardDashboardSid = '') {
    $acl = Get-Acl -LiteralPath $Path -ErrorAction Stop
    $owner = $acl.GetOwner([Security.Principal.SecurityIdentifier]).Value
    if (@('S-1-5-18','S-1-5-32-544') -cnotcontains $owner) {
        throw 'UNSAFE_OWNER'
    }
    $dangerous = [Security.AccessControl.FileSystemRights]::WriteData -bor
        [Security.AccessControl.FileSystemRights]::AppendData -bor
        [Security.AccessControl.FileSystemRights]::WriteExtendedAttributes -bor
        [Security.AccessControl.FileSystemRights]::WriteAttributes -bor
        [Security.AccessControl.FileSystemRights]::Delete -bor
        [Security.AccessControl.FileSystemRights]::ChangePermissions -bor
        [Security.AccessControl.FileSystemRights]::TakeOwnership
    foreach ($rule in $acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier])) {
        $sid = $rule.IdentityReference.Value
        if ($rule.AccessControlType -ne [Security.AccessControl.AccessControlType]::Allow -or
            @('S-1-5-18','S-1-5-32-544',$DashboardSid,$StandardDashboardSid) -cnotcontains $sid -or
            (($rule.FileSystemRights -band $dangerous) -ne 0 -and
                @('S-1-5-18','S-1-5-32-544') -cnotcontains $sid)) {
            throw 'UNSAFE_ACL'
        }
    }
}

function Test-FixedLaunchRecord([string]$Value, $Item, [int]$RunnerPid,
        [datetime]$StartedAtUtc) {
    return ($Item.Length -le 16 -and $Item.LastWriteTimeUtc -ge $StartedAtUtc.AddSeconds(-2) -and
        $Value -match '^\d{1,10}$' -and [int64]$Value -eq $RunnerPid)
}

function Wait-FixedLaunchAck($RunnerProcess, [datetime]$StartedAtUtc,
        [string]$DashboardSid, [string]$StandardDashboardSid) {
    $runnerPid = [int]$RunnerProcess.Id
    $root = 'C:\ProgramData\FamilyDashboardForensics'
    $status = Join-Path $root 'status'
    $ack = Join-Path $status 'launch.pid'
    for ($attempt = 0; $attempt -lt 300; $attempt++) {
        if (Test-Path -LiteralPath $ack -PathType Leaf) {
            Assert-NoRequestReparse $ack
            foreach ($path in @($root,$status,$ack)) {
                Assert-RequestSafeAcl $path $DashboardSid $StandardDashboardSid
            }
            $item = Get-Item -LiteralPath $ack -Force -ErrorAction Stop
            if ($item.Length -le 16) {
                $value = [IO.File]::ReadAllText($ack)
                if (Test-FixedLaunchRecord $value $item $RunnerPid $StartedAtUtc) { return $true }
            }
        }
        if ($RunnerProcess.HasExited) { return $false }
        Start-Sleep -Milliseconds 100
    }
    return $false
}

function Invoke-FixedUacStart([string]$DashboardSid, [string]$StandardDashboardSid) {
    $runner = 'C:\FamilyDashboard\launcher\Invoke-FamilyDashboardPowerForensics.ps1'
    $powershell = 'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe'
    try {
        $startedAtUtc = [datetime]::UtcNow
        $process = Start-Process -FilePath $powershell -Verb RunAs -WindowStyle Hidden -PassThru `
            -WorkingDirectory 'C:\FamilyDashboard\launcher' `
            -ArgumentList @('-NoLogo','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass',
                '-File', ('"{0}"' -f $runner)) -ErrorAction Stop
        if ($null -eq $process -or $process.Id -le 0) { return 30 }
        if (Wait-FixedLaunchAck $process $startedAtUtc $DashboardSid $StandardDashboardSid) { return 0 }
        return 30
    } catch [System.ComponentModel.Win32Exception] {
        return Convert-FixedUacFailure $_.Exception
    } catch {
        return 30
    }
}

$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
if ($principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator) -or
    [Environment]::UserName -ine 'DashboardAdmin') { exit 30 }

$runner = 'C:\FamilyDashboard\launcher\Invoke-FamilyDashboardPowerForensics.ps1'
$powershell = 'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe'
if (-not (Test-Path -LiteralPath $runner -PathType Leaf) -or
    -not (Test-Path -LiteralPath $powershell -PathType Leaf)) { exit 30 }
try {
    Assert-NoRequestReparse $runner
    $item = Get-Item -LiteralPath $runner -Force -ErrorAction Stop
    if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { exit 30 }
    $standardUser = Get-LocalUser -Name 'Dashboard' -ErrorAction Stop
    if ($null -eq $standardUser -or -not $standardUser.SID.Value) { exit 30 }
    foreach ($path in @('C:\FamilyDashboard','C:\FamilyDashboard\launcher',$runner)) {
        Assert-RequestSafeAcl $path $identity.User.Value $standardUser.SID.Value
    }
    exit (Invoke-FixedUacStart $identity.User.Value $standardUser.SID.Value)
} catch { exit 30 }
