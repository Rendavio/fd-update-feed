Set-StrictMode -Version 2.0

$script:ApplyPhaseValues = @(
    "UNKNOWN", "REQUEST_ACCEPTED", "UAC_APPROVED", "COORDINATOR_STARTED",
    "SHUTDOWN_REQUESTED", "SERVER_EXITED", "PORT_CLOSED", "UPDATER_STARTED",
    "UPDATER_FINISHED", "WATCHER_RESTARTED", "HEALTH_OK"
)
$script:ApplyResultValues = @("UNKNOWN", "RUNNING", "PASS", "FAIL", "TIMEOUT")
$script:ApplyErrorValues = @(
    "NONE", "UAC_CANCELLED", "COORDINATOR_NOT_STARTED", "SERVER_EXIT_TIMEOUT",
    "PORT_CLOSE_TIMEOUT", "UPDATER_NOT_STARTED", "UPDATER_EXIT_NONZERO",
    "UPDATER_TIMEOUT", "RESTART_TIMEOUT"
)
$script:UpdaterExitCodeValues = @("0", "2", "3", "5", "64", "OTHER", "UNKNOWN")
$script:UpdaterFailureStageValues = @("UNKNOWN")
$script:ApplyStatePath = Join-Path $env:LOCALAPPDATA "FamilyDashboard\apply-phase.json"
$script:ApplyStateTempPath = $script:ApplyStatePath + ".tmp"
$script:ApplyStateBackupPath = $script:ApplyStatePath + ".bak"
$script:ApplyStateMutexName = "Local\FamilyDashboardApplyPhaseState"

function Read-FamilyDashboardApplyPhase {
    try {
        if (-not (Test-Path -LiteralPath $script:ApplyStatePath -PathType Leaf)) { return $null }
        $bytes = [IO.File]::ReadAllBytes($script:ApplyStatePath)
        if ($bytes.Length -lt 1 -or $bytes.Length -gt 256 -or
            ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF)) {
            return $null
        }
        $value = ([Text.UTF8Encoding]::new($false, $true).GetString($bytes) | ConvertFrom-Json)
        $names = @($value.PSObject.Properties.Name | Sort-Object)
        $legacySchema = (($names -join ",") -ceq "error,phase,result,schemaVersion" -and $value.schemaVersion -eq 1)
        $currentSchema = (($names -join ",") -ceq "error,phase,result,schemaVersion,updaterExitCode,updaterFailureStage" -and
            $value.schemaVersion -eq 2)
        if ((-not $legacySchema -and -not $currentSchema) -or
            $script:ApplyPhaseValues -cnotcontains [string]$value.phase -or
            $script:ApplyResultValues -cnotcontains [string]$value.result -or
            $script:ApplyErrorValues -cnotcontains [string]$value.error) {
            return $null
        }
        if ($legacySchema) {
            $value | Add-Member -NotePropertyName updaterExitCode -NotePropertyValue "UNKNOWN"
            $value | Add-Member -NotePropertyName updaterFailureStage -NotePropertyValue "UNKNOWN"
        } elseif ($script:UpdaterExitCodeValues -cnotcontains [string]$value.updaterExitCode -or
            $script:UpdaterFailureStageValues -cnotcontains [string]$value.updaterFailureStage) {
            return $null
        }
        return $value
    } catch {
        return $null
    }
}

function Write-FamilyDashboardApplyPhase {
    param(
        [Parameter(Mandatory = $true)][ValidateSet(
            "UNKNOWN", "REQUEST_ACCEPTED", "UAC_APPROVED", "COORDINATOR_STARTED",
            "SHUTDOWN_REQUESTED", "SERVER_EXITED", "PORT_CLOSED", "UPDATER_STARTED",
            "UPDATER_FINISHED", "WATCHER_RESTARTED", "HEALTH_OK"
        )][string]$Phase,
        [Parameter(Mandatory = $true)][ValidateSet("UNKNOWN", "RUNNING", "PASS", "FAIL", "TIMEOUT")][string]$Result,
        [Parameter(Mandatory = $true)][ValidateSet(
            "NONE", "UAC_CANCELLED", "COORDINATOR_NOT_STARTED", "SERVER_EXIT_TIMEOUT",
            "PORT_CLOSE_TIMEOUT", "UPDATER_NOT_STARTED", "UPDATER_EXIT_NONZERO",
            "UPDATER_TIMEOUT", "RESTART_TIMEOUT"
        )][string]$ErrorCode,
        [Parameter()][ValidateSet("0", "2", "3", "5", "64", "OTHER", "UNKNOWN")][string]$UpdaterExitCode,
        [Parameter()][ValidateSet("UNKNOWN")][string]$UpdaterFailureStage
    )
    $mutex = New-Object Threading.Mutex($false, $script:ApplyStateMutexName)
    $acquired = $false
    try {
        $acquired = $mutex.WaitOne(5000)
        if (-not $acquired) { throw "Apply phase state lock timeout" }
        $existing = Read-FamilyDashboardApplyPhase
        if ($null -ne $existing) {
            $oldRank = [Array]::IndexOf($script:ApplyPhaseValues, [string]$existing.phase)
            $newRank = [Array]::IndexOf($script:ApplyPhaseValues, $Phase)
            if ($oldRank -gt $newRank) { return }
        }
        $exitCodeValue = if ($PSBoundParameters.ContainsKey("UpdaterExitCode")) {
            $UpdaterExitCode
        } elseif ($null -ne $existing) {
            [string]$existing.updaterExitCode
        } else { "UNKNOWN" }
        $failureStageValue = if ($PSBoundParameters.ContainsKey("UpdaterFailureStage")) {
            $UpdaterFailureStage
        } elseif ($null -ne $existing) {
            [string]$existing.updaterFailureStage
        } else { "UNKNOWN" }
        $record = [ordered]@{
            schemaVersion = 2
            phase = $Phase
            result = $Result
            error = $ErrorCode
            updaterExitCode = $exitCodeValue
            updaterFailureStage = $failureStageValue
        }
        $json = ($record | ConvertTo-Json -Compress) + "`n"
        $bytes = (New-Object Text.UTF8Encoding($false)).GetBytes($json)
        if ($bytes.Length -gt 256) { throw "Apply phase state exceeds its bound" }
        $directory = Split-Path -Parent $script:ApplyStatePath
        New-Item -ItemType Directory -Path $directory -Force | Out-Null
        [IO.File]::WriteAllBytes($script:ApplyStateTempPath, $bytes)
        if ([IO.File]::Exists($script:ApplyStatePath)) {
            [IO.File]::Replace(
                $script:ApplyStateTempPath, $script:ApplyStatePath,
                $script:ApplyStateBackupPath, $true)
            Remove-Item -LiteralPath $script:ApplyStateBackupPath -Force -ErrorAction SilentlyContinue
        } else {
            [IO.File]::Move($script:ApplyStateTempPath, $script:ApplyStatePath)
        }
    } finally {
        Remove-Item -LiteralPath $script:ApplyStateTempPath -Force -ErrorAction SilentlyContinue
        Remove-Item -LiteralPath $script:ApplyStateBackupPath -Force -ErrorAction SilentlyContinue
        if ($acquired) { [void]$mutex.ReleaseMutex() }
        $mutex.Dispose()
    }
}
