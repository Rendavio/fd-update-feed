#requires -Version 5.1
param(
    [Parameter(Mandatory = $true)]
    [ValidateRange(1, 4294967295)]
    [int64]$UpdateProcessId
)
Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"
. (Join-Path $PSScriptRoot "ApplyPhase.Common.ps1")
$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
if ($principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { exit 5 }
if ([Environment]::UserName -ine "DashboardAdmin") { exit 5 }

for ($second = 0; $second -lt 660; $second++) {
    if ($null -eq (Get-Process -Id $UpdateProcessId -ErrorAction SilentlyContinue)) { break }
    Start-Sleep -Seconds 1
}
if ($null -ne (Get-Process -Id $UpdateProcessId -ErrorAction SilentlyContinue)) { exit 6 }

$prior = Read-FamilyDashboardApplyPhase
$priorResult = if ($null -eq $prior -or [string]$prior.result -eq "UNKNOWN") { "FAIL" } else { [string]$prior.result }
$priorError = if ($null -eq $prior -or [string]$prior.result -eq "UNKNOWN") {
    "COORDINATOR_NOT_STARTED"
} else { [string]$prior.error }
if ($priorResult -eq "RUNNING") {
    try { Write-FamilyDashboardApplyPhase "WATCHER_RESTARTED" "RUNNING" "NONE" } catch {}
}

$startScript = "C:\FamilyDashboard\launcher\Start-FamilyDashboard.ps1"
for ($attempt = 0; $attempt -lt 45; $attempt++) {
    try {
        & $startScript -Mode production -Page dashboard
        if ($priorResult -eq "RUNNING") {
            try { Write-FamilyDashboardApplyPhase "HEALTH_OK" "PASS" "NONE" } catch {}
        }
        exit 0
    } catch {
        Start-Sleep -Seconds 2
    }
}
if ($priorResult -eq "RUNNING") {
    try { Write-FamilyDashboardApplyPhase "WATCHER_RESTARTED" "TIMEOUT" "RESTART_TIMEOUT" } catch {}
}
exit 7
