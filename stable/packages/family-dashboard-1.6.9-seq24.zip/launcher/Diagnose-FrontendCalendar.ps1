. (Join-Path $PSScriptRoot "FamilyDashboard.Common.ps1")

if ([Environment]::UserName -ne "Dashboard") {
    throw "Frontend Calendar diagnostics must be run while signed in as Dashboard."
}
$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
if ($principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw "Frontend Calendar diagnostics must not be run from an elevated process."
}
if (-not $env:LOCALAPPDATA) {
    throw "LOCALAPPDATA is unavailable for the Dashboard user."
}
$health = Get-FamilyDashboardHealth
if (-not $health -or $health.appId -ne "family-dashboard" -or $health.mode -ne "production") {
    throw "Production Family Dashboard is not responding at 127.0.0.1:3000. Start it first."
}
$edgePath = Get-FamilyDashboardEdgePath
if (-not $edgePath) {
    throw "Microsoft Edge Chromium was not found."
}
$diagnosticPath = Join-Path $script:AppRoot "frontend_calendar_diagnostics.py"
if (-not (Test-Path -LiteralPath $script:PythonPath -PathType Leaf)) {
    throw "Bundled Python runtime is missing."
}
if (-not (Test-Path -LiteralPath $diagnosticPath -PathType Leaf)) {
    throw "Frontend Calendar diagnostic module is missing."
}

$previousEdgePath = $env:FAMILY_DASHBOARD_EDGE_PATH
$previousUtf8 = $env:PYTHONUTF8
$previousNoBytecode = $env:PYTHONDONTWRITEBYTECODE
try {
    $env:FAMILY_DASHBOARD_EDGE_PATH = $edgePath
    $env:PYTHONUTF8 = "1"
    $env:PYTHONDONTWRITEBYTECODE = "1"
    & $script:PythonPath -B $diagnosticPath
    $diagnosticExitCode = $LASTEXITCODE
} finally {
    $env:FAMILY_DASHBOARD_EDGE_PATH = $previousEdgePath
    $env:PYTHONUTF8 = $previousUtf8
    $env:PYTHONDONTWRITEBYTECODE = $previousNoBytecode
}

$reportPath = Join-Path (Join-Path $env:LOCALAPPDATA "FamilyDashboard") "Frontend-Calendar-Diagnostic-Report.txt"
Write-Host "Sanitized report: $reportPath"
if ($diagnosticExitCode -ne 0) {
    throw "Frontend Calendar diagnostics completed with one or more findings. Review the sanitized report."
}
Write-Host "Frontend Calendar diagnostics PASS"
