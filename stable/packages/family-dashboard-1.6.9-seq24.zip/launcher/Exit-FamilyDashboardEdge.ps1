#requires -Version 5.1
Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"
$productionUrl = "http://127.0.0.1:3000/?display=1&theme=auto&calendar=google&eew=production"
Start-Sleep -Milliseconds 500
$matches = @(Get-CimInstance Win32_Process -Filter "Name='msedge.exe'" | Where-Object {
    $_.CommandLine -and
    $_.CommandLine.Contains($productionUrl) -and
    $_.CommandLine -match '(?i)(?:^|\s)--kiosk(?:\s|=)'
})
foreach ($candidate in $matches) {
    $owner = Invoke-CimMethod -InputObject $candidate -MethodName GetOwner
    if ($owner.ReturnValue -eq 0 -and $owner.User -ieq "DashboardAdmin") {
        Stop-Process -Id $candidate.ProcessId -ErrorAction Stop
    }
}
