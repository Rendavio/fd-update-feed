Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"

$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
if ([Environment]::UserName -ne "DashboardAdmin") {
    throw "Uninstall must be run while signed in as DashboardAdmin."
}
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw "Uninstall must be run as DashboardAdmin."
}

$installRoot = "C:\FamilyDashboard"
$expectedPython = Join-Path $installRoot "runtime\python.exe"
$expectedServer = Join-Path $installRoot "app\server.py"
$matchingProcesses = @(Get-CimInstance Win32_Process | Where-Object {
    $_.ExecutablePath -and
    ([IO.Path]::GetFullPath($_.ExecutablePath) -eq [IO.Path]::GetFullPath($expectedPython)) -and
    $_.CommandLine -like "*$expectedServer*"
})
foreach ($serverProcess in $matchingProcesses) {
    Stop-Process -Id $serverProcess.ProcessId -Force
    Wait-Process -Id $serverProcess.ProcessId -Timeout 10 -ErrorAction SilentlyContinue
}

$rootFull = [IO.Path]::GetFullPath($installRoot).TrimEnd("\")
foreach ($name in @("app", "runtime", "launcher")) {
    $target = [IO.Path]::GetFullPath((Join-Path $installRoot $name))
    if ([IO.Path]::GetDirectoryName($target) -ne $rootFull) {
        throw "Uninstall target escaped C:\FamilyDashboard: $target"
    }
    if (Test-Path -LiteralPath $target) {
        Remove-Item -LiteralPath $target -Recurse -Force
        Write-Host "Removed: $target"
    }
}

$dashboardAccount = Get-CimInstance Win32_UserAccount -Filter "LocalAccount=True AND Name='Dashboard'" | Select-Object -First 1
$dashboardProfile = $null
if ($dashboardAccount) {
    $dashboardProfile = Get-CimInstance Win32_UserProfile | Where-Object {
        $_.SID -eq $dashboardAccount.SID
    } | Select-Object -First 1
}

if ($dashboardProfile) {
    $privateTarget = Join-Path $dashboardProfile.LocalPath "AppData\Local\FamilyDashboard"
    if (Test-Path -LiteralPath $privateTarget) {
        Write-Host ""
        Write-Host "Private settings, Service Account key, caches, logs, and the runtime report remain at:"
        Write-Host $privateTarget
        $answer = Read-Host "Type DELETE-PRIVATE to remove that exact folder, or press Enter to keep it"
        if ($answer -ceq "DELETE-PRIVATE") {
            $expectedPrivate = [IO.Path]::GetFullPath((Join-Path $dashboardProfile.LocalPath "AppData\Local\FamilyDashboard"))
            $resolvedPrivate = [IO.Path]::GetFullPath($privateTarget)
            if ($resolvedPrivate -ne $expectedPrivate -or [IO.Path]::GetFileName($resolvedPrivate) -ne "FamilyDashboard") {
                throw "Private data deletion target validation failed."
            }
            Remove-Item -LiteralPath $resolvedPrivate -Recurse -Force
            Write-Host "Removed private Dashboard data."
        } else {
            Write-Host "Private Dashboard data was kept."
        }
    }
}

Write-Host ""
Write-Host "Uninstall complete."
Write-Host "Dashboard/DashboardAdmin accounts, Windows settings, drivers, Wi-Fi, Firewall rules, and the Phase A report were not removed."
