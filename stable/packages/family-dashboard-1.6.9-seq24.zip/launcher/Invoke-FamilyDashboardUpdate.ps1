#requires -Version 5.1
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidatePattern('^[0-9a-f]{32}$')]
    [string]$RequestId,

    [Parameter(Mandatory = $true)]
    [ValidateRange(1, 4294967295)]
    [int64]$ServerProcessId
)
Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"
. (Join-Path $PSScriptRoot "ApplyPhase.Common.ps1")

function Test-IsAdministrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

if (-not (Test-IsAdministrator) -or [Environment]::UserName -ine "DashboardAdmin") {
    try { Write-FamilyDashboardApplyPhase "COORDINATOR_STARTED" "FAIL" "COORDINATOR_NOT_STARTED" } catch {}
    exit 5
}
try { Write-FamilyDashboardApplyPhase "COORDINATOR_STARTED" "RUNNING" "NONE" } catch {}

function Test-Port3000Listening {
    $client = New-Object Net.Sockets.TcpClient
    try {
        $async = $client.BeginConnect("127.0.0.1", 3000, $null, $null)
        $completed = $async.AsyncWaitHandle.WaitOne(250)
        if (-not $completed) { return $false }
        $client.EndConnect($async)
        return $client.Connected
    } catch {
        return $false
    } finally {
        $client.Dispose()
    }
}

function ConvertTo-SanitizedUpdaterExitCode {
    param([int]$ExitCode)
    switch ($ExitCode) {
        0 { return "0" }
        2 { return "2" }
        3 { return "3" }
        5 { return "5" }
        64 { return "64" }
        default { return "OTHER" }
    }
}

$serverRunning = $true
$listening = $true
$serverExitRecorded = $false
$portClosedRecorded = $false
for ($attempt = 0; $attempt -lt 60; $attempt++) {
    $serverRunning = $null -ne (Get-Process -Id $ServerProcessId -ErrorAction SilentlyContinue)
    $listening = Test-Port3000Listening
    if (-not $serverRunning -and -not $serverExitRecorded) {
        try { Write-FamilyDashboardApplyPhase "SERVER_EXITED" "RUNNING" "NONE" } catch {}
        $serverExitRecorded = $true
    }
    if (-not $listening -and -not $portClosedRecorded) {
        try { Write-FamilyDashboardApplyPhase "PORT_CLOSED" "RUNNING" "NONE" } catch {}
        $portClosedRecorded = $true
    }
    if (-not $serverRunning -and -not $listening) { break }
    Start-Sleep -Milliseconds 500
}
if ($serverRunning -or $listening) {
    $timeoutPhase = if ($portClosedRecorded) { "PORT_CLOSED" } elseif ($serverExitRecorded) { "SERVER_EXITED" } else { "COORDINATOR_STARTED" }
    $timeoutError = if ($serverRunning) { "SERVER_EXIT_TIMEOUT" } else { "PORT_CLOSE_TIMEOUT" }
    try { Write-FamilyDashboardApplyPhase $timeoutPhase "TIMEOUT" $timeoutError } catch {}
    exit 7
}
try { Write-FamilyDashboardApplyPhase "PORT_CLOSED" "RUNNING" "NONE" } catch {}
$root = "C:\ProgramData\FamilyDashboardUpdater"
$python = Join-Path $root "runtime\python.exe"
$apply = Join-Path $root "program\apply_update.py"
if (-not (Test-Path -LiteralPath $python -PathType Leaf) -or
    -not (Test-Path -LiteralPath $apply -PathType Leaf)) {
    try { Write-FamilyDashboardApplyPhase "PORT_CLOSED" "FAIL" "UPDATER_NOT_STARTED" } catch {}
    exit 8
}
$arguments = @("-I", "-s", "-B", "-X", "utf8", ('"{0}"' -f $apply))
try {
    $applyProcess = Start-Process -FilePath $python -ArgumentList $arguments `
        -WorkingDirectory $root -WindowStyle Hidden -PassThru
} catch {
    try { Write-FamilyDashboardApplyPhase "PORT_CLOSED" "FAIL" "UPDATER_NOT_STARTED" } catch {}
    exit 8
}
try { Write-FamilyDashboardApplyPhase "UPDATER_STARTED" "RUNNING" "NONE" } catch {}
for ($second = 0; $second -lt 600; $second++) {
    if ($applyProcess.HasExited) { break }
    Start-Sleep -Seconds 1
    $applyProcess.Refresh()
}
if (-not $applyProcess.HasExited) {
    # This is the exact child created above, not a discovered/arbitrary process.
    Stop-Process -Id $applyProcess.Id -Force -ErrorAction SilentlyContinue
    try { $applyProcess.WaitForExit(5000) } catch {}
    try { Write-FamilyDashboardApplyPhase "UPDATER_STARTED" "TIMEOUT" "UPDATER_TIMEOUT" } catch {}
    exit 9
}
if ($applyProcess.ExitCode -ne 0) {
    $sanitizedExitCode = ConvertTo-SanitizedUpdaterExitCode -ExitCode $applyProcess.ExitCode
    try {
        Write-FamilyDashboardApplyPhase "UPDATER_FINISHED" "FAIL" "UPDATER_EXIT_NONZERO" `
            -UpdaterExitCode $sanitizedExitCode -UpdaterFailureStage "UNKNOWN"
    } catch {}
    exit $applyProcess.ExitCode
}
try {
    Write-FamilyDashboardApplyPhase "UPDATER_FINISHED" "RUNNING" "NONE" `
        -UpdaterExitCode "0" -UpdaterFailureStage "UNKNOWN"
} catch {}
exit $applyProcess.ExitCode
