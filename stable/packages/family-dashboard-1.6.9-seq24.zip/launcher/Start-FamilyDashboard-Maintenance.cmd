@echo off
setlocal
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start-FamilyDashboard.ps1" -Mode development -Page dashboard
if errorlevel 1 pause
endlocal
