. (Join-Path $PSScriptRoot "FamilyDashboard.Common.ps1")

if (-not $env:LOCALAPPDATA) {
    throw "LOCALAPPDATA is unavailable for the current user."
}

$dataRoots = @(
    (Join-Path $env:LOCALAPPDATA "FamilyDashboard"),
    (Join-Path $env:LOCALAPPDATA "FamilyDashboard-Maintenance")
) | Select-Object -Unique

$stopped = 0
foreach ($dataRoot in $dataRoots) {
    $pidPath = Join-Path $dataRoot "server.pid"
    if (-not (Test-Path -LiteralPath $pidPath -PathType Leaf)) { continue }
    $pidText = ([IO.File]::ReadAllText($pidPath)).Trim()
    $processId = 0
    if (-not [int]::TryParse($pidText, [ref]$processId) -or $processId -le 0) {
        throw "Invalid Family Dashboard PID file: $pidPath"
    }
    $process = Get-Process -Id $processId -ErrorAction SilentlyContinue
    if ($process) {
        $actualPath = $null
        try { $actualPath = $process.Path } catch {}
        if (-not $actualPath -or ([IO.Path]::GetFullPath($actualPath) -ne [IO.Path]::GetFullPath($script:PythonPath))) {
            throw "PID $processId does not belong to the bundled Family Dashboard runtime. It was not stopped."
        }
        $cimProcess = Get-CimInstance Win32_Process -Filter "ProcessId=$processId" -ErrorAction SilentlyContinue
        if (-not $cimProcess -or $cimProcess.CommandLine -notlike "*$script:ServerPath*") {
            throw "PID $processId does not have the expected Family Dashboard command line. It was not stopped."
        }
        Stop-Process -Id $processId -Force
        Wait-Process -Id $processId -Timeout 10 -ErrorAction SilentlyContinue
        $stopped += 1
    }
    Remove-Item -LiteralPath $pidPath -Force -ErrorAction SilentlyContinue
}

if ($stopped -eq 0) {
    $health = Get-FamilyDashboardHealth
    if ($health -and $health.appId -eq "family-dashboard") {
        throw "Family Dashboard responded, but no validated PID file was found. No process was stopped."
    }
    Write-Host "Family Dashboard is not running."
} else {
    Write-Host "Family Dashboard stopped."
}
