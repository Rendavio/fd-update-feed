from __future__ import annotations

import copy
import json
import math
import os
import threading
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import urlparse
from urllib.request import HTTPRedirectHandler, Request, build_opener
from zoneinfo import ZoneInfo

from jma_weather_codes import weather_icon, weather_label


JST = ZoneInfo("Asia/Tokyo")
JMA_HOST = "www.jma.go.jp"
JMA_ORIGIN = f"https://{JMA_HOST}"
FORECAST_URL = f"{JMA_ORIGIN}/bosai/forecast/data/forecast/130000.json"
AMEDAS_LATEST_URL = f"{JMA_ORIGIN}/bosai/amedas/data/latest_time.txt"
AMEDAS_MAP_PREFIX = f"{JMA_ORIGIN}/bosai/amedas/data/map/"
FORECAST_AREA_CODE = "130010"
FORECAST_AREA_NAME = "東京地方"
OBSERVATION_STATION_CODE = "44132"
OBSERVATION_STATION_NAME = "東京"


class JmaDataError(RuntimeError):
    pass


class JmaOnlyRedirectHandler(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        parsed = urlparse(newurl)
        if parsed.scheme != "https" or parsed.hostname != JMA_HOST:
            raise JmaDataError("JMA request attempted to leave the approved host")
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def _iso_date(value: str) -> str:
    try:
        return datetime.fromisoformat(value).astimezone(JST).date().isoformat()
    except (TypeError, ValueError) as exc:
        raise JmaDataError("Invalid JMA time definition") from exc


def _number_or_none(value: Any) -> float | int | None:
    if value in (None, ""):
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    if not math.isfinite(number):
        return None
    return int(number) if number.is_integer() else number


def _find_area(series: dict[str, Any], code: str) -> dict[str, Any]:
    areas = series.get("areas")
    if not isinstance(areas, list):
        raise JmaDataError("JMA time series has no areas")
    for item in areas:
        if isinstance(item, dict) and item.get("area", {}).get("code") == code:
            return item
    raise JmaDataError(f"Required JMA area is missing: {code}")


def _series(item: dict[str, Any], index: int) -> dict[str, Any]:
    time_series = item.get("timeSeries")
    if not isinstance(time_series, list) or len(time_series) <= index:
        raise JmaDataError("Required JMA time series is missing")
    series = time_series[index]
    if not isinstance(series, dict) or not isinstance(series.get("timeDefines"), list):
        raise JmaDataError("JMA time series schema is invalid")
    return series


class JmaWeatherProvider:
    """Fetches JMA forecast/AMeDAS data and maintains a last-good local cache."""

    def __init__(
        self,
        cache_path: Path,
        refresh_interval_seconds: int = 600,
        retry_interval_seconds: int = 60,
    ) -> None:
        self.cache_path = cache_path
        self.refresh_interval_seconds = refresh_interval_seconds
        self.retry_interval_seconds = retry_interval_seconds
        self._lock = threading.RLock()
        self._stop_event = threading.Event()
        self._thread: threading.Thread | None = None
        self._snapshot: dict[str, Any] | None = None
        self._opener = build_opener(JmaOnlyRedirectHandler())
        self._load_cache()

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._thread = threading.Thread(target=self._refresh_loop, name="jma-weather-refresh", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop_event.set()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=2)

    def get_snapshot(self) -> dict[str, Any]:
        with self._lock:
            if self._snapshot is None:
                return self._empty_snapshot("気象データを取得中です")
            return copy.deepcopy(self._snapshot)

    def refresh_now(self) -> bool:
        try:
            snapshot = self._fetch_snapshot()
            self._validate_snapshot(snapshot)
            self._store_success(snapshot)
            return True
        except (JmaDataError, HTTPError, URLError, TimeoutError, OSError, ValueError, json.JSONDecodeError):
            self._mark_failure()
            return False

    def _refresh_loop(self) -> None:
        while not self._stop_event.is_set():
            success = self.refresh_now()
            wait_seconds = self.refresh_interval_seconds if success else self.retry_interval_seconds
            self._stop_event.wait(wait_seconds)

    def _fetch_snapshot(self) -> dict[str, Any]:
        forecast = self._fetch_json(FORECAST_URL)
        latest_time = self._fetch_text(AMEDAS_LATEST_URL).strip()
        try:
            observation_time = datetime.fromisoformat(latest_time)
        except ValueError as exc:
            raise JmaDataError("Invalid AMeDAS latest time") from exc
        map_name = observation_time.strftime("%Y%m%d%H%M") + "00.json"
        amedas_map = self._fetch_json(AMEDAS_MAP_PREFIX + map_name)
        return self._snapshot_from_payloads(forecast, latest_time, amedas_map, datetime.now(timezone.utc))

    def _fetch_text(self, url: str) -> str:
        parsed = urlparse(url)
        if parsed.scheme != "https" or parsed.hostname != JMA_HOST:
            raise JmaDataError("Outbound host is not approved")
        request = Request(url, headers={"User-Agent": "FamilyDashboard/1.0"})
        with self._opener.open(request, timeout=12) as response:
            if urlparse(response.geturl()).hostname != JMA_HOST:
                raise JmaDataError("JMA response left the approved host")
            payload = response.read(2_500_000)
        return payload.decode("utf-8")

    def _fetch_json(self, url: str) -> Any:
        return json.loads(self._fetch_text(url))

    def _snapshot_from_payloads(
        self,
        forecast: Any,
        latest_time: str,
        amedas_map: Any,
        fetched_at: datetime,
    ) -> dict[str, Any]:
        if not isinstance(forecast, list) or len(forecast) < 2:
            raise JmaDataError("Forecast root schema is invalid")
        if not isinstance(amedas_map, dict):
            raise JmaDataError("AMeDAS map schema is invalid")

        short = next((item for item in forecast if isinstance(item, dict) and len(item.get("timeSeries", [])) >= 3), None)
        weekly = next((item for item in forecast if isinstance(item, dict) and len(item.get("timeSeries", [])) == 2), None)
        if short is None or weekly is None:
            raise JmaDataError("Short or weekly forecast is missing")

        weather_by_date: dict[str, dict[str, Any]] = {}
        pops_by_date: dict[str, int | float | None] = {}
        temps_by_date: dict[str, dict[str, int | float | None]] = {}

        weekly_weather_series = _series(weekly, 0)
        weekly_weather_area = _find_area(weekly_weather_series, FORECAST_AREA_CODE)
        for time_value, code, pop in zip(
            weekly_weather_series["timeDefines"],
            weekly_weather_area.get("weatherCodes", []),
            weekly_weather_area.get("pops", []),
        ):
            date_key = _iso_date(time_value)
            weather_by_date[date_key] = {"code": str(code), "raw": None}
            pops_by_date[date_key] = _number_or_none(pop)

        weekly_temp_series = _series(weekly, 1)
        weekly_temp_area = _find_area(weekly_temp_series, OBSERVATION_STATION_CODE)
        for index, time_value in enumerate(weekly_temp_series["timeDefines"]):
            date_key = _iso_date(time_value)
            temps_by_date[date_key] = {
                "low": _number_or_none((weekly_temp_area.get("tempsMin") or [])[index])
                if index < len(weekly_temp_area.get("tempsMin") or []) else None,
                "high": _number_or_none((weekly_temp_area.get("tempsMax") or [])[index])
                if index < len(weekly_temp_area.get("tempsMax") or []) else None,
            }

        short_weather_series = _series(short, 0)
        short_weather_area = _find_area(short_weather_series, FORECAST_AREA_CODE)
        short_codes = short_weather_area.get("weatherCodes") or []
        short_raw = short_weather_area.get("weathers") or []
        for index, time_value in enumerate(short_weather_series["timeDefines"]):
            if index >= len(short_codes):
                continue
            date_key = _iso_date(time_value)
            weather_by_date[date_key] = {
                "code": str(short_codes[index]),
                "raw": short_raw[index] if index < len(short_raw) else None,
            }

        short_pop_series = _series(short, 1)
        short_pop_area = _find_area(short_pop_series, FORECAST_AREA_CODE)
        for time_value, pop in zip(short_pop_series["timeDefines"], short_pop_area.get("pops", [])):
            date_key = _iso_date(time_value)
            number = _number_or_none(pop)
            if number is None:
                continue
            previous = pops_by_date.get(date_key)
            pops_by_date[date_key] = number if previous is None else max(previous, number)

        short_temp_series = _series(short, 2)
        short_temp_area = _find_area(short_temp_series, OBSERVATION_STATION_CODE)
        for time_value, temp in zip(short_temp_series["timeDefines"], short_temp_area.get("temps", [])):
            parsed_time = datetime.fromisoformat(time_value).astimezone(JST)
            date_key = parsed_time.date().isoformat()
            entry = temps_by_date.setdefault(date_key, {"low": None, "high": None})
            number = _number_or_none(temp)
            if parsed_time.hour == 0:
                entry["low"] = number
            elif parsed_time.hour == 9:
                entry["high"] = number

        station = amedas_map.get(OBSERVATION_STATION_CODE)
        if not isinstance(station, dict):
            raise JmaDataError("Tokyo AMeDAS observation is missing")
        temp_entry = station.get("temp")
        current_temperature = None
        if isinstance(temp_entry, list) and len(temp_entry) >= 2 and temp_entry[1] == 0:
            current_temperature = _number_or_none(temp_entry[0])

        now_jst = fetched_at.astimezone(JST)
        today = now_jst.date()
        days = []
        for offset in range(7):
            date_key = (today + timedelta(days=offset)).isoformat()
            weather = weather_by_date.get(date_key, {})
            code = weather.get("code")
            temperatures = temps_by_date.get(date_key, {})
            days.append({
                "date": date_key,
                "weatherCode": code,
                "condition": weather_label(code),
                "icon": weather_icon(code),
                "high": temperatures.get("high"),
                "low": temperatures.get("low"),
                "rain": pops_by_date.get(date_key),
            })

        report_times = [item.get("reportDatetime") for item in forecast if isinstance(item, dict)]
        report_times = [value for value in report_times if isinstance(value, str)]
        return {
            "schemaVersion": 1,
            "source": {
                "provider": "気象庁",
                "forecastArea": {"code": FORECAST_AREA_CODE, "name": FORECAST_AREA_NAME},
                "observationStation": {
                    "code": OBSERVATION_STATION_CODE,
                    "name": OBSERVATION_STATION_NAME,
                },
                "forecastReportTime": max(report_times) if report_times else None,
            },
            "fetchedAt": fetched_at.isoformat(),
            "lastSuccessAt": fetched_at.isoformat(),
            "observationTime": latest_time,
            "stale": False,
            "cacheState": "live",
            "error": None,
            "currentTemperature": current_temperature,
            "days": days,
        }

    def _validate_snapshot(self, snapshot: dict[str, Any]) -> None:
        if snapshot.get("schemaVersion") != 1:
            raise JmaDataError("Unexpected dashboard weather schema")
        days = snapshot.get("days")
        if not isinstance(days, list) or len(days) != 7:
            raise JmaDataError("Dashboard weather must contain seven days")
        previous = None
        for item in days:
            if not isinstance(item, dict):
                raise JmaDataError("Dashboard weather day is invalid")
            current = datetime.fromisoformat(item.get("date", "")).date()
            if previous is not None and current != previous + timedelta(days=1):
                raise JmaDataError("Dashboard weather dates are not consecutive")
            previous = current
            for field in ("high", "low"):
                value = item.get(field)
                if value is not None and not -60 <= value <= 60:
                    raise JmaDataError("Temperature is outside the accepted range")
            rain = item.get("rain")
            if rain is not None and not 0 <= rain <= 100:
                raise JmaDataError("Precipitation probability is invalid")
        current_temperature = snapshot.get("currentTemperature")
        if current_temperature is not None and not -60 <= current_temperature <= 60:
            raise JmaDataError("Observed temperature is outside the accepted range")

    def _store_success(self, snapshot: dict[str, Any]) -> None:
        self.cache_path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.cache_path.with_suffix(".tmp")
        temporary.write_text(json.dumps(snapshot, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(temporary, self.cache_path)
        with self._lock:
            self._snapshot = copy.deepcopy(snapshot)

    def _mark_failure(self) -> None:
        with self._lock:
            if self._snapshot is None:
                self._snapshot = self._empty_snapshot("気象データの初回取得を再試行しています")
            else:
                self._snapshot["stale"] = True
                self._snapshot["cacheState"] = "cached"
                self._snapshot["error"] = "気象データの更新を再試行しています"
                self._snapshot["lastAttemptAt"] = datetime.now(timezone.utc).isoformat()

    def _load_cache(self) -> None:
        if not self.cache_path.exists():
            return
        try:
            cached = json.loads(self.cache_path.read_text(encoding="utf-8"))
            self._validate_snapshot(cached)
        except (OSError, ValueError, json.JSONDecodeError, JmaDataError):
            return
        cached["stale"] = True
        cached["cacheState"] = "cached"
        cached["error"] = "保存済みの気象データを表示しています"
        self._snapshot = cached

    def _empty_snapshot(self, message: str) -> dict[str, Any]:
        today = datetime.now(JST).date()
        return {
            "schemaVersion": 1,
            "source": {
                "provider": "気象庁",
                "forecastArea": {"code": FORECAST_AREA_CODE, "name": FORECAST_AREA_NAME},
                "observationStation": {
                    "code": OBSERVATION_STATION_CODE,
                    "name": OBSERVATION_STATION_NAME,
                },
            },
            "fetchedAt": None,
            "lastSuccessAt": None,
            "observationTime": None,
            "stale": True,
            "cacheState": "empty",
            "error": message,
            "currentTemperature": None,
            "days": [
                {
                    "date": (today + timedelta(days=offset)).isoformat(),
                    "weatherCode": None,
                    "condition": "--",
                    "icon": "--",
                    "high": None,
                    "low": None,
                    "rain": None,
                }
                for offset in range(7)
            ],
        }
