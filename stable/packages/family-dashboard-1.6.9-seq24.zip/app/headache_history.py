from __future__ import annotations

from datetime import date, timedelta
from typing import Any, Callable, Mapping, Sequence


HEADACHE_KEYWORD = "片頭痛"
AEROBIC_KEYWORDS = (
    "有酸素運動",
    "有酸素",
    "有酸素外",
    "有酸素運動外",
)
STRENGTH_KEYWORD = "ChocoZAP"
HEADACHE_DAY_OFFSETS = (
    (-4, "4日前"),
    (-3, "3日前"),
    (-2, "2日前"),
    (-1, "昨日"),
    (0, "本日"),
)


def summary_has_headache(summary: Any) -> bool:
    return isinstance(summary, str) and HEADACHE_KEYWORD in summary


def summary_has_aerobic(summary: Any) -> bool:
    return isinstance(summary, str) and any(keyword in summary for keyword in AEROBIC_KEYWORDS)


def summary_has_strength(summary: Any) -> bool:
    return isinstance(summary, str) and STRENGTH_KEYWORD.casefold() in summary.casefold()


def headache_day_specs(today: date) -> list[tuple[str, str]]:
    return [
        ((today + timedelta(days=offset)).isoformat(), label)
        for offset, label in HEADACHE_DAY_OFFSETS
    ]


def _build_occurrence_history(
    events_by_date: Mapping[str, Sequence[Mapping[str, Any]]],
    today: date,
    matcher: Callable[[Any], bool],
) -> list[dict[str, Any]]:
    history = []
    for date_key, label in headache_day_specs(today):
        occurred = any(
            matcher(event.get("summary"))
            for event in events_by_date.get(date_key, ())
            if isinstance(event, Mapping)
        )
        history.append({"date": date_key, "label": label, "occurred": occurred})
    return history


def build_headache_history(
    events_by_date: Mapping[str, Sequence[Mapping[str, Any]]],
    today: date,
) -> list[dict[str, Any]]:
    return _build_occurrence_history(events_by_date, today, summary_has_headache)


def build_aerobic_history(
    events_by_date: Mapping[str, Sequence[Mapping[str, Any]]],
    today: date,
) -> list[dict[str, Any]]:
    return _build_occurrence_history(events_by_date, today, summary_has_aerobic)


def build_strength_history(
    events_by_date: Mapping[str, Sequence[Mapping[str, Any]]],
    today: date,
) -> list[dict[str, Any]]:
    return _build_occurrence_history(events_by_date, today, summary_has_strength)
