const ICON_CODES = {
  sunny: ['100', '130', '131'],
  'sun-cloud': ['101', '110', '111', '132'],
  'sun-rain': ['102', '103', '108', '112', '113', '114', '119', '120', '121', '122', '123', '125', '126', '127', '128', '140'],
  'sun-snow': ['104', '105', '115', '116', '117', '124'],
  cloudy: ['200', '209', '231'],
  'cloud-sun': ['201', '210', '211', '223'],
  'cloud-rain': ['202', '203', '208', '212', '213', '214', '219', '220', '221', '222', '224', '225', '226', '240'],
  'cloud-snow': ['204', '205', '215', '216', '217', '228', '229', '230', '250'],
  rain: ['300', '302', '306', '307', '308', '328', '350'],
  'rain-sun': ['301', '311', '320', '323', '324', '325'],
  'rain-cloud': ['313', '321'],
  snow: ['400', '402', '405', '406', '407', '425', '426', '427', '450'],
  'snow-sun': ['401', '411', '420'],
  'snow-cloud': ['413', '421'],
  'rain-snow': [
    '106', '107', '118', '160', '170', '181',
    '206', '207', '218', '260', '270', '281',
    '303', '304', '309', '314', '315', '316', '317', '322', '326', '327', '329', '340', '361', '371',
    '403', '409', '414', '422', '423', '424',
  ],
};

const CODE_TO_ICON = new Map(
  Object.entries(ICON_CODES).flatMap(([type, codes]) => codes.map((code) => [code, type])),
);

export const WEATHER_ICON_EXAMPLES = [
  { code: '100', label: '晴れ' },
  { code: '101', label: '晴れ＋くもり' },
  { code: '201', label: 'くもり＋晴れ' },
  { code: '200', label: 'くもり' },
  { code: '202', label: 'くもり＋雨' },
  { code: '300', label: '雨' },
  { code: '313', label: '雨＋くもり' },
  { code: '102', label: '晴れ＋雨' },
  { code: '400', label: '雪' },
  { code: '303', label: '雨＋雪' },
  { code: '104', label: '晴れ＋雪' },
  { code: '204', label: 'くもり＋雪' },
];

export function getWeatherIconType(weatherCode) {
  const normalized = String(weatherCode ?? '').trim();
  return CODE_TO_ICON.get(normalized) ?? 'unknown';
}

export function makeWeatherIcon(weatherCode, { primary = false } = {}) {
  const iconType = getWeatherIconType(weatherCode);
  const icon = document.createElement('span');
  icon.className = `weather-icon${primary ? ' primary-icon' : ''}`;
  icon.dataset.weatherIcon = iconType;
  icon.dataset.weatherCode = String(weatherCode ?? '');
  icon.setAttribute('aria-hidden', 'true');

  if (iconType === 'unknown') {
    icon.textContent = '--';
    return icon;
  }

  const glyph = document.createElement('span');
  glyph.className = 'weather-glyph';
  ['sun', 'cloud-back', 'cloud', 'rain', 'snow'].forEach((part) => {
    const element = document.createElement('span');
    element.className = `weather-part weather-part-${part}`;
    glyph.appendChild(element);
  });
  icon.appendChild(glyph);
  return icon;
}
