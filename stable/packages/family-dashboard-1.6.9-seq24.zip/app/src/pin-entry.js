export const PIN_LENGTH = 4;
export const PIN_INDICATOR_SLOTS = 6;

export function sanitizePin(value) {
  return String(value ?? '').replace(/[^0-9]/g, '').slice(0, PIN_LENGTH);
}

export function appendPinDigit(value, digit) {
  const current = sanitizePin(value);
  if (!/^[0-9]$/.test(String(digit)) || current.length >= PIN_LENGTH) return current;
  return `${current}${digit}`;
}

export function removePinDigit(value) {
  return sanitizePin(value).slice(0, -1);
}

export function isCompletePin(value) {
  return /^[0-9]{4}$/.test(String(value ?? ''));
}

export function describePinIndicator(value) {
  const length = sanitizePin(value).length;
  return Array.from(
    { length: PIN_INDICATOR_SLOTS },
    (_, index) => (index < length ? '●' : '○'),
  ).join(' ');
}
