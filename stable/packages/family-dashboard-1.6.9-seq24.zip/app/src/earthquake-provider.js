import { formatDepth, formatMagnitude, formatPredictedIntensity } from './eew-display-data.js';

export const EEW_WARNING_CODE = 556;
export const TOKYO_23_API_NAME = '東京都２３区';
export const TOKYO_23_DISPLAY_NAME = '東京都23区';

export const P2P_EEW_ENDPOINTS = Object.freeze({
  production: 'wss://api.p2pquake.net/v2/ws?codes=556',
  sandbox: 'wss://api-realtime-sandbox.p2pquake.net/v2/ws?codes=556',
});

const MAX_REMEMBERED_MESSAGES = 512;
const MAX_MESSAGE_CHARACTERS = 1_000_000;
const SCENARIO_NAMES = new Set(['A', 'B', 'C', 'D', 'E', 'F', 'G', 'MISSING']);

function rememberBounded(set, value, limit = MAX_REMEMBERED_MESSAGES) {
  set.add(value);
  if (set.size <= limit) return;
  const oldest = set.values().next().value;
  set.delete(oldest);
}

function normalizeAreaName(value) {
  return typeof value === 'string' ? value.normalize('NFKC').trim() : '';
}

export function isTokyo23Area(area) {
  return normalizeAreaName(area?.name) === normalizeAreaName(TOKYO_23_API_NAME);
}

export function includesTokyo23Area(areas) {
  return Array.isArray(areas) && areas.some(isTokyo23Area);
}

export function normalizeP2pTimestamp(value) {
  if (typeof value !== 'string' || value.length > 64) return null;
  const jst = /^(\d{4})\/(\d{2})\/(\d{2}) (\d{2}):(\d{2}):(\d{2})(?:\.(\d{1,3}))?$/.exec(value);
  if (jst) {
    const milliseconds = (jst[7] || '').padEnd(3, '0');
    return `${jst[1]}-${jst[2]}-${jst[3]}T${jst[4]}:${jst[5]}:${jst[6]}${milliseconds ? `.${milliseconds}` : ''}+09:00`;
  }
  const parsed = new Date(value);
  return Number.isNaN(parsed.valueOf()) ? null : parsed.toISOString();
}

function safeIdentifier(value) {
  if (typeof value !== 'string' && typeof value !== 'number') return null;
  const identifier = String(value).trim();
  return identifier && identifier.length <= 200 ? identifier : null;
}

function makeAlert(message, eventId, options) {
  const hypocenter = message?.earthquake?.hypocenter?.name;
  const targetArea = Array.isArray(message?.areas) ? message.areas.find(isTokyo23Area) : null;
  return {
    type: 'warning',
    headline: '緊急地震速報',
    instruction: '強い揺れに警戒してください',
    region: TOKYO_23_DISPLAY_NAME,
    issuedAt: normalizeP2pTimestamp(message?.issue?.time),
    hypocenter: typeof hypocenter === 'string' && hypocenter.trim() ? hypocenter.trim() : null,
    predictedIntensity: formatPredictedIntensity(targetArea?.scaleFrom, targetArea?.scaleTo),
    magnitude: formatMagnitude(message?.earthquake?.hypocenter?.magnitude),
    depth: formatDepth(message?.earthquake?.hypocenter?.depth),
    eventId,
    serial: safeIdentifier(message?.issue?.serial),
    developmentTest: Boolean(options.developmentTest),
    sandbox: Boolean(options.sandbox),
    source: 'p2pquake',
  };
}

export class EewAlertEngine {
  constructor({ onAlert = () => {}, onSound = () => {}, maxRemembered = MAX_REMEMBERED_MESSAGES } = {}) {
    this.onAlert = onAlert;
    this.onSound = onSound;
    this.maxRemembered = maxRemembered;
    this.seenMessageIds = new Set();
    this.soundedEventIds = new Set();
    this.activeAlert = null;
  }

  process(message, options = {}) {
    if (!message || typeof message !== 'object' || Array.isArray(message)) {
      return { status: 'ignored_invalid', soundPlayed: false };
    }
    if (Number(message.code) !== EEW_WARNING_CODE) {
      return { status: 'ignored_code', soundPlayed: false };
    }

    const messageId = safeIdentifier(message.id);
    const eventId = safeIdentifier(message?.issue?.eventId) || messageId;
    if (!messageId || !eventId) {
      return { status: 'ignored_invalid', soundPlayed: false };
    }
    if (this.seenMessageIds.has(messageId)) {
      return { status: 'ignored_duplicate', soundPlayed: false, eventId };
    }
    rememberBounded(this.seenMessageIds, messageId, this.maxRemembered);

    if (message.test === true && options.allowTest !== true) {
      return { status: 'ignored_test', soundPlayed: false, eventId };
    }

    if (message.cancelled === true) {
      const cleared = this.activeAlert?.eventId === eventId;
      if (cleared) {
        this.activeAlert = null;
        this.onAlert(null);
      }
      return { status: cleared ? 'cancelled' : 'ignored_cancel', soundPlayed: false, eventId };
    }

    if (!includesTokyo23Area(message.areas)) {
      return { status: 'outside_target', soundPlayed: false, eventId };
    }

    const alert = makeAlert(message, eventId, options);
    const shouldSound = !this.soundedEventIds.has(eventId);
    if (shouldSound) rememberBounded(this.soundedEventIds, eventId, this.maxRemembered);
    this.activeAlert = alert;
    this.onAlert(alert);

    const soundPlayed = shouldSound && options.suppressSound !== true;
    if (soundPlayed) this.onSound(alert);
    return {
      status: shouldSound ? 'alert_started' : 'alert_updated',
      soundPlayed,
      soundSuppressed: shouldSound && options.suppressSound === true,
      eventId,
      alert,
    };
  }

  clearDevelopmentAlert() {
    if (!this.activeAlert?.developmentTest) return false;
    this.activeAlert = null;
    this.onAlert(null);
    return true;
  }
}

function scenarioMessage({
  nonce,
  id,
  eventId,
  serial = '1',
  areas,
  test = true,
  cancelled = false,
  includeMetrics = true,
}) {
  return {
    id: `development-${nonce}-${id}`,
    code: EEW_WARNING_CODE,
    time: '2026/08/30 22:00:00.000',
    test,
    cancelled,
    issue: {
      time: '2026/08/30 22:00:00',
      eventId: `DEVELOPMENT-${nonce}-${eventId}`,
      serial,
    },
    ...(cancelled ? {} : {
      earthquake: {
        originTime: '2026/08/30 21:59:40',
        arrivalTime: '2026/08/30 21:59:50',
        hypocenter: {
          name: '相模湾',
          ...(includeMetrics ? { magnitude: 6.3, depth: 40 } : {}),
        },
      },
      areas: areas.map((name) => ({
        pref: name.startsWith('東京') ? '東京都' : '神奈川県',
        name,
        ...(includeMetrics ? { scaleFrom: 45, scaleTo: 50 } : {}),
      })),
    }),
  };
}

export function createDevelopmentScenario(name, nonce = '1') {
  const scenario = String(name).toUpperCase();
  if (!SCENARIO_NAMES.has(scenario)) throw new Error(`Unknown EEW development scenario: ${name}`);
  const tokyo23 = [TOKYO_23_API_NAME];
  const tamaEast = ['東京都多摩東部'];
  const kanagawaEast = ['神奈川県東部'];

  if (scenario === 'A') {
    return [{ message: scenarioMessage({ nonce, id: 'a-1', eventId: 'A', areas: tokyo23 }), allowTest: true }];
  }
  if (scenario === 'B') {
    return [{ message: scenarioMessage({ nonce, id: 'b-1', eventId: 'B', areas: tamaEast }), allowTest: true }];
  }
  if (scenario === 'C') {
    return [{ message: scenarioMessage({ nonce, id: 'c-1', eventId: 'C', areas: kanagawaEast }), allowTest: true }];
  }
  if (scenario === 'D') {
    return [{ message: scenarioMessage({ nonce, id: 'd-1', eventId: 'D', areas: tokyo23 }), allowTest: false }];
  }
  if (scenario === 'E') {
    return [
      { message: scenarioMessage({ nonce, id: 'e-1', eventId: 'E', areas: tokyo23 }), allowTest: true },
      { message: scenarioMessage({ nonce, id: 'e-2', eventId: 'E', serial: '2', areas: [], cancelled: true }), allowTest: true },
    ];
  }
  if (scenario === 'F') {
    const duplicate = scenarioMessage({ nonce, id: 'f-1', eventId: 'F', areas: tokyo23 });
    return [
      { message: duplicate, allowTest: true },
      { message: structuredClone(duplicate), allowTest: true },
    ];
  }
  if (scenario === 'MISSING') {
    return [{
      message: scenarioMessage({
        nonce,
        id: 'missing-1',
        eventId: 'MISSING',
        areas: tokyo23,
        includeMetrics: false,
      }),
      allowTest: true,
    }];
  }
  return [
    { message: scenarioMessage({ nonce, id: 'g-1', eventId: 'G', serial: '1', areas: tamaEast }), allowTest: true },
    { message: scenarioMessage({ nonce, id: 'g-2', eventId: 'G', serial: '2', areas: tokyo23 }), allowTest: true },
  ];
}

export class P2PEarthquakeProvider {
  constructor({
    endpointKind = 'production',
    environment = 'production',
    WebSocketImpl = globalThis.WebSocket,
    setTimeoutImpl = globalThis.setTimeout?.bind(globalThis),
    clearTimeoutImpl = globalThis.clearTimeout?.bind(globalThis),
    random = Math.random,
    baseRetryMs = 1_000,
    maxRetryMs = 60_000,
    onSound = () => {},
  } = {}) {
    if (!Object.hasOwn(P2P_EEW_ENDPOINTS, endpointKind)) throw new Error('Unsupported P2P EEW endpoint');
    if (endpointKind === 'sandbox' && environment !== 'development') {
      throw new Error('P2P EEW Sandbox is restricted to development mode');
    }
    if (typeof WebSocketImpl !== 'function') throw new Error('WebSocket is not available');

    this.endpointKind = endpointKind;
    this.endpoint = P2P_EEW_ENDPOINTS[endpointKind];
    this.environment = environment;
    this.WebSocketImpl = WebSocketImpl;
    this.setTimeoutImpl = setTimeoutImpl;
    this.clearTimeoutImpl = clearTimeoutImpl;
    this.random = random;
    this.baseRetryMs = baseRetryMs;
    this.maxRetryMs = maxRetryMs;
    this.alertListeners = new Set();
    this.statusListeners = new Set();
    this.socket = null;
    this.retryTimer = null;
    this.retryAttempt = 0;
    this.stopped = true;
    this.scenarioRun = 0;
    this.status = { state: 'idle', endpointKind, retryInMs: null };
    this.engine = new EewAlertEngine({
      onAlert: (alert) => this.alertListeners.forEach((listener) => listener(alert)),
      onSound,
    });
  }

  subscribe(listener) {
    this.alertListeners.add(listener);
    return () => this.alertListeners.delete(listener);
  }

  subscribeStatus(listener) {
    this.statusListeners.add(listener);
    listener({ ...this.status });
    return () => this.statusListeners.delete(listener);
  }

  setStatus(state, details = {}) {
    this.status = { state, endpointKind: this.endpointKind, retryInMs: details.retryInMs ?? null };
    this.statusListeners.forEach((listener) => listener({ ...this.status }));
  }

  connect() {
    if (!this.stopped) return;
    this.stopped = false;
    this.openSocket();
  }

  openSocket() {
    if (this.stopped) return;
    this.setStatus(this.retryAttempt > 0 ? 'reconnecting' : 'connecting');
    let socket;
    try {
      socket = new this.WebSocketImpl(this.endpoint);
    } catch {
      this.scheduleReconnect();
      return;
    }
    this.socket = socket;
    socket.onopen = () => {
      if (socket !== this.socket || this.stopped) return;
      this.retryAttempt = 0;
      this.setStatus('connected');
    };
    socket.onmessage = (event) => {
      if (socket !== this.socket || typeof event.data !== 'string' || event.data.length > MAX_MESSAGE_CHARACTERS) return;
      let message;
      try {
        message = JSON.parse(event.data);
      } catch {
        return;
      }
      this.engine.process(message, {
        allowTest: this.endpointKind === 'sandbox',
        developmentTest: this.endpointKind === 'sandbox',
        sandbox: this.endpointKind === 'sandbox',
      });
    };
    socket.onerror = () => {
      if (socket !== this.socket || this.stopped) return;
      this.setStatus('connection_error');
    };
    socket.onclose = () => {
      if (socket !== this.socket) return;
      this.socket = null;
      if (!this.stopped) this.scheduleReconnect();
    };
  }

  scheduleReconnect() {
    if (this.stopped || this.retryTimer !== null) return;
    const exponent = Math.min(this.retryAttempt, 16);
    const rawDelay = Math.min(this.baseRetryMs * (2 ** exponent), this.maxRetryMs);
    const delay = Math.round(rawDelay * (1 + (this.random() * 0.2)));
    this.retryAttempt += 1;
    this.setStatus('reconnecting', { retryInMs: delay });
    this.retryTimer = this.setTimeoutImpl(() => {
      this.retryTimer = null;
      this.openSocket();
    }, delay);
  }

  stop() {
    this.stopped = true;
    if (this.retryTimer !== null) {
      this.clearTimeoutImpl(this.retryTimer);
      this.retryTimer = null;
    }
    const socket = this.socket;
    this.socket = null;
    if (socket && (socket.readyState === 0 || socket.readyState === 1)) socket.close();
    this.setStatus('stopped');
  }

  runDevelopmentScenario(name, { suppressSound = false } = {}) {
    if (this.environment !== 'development') throw new Error('EEW scenarios are restricted to development mode');
    if (this.engine.activeAlert && !this.engine.activeAlert.developmentTest) {
      return [{ status: 'blocked_by_active_warning', soundPlayed: false }];
    }
    this.engine.clearDevelopmentAlert();
    this.scenarioRun += 1;
    const steps = createDevelopmentScenario(name, String(this.scenarioRun));
    return steps.map((step) => this.engine.process(step.message, {
      allowTest: step.allowTest,
      developmentTest: true,
      sandbox: false,
      suppressSound,
    }));
  }

  clearDevelopmentAlert() {
    return this.engine.clearDevelopmentAlert();
  }
}
