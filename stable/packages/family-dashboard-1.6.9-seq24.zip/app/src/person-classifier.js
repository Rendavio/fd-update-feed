const PERSON_IDS = Object.freeze(['person1', 'person2']);
const NAME_SEPARATOR_SOURCE = '\\s\\u3000:：/／・･\\-‐‑‒–—―_＿,，、;；()（）\\[\\]［］{}｛｝【】「」『』〈〉《》〔〕<>＜＞';
const LEADING_NAME_SEPARATORS = new RegExp('^[' + NAME_SEPARATOR_SOURCE + ']+', 'u');
const ANY_NAME_SEPARATOR = new RegExp('[' + NAME_SEPARATOR_SOURCE + ']', 'u');

export function normalizeEventSummary(summary) {
  return String(summary ?? '').normalize('NFKC').trim();
}

function normalizeAlias(value) {
  if (typeof value !== 'string') throw new Error('Alias must be a string');
  const normalized = value.normalize('NFKC').trim();
  if (
    Array.from(normalized).length < 1
    || Array.from(normalized).length > 32
    || /[\p{Cc}\p{Cf}]/u.test(normalized)
    || ANY_NAME_SEPARATOR.test(normalized)
  ) {
    throw new Error('Alias has an unsafe format');
  }
  const folded = normalized.toLowerCase();
  if (folded.length !== normalized.length) throw new Error('Alias has ambiguous case folding');
  return Object.freeze({ value: normalized, folded });
}

export function validatePersonRules(value) {
  if (!Array.isArray(value) || value.length !== PERSON_IDS.length) {
    throw new Error('People must contain exactly two roles');
  }
  const seenPeople = new Set();
  const seenAliases = new Set();
  const people = value.map((person) => {
    if (
      !person
      || typeof person !== 'object'
      || Array.isArray(person)
      || Object.keys(person).sort().join(',') !== 'aliases,displayRole,id'
      || !PERSON_IDS.includes(person.id)
      || person.displayRole !== person.id
      || seenPeople.has(person.id)
      || !Array.isArray(person.aliases)
      || person.aliases.length < 1
      || person.aliases.length > 32
    ) {
      throw new Error('Person rule schema is invalid');
    }
    seenPeople.add(person.id);
    const aliases = person.aliases.map(normalizeAlias);
    aliases.forEach((alias) => {
      if (seenAliases.has(alias.folded)) throw new Error('Alias is duplicated');
      seenAliases.add(alias.folded);
    });
    aliases.sort((left, right) => right.value.length - left.value.length);
    return Object.freeze({ id: person.id, aliases: Object.freeze(aliases) });
  });
  if (seenPeople.size !== PERSON_IDS.length) throw new Error('Both person roles are required');
  people.sort((left, right) => PERSON_IDS.indexOf(left.id) - PERSON_IDS.indexOf(right.id));
  return Object.freeze(people);
}

function flattenAliases(people, allowedIds = null) {
  return people
    .filter((person) => !allowedIds || allowedIds.has(person.id))
    .flatMap((person) => person.aliases.map((alias) => ({ person, alias })))
    .sort((left, right) => right.alias.value.length - left.alias.value.length);
}

function stripLeadingSeparators(value) {
  return value.replace(LEADING_NAME_SEPARATORS, '');
}

function matchPrefix(value, people, allowedIds = null) {
  const folded = value.toLowerCase();
  for (const { person, alias } of flattenAliases(people, allowedIds)) {
    if (!folded.startsWith(alias.folded)) continue;
    const remainder = value.slice(alias.value.length);
    return { person, remainder };
  }
  return null;
}

export function classifyPerson(summary, rules) {
  let people;
  try {
    people = validatePersonRules(rules);
  } catch {
    return 'neutral';
  }
  const value = stripLeadingSeparators(normalizeEventSummary(summary));
  if (!value) return 'neutral';
  const first = matchPrefix(value, people);
  if (!first) return 'neutral';
  const secondValue = stripLeadingSeparators(first.remainder);
  if (secondValue) {
    const otherIds = new Set(PERSON_IDS.filter((personId) => personId !== first.person.id));
    if (matchPrefix(secondValue, people, otherIds)) return 'joint';
  }
  return first.person.id;
}
