export const DASHBOARD_DESIGN_WIDTH = 1920;
export const DASHBOARD_DESIGN_HEIGHT = 1200;
export const DISPLAY_HOLD_DURATION_MS = 5000;
export const PRIVACY_MODE_STORAGE_KEY = 'family-dashboard.privacy-mode.v1';

export function loadPrivacyMode(storage) {
  try {
    return storage?.getItem(PRIVACY_MODE_STORAGE_KEY) === 'on';
  } catch {
    return false;
  }
}

export function savePrivacyMode(storage, enabled) {
  try {
    storage?.setItem(PRIVACY_MODE_STORAGE_KEY, enabled ? 'on' : 'off');
    return true;
  } catch {
    return false;
  }
}

export function describePrivacyClock(now = new Date()) {
  const parts = new Intl.DateTimeFormat('ja-JP', {
    timeZone: 'Asia/Tokyo',
    month: 'numeric',
    day: 'numeric',
    weekday: 'long',
    hour: '2-digit',
    minute: '2-digit',
    hourCycle: 'h23',
  }).formatToParts(now);
  const values = Object.fromEntries(parts.map((part) => [part.type, part.value]));
  return {
    date: `${values.month}月${values.day}日`,
    weekday: values.weekday,
    time: `${values.hour}:${values.minute}`,
  };
}

export function calculateDashboardScale(viewportWidth, viewportHeight) {
  const width = Number(viewportWidth);
  const height = Number(viewportHeight);
  if (!Number.isFinite(width) || !Number.isFinite(height) || width <= 0 || height <= 0) return 1;
  return Math.min(width / DASHBOARD_DESIGN_WIDTH, height / DASHBOARD_DESIGN_HEIGHT);
}

export function targetBrightnessForTheme(settings, theme) {
  if (!settings?.autoBrightness) return null;
  if (theme === 'light') return settings.dayBrightness;
  if (theme === 'dark') return settings.nightBrightness;
  return null;
}

export function detectFullscreenOrKiosk(windowLike, documentLike) {
  if (documentLike?.fullscreenElement) return true;
  if (windowLike?.matchMedia?.('(display-mode: fullscreen)').matches) return true;
  const screen = windowLike?.screen;
  if (!screen) return false;
  const widthMatches = Math.abs(Number(windowLike.innerWidth) - Number(screen.width)) <= 2;
  const heightMatches = (
    Math.abs(Number(windowLike.innerHeight) - Number(screen.height)) <= 2
    || Math.abs(Number(windowLike.innerHeight) - Number(screen.availHeight)) <= 2
  );
  return widthMatches && heightMatches;
}

export function createLongPressController({
  durationMs = DISPLAY_HOLD_DURATION_MS,
  onComplete,
  schedule = window.setTimeout.bind(window),
  cancelSchedule = window.clearTimeout.bind(window),
}) {
  let active = null;

  function cancel() {
    if (!active) return false;
    cancelSchedule(active.timer);
    active = null;
    return true;
  }

  return {
    start(pointerId, isInside, isPrimary = true) {
      if (active && active.pointerId !== pointerId) {
        cancel();
        return false;
      }
      if (!isPrimary || !isInside) return false;
      if (active) {
        return false;
      }
      const record = { pointerId, timer: null };
      record.timer = schedule(() => {
        if (active !== record) return;
        active = null;
        onComplete();
      }, durationMs);
      active = record;
      return true;
    },
    move(pointerId, isInside) {
      if (active?.pointerId !== pointerId) return false;
      if (!isInside) cancel();
      return Boolean(active);
    },
    end(pointerId) {
      if (active?.pointerId !== pointerId) return false;
      cancel();
      return true;
    },
    cancel,
    isActive() {
      return Boolean(active);
    },
  };
}
