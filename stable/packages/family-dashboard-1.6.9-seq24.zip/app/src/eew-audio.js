let sharedAudioContext = null;

export const EEW_TONE_PATTERN = Object.freeze([
  { frequency: 880, start: 0.00, duration: 0.16 },
  { frequency: 660, start: 0.20, duration: 0.16 },
  { frequency: 880, start: 0.40, duration: 0.16 },
  { frequency: 660, start: 0.60, duration: 0.16 },
  { frequency: 990, start: 0.88, duration: 0.24 },
  { frequency: 740, start: 1.16, duration: 0.24 },
]);

function getAudioContext() {
  if (sharedAudioContext) return sharedAudioContext;
  const AudioContextImpl = globalThis.AudioContext || globalThis.webkitAudioContext;
  if (!AudioContextImpl) return null;
  sharedAudioContext = new AudioContextImpl();
  return sharedAudioContext;
}

export async function armEewAudio() {
  const context = getAudioContext();
  if (!context) return { ready: false, reason: 'unsupported' };
  try {
    if (context.state === 'suspended') await context.resume();
    return { ready: context.state === 'running', reason: context.state };
  } catch {
    return { ready: false, reason: 'autoplay_blocked' };
  }
}

export async function playEewWarningTone({ developmentTest = false } = {}) {
  const armed = await armEewAudio();
  if (!armed.ready) return { played: false, reason: armed.reason };

  const context = sharedAudioContext;
  const master = context.createGain();
  master.gain.value = developmentTest ? 0.08 : 0.34;
  master.connect(context.destination);
  const baseTime = context.currentTime + 0.02;

  EEW_TONE_PATTERN.forEach(({ frequency, start, duration }) => {
    const oscillator = context.createOscillator();
    const envelope = context.createGain();
    oscillator.type = 'square';
    oscillator.frequency.value = frequency;
    envelope.gain.setValueAtTime(0.0001, baseTime + start);
    envelope.gain.exponentialRampToValueAtTime(0.7, baseTime + start + 0.015);
    envelope.gain.exponentialRampToValueAtTime(0.0001, baseTime + start + duration);
    oscillator.connect(envelope);
    envelope.connect(master);
    oscillator.start(baseTime + start);
    oscillator.stop(baseTime + start + duration + 0.02);
  });

  const totalDuration = Math.max(...EEW_TONE_PATTERN.map((tone) => tone.start + tone.duration));
  globalThis.setTimeout?.(() => master.disconnect(), Math.ceil((totalDuration + 0.2) * 1000));
  return { played: true, developmentTest };
}

export function installEewAudioArming() {
  const arm = () => void armEewAudio();
  globalThis.addEventListener?.('pointerdown', arm, { once: true, passive: true });
  globalThis.addEventListener?.('keydown', arm, { once: true });
}
