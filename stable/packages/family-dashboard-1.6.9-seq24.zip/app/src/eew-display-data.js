const SEISMIC_INTENSITY_LABELS = new Map([
  [10, '1'],
  [20, '2'],
  [30, '3'],
  [40, '4'],
  [45, '5弱'],
  [50, '5強'],
  [55, '6弱'],
  [60, '6強'],
  [70, '7'],
]);

function intensityLabel(value) {
  if (typeof value !== 'number' || !Number.isFinite(value) || value <= 0) return null;
  return SEISMIC_INTENSITY_LABELS.get(Math.trunc(value)) ?? null;
}

export function formatPredictedIntensity(scaleFrom, scaleTo) {
  const from = intensityLabel(scaleFrom);
  if (!from) return '--';
  if (scaleTo === 99) return `${from}以上`;
  const to = intensityLabel(scaleTo);
  if (!to) return '--';
  return from === to ? from : `${from}〜${to}`;
}

export function formatMagnitude(value) {
  if (typeof value !== 'number' || !Number.isFinite(value) || value <= 0) return '--';
  return value.toFixed(1);
}

export function formatDepth(value) {
  if (typeof value !== 'number' || !Number.isFinite(value) || value <= 0) return '--';
  return `${Math.trunc(value)}km`;
}
