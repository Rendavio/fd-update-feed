export const NEWS_REFRESH_MS = 20 * 60 * 1000;

export function normalizeNewsTitle(value) {
  if (typeof value !== 'string') return '';
  return value.replace(/[\u0000-\u001f\u007f-\u009f\u200b-\u200f\u202a-\u202e\u2060-\u206f\ufeff]/gu, ' ')
    .replace(/\s+/gu, ' ')
    .trim()
    .slice(0, 500);
}

export function sanitizeNewsPayload(payload) {
  const sanitizeList = (value) => {
    if (!Array.isArray(value)) return [];
    return value.slice(0, 3).map(normalizeNewsTitle).filter(Boolean);
  };
  return {
    yahoo: sanitizeList(payload?.yahoo),
    bbc: sanitizeList(payload?.bbc),
    refreshedAt: typeof payload?.refreshedAt === 'string' ? payload.refreshedAt : null,
  };
}

export function selectNewsDensity(availableHeight, threeItemHeight, twoItemHeight) {
  if (![availableHeight, threeItemHeight, twoItemHeight].every(Number.isFinite)) return 0;
  if (availableHeight >= threeItemHeight) return 3;
  if (availableHeight >= twoItemHeight) return 2;
  return 0;
}

export async function fetchNews(fetchImpl = fetch) {
  const response = await fetchImpl('/api/news', { cache: 'no-store' });
  if (!response.ok) throw new Error('News unavailable');
  return sanitizeNewsPayload(await response.json());
}
