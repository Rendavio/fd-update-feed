// Broad regional daylight characteristics keep automatic theming seasonal
// without embedding a household position in the public application.
const SUMMER_REFERENCE_DAY = 172;
const SUNRISE_CENTER_MINUTES = 350;
const SUNRISE_SEASONAL_RANGE_MINUTES = 70;
const SUNSET_CENTER_MINUTES = 1068;
const SUNSET_SEASONAL_RANGE_MINUTES = 72;

function dayOfYear(year, month, day) {
  const start = Date.UTC(year, 0, 0);
  const current = Date.UTC(year, month - 1, day);
  return Math.floor((current - start) / 86400000);
}

function daysInYear(year) {
  return Date.UTC(year + 1, 0, 1) - Date.UTC(year, 0, 1) === 366 * 86400000
    ? 366
    : 365;
}

function calculateSeasonalSunTimes(year, month, day) {
  const phase = (
    2 * Math.PI * (dayOfYear(year, month, day) - SUMMER_REFERENCE_DAY)
  ) / daysInYear(year);
  const summerWeight = Math.cos(phase);

  return {
    sunriseMinutes: Math.round(
      SUNRISE_CENTER_MINUTES - SUNRISE_SEASONAL_RANGE_MINUTES * summerWeight,
    ),
    sunsetMinutes: Math.round(
      SUNSET_CENTER_MINUTES + SUNSET_SEASONAL_RANGE_MINUTES * summerWeight,
    ),
  };
}

export function getTokyoDateParts(now = new Date()) {
  const parts = new Intl.DateTimeFormat('ja-JP', {
    timeZone: 'Asia/Tokyo',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hourCycle: 'h23',
  }).formatToParts(now);
  const values = Object.fromEntries(parts.map((part) => [part.type, part.value]));
  return {
    year: Number(values.year),
    month: Number(values.month),
    day: Number(values.day),
    hour: Number(values.hour),
    minute: Number(values.minute),
  };
}

export function getTokyoSunTimes(now = new Date()) {
  const parts = getTokyoDateParts(now);
  return calculateSeasonalSunTimes(parts.year, parts.month, parts.day);
}

export function resolveAutomaticTheme(now = new Date()) {
  const parts = getTokyoDateParts(now);
  const solar = getTokyoSunTimes(now);
  const currentMinutes = parts.hour * 60 + parts.minute;
  const isLight = solar.sunriseMinutes !== null
    && solar.sunsetMinutes !== null
    && currentMinutes >= solar.sunriseMinutes
    && currentMinutes < solar.sunsetMinutes;
  return {
    theme: isLight ? 'light' : 'dark',
    ...solar,
  };
}

export function formatMinutes(minutes) {
  if (minutes === null) return '--:--';
  const hour = Math.floor(minutes / 60).toString().padStart(2, '0');
  const minute = (minutes % 60).toString().padStart(2, '0');
  return `${hour}:${minute}`;
}
