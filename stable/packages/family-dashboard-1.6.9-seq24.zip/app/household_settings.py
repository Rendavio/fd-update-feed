from __future__ import annotations

import json
import stat
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from person_classifier import PersonRule, PersonRulesError, validate_person_rules


HOUSEHOLD_CONFIG_KIND = "family-dashboard-household-config"
HOUSEHOLD_CONFIG_FILENAME = "household-config.json"
MAX_HOUSEHOLD_CONFIG_BYTES = 65_536


class HouseholdConfigurationError(ValueError):
    pass


@dataclass(frozen=True)
class HouseholdSettings:
    config_path: Path
    state: str
    people: tuple[PersonRule, ...]

    @property
    def configured(self) -> bool:
        return self.state == "ready"


def _pairs_without_duplicates(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise HouseholdConfigurationError("duplicate JSON field")
        result[key] = value
    return result


def _is_within(path: Path, parent: Path) -> bool:
    try:
        path.resolve(strict=False).relative_to(parent.resolve(strict=False))
        return True
    except ValueError:
        return False


def _external_path(path: Path, project_root: Path) -> Path:
    resolved = path.expanduser().resolve(strict=False)
    if _is_within(resolved, project_root):
        raise HouseholdConfigurationError("household config must be outside the project folder")
    return resolved


def parse_household_config(raw: bytes) -> tuple[PersonRule, ...]:
    if len(raw) > MAX_HOUSEHOLD_CONFIG_BYTES or raw.startswith(b"\xef\xbb\xbf"):
        raise HouseholdConfigurationError("household config encoding or size is invalid")
    try:
        value = json.loads(
            raw.decode("utf-8", errors="strict"),
            object_pairs_hook=_pairs_without_duplicates,
        )
    except (UnicodeDecodeError, json.JSONDecodeError, HouseholdConfigurationError) as exc:
        raise HouseholdConfigurationError("household config is not strict UTF-8 JSON") from exc
    if not isinstance(value, dict) or set(value) != {"schemaVersion", "kind", "people"}:
        raise HouseholdConfigurationError("household config fields do not match the schema")
    if value.get("schemaVersion") != 1 or value.get("kind") != HOUSEHOLD_CONFIG_KIND:
        raise HouseholdConfigurationError("household config version or kind is unsupported")
    try:
        return validate_person_rules(value.get("people"))
    except PersonRulesError as exc:
        raise HouseholdConfigurationError("household config person rules are invalid") from exc


def load_household_settings(
    project_root: Path,
    app_data_root: Path,
) -> HouseholdSettings:
    path = app_data_root / HOUSEHOLD_CONFIG_FILENAME
    try:
        config_path = _external_path(path, project_root)
    except HouseholdConfigurationError:
        return HouseholdSettings(path.resolve(strict=False), "invalid", ())
    if not config_path.exists():
        return HouseholdSettings(config_path, "missing", ())
    try:
        info = config_path.lstat()
        if config_path.is_symlink() or not stat.S_ISREG(info.st_mode):
            raise HouseholdConfigurationError("household config must be a normal file")
        if info.st_size > MAX_HOUSEHOLD_CONFIG_BYTES:
            raise HouseholdConfigurationError("household config is unexpectedly large")
        people = parse_household_config(config_path.read_bytes())
    except (OSError, HouseholdConfigurationError):
        return HouseholdSettings(config_path, "invalid", ())
    return HouseholdSettings(config_path, "ready", people)
