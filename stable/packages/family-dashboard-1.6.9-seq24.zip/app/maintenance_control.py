"""Local-only child-lock PIN verification and fixed production-Edge exit."""

from __future__ import annotations

import base64
import binascii
import hashlib
import hmac
import json
import os
import stat
import subprocess
import threading
import time
from pathlib import Path
from typing import Any, Callable, Sequence

PIN_KIND = "family-dashboard-maintenance-pin"
PIN_ALGORITHM = "PBKDF2-HMAC-SHA256"
PIN_ITERATIONS = 200_000
MAX_PIN_FILE_BYTES = 4_096
MAX_FAILURES = 5
LOCK_SECONDS = 30
POWERSHELL_EXE = Path(os.environ.get("SystemRoot", r"C:\Windows"),
    "System32", "WindowsPowerShell", "v1.0", "powershell.exe")
EXIT_HELPER = Path(r"C:\FamilyDashboard\launcher\Exit-FamilyDashboardEdge.ps1")


class MaintenancePinUnavailable(RuntimeError):
    pass


class MaintenancePinRejected(RuntimeError):
    pass


class MaintenancePinLocked(RuntimeError):
    def __init__(self, retry_after_seconds: int):
        super().__init__("Maintenance PIN is temporarily locked")
        self.retry_after_seconds = retry_after_seconds


class MaintenanceExitUnavailable(RuntimeError):
    pass


def _without_duplicates(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON keys are forbidden")
        result[key] = value
    return result


def _decode_fixed_base64(value: Any, size: int) -> bytes:
    if not isinstance(value, str):
        raise ValueError("PIN record encoding is invalid")
    try:
        decoded = base64.b64decode(value.encode("ascii"), validate=True)
    except (UnicodeEncodeError, binascii.Error) as exc:
        raise ValueError("PIN record encoding is invalid") from exc
    if len(decoded) != size or base64.b64encode(decoded).decode("ascii") != value:
        raise ValueError("PIN record encoding is invalid")
    return decoded


class MaintenancePinStore:
    def __init__(self, path: Path, *, monotonic: Callable[[], float] = time.monotonic):
        self.path = Path(path)
        self._monotonic = monotonic
        self._failures = 0
        self._locked_until = 0.0
        self._lock = threading.Lock()

    def _load(self) -> tuple[bytes, bytes]:
        try:
            info = self.path.lstat()
            attributes = getattr(info, "st_file_attributes", 0)
            if stat.S_ISLNK(info.st_mode) or attributes & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400):
                raise ValueError("PIN record cannot be a reparse point")
            if not stat.S_ISREG(info.st_mode) or not 1 <= info.st_size <= MAX_PIN_FILE_BYTES:
                raise ValueError("PIN record metadata is invalid")
            raw = self.path.read_bytes()
            if len(raw) != info.st_size or raw.startswith(b"\xef\xbb\xbf"):
                raise ValueError("PIN record changed or has a BOM")
            value = json.loads(raw.decode("utf-8", errors="strict"),
                object_pairs_hook=_without_duplicates,
                parse_constant=lambda _value: (_ for _ in ()).throw(ValueError("Non-finite JSON")))
            if not isinstance(value, dict) or set(value) != {
                "schemaVersion", "kind", "algorithm", "iterations", "salt", "hash"}:
                raise ValueError("PIN record fields are invalid")
            if value["schemaVersion"] != 1 or value["kind"] != PIN_KIND:
                raise ValueError("PIN record identity is invalid")
            if value["algorithm"] != PIN_ALGORITHM or value["iterations"] != PIN_ITERATIONS:
                raise ValueError("PIN record algorithm is invalid")
            return _decode_fixed_base64(value["salt"], 16), _decode_fixed_base64(value["hash"], 32)
        except (OSError, UnicodeError, json.JSONDecodeError, ValueError) as exc:
            raise MaintenancePinUnavailable("Maintenance PIN record is unavailable") from exc

    def verify(self, pin: str) -> None:
        with self._lock:
            now = self._monotonic()
            if now < self._locked_until:
                raise MaintenancePinLocked(max(1, int(self._locked_until - now + 0.999)))
            if isinstance(pin, str) and len(pin) == 4 and pin.isascii() and pin.isdecimal():
                salt, expected = self._load()
                actual = hashlib.pbkdf2_hmac("sha256", pin.encode("ascii"), salt,
                    PIN_ITERATIONS, dklen=32)
                matched = hmac.compare_digest(actual, expected)
            else:
                matched = False
            if matched:
                self._failures = 0
                self._locked_until = 0.0
                return
            self._failures += 1
            if self._failures >= MAX_FAILURES:
                self._failures = 0
                self._locked_until = now + LOCK_SECONDS
                raise MaintenancePinLocked(LOCK_SECONDS)
            raise MaintenancePinRejected("Maintenance PIN was rejected")


def _default_exit_starter(argv: Sequence[str]) -> None:
    subprocess.Popen(
        tuple(argv), stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL, shell=False, close_fds=True,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )


class MaintenanceExitControl:
    def __init__(
        self,
        pin_path: Path,
        *,
        exit_starter: Callable[[Sequence[str]], None] = _default_exit_starter,
    ) -> None:
        self.pin_store = MaintenancePinStore(pin_path)
        self._exit_starter = exit_starter

    def request_exit(self, pin: str) -> None:
        self.pin_store.verify(pin)
        argv = (
            str(POWERSHELL_EXE), "-NoLogo", "-NoProfile", "-NonInteractive",
            "-ExecutionPolicy", "Bypass", "-File", str(EXIT_HELPER),
        )
        try:
            self._exit_starter(argv)
        except (OSError, subprocess.SubprocessError) as exc:
            raise MaintenanceExitUnavailable("The fixed Edge exit helper could not start") from exc
