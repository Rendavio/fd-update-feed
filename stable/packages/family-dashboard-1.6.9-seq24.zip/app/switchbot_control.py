from __future__ import annotations

import base64
import copy
import ctypes
import hashlib
import hmac
import json
import os
import re
import sys
import threading
import time
import uuid
from dataclasses import dataclass
from datetime import date, datetime, timezone
from html.parser import HTMLParser
from pathlib import Path
from typing import Any, Callable
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlparse
from urllib.request import HTTPRedirectHandler, ProxyHandler, Request, build_opener
from zoneinfo import ZoneInfo


JST = ZoneInfo("Asia/Tokyo")
SETUP_EVENT_SUMMARY = "FD-SWITCHBOT-SETUP"
SWITCHBOT_ORIGIN = "https://api.switch-bot.com"
TARGET_DEVICE_NAME = "CHUWI"
SWITCHBOT_DEVICE_TYPE = "Plug Mini (JP)"
CONFIG_SCHEMA_VERSION = 1
CONTROL_INTERVAL_SECONDS = 600
START_DELAY_SECONDS = 15
HTTP_TIMEOUT_SECONDS = 8
MAX_HTTP_RESPONSE_BYTES = 1_000_000
MAX_DESCRIPTION_LENGTH = 2_048
MAX_CREDENTIAL_LENGTH = 512
DEVICE_ID_PATTERN = re.compile(r"^[0-9A-Za-z_-]{1,128}$")
SWITCHBOT_ERROR_CODES = frozenset({
    "NONE",
    "BATTERY_READ",
    "SETUP_PARSE",
    "API_TRANSPORT",
    "API_AUTH",
    "API_RESPONSE",
    "TARGET_MATCH",
    "DEVICE_TYPE",
    "CLOUD_DISABLED",
    "STATUS_TRANSPORT",
    "STATUS_AUTH",
    "STATUS_RESPONSE",
    "STATUS_READ",
    "POWER_SCHEMA",
    "CONFIG_WRITE",
    "UNKNOWN",
})


class SwitchBotError(Exception):
    def __init__(self, category: str = "UNKNOWN") -> None:
        self.category = category if category in SWITCHBOT_ERROR_CODES else "UNKNOWN"
        super().__init__(self.category)


class _NoRedirectHandler(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise SwitchBotError("API_RESPONSE")


class _SystemPowerStatus(ctypes.Structure):
    _fields_ = [
        ("ACLineStatus", ctypes.c_ubyte),
        ("BatteryFlag", ctypes.c_ubyte),
        ("BatteryLifePercent", ctypes.c_ubyte),
        ("SystemStatusFlag", ctypes.c_ubyte),
        ("BatteryLifeTime", ctypes.c_ulong),
        ("BatteryFullLifeTime", ctypes.c_ulong),
    ]


def read_battery_percent() -> int | None:
    if sys.platform != "win32":
        return None
    try:
        status = _SystemPowerStatus()
        if not ctypes.windll.kernel32.GetSystemPowerStatus(ctypes.byref(status)):
            return None
        value = int(status.BatteryLifePercent)
        return value if 0 <= value <= 100 else None
    except Exception:
        return None


def is_setup_event(item: Any) -> bool:
    return isinstance(item, dict) and item.get("summary") == SETUP_EVENT_SUMMARY


def _event_occurs_on(item: dict[str, Any], expected: date) -> bool:
    start = item.get("start")
    if not isinstance(start, dict):
        return False
    all_day = start.get("date")
    if isinstance(all_day, str):
        try:
            return date.fromisoformat(all_day) == expected
        except ValueError:
            return False
    date_time = start.get("dateTime")
    if not isinstance(date_time, str):
        return False
    try:
        parsed = datetime.fromisoformat(date_time.replace("Z", "+00:00"))
    except ValueError:
        return False
    return parsed.tzinfo is not None and parsed.astimezone(JST).date() == expected


class _SetupDescriptionHtmlParser(HTMLParser):
    _BLOCK_TAGS = {"div", "p"}

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.parts: list[str] = []
        self.stack: list[str] = []
        self.valid = True

    def _line_break(self) -> None:
        if self.parts and self.parts[-1] != "\n":
            self.parts.append("\n")

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        del attrs  # Attributes are inert and never interpreted.
        if tag == "br":
            self._line_break()
            return
        if tag in self._BLOCK_TAGS:
            self._line_break()
            self.stack.append(tag)
            return
        self.valid = False

    def handle_startendtag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        del attrs
        if tag == "br":
            self._line_break()
            return
        self.valid = False

    def handle_endtag(self, tag: str) -> None:
        if tag not in self._BLOCK_TAGS or not self.stack or self.stack[-1] != tag:
            self.valid = False
            return
        self.stack.pop()
        self._line_break()

    def handle_data(self, data: str) -> None:
        self.parts.append(data)

    def handle_comment(self, data: str) -> None:
        del data
        self.valid = False

    def handle_decl(self, decl: str) -> None:
        del decl
        self.valid = False

    def handle_pi(self, data: str) -> None:
        del data
        self.valid = False

    def unknown_decl(self, data: str) -> None:
        del data
        self.valid = False

    def normalized_text(self) -> str | None:
        try:
            self.close()
        except Exception:
            return None
        if not self.valid or self.stack:
            return None
        return "".join(self.parts)


def _normalize_description(description: str) -> str | None:
    parser = _SetupDescriptionHtmlParser()
    try:
        parser.feed(description)
    except Exception:
        return None
    return parser.normalized_text()


def _parse_description(description: Any) -> tuple[str, str] | None:
    if not isinstance(description, str) or not (1 <= len(description) <= MAX_DESCRIPTION_LENGTH):
        return None
    normalized = _normalize_description(description)
    if normalized is None:
        return None
    if any(character not in "\r\n" and not 0x20 <= ord(character) <= 0x7E for character in normalized):
        return None
    lines = [line.strip() for line in normalized.replace("\r\n", "\n").replace("\r", "\n").split("\n") if line.strip()]
    if len(lines) != 2:
        return None
    values: dict[str, str] = {}
    for line, expected_key in zip(lines, ("TOKEN", "SECRET")):
        if "=" not in line:
            return None
        key, value = line.split("=", 1)
        if key != expected_key or key in values:
            return None
        if not (1 <= len(value) <= MAX_CREDENTIAL_LENGTH):
            return None
        if any(not 0x20 <= ord(character) <= 0x7E for character in value):
            return None
        values[key] = value
    if set(values) != {"TOKEN", "SECRET"}:
        return None
    return values["TOKEN"], values["SECRET"]


def parse_setup_credentials(items: list[dict[str, Any]], fetched_at: datetime) -> tuple[str, str] | None:
    today = fetched_at.astimezone(JST).date()
    matches = [item for item in items if is_setup_event(item) and _event_occurs_on(item, today)]
    if len(matches) != 1:
        return None
    return _parse_description(matches[0].get("description"))


@dataclass(frozen=True)
class SwitchBotTarget:
    device_id: str
    power: str


class SwitchBotApiClient:
    def __init__(self, requester: Callable[[str, str, dict[str, str], bytes | None, float], Any] | None = None, timeout_seconds: float = HTTP_TIMEOUT_SECONDS) -> None:
        self._requester = requester or self._request_json
        self.timeout_seconds = timeout_seconds
        self._opener = build_opener(ProxyHandler({}), _NoRedirectHandler())

    @staticmethod
    def auth_headers(token: str, secret: str) -> dict[str, str]:
        timestamp = str(int(time.time() * 1000))
        nonce = str(uuid.uuid4())
        message = f"{token}{timestamp}{nonce}".encode("utf-8")
        signature = base64.b64encode(hmac.new(secret.encode("utf-8"), message, hashlib.sha256).digest()).decode("ascii")
        return {"Authorization": token, "sign": signature, "nonce": nonce, "t": timestamp, "Content-Type": "application/json; charset=utf8", "Accept": "application/json"}

    def _call(self, method: str, path: str, token: str, secret: str, body: dict[str, str] | None = None) -> dict[str, Any]:
        if not path.startswith("/v1.1/"):
            raise SwitchBotError("API_RESPONSE")
        raw_body = None if body is None else json.dumps(body, separators=(",", ":")).encode("utf-8")
        payload = self._requester(method, f"{SWITCHBOT_ORIGIN}{path}", self.auth_headers(token, secret), raw_body, self.timeout_seconds)
        if not isinstance(payload, dict):
            raise SwitchBotError("API_RESPONSE")
        if payload.get("statusCode") != 100:
            message = payload.get("message")
            category = "API_AUTH" if isinstance(message, str) and message.strip().casefold() == "unauthorized" else "API_RESPONSE"
            raise SwitchBotError(category)
        return payload

    def _request_json(self, method: str, url: str, headers: dict[str, str], body: bytes | None, timeout: float) -> Any:
        parsed = urlparse(url)
        if parsed.scheme != "https" or parsed.hostname != "api.switch-bot.com":
            raise SwitchBotError("API host rejected")
        request = Request(url, data=body, headers=headers, method=method)
        try:
            with self._opener.open(request, timeout=timeout) as response:
                if response.status != 200 or response.geturl() != url:
                    raise SwitchBotError("API response rejected")
                raw = response.read(MAX_HTTP_RESPONSE_BYTES + 1)
        except HTTPError as exc:
            raise SwitchBotError("API_AUTH" if exc.code in {401, 403} else "API_RESPONSE") from None
        except SwitchBotError:
            raise
        except (URLError, TimeoutError, OSError):
            raise SwitchBotError("API_TRANSPORT") from None
        if len(raw) > MAX_HTTP_RESPONSE_BYTES:
            raise SwitchBotError("API_RESPONSE")
        try:
            return json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            raise SwitchBotError("API_RESPONSE") from None

    def resolve_target(self, token: str, secret: str) -> SwitchBotTarget:
        payload = self._call("GET", "/v1.1/devices", token, secret)
        body = payload.get("body")
        devices = body.get("deviceList") if isinstance(body, dict) else None
        if not isinstance(devices, list):
            raise SwitchBotError("API_RESPONSE")
        named = [item for item in devices if isinstance(item, dict) and item.get("deviceName") == TARGET_DEVICE_NAME]
        if len(named) != 1:
            raise SwitchBotError("TARGET_MATCH")
        device = named[0]
        device_id = device.get("deviceId")
        if device.get("deviceType") != SWITCHBOT_DEVICE_TYPE:
            raise SwitchBotError("DEVICE_TYPE")
        if device.get("enableCloudService") is not True:
            raise SwitchBotError("CLOUD_DISABLED")
        if not isinstance(device_id, str) or not DEVICE_ID_PATTERN.fullmatch(device_id):
            raise SwitchBotError("TARGET_MATCH")
        try:
            power = self.get_power(token, secret, device_id)
        except SwitchBotError as exc:
            status_categories = {
                "API_TRANSPORT": "STATUS_TRANSPORT",
                "API_AUTH": "STATUS_AUTH",
                "API_RESPONSE": "STATUS_RESPONSE",
                "POWER_SCHEMA": "POWER_SCHEMA",
            }
            raise SwitchBotError(status_categories.get(exc.category, "STATUS_READ")) from None
        except Exception:
            raise SwitchBotError("STATUS_READ") from None
        return SwitchBotTarget(device_id=device_id, power=power)

    def get_power(self, token: str, secret: str, device_id: str) -> str:
        if not DEVICE_ID_PATTERN.fullmatch(device_id):
            raise SwitchBotError("API_RESPONSE")
        payload = self._call("GET", f"/v1.1/devices/{quote(device_id, safe='')}/status", token, secret)
        body = payload.get("body")
        if not isinstance(body, dict):
            raise SwitchBotError("API_RESPONSE")
        raw_power = body.get("power") or body.get("powerState")
        power = raw_power.upper() if isinstance(raw_power, str) else None
        if power not in {"ON", "OFF"}:
            raise SwitchBotError("POWER_SCHEMA")
        return power

    def set_power(self, token: str, secret: str, device_id: str, desired: str) -> None:
        if desired not in {"ON", "OFF"} or not DEVICE_ID_PATTERN.fullmatch(device_id):
            raise SwitchBotError("API_RESPONSE")
        self._call("POST", f"/v1.1/devices/{quote(device_id, safe='')}/commands", token, secret, {"command": "turnOn" if desired == "ON" else "turnOff", "parameter": "default", "commandType": "command"})


class SwitchBotController:
    def __init__(self, app_data_root: Path, api_client: SwitchBotApiClient | None = None, battery_reader: Callable[[], int | None] = read_battery_percent, interval_seconds: int = CONTROL_INTERVAL_SECONDS, start_delay_seconds: int = START_DELAY_SECONDS, now_factory: Callable[[], datetime] | None = None) -> None:
        self.config_path = app_data_root / "switchbot.json"
        self.api_client = api_client or SwitchBotApiClient()
        self.battery_reader = battery_reader
        self.interval_seconds = interval_seconds
        self.start_delay_seconds = start_delay_seconds
        self._now_factory = now_factory or (lambda: datetime.now(timezone.utc))
        self._lock = threading.RLock()
        self._stop_event = threading.Event()
        self._wake_event = threading.Event()
        self._thread: threading.Thread | None = None
        self._config = self._load_config()
        self._pending_credentials: tuple[str, str] | None = None
        self._status = {"configured": self._config is not None, "batteryPercent": None, "plug": "Unknown", "lastCheck": "Unknown", "error": "NONE"}

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._thread = threading.Thread(target=self._loop, name="switchbot-battery-control", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop_event.set()
        self._wake_event.set()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=2)

    def get_status(self) -> dict[str, Any]:
        with self._lock:
            return copy.deepcopy(self._status)

    def consume_calendar_items(self, items: list[dict[str, Any]], fetched_at: datetime) -> None:
        with self._lock:
            if self._config is not None:
                return
        credentials = parse_setup_credentials(items, fetched_at)
        if credentials is None:
            today = fetched_at.astimezone(JST).date()
            if any(is_setup_event(item) and _event_occurs_on(item, today) for item in items):
                with self._lock:
                    self._status["error"] = "SETUP_PARSE"
            return
        with self._lock:
            if self._config is None and self._pending_credentials is None:
                self._pending_credentials = credentials
                self._status["error"] = "NONE"
                self._wake_event.set()

    def process_pending_setup(self) -> bool:
        with self._lock:
            if self._config is not None or self._pending_credentials is None:
                return False
            token, secret = self._pending_credentials
            self._pending_credentials = None
        try:
            target = self.api_client.resolve_target(token, secret)
            config = {"schemaVersion": CONFIG_SCHEMA_VERSION, "token": token, "secret": secret, "deviceId": target.device_id, "deviceType": SWITCHBOT_DEVICE_TYPE, "configuredAt": self._now_factory().astimezone(timezone.utc).replace(microsecond=0).isoformat()}
            with self._lock:
                if self._config is not None:
                    return
                try:
                    self._write_config(config)
                except Exception:
                    raise SwitchBotError("CONFIG_WRITE") from None
                self._config = config
                self._status.update(configured=True, plug=target.power, lastCheck="PASS", error="NONE")
            return True
        except SwitchBotError as exc:
            with self._lock:
                self._status.update(configured=False, plug="Unknown", lastCheck="FAIL", error=exc.category)
            return False
        except Exception:
            with self._lock:
                self._status.update(configured=False, plug="Unknown", lastCheck="FAIL", error="UNKNOWN")
            return False

    def run_cycle(self) -> None:
        try:
            battery = self.battery_reader()
        except Exception:
            battery = None
        if not isinstance(battery, int) or isinstance(battery, bool) or not 0 <= battery <= 100:
            with self._lock:
                self._status.update(batteryPercent=None, lastCheck="FAIL", error="BATTERY_READ")
            return
        with self._lock:
            config = copy.deepcopy(self._config)
            self._status["batteryPercent"] = battery
        if config is None:
            return
        try:
            power = self.api_client.get_power(config["token"], config["secret"], config["deviceId"])
            desired = "ON" if battery <= 50 else "OFF" if battery >= 75 else None
            if desired is not None and power != desired:
                self.api_client.set_power(config["token"], config["secret"], config["deviceId"], desired)
                power = desired
            with self._lock:
                self._status.update(plug=power, lastCheck="PASS", error="NONE")
        except SwitchBotError as exc:
            with self._lock:
                self._status.update(plug="Unknown", lastCheck="FAIL", error=exc.category)
        except Exception:
            with self._lock:
                self._status.update(plug="Unknown", lastCheck="FAIL", error="UNKNOWN")

    def _loop(self) -> None:
        if self._stop_event.wait(self.start_delay_seconds):
            return
        while not self._stop_event.is_set():
            self._wake_event.clear()
            configured_now = self.process_pending_setup()
            if not configured_now:
                self.run_cycle()
            if self._stop_event.is_set():
                return
            self._wake_event.wait(self.interval_seconds)

    def _load_config(self) -> dict[str, Any] | None:
        if not self.config_path.is_file():
            return None
        try:
            if self.config_path.stat().st_size > 4_096:
                return None
            value = json.loads(self.config_path.read_text(encoding="utf-8"))
        except (OSError, UnicodeDecodeError, json.JSONDecodeError):
            return None
        expected = {"schemaVersion", "token", "secret", "deviceId", "deviceType", "configuredAt"}
        if not isinstance(value, dict) or set(value) != expected or value.get("schemaVersion") != CONFIG_SCHEMA_VERSION:
            return None
        credentials = _parse_description(f"TOKEN={value.get('token', '')}\nSECRET={value.get('secret', '')}")
        if credentials is None or value.get("deviceType") != SWITCHBOT_DEVICE_TYPE or not isinstance(value.get("deviceId"), str) or not DEVICE_ID_PATTERN.fullmatch(value["deviceId"]) or not isinstance(value.get("configuredAt"), str) or len(value["configuredAt"]) > 64:
            return None
        return value

    def _write_config(self, config: dict[str, Any]) -> None:
        self.config_path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.config_path.with_name(f".{self.config_path.name}.{uuid.uuid4().hex}.tmp")
        try:
            temporary.write_text(json.dumps(config, ensure_ascii=True, sort_keys=True, separators=(",", ":")), encoding="utf-8")
            os.chmod(temporary, 0o600)
            os.replace(temporary, self.config_path)
        finally:
            try:
                if temporary.exists():
                    temporary.unlink()
            except OSError:
                pass
