from __future__ import annotations

import copy
import re
import threading
import unicodedata
from datetime import datetime, timezone
from typing import Callable
from urllib.error import HTTPError, URLError
from urllib.parse import urlparse
from urllib.request import HTTPRedirectHandler, Request, build_opener
from xml.etree import ElementTree


YAHOO_RSS_URL = "https://news.yahoo.co.jp/rss/topics/top-picks.xml"
BBC_RSS_URL = "https://feeds.bbci.co.uk/news/world/rss.xml"
APPROVED_FEEDS = {
    "yahoo": (YAHOO_RSS_URL, "news.yahoo.co.jp"),
    "bbc": (BBC_RSS_URL, "feeds.bbci.co.uk"),
}
REFRESH_INTERVAL_SECONDS = 20 * 60
CACHE_MAX_AGE_SECONDS = 2 * REFRESH_INTERVAL_SECONDS
MAX_FEED_BYTES = 1_000_000
MAX_TITLES = 3
MAX_TITLE_LENGTH = 500


class NewsDataError(RuntimeError):
    pass


class NoRedirectHandler(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise NewsDataError("News feed redirect is not allowed")


def normalize_title(value: str) -> str:
    if not isinstance(value, str):
        return ""
    cleaned = "".join(
        " " if unicodedata.category(character) in {"Cc", "Cf"} else character
        for character in value
    )
    return re.sub(r"\s+", " ", cleaned).strip()[:MAX_TITLE_LENGTH]


def parse_rss_titles(payload: bytes) -> tuple[str, ...]:
    if not isinstance(payload, bytes) or not payload or len(payload) > MAX_FEED_BYTES:
        raise NewsDataError("News feed size is invalid")
    lowered = payload[:4096].lower()
    if b"<!doctype" in lowered or b"<!entity" in lowered:
        raise NewsDataError("News feed declarations are not allowed")
    try:
        root = ElementTree.fromstring(payload)
    except ElementTree.ParseError as exc:
        raise NewsDataError("News feed XML is invalid") from exc
    if root.tag.rsplit("}", 1)[-1].lower() != "rss":
        raise NewsDataError("News feed root is not RSS")
    titles: list[str] = []
    for item in root.iter():
        if item.tag.rsplit("}", 1)[-1].lower() != "item":
            continue
        title_node = next(
            (child for child in item if child.tag.rsplit("}", 1)[-1].lower() == "title"),
            None,
        )
        title = normalize_title("".join(title_node.itertext())) if title_node is not None else ""
        if title:
            titles.append(title)
        if len(titles) == MAX_TITLES:
            break
    if not titles:
        raise NewsDataError("News feed has no titles")
    return tuple(titles)


class NewsProvider:
    """Fetches two fixed official RSS feeds into a small, volatile cache."""

    def __init__(
        self,
        refresh_interval_seconds: int = REFRESH_INTERVAL_SECONDS,
        cache_max_age_seconds: int = CACHE_MAX_AGE_SECONDS,
        fetcher: Callable[[str, str], bytes] | None = None,
        now: Callable[[], datetime] | None = None,
    ) -> None:
        self.refresh_interval_seconds = refresh_interval_seconds
        self.cache_max_age_seconds = cache_max_age_seconds
        self._fetcher = fetcher or self._fetch_feed
        self._now = now or (lambda: datetime.now(timezone.utc))
        self._opener = build_opener(NoRedirectHandler())
        self._lock = threading.RLock()
        self._stop_event = threading.Event()
        self._thread: threading.Thread | None = None
        self._cache = {
            key: {"titles": (), "refreshedAt": None}
            for key in APPROVED_FEEDS
        }

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._thread = threading.Thread(target=self._refresh_loop, name="dashboard-news-refresh", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop_event.set()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=2)

    def refresh_now(self) -> dict[str, bool]:
        results: dict[str, bool] = {}
        for key, (url, host) in APPROVED_FEEDS.items():
            try:
                titles = parse_rss_titles(self._fetcher(url, host))
            except (NewsDataError, HTTPError, URLError, TimeoutError, OSError, ValueError):
                results[key] = False
                continue
            refreshed_at = self._now().astimezone(timezone.utc)
            with self._lock:
                self._cache[key] = {"titles": titles, "refreshedAt": refreshed_at}
            results[key] = True
        return results

    def get_snapshot(self) -> dict[str, object]:
        now = self._now().astimezone(timezone.utc)
        with self._lock:
            cached = copy.deepcopy(self._cache)
        active_times = []
        result: dict[str, object] = {}
        for key in APPROVED_FEEDS:
            item = cached[key]
            refreshed_at = item["refreshedAt"]
            is_fresh = (
                isinstance(refreshed_at, datetime)
                and max(0.0, (now - refreshed_at).total_seconds()) <= self.cache_max_age_seconds
            )
            result[key] = list(item["titles"]) if is_fresh else []
            if is_fresh:
                active_times.append(refreshed_at)
        result["refreshedAt"] = (
            max(active_times).isoformat().replace("+00:00", "Z") if active_times else None
        )
        return result

    def _refresh_loop(self) -> None:
        while not self._stop_event.is_set():
            self.refresh_now()
            self._stop_event.wait(self.refresh_interval_seconds)

    def _fetch_feed(self, url: str, expected_host: str) -> bytes:
        parsed = urlparse(url)
        if parsed.scheme != "https" or parsed.hostname != expected_host:
            raise NewsDataError("Outbound news host is not approved")
        request = Request(url, headers={"User-Agent": "FamilyDashboard/1.0", "Accept": "application/rss+xml, application/xml, text/xml"})
        with self._opener.open(request, timeout=10) as response:
            final = urlparse(response.geturl())
            if final.scheme != "https" or final.hostname != expected_host or response.status != 200:
                raise NewsDataError("News response identity is invalid")
            payload = response.read(MAX_FEED_BYTES + 1)
        if len(payload) > MAX_FEED_BYTES:
            raise NewsDataError("News feed is too large")
        return payload
