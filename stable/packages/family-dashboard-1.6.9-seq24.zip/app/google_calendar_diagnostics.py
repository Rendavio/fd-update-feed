from __future__ import annotations

import json
import os
from dataclasses import dataclass
from datetime import date, datetime, time, timedelta, timezone
from pathlib import Path
from typing import Any, Callable, Mapping
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlencode, urlparse
from urllib.request import ProxyHandler, Request, build_opener
from zoneinfo import ZoneInfo


JST = ZoneInfo("Asia/Tokyo")
GOOGLE_CALENDAR_SCOPE = "https://www.googleapis.com/auth/calendar.events.readonly"
GOOGLE_TOKEN_URL = "https://oauth2.googleapis.com/token"
GOOGLE_CALENDAR_API_ORIGIN = "https://www.googleapis.com"
DIRECT_EVENT_FIELDS = "nextPageToken,items(start(date,dateTime))"
CALENDAR_LOOKBACK_DAYS = 5
CALENDAR_DISPLAY_DAYS = 7
MAX_SETTINGS_BYTES = 64_000
MAX_CREDENTIAL_BYTES = 128_000
MAX_GOOGLE_RESPONSE_BYTES = 2_500_000
MAX_LOCAL_RESPONSE_BYTES = 2_500_000
SAFE_CACHE_STATES = frozenset({"live", "cached", "empty"})
SAFE_ERROR_CATEGORIES = frozenset({
    "none",
    "configuration",
    "authentication",
    "permission",
    "not_found",
    "quota",
    "network",
    "data",
    "cache",
    "local_api",
    "internal",
})


@dataclass(frozen=True)
class FetchPeriod:
    time_min: datetime
    time_max: datetime

    @property
    def dates(self) -> list[date]:
        days = (self.time_max.date() - self.time_min.date()).days
        return [self.time_min.date() + timedelta(days=offset) for offset in range(days)]


class DiagnosticFailure(RuntimeError):
    def __init__(self, category: str, http_status: int | None = None) -> None:
        super().__init__(category)
        self.category = category if category in SAFE_ERROR_CATEGORIES else "internal"
        self.http_status = http_status


def build_fetch_period(now: datetime) -> FetchPeriod:
    now_jst = now.astimezone(JST)
    display_start = datetime.combine(now_jst.date(), time.min, tzinfo=JST)
    return FetchPeriod(
        time_min=display_start - timedelta(days=CALENDAR_LOOKBACK_DAYS),
        time_max=display_start + timedelta(days=CALENDAR_DISPLAY_DAYS),
    )


def build_events_list_url(calendar_id: str, period: FetchPeriod, page_token: str | None = None) -> str:
    normalized = calendar_id.strip()
    if not normalized or normalized.casefold() == "primary":
        raise DiagnosticFailure("configuration")
    query = {
        "timeMin": period.time_min.isoformat(),
        "timeMax": period.time_max.isoformat(),
        "timeZone": "Asia/Tokyo",
        "singleEvents": "true",
        "orderBy": "startTime",
        "showDeleted": "false",
        "maxResults": "2500",
        "fields": DIRECT_EVENT_FIELDS,
    }
    if page_token:
        query["pageToken"] = page_token
    encoded_calendar_id = quote(normalized, safe="")
    return f"{GOOGLE_CALENDAR_API_ORIGIN}/calendar/v3/calendars/{encoded_calendar_id}/events?{urlencode(query)}"


def _safe_iso_timestamp(value: Any) -> str:
    if not isinstance(value, str) or len(value) > 64:
        return "unavailable"
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return "unavailable"
    if parsed.tzinfo is None:
        return "unavailable"
    return parsed.isoformat()


def _safe_http_status(value: int | None) -> str:
    return str(value) if isinstance(value, int) and 100 <= value <= 599 else "unavailable"


def _safe_category(value: Any) -> str:
    return value if isinstance(value, str) and value in SAFE_ERROR_CATEGORIES else "internal"


def _safe_cache_state(value: Any) -> str:
    return value if isinstance(value, str) and value in SAFE_CACHE_STATES else "unknown"


def _empty_day_counts(period: FetchPeriod) -> dict[str, int]:
    return {day.isoformat(): 0 for day in period.dates}


def _event_start_date(item: Any) -> date | None:
    if not isinstance(item, dict) or not isinstance(item.get("start"), dict):
        return None
    start = item["start"]
    if isinstance(start.get("date"), str):
        try:
            return date.fromisoformat(start["date"])
        except ValueError:
            return None
    if isinstance(start.get("dateTime"), str):
        try:
            parsed = datetime.fromisoformat(start["dateTime"].replace("Z", "+00:00"))
        except ValueError:
            return None
        if parsed.tzinfo is None:
            return None
        return parsed.astimezone(JST).date()
    return None


def count_direct_events(items: list[dict[str, Any]], period: FetchPeriod) -> tuple[dict[str, int], int]:
    counts = _empty_day_counts(period)
    unclassified = 0
    for item in items:
        event_date = _event_start_date(item)
        if event_date is None or event_date.isoformat() not in counts:
            unclassified += 1
            continue
        counts[event_date.isoformat()] += 1
    return counts, unclassified


def count_snapshot_events(snapshot: Any, period: FetchPeriod) -> tuple[dict[str, int], int]:
    counts = _empty_day_counts(period)
    total = 0
    if not isinstance(snapshot, dict) or not isinstance(snapshot.get("days"), list):
        return counts, total
    for day_item in snapshot["days"]:
        if not isinstance(day_item, dict):
            continue
        date_key = day_item.get("date")
        events = day_item.get("events")
        if isinstance(date_key, str) and date_key in counts and isinstance(events, list):
            counts[date_key] = len(events)
            total += len(events)
    return counts, total


def _validate_settings_schema(settings_path: Path) -> tuple[dict[str, Any] | None, str | None]:
    try:
        if settings_path.stat().st_size > MAX_SETTINGS_BYTES:
            return None, None
        payload = json.loads(settings_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError):
        return None, None
    if not isinstance(payload, dict) or set(payload) != {"calendar"}:
        return None, None
    calendar = payload.get("calendar")
    if not isinstance(calendar, dict) or set(calendar) != {"calendarId"}:
        return None, None
    calendar_id = calendar.get("calendarId")
    if not isinstance(calendar_id, str):
        return payload, None
    normalized = calendar_id.strip()
    if not normalized or normalized.casefold() == "primary":
        return payload, None
    return payload, normalized


def _validate_credential_schema(secret_path: Path) -> dict[str, Any] | None:
    try:
        if secret_path.stat().st_size > MAX_CREDENTIAL_BYTES:
            return None
        payload = json.loads(secret_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError):
        return None
    required = {"type", "private_key", "client_email", "token_uri"}
    if not isinstance(payload, dict) or not required.issubset(payload):
        return None
    if payload.get("type") != "service_account" or payload.get("token_uri") != GOOGLE_TOKEN_URL:
        return None
    client_email = payload.get("client_email")
    private_key = payload.get("private_key")
    if not isinstance(client_email, str) or not client_email.endswith(".gserviceaccount.com"):
        return None
    if not isinstance(private_key, str) or "BEGIN PRIVATE KEY" not in private_key:
        return None
    return payload


def _validate_cache_schema(snapshot: Any) -> bool:
    if not isinstance(snapshot, dict) or snapshot.get("schemaVersion") != 2 or snapshot.get("provider") != "google":
        return False
    days = snapshot.get("days")
    if not isinstance(days, list) or len(days) != CALENDAR_DISPLAY_DAYS:
        return False
    previous: date | None = None
    for day_item in days:
        if not isinstance(day_item, dict) or not isinstance(day_item.get("events"), list):
            return False
        try:
            current = date.fromisoformat(day_item.get("date", ""))
        except (TypeError, ValueError):
            return False
        if previous is not None and current != previous + timedelta(days=1):
            return False
        previous = current
    return True


def _inspect_cache(cache_path: Path, period: FetchPeriod) -> dict[str, Any]:
    result = {
        "file_exists": cache_path.is_file(),
        "state": "missing",
        "cache_state": "unknown",
        "last_success_at": "unavailable",
        "event_count": 0,
        "day_counts": _empty_day_counts(period),
    }
    if not result["file_exists"]:
        return result
    try:
        if cache_path.stat().st_size > MAX_LOCAL_RESPONSE_BYTES:
            result["state"] = "invalid"
            return result
        snapshot = json.loads(cache_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError):
        result["state"] = "invalid"
        return result
    if not _validate_cache_schema(snapshot):
        result["state"] = "invalid"
        return result
    result["state"] = "valid"
    result["cache_state"] = _safe_cache_state(snapshot.get("cacheState"))
    result["last_success_at"] = _safe_iso_timestamp(snapshot.get("lastSuccessAt"))
    result["day_counts"], result["event_count"] = count_snapshot_events(snapshot, period)
    return result


def _default_credential_factory(info: dict[str, Any]):
    try:
        from google.oauth2 import service_account
    except ImportError as exc:
        raise DiagnosticFailure("configuration") from exc
    try:
        return service_account.Credentials.from_service_account_info(
            info,
            scopes=[GOOGLE_CALENDAR_SCOPE],
        )
    except Exception as exc:
        raise DiagnosticFailure("configuration") from exc


def _default_token_refresher(credentials) -> tuple[str, int | None]:
    try:
        import requests
        from google.auth.exceptions import RefreshError, TransportError
        from google.auth.transport.requests import Request as GoogleAuthRequest
    except ImportError as exc:
        raise DiagnosticFailure("configuration") from exc

    class StatusCapturingSession(requests.Session):
        def __init__(self) -> None:
            super().__init__()
            self.last_status: int | None = None

        def request(self, *args, **kwargs):
            response = super().request(*args, **kwargs)
            self.last_status = int(response.status_code)
            return response

    session = StatusCapturingSession()
    session.trust_env = False
    session.max_redirects = 0
    try:
        credentials.refresh(GoogleAuthRequest(session=session))
        token = credentials.token
        if not isinstance(token, str) or not token:
            raise DiagnosticFailure("authentication", session.last_status)
        return token, session.last_status
    except RefreshError as exc:
        raise DiagnosticFailure("authentication", session.last_status) from exc
    except (TransportError, requests.RequestException) as exc:
        raise DiagnosticFailure("network", session.last_status) from exc
    finally:
        session.close()


def _google_error_category(status: int, payload: Any) -> str:
    if status == 401:
        return "authentication"
    if status == 404:
        return "not_found"
    if status == 429:
        return "quota"
    if 500 <= status <= 599:
        return "network"
    if status == 403:
        reasons: set[str] = set()
        if isinstance(payload, dict) and isinstance(payload.get("error"), dict):
            details = payload["error"].get("errors")
            if isinstance(details, list):
                for detail in details:
                    if isinstance(detail, dict) and isinstance(detail.get("reason"), str):
                        reasons.add(detail["reason"])
        quota_reasons = {"rateLimitExceeded", "userRateLimitExceeded", "quotaExceeded", "dailyLimitExceeded"}
        return "quota" if reasons & quota_reasons else "permission"
    return "data"


def _default_events_fetcher(
    calendar_id: str,
    token: str,
    period: FetchPeriod,
) -> tuple[list[dict[str, Any]], int | None, int]:
    try:
        import requests
    except ImportError as exc:
        raise DiagnosticFailure("configuration") from exc
    session = requests.Session()
    session.trust_env = False
    session.max_redirects = 0
    page_token: str | None = None
    items: list[dict[str, Any]] = []
    last_status: int | None = None
    request_count = 0
    try:
        for _ in range(20):
            url = build_events_list_url(calendar_id, period, page_token)
            parsed = urlparse(url)
            if parsed.scheme != "https" or parsed.hostname != "www.googleapis.com":
                raise DiagnosticFailure("data")
            try:
                response = session.get(
                    url,
                    headers={"Authorization": f"Bearer {token}", "Accept": "application/json"},
                    timeout=15,
                    allow_redirects=False,
                )
            except requests.RequestException as exc:
                raise DiagnosticFailure("network", last_status) from exc
            request_count += 1
            last_status = int(response.status_code)
            if 300 <= last_status <= 399:
                raise DiagnosticFailure("data", last_status)
            if len(response.content) > MAX_GOOGLE_RESPONSE_BYTES:
                raise DiagnosticFailure("data", last_status)
            try:
                payload = response.json()
            except (ValueError, json.JSONDecodeError) as exc:
                raise DiagnosticFailure("data", last_status) from exc
            if last_status != 200:
                raise DiagnosticFailure(_google_error_category(last_status, payload), last_status)
            if not isinstance(payload, dict) or not isinstance(payload.get("items", []), list):
                raise DiagnosticFailure("data", last_status)
            items.extend(item for item in payload.get("items", []) if isinstance(item, dict))
            page_token = payload.get("nextPageToken")
            if not page_token:
                return items, last_status, request_count
            if not isinstance(page_token, str) or len(page_token) > 4096:
                raise DiagnosticFailure("data", last_status)
        raise DiagnosticFailure("data", last_status)
    finally:
        session.close()


def _default_local_api_fetcher() -> tuple[int, Any]:
    request = Request("http://127.0.0.1:3000/api/calendar", headers={"Accept": "application/json"})
    opener = build_opener(ProxyHandler({}))
    try:
        with opener.open(request, timeout=5) as response:
            status = int(response.status)
            payload_bytes = response.read(MAX_LOCAL_RESPONSE_BYTES + 1)
    except HTTPError as exc:
        status = int(exc.code)
        payload_bytes = exc.read(MAX_LOCAL_RESPONSE_BYTES + 1)
    except (URLError, TimeoutError, OSError) as exc:
        raise DiagnosticFailure("local_api") from exc
    if len(payload_bytes) > MAX_LOCAL_RESPONSE_BYTES:
        raise DiagnosticFailure("local_api", status)
    try:
        return status, json.loads(payload_bytes.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise DiagnosticFailure("local_api", status) from exc


def run_diagnostics(
    data_root: Path,
    *,
    now_factory: Callable[[], datetime] | None = None,
    credential_factory: Callable[[dict[str, Any]], Any] | None = None,
    token_refresher: Callable[[Any], tuple[str, int | None]] | None = None,
    events_fetcher: Callable[[str, str, FetchPeriod], tuple[list[dict[str, Any]], int | None, int]] | None = None,
    local_api_fetcher: Callable[[], tuple[int, Any]] | None = None,
) -> dict[str, Any]:
    now = (now_factory or (lambda: datetime.now(timezone.utc)))()
    period = build_fetch_period(now)
    settings_path = data_root / "settings.json"
    secret_path = data_root / "secrets" / "service-account.json"
    cache_path = data_root / "cache" / "calendar-latest.json"
    result: dict[str, Any] = {
        "diagnostic_timestamp": now.astimezone(JST).isoformat(),
        "fetch_period": period,
        "settings_exists": settings_path.is_file(),
        "settings_schema": "FAIL",
        "calendar_id_configured": "FAIL",
        "secret_exists": secret_path.is_file(),
        "credential_schema": "FAIL",
        "credential_load": "NOT RUN",
        "token_status": "NOT RUN",
        "token_http_status": None,
        "token_error_category": "none",
        "events_status": "NOT RUN",
        "events_http_status": None,
        "events_error_category": "none",
        "events_request_count": 0,
        "events_count": 0,
        "events_day_counts": _empty_day_counts(period),
        "events_unclassified": 0,
        "cache": _inspect_cache(cache_path, period),
        "local_api_status": "NOT RUN",
        "local_api_http_status": None,
        "local_api_error_category": "none",
        "local_api_cache_state": "unknown",
        "local_api_last_success_at": "unavailable",
        "local_api_event_count": 0,
        "local_api_day_counts": _empty_day_counts(period),
        "overall": "FAIL",
    }

    calendar_id: str | None = None
    if result["settings_exists"]:
        settings_payload, calendar_id = _validate_settings_schema(settings_path)
        if settings_payload is not None:
            result["settings_schema"] = "PASS"
        if calendar_id is not None:
            result["calendar_id_configured"] = "PASS"

    credentials = None
    if result["secret_exists"]:
        credential_info = _validate_credential_schema(secret_path)
        if credential_info is not None:
            result["credential_schema"] = "PASS"
            try:
                credentials = (credential_factory or _default_credential_factory)(credential_info)
                result["credential_load"] = "PASS"
            except DiagnosticFailure as exc:
                result["credential_load"] = "FAIL"
                result["token_error_category"] = _safe_category(exc.category)
            finally:
                credential_info = None

    token: str | None = None
    if credentials is not None and calendar_id is not None:
        try:
            token, token_http_status = (token_refresher or _default_token_refresher)(credentials)
            result["token_status"] = "PASS"
            result["token_http_status"] = token_http_status
        except DiagnosticFailure as exc:
            result["token_status"] = "FAIL"
            result["token_http_status"] = exc.http_status
            result["token_error_category"] = _safe_category(exc.category)

    if token is not None and calendar_id is not None:
        try:
            items, events_http_status, request_count = (events_fetcher or _default_events_fetcher)(
                calendar_id,
                token,
                period,
            )
            result["events_status"] = "PASS"
            result["events_http_status"] = events_http_status
            result["events_request_count"] = request_count
            result["events_count"] = len(items)
            result["events_day_counts"], result["events_unclassified"] = count_direct_events(items, period)
        except DiagnosticFailure as exc:
            result["events_status"] = "FAIL"
            result["events_http_status"] = exc.http_status
            result["events_error_category"] = _safe_category(exc.category)
        finally:
            token = None

    try:
        local_status, local_payload = (local_api_fetcher or _default_local_api_fetcher)()
        result["local_api_http_status"] = local_status
        if local_status == 200 and isinstance(local_payload, dict):
            result["local_api_status"] = "PASS"
        elif local_status == 503 and isinstance(local_payload, dict):
            result["local_api_status"] = "EMPTY CACHE"
        else:
            result["local_api_status"] = "FAIL"
        if isinstance(local_payload, dict):
            result["local_api_cache_state"] = _safe_cache_state(local_payload.get("cacheState"))
            result["local_api_last_success_at"] = _safe_iso_timestamp(local_payload.get("lastSuccessAt"))
            result["local_api_day_counts"], result["local_api_event_count"] = count_snapshot_events(local_payload, period)
            result["local_api_error_category"] = _safe_category(local_payload.get("errorType") or "none")
        if local_status not in {200, 503}:
            result["local_api_error_category"] = "local_api"
    except DiagnosticFailure as exc:
        result["local_api_status"] = "FAIL"
        result["local_api_http_status"] = exc.http_status
        result["local_api_error_category"] = "local_api"

    if (
        result["settings_schema"] == "PASS"
        and result["calendar_id_configured"] == "PASS"
        and result["credential_schema"] == "PASS"
        and result["credential_load"] == "PASS"
        and result["token_status"] == "PASS"
        and result["events_status"] == "PASS"
        and result["local_api_status"] == "PASS"
    ):
        result["overall"] = "PASS"
    return result


def render_report(result: Mapping[str, Any]) -> str:
    period = result["fetch_period"]
    lines = [
        "Family Dashboard Google Calendar non-destructive diagnostics",
        f"diagnostic timestamp (JST): {result['diagnostic_timestamp']}",
        "operation: read-only token request + events.list for one configured Calendar ID",
        f"OAuth scope: {GOOGLE_CALENDAR_SCOPE}",
        "Calendar ID value: suppressed",
        "Service Account identity: suppressed",
        "event titles and contents: not requested or logged",
        "configuration changes: none",
        "Google write API calls: none",
        "calendarList.list / primary / other-calendar discovery: not used",
        "Gmail / Drive / Contacts: not used",
        "",
        f"1. settings.json exists: {'PASS' if result['settings_exists'] else 'FAIL'}",
        f"2. service-account.json exists: {'PASS' if result['secret_exists'] else 'FAIL'}",
        f"3a. settings.json schema: {result['settings_schema']}",
        f"3b. service-account.json schema: {result['credential_schema']}",
        f"4. exact non-primary Calendar ID configured: {result['calendar_id_configured']} (value suppressed)",
        f"5. Service Account credential load: {result['credential_load']} (identity and key suppressed)",
        f"6. oauth2 token request: {result['token_status']}",
        f"6a. token HTTP status: {_safe_http_status(result['token_http_status'])}",
        f"6b. token error category: {_safe_category(result['token_error_category'])}",
        f"7. fixed Calendar ID events.list: {result['events_status']}",
        f"7a. events.list request count: {result['events_request_count']}",
        f"8a. events.list HTTP status: {_safe_http_status(result['events_http_status'])}",
        f"8b. Google API error category: {_safe_category(result['events_error_category'])}",
        f"9a. current fetch timeMin: {period.time_min.isoformat()}",
        f"9b. current fetch timeMax (exclusive): {period.time_max.isoformat()}",
        f"10. direct events.list item count: {result['events_count']}",
        f"10a. direct events.list unclassified start count: {result['events_unclassified']}",
        "11. direct events.list start-date counts:",
    ]
    for day, count in result["events_day_counts"].items():
        lines.append(f"  {day}: {count}")
    cache = result["cache"]
    lines.extend([
        "",
        f"12a. cache file exists: {'yes' if cache['file_exists'] else 'no'}",
        f"12b. cache file schema state: {cache['state']}",
        f"12c. saved cache state: {cache['cache_state']}",
        f"12d. cached displayed event count: {cache['event_count']}",
        f"13. last normal fetch time: {cache['last_success_at']}",
        "",
        f"14a. Dashboard local Calendar API: {result['local_api_status']}",
        f"14b. local Calendar API HTTP status: {_safe_http_status(result['local_api_http_status'])}",
        f"14c. local Calendar API error category: {_safe_category(result['local_api_error_category'])}",
        f"14d. local Calendar API cache state: {result['local_api_cache_state']}",
        f"14e. local Calendar API last success: {result['local_api_last_success_at']}",
        f"14f. local Calendar API event count: {result['local_api_event_count']}",
        "14g. local Calendar API day counts:",
    ])
    for day, count in result["local_api_day_counts"].items():
        lines.append(f"  {day}: {count}")
    lines.extend(["", f"overall diagnostic result: {result['overall']}"])
    return "\n".join(lines) + "\n"


def _safe_data_root(environ: Mapping[str, str]) -> Path:
    configured = environ.get("FAMILY_DASHBOARD_HOME")
    if configured:
        return Path(configured).expanduser().resolve(strict=False)
    local_app_data = environ.get("LOCALAPPDATA")
    if not local_app_data:
        raise DiagnosticFailure("configuration")
    return (Path(local_app_data) / "FamilyDashboard").resolve(strict=False)


def main() -> int:
    try:
        data_root = _safe_data_root(os.environ)
    except DiagnosticFailure:
        print("Google Calendar diagnostics could not locate the Dashboard local data folder.")
        return 2
    report_path = data_root / "GoogleCalendar-Diagnostic-Report.txt"
    try:
        result = run_diagnostics(data_root)
    except Exception:
        now = datetime.now(timezone.utc)
        period = build_fetch_period(now)
        result = {
            "diagnostic_timestamp": now.astimezone(JST).isoformat(),
            "fetch_period": period,
            "settings_exists": False,
            "secret_exists": False,
            "settings_schema": "NOT RUN",
            "credential_schema": "NOT RUN",
            "calendar_id_configured": "NOT RUN",
            "credential_load": "NOT RUN",
            "token_status": "NOT RUN",
            "token_http_status": None,
            "token_error_category": "internal",
            "events_status": "NOT RUN",
            "events_http_status": None,
            "events_error_category": "internal",
            "events_request_count": 0,
            "events_count": 0,
            "events_unclassified": 0,
            "events_day_counts": _empty_day_counts(period),
            "cache": {"file_exists": False, "state": "unknown", "cache_state": "unknown", "event_count": 0, "last_success_at": "unavailable"},
            "local_api_status": "NOT RUN",
            "local_api_http_status": None,
            "local_api_error_category": "internal",
            "local_api_cache_state": "unknown",
            "local_api_last_success_at": "unavailable",
            "local_api_event_count": 0,
            "local_api_day_counts": _empty_day_counts(period),
            "overall": "FAIL",
        }
    try:
        data_root.mkdir(parents=True, exist_ok=True)
        temporary = report_path.with_suffix(".tmp")
        temporary.write_text(render_report(result), encoding="utf-8", newline="\n")
        os.replace(temporary, report_path)
    except OSError:
        print("Google Calendar diagnostics could not write the sanitized report.")
        return 2
    print(f"Google Calendar diagnostic report: {report_path}")
    print(f"Overall result: {result['overall']}")
    return 0 if result["overall"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
