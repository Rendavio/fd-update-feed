class CalendarProviderError(RuntimeError):
    """Base class for calendar provider failures."""


class CalendarConfigurationError(CalendarProviderError):
    pass


class CalendarAuthenticationError(CalendarProviderError):
    pass


class CalendarPermissionError(CalendarProviderError):
    pass


class CalendarTransientError(CalendarProviderError):
    pass


class CalendarDataError(CalendarProviderError):
    pass
