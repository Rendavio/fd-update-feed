from __future__ import annotations

import ctypes
import json
import os
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Mapping


DEFAULT_DISPLAY_SETTINGS = {
    "autoBrightness": True,
    "dayBrightness": 65,
    "nightBrightness": 30,
}
DISPLAY_SETTINGS_KEYS = frozenset(DEFAULT_DISPLAY_SETTINGS)
MAX_DISPLAY_SETTINGS_BYTES = 4_096

ES_SYSTEM_REQUIRED = 0x00000001
ES_DISPLAY_REQUIRED = 0x00000002
ES_CONTINUOUS = 0x80000000


class DisplaySettingsError(ValueError):
    pass


def validate_display_settings(value: Any) -> dict[str, bool | int]:
    if not isinstance(value, dict) or set(value) != DISPLAY_SETTINGS_KEYS:
        raise DisplaySettingsError("Display settings schema is invalid")
    auto = value.get("autoBrightness")
    day = value.get("dayBrightness")
    night = value.get("nightBrightness")
    if type(auto) is not bool:
        raise DisplaySettingsError("autoBrightness must be boolean")
    for label, brightness in (("dayBrightness", day), ("nightBrightness", night)):
        if type(brightness) is not int or not 0 <= brightness <= 100:
            raise DisplaySettingsError(f"{label} must be an integer from 0 to 100")
    return {
        "autoBrightness": auto,
        "dayBrightness": day,
        "nightBrightness": night,
    }


class DisplaySettingsStore:
    def __init__(self, path: Path):
        self.path = Path(path)

    def load(self) -> tuple[dict[str, bool | int], str]:
        if not self.path.exists():
            return dict(DEFAULT_DISPLAY_SETTINGS), "default"
        try:
            if self.path.stat().st_size > MAX_DISPLAY_SETTINGS_BYTES:
                raise DisplaySettingsError("Display settings file is oversized")
            raw = self.path.read_bytes()
            value = json.loads(raw.decode("utf-8", errors="strict"))
            return validate_display_settings(value), "saved"
        except (OSError, UnicodeDecodeError, json.JSONDecodeError, DisplaySettingsError):
            return dict(DEFAULT_DISPLAY_SETTINGS), "invalid"

    def save(self, value: Mapping[str, Any]) -> dict[str, bool | int]:
        validated = validate_display_settings(dict(value))
        encoded = json.dumps(
            validated,
            ensure_ascii=False,
            allow_nan=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
        self.path.parent.mkdir(parents=True, exist_ok=True)
        descriptor, temporary_name = tempfile.mkstemp(
            prefix=f".{self.path.name}.", suffix=".tmp", dir=self.path.parent
        )
        temporary = Path(temporary_name)
        try:
            with os.fdopen(descriptor, "wb") as target:
                target.write(encoded)
                target.flush()
                os.fsync(target.fileno())
            os.replace(temporary, self.path)
        except Exception:
            temporary.unlink(missing_ok=True)
            raise
        return validated


@dataclass(frozen=True)
class BrightnessStatus:
    available: bool
    current: int | None

    def as_dict(self) -> dict[str, bool | int | None]:
        return {"available": self.available, "currentBrightness": self.current}


_GET_BRIGHTNESS_SCRIPT = r"""
$ErrorActionPreference = 'Stop'
$monitor = Get-CimInstance -Namespace 'root/WMI' -ClassName 'WmiMonitorBrightness' -ErrorAction Stop | Select-Object -First 1
if ($null -eq $monitor) { exit 3 }
[Console]::Write([int]$monitor.CurrentBrightness)
""".strip()

_SET_BRIGHTNESS_SCRIPT = r"""
$ErrorActionPreference = 'Stop'
$method = Get-CimInstance -Namespace 'root/WMI' -ClassName 'WmiMonitorBrightnessMethods' -ErrorAction Stop | Select-Object -First 1
if ($null -eq $method) { exit 3 }
$result = Invoke-CimMethod -InputObject $method -MethodName 'WmiSetBrightness' -Arguments @{ Timeout = [uint32]0; Brightness = [byte]__VALUE__ } -ErrorAction Stop
if ($null -eq $result -or [int]$result.ReturnValue -ne 0) { exit 4 }
""".strip()


class WindowsBrightnessController:
    """Narrow Windows-standard WMI/CIM brightness adapter."""

    def __init__(
        self,
        runner: Callable[..., subprocess.CompletedProcess[str]] = subprocess.run,
        platform_name: str | None = None,
        powershell_path: Path | None = None,
    ):
        self._runner = runner
        self._platform_name = os.name if platform_name is None else platform_name
        windows_root = os.environ.get("SystemRoot", r"C:\Windows")
        self._powershell_path = Path(powershell_path or Path(
            windows_root, "System32", "WindowsPowerShell", "v1.0", "powershell.exe"
        ))

    def _run_script(self, script: str) -> subprocess.CompletedProcess[str] | None:
        if self._platform_name != "nt" or not self._powershell_path.is_file():
            return None
        creation_flags = 0x08000000 if self._platform_name == "nt" else 0
        try:
            return self._runner(
                [str(self._powershell_path), "-NoLogo", "-NoProfile", "-NonInteractive",
                 "-Command", script],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="strict",
                timeout=5,
                check=False,
                shell=False,
                creationflags=creation_flags,
            )
        except (OSError, subprocess.SubprocessError, UnicodeError):
            return None

    def get_status(self) -> BrightnessStatus:
        result = self._run_script(_GET_BRIGHTNESS_SCRIPT)
        if result is None or result.returncode != 0:
            return BrightnessStatus(False, None)
        try:
            current = int(result.stdout.strip())
        except (TypeError, ValueError):
            return BrightnessStatus(False, None)
        if not 0 <= current <= 100:
            return BrightnessStatus(False, None)
        return BrightnessStatus(True, current)

    def set_brightness(self, value: int) -> BrightnessStatus:
        if type(value) is not int or not 0 <= value <= 100:
            raise ValueError("Brightness must be an integer from 0 to 100")
        current = self.get_status()
        if not current.available or current.current == value:
            return current
        script = _SET_BRIGHTNESS_SCRIPT.replace("__VALUE__", str(value))
        result = self._run_script(script)
        if result is None or result.returncode != 0:
            return BrightnessStatus(False, None)
        return self.get_status()


class KeepAwakeController:
    def __init__(
        self,
        execution_state: Callable[[int], int] | None = None,
        platform_name: str | None = None,
    ):
        self._platform_name = os.name if platform_name is None else platform_name
        self._execution_state = execution_state
        self.active = False

    def _call(self, flags: int) -> int:
        if self._execution_state is not None:
            return int(self._execution_state(flags))
        if self._platform_name != "nt":
            return 0
        try:
            return int(ctypes.windll.kernel32.SetThreadExecutionState(flags))
        except (AttributeError, OSError):
            return 0

    def activate(self) -> bool:
        flags = ES_CONTINUOUS | ES_SYSTEM_REQUIRED | ES_DISPLAY_REQUIRED
        self.active = self._call(flags) != 0
        return self.active

    def deactivate(self) -> None:
        if self.active:
            self._call(ES_CONTINUOUS)
        self.active = False
