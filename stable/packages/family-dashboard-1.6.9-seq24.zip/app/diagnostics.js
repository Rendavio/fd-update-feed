import { P2PEarthquakeProvider } from './src/earthquake-provider.js';
import {
  calculateDashboardScale,
  detectFullscreenOrKiosk,
} from './src/display-mode.js';

const runtimeMetrics = document.getElementById('runtimeMetrics');
const displayMetrics = document.getElementById('displayMetrics');
const eewMetrics = document.getElementById('eewMetrics');
const maintenanceTests = document.getElementById('maintenanceTests');
const eewTestResult = document.getElementById('eewTestResult');
const saveDisplayReport = document.getElementById('saveDisplayReport');
const saveStatus = document.getElementById('saveStatus');
let displayRuntimeStatus = null;

function renderDefinitionList(target, rows) {
  target.replaceChildren();
  rows.forEach(([label, value]) => {
    const term = document.createElement('dt');
    const description = document.createElement('dd');
    term.textContent = label;
    description.textContent = String(value);
    target.append(term, description);
  });
}

function browserFamily() {
  return /Edg\//.test(navigator.userAgent) ? 'Microsoft Edge' : 'Other';
}

function collectDisplayMetrics() {
  const zoomEstimate = window.outerWidth > 0
    ? Math.round((window.outerWidth / window.innerWidth) * 100)
    : 100;
  const devicePixelRatio = window.devicePixelRatio || 1;
  return {
    screenWidth: window.screen.width,
    screenHeight: window.screen.height,
    availableWidth: window.screen.availWidth,
    availableHeight: window.screen.availHeight,
    viewportWidth: window.innerWidth,
    viewportHeight: window.innerHeight,
    outerWidth: Math.max(window.outerWidth, 1),
    outerHeight: Math.max(window.outerHeight, 1),
    devicePixelRatio,
    browserZoomEstimatePercent: Math.max(zoomEstimate, 1),
    physicalWidthEstimate: Math.round(window.screen.width * devicePixelRatio),
    physicalHeightEstimate: Math.round(window.screen.height * devicePixelRatio),
    windowsScalingEstimatePercent: Math.round(devicePixelRatio * 100),
    calculatedDashboardScale: calculateDashboardScale(window.innerWidth, window.innerHeight),
    fullscreenOrKiosk: detectFullscreenOrKiosk(window, document),
    userAgentFamily: browserFamily(),
  };
}

function updateDisplayMetrics() {
  const metrics = collectDisplayMetrics();
  const rows = [
    ['screen (CSS px)', `${metrics.screenWidth} × ${metrics.screenHeight}`],
    ['available screen (CSS px)', `${metrics.availableWidth} × ${metrics.availableHeight}`],
    ['browser viewport (CSS px)', `${metrics.viewportWidth} × ${metrics.viewportHeight}`],
    ['browser outer (CSS px)', `${metrics.outerWidth} × ${metrics.outerHeight}`],
    ['devicePixelRatio', metrics.devicePixelRatio],
    ['estimated physical resolution', `${Math.round(metrics.screenWidth * metrics.devicePixelRatio)} × ${Math.round(metrics.screenHeight * metrics.devicePixelRatio)}`],
    ['browser zoom estimate', `${metrics.browserZoomEstimatePercent}%`],
    ['browser family', metrics.userAgentFamily],
    ['Windows scaling estimate', `${metrics.windowsScalingEstimatePercent}%`],
    ['calculated Dashboard scale', metrics.calculatedDashboardScale.toFixed(4)],
    ['fullscreen / kiosk detected', metrics.fullscreenOrKiosk ? 'yes' : 'no'],
  ];
  if (displayRuntimeStatus) {
    rows.push(
      ['brightness API available', displayRuntimeStatus.available ? 'yes' : 'no'],
      ['current brightness', Number.isInteger(displayRuntimeStatus.currentBrightness)
        ? `${displayRuntimeStatus.currentBrightness}%`
        : 'unavailable'],
      ['autoBrightness', displayRuntimeStatus.settings.autoBrightness ? 'ON' : 'OFF'],
      ['day / night targets', `${displayRuntimeStatus.settings.dayBrightness}% / ${displayRuntimeStatus.settings.nightBrightness}%`],
      ['display settings status', displayRuntimeStatus.settingsStatus],
      ['keep-awake active', displayRuntimeStatus.keepAwakeActive ? 'yes' : 'no'],
    );
  }
  renderDefinitionList(displayMetrics, rows);
}

async function loadDisplayRuntimeStatus() {
  const response = await fetch('/api/display/status', { cache: 'no-store' });
  if (!response.ok) throw new Error(`display diagnostics failed: ${response.status}`);
  displayRuntimeStatus = await response.json();
  updateDisplayMetrics();
}

async function initialize() {
  const response = await fetch('/api/diagnostics/system', { cache: 'no-store' });
  if (!response.ok) throw new Error(`runtime diagnostics failed: ${response.status}`);
  const runtime = await response.json();
  renderDefinitionList(runtimeMetrics, [
    ['app', `${runtime.appId} ${runtime.appVersion}`],
    ['build', runtime.buildId],
    ['mode', runtime.mode],
    ['listen', `${runtime.host}:${runtime.port}`],
    ['Python', `${runtime.pythonVersion} / ${runtime.architecture}`],
    ['platform', runtime.platform],
  ]);
  await loadDisplayRuntimeStatus();

  const provider = new P2PEarthquakeProvider({
    endpointKind: 'production',
    environment: runtime.mode,
  });
  provider.subscribeStatus((status) => {
    renderDefinitionList(eewMetrics, [
      ['endpoint', 'wss://api.p2pquake.net/v2/ws?codes=556'],
      ['state', status.state],
      ['retry delay', status.retryInMs === null ? '--' : `${status.retryInMs} ms`],
    ]);
  });
  provider.connect();

  if (runtime.mode === 'development') {
    maintenanceTests.hidden = false;
    document.querySelectorAll('[data-eew-test]').forEach((button) => {
      button.addEventListener('click', () => {
        const scenario = button.dataset.eewTest;
        const results = provider.runDevelopmentScenario(scenario, { suppressSound: true });
        eewTestResult.textContent = results.map((result) => `${scenario}: ${result.status}`).join('\n');
      });
    });
  }
}

saveDisplayReport.addEventListener('click', async () => {
  saveDisplayReport.disabled = true;
  saveStatus.textContent = '保存中…';
  try {
    const response = await fetch('/api/diagnostics/display', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(collectDisplayMetrics()),
    });
    if (!response.ok) throw new Error(`save failed: ${response.status}`);
    saveStatus.textContent = 'レポートへ追記しました';
  } catch {
    saveStatus.textContent = '保存できませんでした';
  } finally {
    saveDisplayReport.disabled = false;
  }
});

window.addEventListener('resize', updateDisplayMetrics);
updateDisplayMetrics();
initialize().catch((error) => {
  renderDefinitionList(runtimeMetrics, [['error', error.message]]);
});
