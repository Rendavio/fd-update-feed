from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping

from calendar_errors import CalendarConfigurationError


@dataclass(frozen=True)
class CalendarSettings:
    runtime_mode: str
    app_data_root: Path
    config_path: Path
    secret_path: Path
    calendar_id: str | None
    configuration_error: str | None

    @property
    def configured(self) -> bool:
        return self.configuration_error is None


def _is_within(path: Path, parent: Path) -> bool:
    try:
        path.resolve(strict=False).relative_to(parent.resolve(strict=False))
        return True
    except ValueError:
        return False


def _external_path(path: Path, project_root: Path, label: str) -> Path:
    resolved = path.expanduser().resolve(strict=False)
    if _is_within(resolved, project_root):
        raise CalendarConfigurationError(f"{label} must be outside the project folder")
    return resolved


def load_calendar_settings(
    project_root: Path,
    environ: Mapping[str, str] | None = None,
) -> CalendarSettings:
    env = dict(os.environ if environ is None else environ)
    runtime_mode = env.get("FAMILY_DASHBOARD_MODE", "development").strip().lower()
    if runtime_mode not in {"development", "production"}:
        raise CalendarConfigurationError("FAMILY_DASHBOARD_MODE must be development or production")

    local_app_data = Path(env.get("LOCALAPPDATA") or (Path.home() / "AppData" / "Local"))
    app_data_root = Path(env.get("FAMILY_DASHBOARD_HOME") or (local_app_data / "FamilyDashboard"))
    app_data_root = _external_path(app_data_root, project_root, "FamilyDashboard local data folder")

    config_path = Path(env.get("FAMILY_DASHBOARD_CONFIG_PATH") or (app_data_root / "settings.json"))
    config_path = _external_path(config_path, project_root, "Calendar settings file")

    config = {}
    if config_path.exists():
        try:
            if config_path.stat().st_size > 64_000:
                raise CalendarConfigurationError("Calendar settings file is unexpectedly large")
            config = json.loads(config_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise CalendarConfigurationError("Calendar settings file is invalid") from exc
        if not isinstance(config, dict) or not isinstance(config.get("calendar", {}), dict):
            raise CalendarConfigurationError("Calendar settings schema is invalid")

    calendar_config = config.get("calendar", {})
    calendar_id = (env.get("FAMILY_DASHBOARD_CALENDAR_ID") or calendar_config.get("calendarId") or "").strip()
    configured_secret = env.get("FAMILY_DASHBOARD_SERVICE_ACCOUNT_FILE") or calendar_config.get("serviceAccountKeyFile")
    secret_path = Path(configured_secret) if configured_secret else app_data_root / "secrets" / "service-account.json"
    if not secret_path.is_absolute():
        secret_path = app_data_root / secret_path
    secret_path = _external_path(secret_path, project_root, "Service Account key file")

    error = None
    if not calendar_id:
        error = "Calendar ID is not configured"
    elif calendar_id.casefold() == "primary":
        error = "The primary alias is forbidden; configure the exact Calendar ID"
    elif not secret_path.exists():
        error = "Service Account key file is not present"
    elif secret_path.suffix.lower() != ".json":
        error = "Service Account key file must be JSON"

    if runtime_mode == "production" and error:
        raise CalendarConfigurationError(error)

    return CalendarSettings(
        runtime_mode=runtime_mode,
        app_data_root=app_data_root,
        config_path=config_path,
        secret_path=secret_path,
        calendar_id=calendar_id or None,
        configuration_error=error,
    )
