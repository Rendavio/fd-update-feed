import json
import platform
import sys
import threading
import time
import ctypes
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

from calendar_settings import load_calendar_settings
from dashboard_update_control_v1 import (
    ApplyAlreadyRequested,
    ApplyConsentCancelled,
    ApplyLaunchUnavailable,
    DashboardUpdateControl,
    NoPendingUpdate,
)
from display_control import (
    DisplaySettingsError,
    DisplaySettingsStore,
    KeepAwakeController,
    WindowsBrightnessController,
)
from google_calendar_provider import GoogleCalendarProvider
from household_settings import load_household_settings
from jma_weather_provider import JmaWeatherProvider
from maintenance_control import (
    MaintenanceExitControl,
    MaintenanceExitUnavailable,
    MaintenancePinLocked,
    MaintenancePinRejected,
    MaintenancePinUnavailable,
)


HOST = "127.0.0.1"
PORT = 3000
ROOT = Path(__file__).resolve().parent
APP_ID = "family-dashboard"
APP_VERSION = "1.5.1"
BUILD_ID = "20260904-update-orchestration-seq6-r1"
MAX_DIAGNOSTIC_BODY_BYTES = 16_384
MAX_DISPLAY_BODY_BYTES = 4_096
MAX_UPDATE_BODY_BYTES = 64
DIAGNOSTIC_FIELDS = {
    "screenWidth",
    "screenHeight",
    "availableWidth",
    "availableHeight",
    "viewportWidth",
    "viewportHeight",
    "outerWidth",
    "outerHeight",
    "devicePixelRatio",
    "browserZoomEstimatePercent",
    "physicalWidthEstimate",
    "physicalHeightEstimate",
    "windowsScalingEstimatePercent",
    "calculatedDashboardScale",
    "fullscreenOrKiosk",
    "userAgentFamily",
}


def is_process_elevated() -> bool:
    if sys.platform != "win32":
        return False
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        # Production must fail closed if Windows cannot prove this process is
        # running at medium integrity.
        return True


def _json_object_without_duplicates(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON keys are forbidden")
        result[key] = value
    return result


class DashboardHTTPServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._shutdown_requested = threading.Event()

    def request_graceful_shutdown(self, delay_seconds=0.25):
        if self._shutdown_requested.is_set():
            return False
        self._shutdown_requested.set()

        def stop_after_response():
            time.sleep(delay_seconds)
            self.shutdown()

        threading.Thread(
            target=stop_after_response,
            name="dashboard-update-shutdown",
            daemon=True,
        ).start()
        return True


class PreviewHandler(SimpleHTTPRequestHandler):
    weather_provider = None
    calendar_provider = None
    calendar_settings = None
    household_settings = None
    display_settings_store = None
    brightness_controller = None
    keep_awake_controller = None
    update_control = None
    maintenance_control = None

    def do_GET(self):
        path = urlsplit(self.path).path
        if path == "/api/update/status":
            if not self._accept_production_request(require_origin=False):
                return
            self._send_json(self.update_control.read_status())
            return
        if path in {
            "/api/display/status",
            "/api/display/brightness",
            "/api/display/settings",
        }:
            if not self._accept_local_request(require_origin=False):
                return
            settings, settings_status = self.display_settings_store.load()
            if path == "/api/display/settings":
                self._send_json({
                    "settings": settings,
                    "settingsStatus": settings_status,
                })
                return
            brightness = self.brightness_controller.get_status()
            if path == "/api/display/brightness":
                self._send_json(brightness.as_dict())
                return
            self._send_json({
                **brightness.as_dict(),
                "settings": settings,
                "settingsStatus": settings_status,
                "keepAwakeActive": bool(self.keep_awake_controller.active),
            })
            return
        if path == "/api/weather":
            self._send_json(self.weather_provider.get_snapshot())
            return
        if path == "/api/calendar":
            snapshot = self.calendar_provider.get_snapshot()
            status = 503 if snapshot.get("cacheState") == "empty" else 200
            self._send_json(snapshot, status=status)
            return
        if path == "/api/runtime":
            self._send_json({
                "mode": self.calendar_settings.runtime_mode,
                "appVersion": APP_VERSION,
                "buildId": BUILD_ID,
                "processIntegrity": "elevated" if is_process_elevated() else "nonElevated",
                "calendar": {
                    "defaultProvider": "google" if self.calendar_settings.runtime_mode == "production" else "mock",
                    "googleConfigured": self.calendar_settings.configured,
                    "householdConfigured": bool(
                        self.household_settings and self.household_settings.configured
                    ),
                },
            })
            return
        if path == "/api/health":
            self._send_json({
                "status": "ok",
                "appId": APP_ID,
                "appVersion": APP_VERSION,
                "buildId": BUILD_ID,
                "host": HOST,
                "port": PORT,
                "mode": self.calendar_settings.runtime_mode,
                "processIntegrity": "elevated" if is_process_elevated() else "nonElevated",
            })
            return
        if path == "/api/diagnostics/system":
            self._send_json({
                "appId": APP_ID,
                "appVersion": APP_VERSION,
                "buildId": BUILD_ID,
                "host": HOST,
                "port": PORT,
                "mode": self.calendar_settings.runtime_mode,
                "pythonVersion": platform.python_version(),
                "architecture": platform.machine(),
                "platform": platform.system(),
                "processIntegrity": "elevated" if is_process_elevated() else "nonElevated",
                "keepAwakeActive": bool(self.keep_awake_controller.active),
            })
            return
        super().do_GET()

    def do_POST(self):
        parsed_target = urlsplit(self.path)
        path = parsed_target.path
        allowed = {
            "/api/diagnostics/display",
            "/api/display/brightness",
            "/api/display/settings",
            "/api/update/apply",
            "/api/maintenance/exit",
        }
        if path not in allowed:
            self._send_json({"error": "not_found"}, status=404)
            return
        accepted = (
            self._accept_production_request(require_origin=True)
            if path in {"/api/update/apply", "/api/maintenance/exit"}
            else self._accept_local_request(require_origin=True)
        )
        if not accepted:
            return
        if path in {"/api/update/apply", "/api/maintenance/exit"} and (
            self.path != path or parsed_target.query or parsed_target.fragment
        ):
            error = "invalid_update_request" if path == "/api/update/apply" else "invalid_exit_request"
            self._send_json({"error": error}, status=400)
            return
        maximum = (
            MAX_DIAGNOSTIC_BODY_BYTES
            if path == "/api/diagnostics/display"
            else MAX_UPDATE_BODY_BYTES
            if path in {"/api/update/apply", "/api/maintenance/exit"}
            else MAX_DISPLAY_BODY_BYTES
        )
        if path == "/api/update/apply" and self.headers.get("Content-Length") != "2":
            self._send_json({"error": "invalid_update_request"}, status=400)
            return
        try:
            payload = self._read_strict_json(maximum)
        except (OSError, UnicodeDecodeError, ValueError, json.JSONDecodeError):
            self._send_json({"error": "invalid_json"}, status=400)
            return

        if path == "/api/update/apply":
            if type(payload) is not dict or payload:
                self._send_json({"error": "invalid_update_request"}, status=400)
                return
            try:
                self.update_control.request_apply()
            except NoPendingUpdate:
                self._send_json({"error": "no_pending_update"}, status=409)
                return
            except ApplyAlreadyRequested:
                self._send_json({"error": "apply_already_requested"}, status=409)
                return
            except ApplyConsentCancelled:
                self._send_json({"error": "uac_cancelled"}, status=409)
                return
            except ApplyLaunchUnavailable:
                self._send_json({"error": "updater_unavailable"}, status=503)
                return
            self.close_connection = True
            try:
                self._send_json({"accepted": True, "state": "APPLY_REQUESTED"}, status=202)
                self.wfile.flush()
            finally:
                self.server.request_graceful_shutdown()
            return

        if path == "/api/maintenance/exit":
            if (
                type(payload) is not dict
                or set(payload) != {"pin"}
                or not isinstance(payload.get("pin"), str)
            ):
                self._send_json({"error": "invalid_exit_request"}, status=400)
                return
            try:
                self.maintenance_control.request_exit(payload["pin"])
            except MaintenancePinRejected:
                self._send_json({"error": "pin_rejected"}, status=403)
                return
            except MaintenancePinLocked as exc:
                self._send_json({
                    "error": "pin_locked",
                    "retryAfterSeconds": exc.retry_after_seconds,
                }, status=429)
                return
            except MaintenancePinUnavailable:
                self._send_json({"error": "pin_unavailable"}, status=503)
                return
            except MaintenanceExitUnavailable:
                self._send_json({"error": "exit_unavailable"}, status=503)
                return
            self._send_json({"accepted": True, "state": "EXIT_REQUESTED"}, status=202)
            return

        if path == "/api/display/brightness":
            if (
                not isinstance(payload, dict)
                or set(payload) != {"value"}
                or type(payload.get("value")) is not int
                or not 0 <= payload["value"] <= 100
            ):
                self._send_json({"error": "invalid_brightness"}, status=400)
                return
            result = self.brightness_controller.set_brightness(payload["value"])
            status = 200 if result.available else 503
            response = result.as_dict()
            if not result.available:
                response["error"] = "brightness_unavailable"
            self._send_json(response, status=status)
            return

        if path == "/api/display/settings":
            try:
                saved = self.display_settings_store.save(payload)
            except DisplaySettingsError:
                self._send_json({"error": "invalid_display_settings"}, status=400)
                return
            except OSError:
                self._send_json({"error": "display_settings_write_failed"}, status=500)
                return
            self._send_json({"settings": saved, "settingsStatus": "saved"})
            return

        try:
            sanitized = self._sanitize_display_diagnostics(payload)
            self._append_display_diagnostics(sanitized)
        except (OSError, ValueError):
            self._send_json({"error": "invalid_diagnostics"}, status=400)
            return
        self._send_json({"status": "saved"})

    def _accept_local_request(self, require_origin):
        expected_host = f"{HOST}:{PORT}"
        if self.headers.get("Host") != expected_host:
            self._send_json({"error": "host_rejected"}, status=403)
            return False
        expected_origin = f"http://{expected_host}"
        origin = self.headers.get("Origin")
        if (require_origin and origin != expected_origin) or (
            origin is not None and origin != expected_origin
        ):
            self._send_json({"error": "origin_rejected"}, status=403)
            return False
        return True

    def _accept_loopback_client(self):
        client_host = self.client_address[0] if self.client_address else None
        if client_host != HOST:
            self._send_json({"error": "client_rejected"}, status=403)
            return False
        return True

    def _accept_production_request(self, require_origin):
        if not self.calendar_settings or self.calendar_settings.runtime_mode != "production":
            self._send_json({"error": "not_found"}, status=404)
            return False
        return self._accept_local_request(require_origin) and self._accept_loopback_client()

    def _read_strict_json(self, maximum):
        if self.headers.get("Transfer-Encoding") is not None:
            raise ValueError("Transfer-Encoding is not accepted")
        if self.headers.get("Content-Type", "").casefold() != "application/json":
            raise ValueError("Content-Type must be application/json")
        length_text = self.headers.get("Content-Length", "")
        if not length_text.isascii() or not length_text.isdecimal():
            raise ValueError("Content-Length is invalid")
        length = int(length_text)
        if length <= 0 or length > maximum:
            raise ValueError("Content-Length is outside the accepted range")
        raw = self.rfile.read(length)
        return json.loads(
            raw.decode("utf-8", errors="strict"),
            object_pairs_hook=_json_object_without_duplicates,
            parse_constant=lambda _value: (_ for _ in ()).throw(
                ValueError("Non-finite JSON number")
            ),
        )

    @staticmethod
    def _sanitize_display_diagnostics(payload):
        if not isinstance(payload, dict) or set(payload) != DIAGNOSTIC_FIELDS:
            raise ValueError("Unexpected diagnostic field")
        sanitized = {}
        for field in DIAGNOSTIC_FIELDS:
            value = payload.get(field)
            if field == "userAgentFamily":
                if value not in {"Microsoft Edge", "Other"}:
                    raise ValueError("Unexpected browser family")
                sanitized[field] = value
                continue
            if field == "fullscreenOrKiosk":
                if type(value) is not bool:
                    raise ValueError("fullscreenOrKiosk must be boolean")
                sanitized[field] = value
                continue
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                raise ValueError("Diagnostic values must be numeric")
            if not 0 < float(value) <= 100_000:
                raise ValueError("Diagnostic value is outside the accepted range")
            sanitized[field] = round(float(value), 2)
        return sanitized

    def _append_display_diagnostics(self, payload):
        report_path = self.calendar_settings.app_data_root / "CHUWI_Dashboard_Install_Report.txt"
        report_path.parent.mkdir(parents=True, exist_ok=True)
        lines = ["", "[Browser display diagnostics]"]
        labels = {
            "screenWidth": "screen width (CSS px)",
            "screenHeight": "screen height (CSS px)",
            "availableWidth": "available width (CSS px)",
            "availableHeight": "available height (CSS px)",
            "viewportWidth": "browser viewport width (CSS px)",
            "viewportHeight": "browser viewport height (CSS px)",
            "outerWidth": "browser outer width (CSS px)",
            "outerHeight": "browser outer height (CSS px)",
            "devicePixelRatio": "devicePixelRatio",
            "browserZoomEstimatePercent": "browser zoom estimate (%)",
            "physicalWidthEstimate": "physical width estimate (px)",
            "physicalHeightEstimate": "physical height estimate (px)",
            "windowsScalingEstimatePercent": "Windows scaling estimate (%)",
            "calculatedDashboardScale": "calculated Dashboard scale",
            "fullscreenOrKiosk": "fullscreen/kiosk detected",
            "userAgentFamily": "browser family",
        }
        for field in sorted(DIAGNOSTIC_FIELDS):
            lines.append(f"{labels[field]}: {payload[field]}")
        with report_path.open("a", encoding="utf-8", newline="\n") as report:
            report.write("\n".join(lines) + "\n")

    def _send_json(self, payload, status=200):
        encoded = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(encoded)))
        self.end_headers()
        self.wfile.write(encoded)

    def end_headers(self):
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate")
        self.send_header("Pragma", "no-cache")
        self.send_header("Expires", "0")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("X-Frame-Options", "DENY")
        connect_sources = ["'self'", "wss://api.p2pquake.net"]
        if self.calendar_settings and self.calendar_settings.runtime_mode == "development":
            connect_sources.append("wss://api-realtime-sandbox.p2pquake.net")
        self.send_header(
            "Content-Security-Policy",
            "default-src 'self'; "
            "script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; "
            f"connect-src {' '.join(connect_sources)}; "
            "object-src 'none'; base-uri 'none'; frame-ancestors 'none'",
        )
        super().end_headers()

    def log_message(self, format, *args):
        return


def run_server():
    calendar_settings = load_calendar_settings(ROOT)
    if calendar_settings.runtime_mode == "production" and is_process_elevated():
        raise RuntimeError("Production Dashboard must not run elevated")
    household_settings = load_household_settings(
        ROOT,
        calendar_settings.app_data_root,
    )
    cache_path = calendar_settings.app_data_root / "cache" / "weather-latest.json"
    weather_provider = JmaWeatherProvider(cache_path)
    calendar_provider = GoogleCalendarProvider(
        calendar_settings,
        person_rules=household_settings.people,
    )
    display_settings_store = DisplaySettingsStore(
        calendar_settings.app_data_root / "display-settings.json"
    )
    brightness_controller = WindowsBrightnessController()
    keep_awake_controller = KeepAwakeController()
    update_control = DashboardUpdateControl(APP_VERSION)
    maintenance_control = MaintenanceExitControl(
        calendar_settings.app_data_root / "maintenance-pin.json"
    )
    if calendar_settings.runtime_mode == "production":
        keep_awake_controller.activate()
    weather_provider.start()
    calendar_provider.start()
    PreviewHandler.weather_provider = weather_provider
    PreviewHandler.calendar_provider = calendar_provider
    PreviewHandler.calendar_settings = calendar_settings
    PreviewHandler.household_settings = household_settings
    PreviewHandler.display_settings_store = display_settings_store
    PreviewHandler.brightness_controller = brightness_controller
    PreviewHandler.keep_awake_controller = keep_awake_controller
    PreviewHandler.update_control = update_control
    PreviewHandler.maintenance_control = maintenance_control
    handler = partial(PreviewHandler, directory=str(ROOT))
    server = DashboardHTTPServer((HOST, PORT), handler)
    print(f"Family Dashboard {APP_VERSION} ({BUILD_ID}): http://{HOST}:{PORT}", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        calendar_provider.stop()
        weather_provider.stop()
        server.server_close()
        keep_awake_controller.deactivate()


if __name__ == "__main__":
    try:
        run_server()
    except Exception as exc:
        print(f"Family Dashboard startup failed: {type(exc).__name__}: {exc}", file=sys.stderr, flush=True)
        raise
