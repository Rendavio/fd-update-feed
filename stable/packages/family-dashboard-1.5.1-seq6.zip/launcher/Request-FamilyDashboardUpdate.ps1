#requires -Version 5.1
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidatePattern('^[0-9a-f]{32}$')]
    [string]$RequestId
)
Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"

function Test-IsAdministrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

if (Test-IsAdministrator) { exit 6 }
if ([Environment]::UserName -ine "DashboardAdmin") { exit 6 }
$elevatedScript = "C:\FamilyDashboard\launcher\Invoke-FamilyDashboardUpdate.ps1"
$powershell = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
$handoff = Join-Path $env:LOCALAPPDATA "FamilyDashboard\update-apply-handoff.json"
$handoffTemp = $handoff + ".tmp"
if (-not (Test-Path -LiteralPath $elevatedScript -PathType Leaf) -or
    (Test-Path -LiteralPath $handoff) -or (Test-Path -LiteralPath $handoffTemp)) { exit 6 }
try {
    $process = Start-Process -FilePath $powershell -Verb RunAs -WindowStyle Hidden -PassThru -ArgumentList @(
        "-NoLogo", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
        "-File", ('"{0}"' -f $elevatedScript), "-RequestId", $RequestId
    )
} catch {
    exit 5
}
if ($null -eq $process -or $process.Id -le 0) { exit 6 }
$record = [ordered]@{
    schemaVersion = 1
    kind = "family-dashboard-update-apply-handoff"
    requestId = $RequestId
    state = "COORDINATOR_WAITING"
    processId = [int64]$process.Id
}
try {
    $json = $record | ConvertTo-Json -Compress
    [IO.File]::WriteAllText($handoffTemp, $json, (New-Object Text.UTF8Encoding($false)))
    Move-Item -LiteralPath $handoffTemp -Destination $handoff
} catch {
    Remove-Item -LiteralPath $handoffTemp -Force -ErrorAction SilentlyContinue
    exit 6
}
exit 0
