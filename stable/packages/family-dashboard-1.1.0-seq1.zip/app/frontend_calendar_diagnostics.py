from __future__ import annotations

import base64
import hashlib
import json
import os
import re
import secrets
import shutil
import socket
import struct
import subprocess
import tempfile
import time
from collections import Counter
from pathlib import Path
from typing import Any, Callable
from urllib.parse import urlparse
from urllib.request import ProxyHandler, build_opener


PRODUCTION_URL = "http://127.0.0.1:3000/?display=1&theme=auto&calendar=google&eew=production"
REPORT_NAME = "Frontend-Calendar-Diagnostic-Report.txt"
SAFE_EXCEPTION_TYPES = frozenset({
    "Error", "TypeError", "ReferenceError", "SyntaxError", "RangeError",
    "URIError", "EvalError", "AggregateError", "JavaScriptError",
})
SAFE_CONSOLE_TYPES = frozenset({"error", "warning", "assert", "trace"})
SAFE_LOG_SOURCES = frozenset({"javascript", "network", "security", "deprecation", "violation", "other"})


class FrontendDiagnosticFailure(RuntimeError):
    def __init__(self, category: str) -> None:
        super().__init__(category)
        self.category = category if re.fullmatch(r"[a-z_]{1,40}", category) else "internal"


def _safe_int(value: Any, default: int = 0) -> int:
    return value if isinstance(value, int) and not isinstance(value, bool) and 0 <= value <= 1_000_000 else default


def _safe_count_list(value: Any, length: int = 7) -> list[int]:
    if not isinstance(value, list) or len(value) != length:
        return [-1] * length
    return [_safe_int(item, -1) for item in value]


def _safe_exception_type(value: Any) -> str:
    return value if isinstance(value, str) and value in SAFE_EXCEPTION_TYPES else "JavaScriptError"


def _safe_edge_version(value: Any) -> str:
    if not isinstance(value, str):
        return "unavailable"
    match = re.search(r"(?:Edg|Chrome)/(\d+(?:\.\d+){0,3})", value)
    return match.group(1) if match else "unavailable"


def _read_exact(stream: socket.socket, size: int) -> bytes:
    chunks = bytearray()
    while len(chunks) < size:
        chunk = stream.recv(size - len(chunks))
        if not chunk:
            raise FrontendDiagnosticFailure("devtools_connection_closed")
        chunks.extend(chunk)
    return bytes(chunks)


class LocalWebSocket:
    def __init__(self, url: str, timeout: float = 0.5) -> None:
        parsed = urlparse(url)
        if parsed.scheme != "ws" or parsed.hostname not in {"127.0.0.1", "localhost"}:
            raise FrontendDiagnosticFailure("unsafe_devtools_url")
        port = parsed.port
        if not port:
            raise FrontendDiagnosticFailure("invalid_devtools_url")
        self._socket = socket.create_connection((parsed.hostname, port), timeout=5)
        self._socket.settimeout(timeout)
        key = base64.b64encode(secrets.token_bytes(16)).decode("ascii")
        path = parsed.path or "/"
        if parsed.query:
            path += f"?{parsed.query}"
        request = (
            f"GET {path} HTTP/1.1\r\n"
            f"Host: {parsed.hostname}:{port}\r\n"
            "Upgrade: websocket\r\n"
            "Connection: Upgrade\r\n"
            f"Sec-WebSocket-Key: {key}\r\n"
            "Sec-WebSocket-Version: 13\r\n\r\n"
        ).encode("ascii")
        self._socket.sendall(request)
        response = bytearray()
        while b"\r\n\r\n" not in response and len(response) < 32_768:
            response.extend(_read_exact(self._socket, 1))
        header_text = response.decode("iso-8859-1", errors="replace")
        expected_accept = base64.b64encode(
            hashlib.sha1((key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").encode("ascii")).digest()
        ).decode("ascii")
        if not header_text.startswith("HTTP/1.1 101") or expected_accept.lower() not in header_text.lower():
            self.close()
            raise FrontendDiagnosticFailure("devtools_websocket_rejected")

    def _send_frame(self, payload: bytes, opcode: int) -> None:
        mask = secrets.token_bytes(4)
        length = len(payload)
        header = bytearray([0x80 | opcode])
        if length < 126:
            header.append(0x80 | length)
        elif length <= 0xFFFF:
            header.append(0x80 | 126)
            header.extend(struct.pack("!H", length))
        else:
            header.append(0x80 | 127)
            header.extend(struct.pack("!Q", length))
        header.extend(mask)
        masked = bytes(byte ^ mask[index % 4] for index, byte in enumerate(payload))
        self._socket.sendall(bytes(header) + masked)

    def send_json(self, payload: dict[str, Any]) -> None:
        self._send_frame(json.dumps(payload, separators=(",", ":")).encode("utf-8"), 0x1)

    def receive_json(self) -> dict[str, Any] | None:
        fragments = bytearray()
        message_opcode: int | None = None
        while True:
            try:
                first, second = _read_exact(self._socket, 2)
            except socket.timeout:
                return None
            final = bool(first & 0x80)
            opcode = first & 0x0F
            masked = bool(second & 0x80)
            length = second & 0x7F
            if length == 126:
                length = struct.unpack("!H", _read_exact(self._socket, 2))[0]
            elif length == 127:
                length = struct.unpack("!Q", _read_exact(self._socket, 8))[0]
            if length > 16_000_000:
                raise FrontendDiagnosticFailure("devtools_message_too_large")
            mask = _read_exact(self._socket, 4) if masked else b""
            payload = _read_exact(self._socket, length)
            if masked:
                payload = bytes(byte ^ mask[index % 4] for index, byte in enumerate(payload))
            if opcode == 0x8:
                return None
            if opcode == 0x9:
                self._send_frame(payload, 0xA)
                continue
            if opcode == 0xA:
                continue
            if opcode in {0x1, 0x2}:
                message_opcode = opcode
                fragments = bytearray(payload)
            elif opcode == 0x0 and message_opcode is not None:
                fragments.extend(payload)
            else:
                continue
            if not final:
                continue
            if message_opcode != 0x1:
                fragments.clear()
                message_opcode = None
                continue
            try:
                decoded = json.loads(fragments.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                raise FrontendDiagnosticFailure("invalid_devtools_message") from exc
            return decoded if isinstance(decoded, dict) else None

    def close(self) -> None:
        try:
            self._send_frame(b"", 0x8)
        except Exception:
            pass
        try:
            self._socket.close()
        except Exception:
            pass


class CdpClient:
    def __init__(self, websocket: LocalWebSocket) -> None:
        self.websocket = websocket
        self.next_id = 1
        self.responses: dict[int, dict[str, Any]] = {}
        self.event_handler: Callable[[dict[str, Any]], None] | None = None

    def _dispatch(self, message: dict[str, Any]) -> None:
        message_id = message.get("id")
        if isinstance(message_id, int):
            self.responses[message_id] = message
            return
        if self.event_handler and isinstance(message.get("method"), str):
            self.event_handler(message)

    def receive_once(self) -> None:
        message = self.websocket.receive_json()
        if message is not None:
            self._dispatch(message)

    def call(self, method: str, params: dict[str, Any] | None = None, timeout: float = 10) -> dict[str, Any]:
        command_id = self.next_id
        self.next_id += 1
        payload: dict[str, Any] = {"id": command_id, "method": method}
        if params is not None:
            payload["params"] = params
        self.websocket.send_json(payload)
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if command_id in self.responses:
                response = self.responses.pop(command_id)
                if "error" in response:
                    raise FrontendDiagnosticFailure("devtools_command_failed")
                result = response.get("result")
                return result if isinstance(result, dict) else {}
            self.receive_once()
        raise FrontendDiagnosticFailure("devtools_command_timeout")

    def close(self) -> None:
        self.websocket.close()


def _default_result() -> dict[str, Any]:
    return {
        "overall": "FAIL",
        "failure_category": "none",
        "edge_version": "unavailable",
        "calendar_fetch_count": 0,
        "calendar_loader_entry_count": 0,
        "calendar_provider_available": False,
        "calendar_http_status": -1,
        "calendar_json_valid": False,
        "calendar_api_event_count": -1,
        "calendar_api_day_counts": [-1] * 7,
        "provider_event_count": -1,
        "provider_day_counts": [-1] * 7,
        "render_event_count": -1,
        "render_day_counts": [-1] * 7,
        "render_snapshot_count": 0,
        "dom_day_columns": -1,
        "dom_heading_total": -1,
        "dom_heading_counts": [-1] * 7,
        "dom_event_cards": -1,
        "dom_expected_visible_cards": -1,
        "dom_more_indicators": -1,
        "css_visible_cards": -1,
        "css_hidden_cards": -1,
        "css_zero_rect_cards": -1,
        "css_clipped_cards": -1,
        "calendar_resource_entries": -1,
        "display_param_is_1": False,
        "calendar_param_is_google": False,
        "display_only_class": False,
        "provider_select_is_google": False,
        "runtime_mode": "unknown",
        "calendar_mode": "unknown",
        "state_display_only": False,
        "app_script_parsed": False,
        "providers_script_parsed": False,
        "script_parse_failures": 0,
        "runtime_exception_count": 0,
        "runtime_exception_types": Counter(),
        "calendar_caught_exception_count": 0,
        "calendar_caught_exception_types": Counter(),
        "console_error_count": 0,
        "console_error_types": Counter(),
        "log_error_count": 0,
        "log_error_sources": Counter(),
        "feature_support": {},
        "temporary_profile_removed": False,
    }


def _http_json(url: str) -> Any:
    parsed = urlparse(url)
    if parsed.scheme != "http" or parsed.hostname != "127.0.0.1":
        raise FrontendDiagnosticFailure("unsafe_local_http_url")
    opener = build_opener(ProxyHandler({}))
    with opener.open(url, timeout=5) as response:
        payload = response.read(2_000_000)
    try:
        return json.loads(payload.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise FrontendDiagnosticFailure("invalid_local_http_json") from exc


def _evaluate_value(client: CdpClient, expression: str) -> Any:
    result = client.call("Runtime.evaluate", {
        "expression": expression,
        "returnByValue": True,
        "awaitPromise": True,
        "silent": True,
    })
    remote = result.get("result")
    return remote.get("value") if isinstance(remote, dict) else None


def _evaluate_call_frame(client: CdpClient, call_frame_id: str, expression: str) -> Any:
    result = client.call("Debugger.evaluateOnCallFrame", {
        "callFrameId": call_frame_id,
        "expression": expression,
        "returnByValue": True,
        "silent": True,
    })
    remote = result.get("result")
    return remote.get("value") if isinstance(remote, dict) else None


def _sanitize_pipeline_snapshot(value: Any) -> dict[str, Any] | None:
    if not isinstance(value, dict):
        return None
    return {
        "total": _safe_int(value.get("total"), -1),
        "per_day": _safe_count_list(value.get("perDay")),
        "runtime_mode": value.get("runtimeMode") if value.get("runtimeMode") in {"production", "development"} else "unknown",
        "calendar_mode": value.get("calendarMode") if value.get("calendarMode") in {"google", "mock"} else "unknown",
        "display_only": value.get("displayOnly") is True,
    }


def _dom_expression() -> str:
    return r"""
(() => {
  const params = new URL(location.href).searchParams;
  const cards = [...document.querySelectorAll('.event-card')];
  const dayCards = [...document.querySelectorAll('.day-card')];
  const isCssHidden = (element) => {
    for (let current = element; current; current = current.parentElement) {
      const style = getComputedStyle(current);
      if (style.display === 'none' || style.visibility === 'hidden' || style.visibility === 'collapse' || Number(style.opacity) === 0) return true;
    }
    return false;
  };
  const cardMetrics = cards.map((card) => {
    const rect = card.getBoundingClientRect();
    const day = card.closest('.day-card');
    const dayRect = day ? day.getBoundingClientRect() : null;
    const intersectionWidth = dayRect ? Math.max(0, Math.min(rect.right, dayRect.right) - Math.max(rect.left, dayRect.left)) : 0;
    const intersectionHeight = dayRect ? Math.max(0, Math.min(rect.bottom, dayRect.bottom) - Math.max(rect.top, dayRect.top)) : 0;
    return {
      hidden: isCssHidden(card),
      zeroRect: rect.width <= 0 || rect.height <= 0 || card.getClientRects().length === 0,
      clipped: !dayRect || intersectionWidth <= 0 || intersectionHeight <= 0,
    };
  });
  const headingCounts = dayCards.map((day) => {
    const text = day.querySelector('.section-heading b')?.textContent || '';
    const match = text.match(/\d+/);
    return match ? Number(match[0]) : -1;
  });
  const expectedCards = headingCounts.reduce((total, count, index) => total + (count < 0 ? 0 : Math.min(count, index === 0 ? 5 : 3)), 0);
  const resources = performance.getEntriesByType('resource').filter((entry) => {
    try { return new URL(entry.name).pathname === '/api/calendar'; } catch { return false; }
  });
  return {
    dayColumns: dayCards.length,
    headingCounts,
    headingTotal: headingCounts.reduce((total, count) => total + Math.max(0, count), 0),
    eventCards: cards.length,
    expectedCards,
    moreIndicators: document.querySelectorAll('.more-events').length,
    visibleCards: cardMetrics.filter((item) => !item.hidden && !item.zeroRect && !item.clipped).length,
    hiddenCards: cardMetrics.filter((item) => item.hidden).length,
    zeroRectCards: cardMetrics.filter((item) => item.zeroRect).length,
    clippedCards: cardMetrics.filter((item) => item.clipped).length,
    calendarResourceEntries: resources.length,
    displayParamIs1: params.get('display') === '1',
    calendarParamIsGoogle: params.get('calendar') === 'google',
    displayOnlyClass: document.getElementById('previewApp')?.classList.contains('display-only') === true,
    providerSelectIsGoogle: document.getElementById('calendarProviderSelect')?.value === 'google',
  };
})()
"""


def _feature_expression() -> str:
    return r"""
(() => ({
  fetch: typeof fetch === 'function',
  WebSocket: typeof WebSocket === 'function',
  URLSearchParams: typeof URLSearchParams === 'function',
  IntlDateTimeFormat: typeof Intl?.DateTimeFormat === 'function',
  PromiseAll: typeof Promise?.all === 'function',
  ObjectHasOwn: typeof Object?.hasOwn === 'function',
  ArrayFind: typeof Array?.prototype?.find === 'function',
  ReplaceChildren: typeof Element?.prototype?.replaceChildren === 'function',
  ModuleScripts: 'noModule' in HTMLScriptElement.prototype,
}))()
"""


def _apply_dom_result(result: dict[str, Any], value: Any) -> None:
    if not isinstance(value, dict):
        return
    result["dom_day_columns"] = _safe_int(value.get("dayColumns"), -1)
    result["dom_heading_counts"] = _safe_count_list(value.get("headingCounts"))
    result["dom_heading_total"] = _safe_int(value.get("headingTotal"), -1)
    result["dom_event_cards"] = _safe_int(value.get("eventCards"), -1)
    result["dom_expected_visible_cards"] = _safe_int(value.get("expectedCards"), -1)
    result["dom_more_indicators"] = _safe_int(value.get("moreIndicators"), -1)
    result["css_visible_cards"] = _safe_int(value.get("visibleCards"), -1)
    result["css_hidden_cards"] = _safe_int(value.get("hiddenCards"), -1)
    result["css_zero_rect_cards"] = _safe_int(value.get("zeroRectCards"), -1)
    result["css_clipped_cards"] = _safe_int(value.get("clippedCards"), -1)
    result["calendar_resource_entries"] = _safe_int(value.get("calendarResourceEntries"), -1)
    result["display_param_is_1"] = value.get("displayParamIs1") is True
    result["calendar_param_is_google"] = value.get("calendarParamIsGoogle") is True
    result["display_only_class"] = value.get("displayOnlyClass") is True
    result["provider_select_is_google"] = value.get("providerSelectIsGoogle") is True


def _finalize_result(result: dict[str, Any]) -> None:
    api_total = result["calendar_api_event_count"]
    provider_total = result["provider_event_count"]
    render_total = result["render_event_count"]
    checks = [
        result["calendar_loader_entry_count"] >= 1,
        result["calendar_provider_available"],
        result["calendar_fetch_count"] >= 1,
        result["calendar_http_status"] == 200,
        result["calendar_json_valid"],
        api_total >= 0,
        provider_total == api_total,
        render_total == provider_total,
        result["dom_heading_total"] == render_total,
        result["dom_day_columns"] == 7,
        result["dom_event_cards"] == result["dom_expected_visible_cards"],
        render_total == 0 or result["css_visible_cards"] > 0,
        result["css_hidden_cards"] == 0,
        result["display_param_is_1"],
        result["calendar_param_is_google"],
        result["display_only_class"],
        result["provider_select_is_google"],
        result["runtime_mode"] == "production",
        result["calendar_mode"] == "google",
        result["state_display_only"],
        result["app_script_parsed"],
        result["providers_script_parsed"],
        result["script_parse_failures"] == 0,
        result["runtime_exception_count"] == 0,
        result["calendar_caught_exception_count"] == 0,
        result["console_error_count"] == 0,
        all(result["feature_support"].values()) if result["feature_support"] else False,
    ]
    result["overall"] = "PASS" if all(checks) else "FAIL"


def run_frontend_diagnostics(edge_path: Path, dashboard_url: str = PRODUCTION_URL, timeout_seconds: int = 25) -> dict[str, Any]:
    parsed_dashboard = urlparse(dashboard_url)
    if parsed_dashboard.scheme != "http" or parsed_dashboard.hostname != "127.0.0.1":
        raise FrontendDiagnosticFailure("unsafe_dashboard_url")
    if not edge_path.is_file() or edge_path.name.lower() != "msedge.exe":
        raise FrontendDiagnosticFailure("edge_not_found")

    result = _default_result()
    profile_root = Path(tempfile.mkdtemp(prefix="FamilyDashboardFrontendDiagnostic-"))
    process: subprocess.Popen | None = None
    client: CdpClient | None = None
    request_paths: dict[str, str] = {}
    calendar_request_ids: set[str] = set()
    loader_breakpoint = ""
    provider_breakpoint = ""
    render_breakpoint = ""
    calendar_catch_breakpoint = ""
    provider_seen = False
    render_snapshots: list[dict[str, Any]] = []

    try:
        creation_flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        process = subprocess.Popen(
            [
                str(edge_path),
                "--headless=new",
                "--disable-gpu",
                "--disable-background-networking",
                "--disable-component-update",
                "--disable-default-apps",
                "--no-first-run",
                "--no-default-browser-check",
                "--remote-debugging-address=127.0.0.1",
                "--remote-debugging-port=0",
                f"--user-data-dir={profile_root}",
                "about:blank",
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=creation_flags,
        )
        active_port_path = profile_root / "DevToolsActivePort"
        deadline = time.monotonic() + 15
        while time.monotonic() < deadline and not active_port_path.is_file():
            if process.poll() is not None:
                raise FrontendDiagnosticFailure("edge_start_failed")
            time.sleep(0.1)
        if not active_port_path.is_file():
            raise FrontendDiagnosticFailure("edge_devtools_timeout")
        port_lines = active_port_path.read_text(encoding="utf-8").splitlines()
        if not port_lines or not port_lines[0].isdigit():
            raise FrontendDiagnosticFailure("invalid_devtools_port")
        port = int(port_lines[0])
        version_payload = _http_json(f"http://127.0.0.1:{port}/json/version")
        result["edge_version"] = _safe_edge_version(version_payload.get("Browser") if isinstance(version_payload, dict) else None)
        targets = _http_json(f"http://127.0.0.1:{port}/json/list")
        target = next((item for item in targets if isinstance(item, dict) and item.get("type") == "page"), None) if isinstance(targets, list) else None
        websocket_url = target.get("webSocketDebuggerUrl") if isinstance(target, dict) else None
        if not isinstance(websocket_url, str):
            raise FrontendDiagnosticFailure("devtools_page_missing")
        client = CdpClient(LocalWebSocket(websocket_url))

        def handle_event(message: dict[str, Any]) -> None:
            nonlocal provider_seen
            method = message.get("method")
            params = message.get("params") if isinstance(message.get("params"), dict) else {}
            if method == "Network.requestWillBeSent":
                request = params.get("request") if isinstance(params.get("request"), dict) else {}
                url = request.get("url")
                request_id = params.get("requestId")
                if isinstance(url, str) and isinstance(request_id, str):
                    try:
                        path = urlparse(url).path
                    except ValueError:
                        path = ""
                    if path in {"/api/calendar", "/api/runtime", "/app.js", "/src/providers.js"}:
                        request_paths[request_id] = path
                    if path == "/api/calendar":
                        calendar_request_ids.add(request_id)
                        result["calendar_fetch_count"] += 1
            elif method == "Network.responseReceived":
                request_id = params.get("requestId")
                response = params.get("response") if isinstance(params.get("response"), dict) else {}
                if isinstance(request_id, str) and request_paths.get(request_id) == "/api/calendar":
                    status = response.get("status")
                    result["calendar_http_status"] = int(status) if isinstance(status, (int, float)) else -1
            elif method == "Network.loadingFinished":
                request_id = params.get("requestId")
                if isinstance(request_id, str) and request_id in calendar_request_ids:
                    try:
                        body_result = client.call("Network.getResponseBody", {"requestId": request_id})
                        body_value = body_result.get("body")
                        if body_result.get("base64Encoded") is True and isinstance(body_value, str):
                            body_value = base64.b64decode(body_value).decode("utf-8")
                        payload = json.loads(body_value) if isinstance(body_value, str) else None
                        days = payload.get("days") if isinstance(payload, dict) else None
                        if isinstance(days, list) and len(days) == 7:
                            counts = [
                                len(day.get("events", []))
                                if isinstance(day, dict) and isinstance(day.get("events"), list)
                                else -1
                                for day in days
                            ]
                            result["calendar_api_day_counts"] = _safe_count_list(counts)
                            result["calendar_api_event_count"] = sum(count for count in counts if count >= 0)
                            result["calendar_json_valid"] = all(count >= 0 for count in counts)
                    except Exception:
                        result["calendar_json_valid"] = False
            elif method == "Debugger.scriptParsed":
                url = params.get("url")
                if isinstance(url, str):
                    path = urlparse(url).path
                    if path == "/app.js":
                        result["app_script_parsed"] = True
                    elif path == "/src/providers.js":
                        result["providers_script_parsed"] = True
            elif method == "Debugger.scriptFailedToParse":
                result["script_parse_failures"] += 1
            elif method == "Runtime.exceptionThrown":
                details = params.get("exceptionDetails") if isinstance(params.get("exceptionDetails"), dict) else {}
                exception = details.get("exception") if isinstance(details.get("exception"), dict) else {}
                exception_type = _safe_exception_type(exception.get("className"))
                result["runtime_exception_count"] += 1
                result["runtime_exception_types"][exception_type] += 1
            elif method == "Runtime.consoleAPICalled":
                console_type = params.get("type")
                if console_type in SAFE_CONSOLE_TYPES:
                    result["console_error_count"] += 1
                    result["console_error_types"][console_type] += 1
            elif method == "Log.entryAdded":
                entry = params.get("entry") if isinstance(params.get("entry"), dict) else {}
                if entry.get("level") in {"error", "warning"}:
                    source = entry.get("source") if entry.get("source") in SAFE_LOG_SOURCES else "other"
                    result["log_error_count"] += 1
                    result["log_error_sources"][source] += 1
            elif method == "Debugger.paused":
                hit = params.get("hitBreakpoints") if isinstance(params.get("hitBreakpoints"), list) else []
                frames = params.get("callFrames") if isinstance(params.get("callFrames"), list) else []
                call_frame_id = frames[0].get("callFrameId") if frames and isinstance(frames[0], dict) else None
                try:
                    if isinstance(call_frame_id, str) and loader_breakpoint in hit:
                        expression = "({ calendarMode: state?.calendarMode, runtimeMode: state?.runtimeMode, displayOnly: state?.displayOnly, providerAvailable: Boolean(providers?.calendars?.[state?.calendarMode]) })"
                        entry = _evaluate_call_frame(client, call_frame_id, expression)
                        if isinstance(entry, dict):
                            result["calendar_loader_entry_count"] += 1
                            result["calendar_provider_available"] = entry.get("providerAvailable") is True
                            if entry.get("calendarMode") in {"google", "mock"}:
                                result["calendar_mode"] = entry["calendarMode"]
                            if entry.get("runtimeMode") in {"production", "development"}:
                                result["runtime_mode"] = entry["runtimeMode"]
                            result["state_display_only"] = entry.get("displayOnly") is True
                    if isinstance(call_frame_id, str) and provider_breakpoint in hit:
                        expression = "({ total: Array.isArray(result?.days) ? result.days.reduce((n,d) => n + (Array.isArray(d.events) ? d.events.length : 0), 0) : -1, perDay: Array.isArray(result?.days) ? result.days.map(d => Array.isArray(d.events) ? d.events.length : -1) : [] })"
                        snapshot = _sanitize_pipeline_snapshot(_evaluate_call_frame(client, call_frame_id, expression))
                        if snapshot:
                            result["provider_event_count"] = snapshot["total"]
                            result["provider_day_counts"] = snapshot["per_day"]
                            provider_seen = True
                    if isinstance(call_frame_id, str) and render_breakpoint in hit:
                        expression = "({ total: Array.isArray(state?.calendarDays) ? state.calendarDays.reduce((n,d) => n + (Array.isArray(d) ? d.length : 0), 0) : -1, perDay: Array.isArray(state?.calendarDays) ? state.calendarDays.map(d => Array.isArray(d) ? d.length : -1) : [], runtimeMode: state?.runtimeMode, calendarMode: state?.calendarMode, displayOnly: state?.displayOnly })"
                        snapshot = _sanitize_pipeline_snapshot(_evaluate_call_frame(client, call_frame_id, expression))
                        if snapshot:
                            render_snapshots.append(snapshot)
                            result["render_snapshot_count"] = len(render_snapshots)
                            if provider_seen:
                                result["render_event_count"] = snapshot["total"]
                                result["render_day_counts"] = snapshot["per_day"]
                                result["runtime_mode"] = snapshot["runtime_mode"]
                                result["calendar_mode"] = snapshot["calendar_mode"]
                                result["state_display_only"] = snapshot["display_only"]
                    if isinstance(call_frame_id, str) and calendar_catch_breakpoint in hit:
                        exception_type = _evaluate_call_frame(client, call_frame_id, "error?.constructor?.name")
                        safe_type = _safe_exception_type(exception_type)
                        result["calendar_caught_exception_count"] += 1
                        result["calendar_caught_exception_types"][safe_type] += 1
                finally:
                    try:
                        client.call("Debugger.resume")
                    except FrontendDiagnosticFailure:
                        pass

        client.event_handler = handle_event
        for domain in ("Page", "Runtime", "Network", "Debugger", "Log"):
            client.call(f"{domain}.enable")
        loader_breakpoint = client.call("Debugger.setBreakpointByUrl", {
            "lineNumber": 403,
            "urlRegex": r"app\.js(?:\?.*)?$",
        }).get("breakpointId", "")
        provider_breakpoint = client.call("Debugger.setBreakpointByUrl", {
            "lineNumber": 417,
            "urlRegex": r"app\.js(?:\?.*)?$",
        }).get("breakpointId", "")
        render_breakpoint = client.call("Debugger.setBreakpointByUrl", {
            "lineNumber": 287,
            "urlRegex": r"app\.js(?:\?.*)?$",
        }).get("breakpointId", "")
        calendar_catch_breakpoint = client.call("Debugger.setBreakpointByUrl", {
            "lineNumber": 427,
            "urlRegex": r"app\.js(?:\?.*)?$",
        }).get("breakpointId", "")
        client.call("Page.navigate", {"url": dashboard_url})

        deadline = time.monotonic() + timeout_seconds
        ready_since: float | None = None
        while time.monotonic() < deadline:
            client.receive_once()
            ready = (
                result["calendar_json_valid"]
                and result["provider_event_count"] >= 0
                and result["render_event_count"] >= 0
                and result["app_script_parsed"]
                and result["providers_script_parsed"]
            )
            if ready:
                ready_since = ready_since or time.monotonic()
                if time.monotonic() - ready_since >= 1.5:
                    break

        _apply_dom_result(result, _evaluate_value(client, _dom_expression()))
        features = _evaluate_value(client, _feature_expression())
        if isinstance(features, dict):
            allowed_features = {
                "fetch", "WebSocket", "URLSearchParams", "IntlDateTimeFormat",
                "PromiseAll", "ObjectHasOwn", "ArrayFind", "ReplaceChildren", "ModuleScripts",
            }
            result["feature_support"] = {
                key: value is True for key, value in features.items() if key in allowed_features
            }
        _finalize_result(result)
    except FrontendDiagnosticFailure as exc:
        result["failure_category"] = exc.category
    except Exception:
        result["failure_category"] = "internal"
    finally:
        if client is not None:
            try:
                client.call("Browser.close", timeout=3)
            except Exception:
                pass
            client.close()
        if process is not None:
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.terminate()
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill()
                    try:
                        process.wait(timeout=3)
                    except subprocess.TimeoutExpired:
                        pass
        for _ in range(20):
            try:
                shutil.rmtree(profile_root)
                break
            except OSError:
                time.sleep(0.25)
        result["temporary_profile_removed"] = not profile_root.exists()
        if not result["temporary_profile_removed"]:
            result["overall"] = "FAIL"
    return result


def _counter_lines(prefix: str, counter: Counter) -> list[str]:
    if not counter:
        return [f"{prefix}: none"]
    return [f"{prefix} {key}: {_safe_int(value)}" for key, value in sorted(counter.items())]


def render_report(result: dict[str, Any]) -> str:
    lines = [
        "Family Dashboard Frontend Calendar non-destructive diagnostics",
        "target: isolated Edge production Dashboard session on 127.0.0.1",
        "Calendar ID / Service Account / private key / token: not read or logged",
        "event titles and contents: not logged",
        "existing Dashboard UI and files modified: no",
        "Google configuration, Provider, cache, and API range modified: no",
        "",
        f"overall result: {result['overall']}",
        f"safe failure category: {result['failure_category']}",
        f"Edge version: {result['edge_version']}",
        "",
        f"1a. Calendar loader entry count: {result['calendar_loader_entry_count']}",
        f"1b. selected Calendar provider available: {'PASS' if result['calendar_provider_available'] else 'FAIL'}",
        f"1c. production Dashboard /api/calendar fetch count: {result['calendar_fetch_count']}",
        f"2. /api/calendar HTTP status: {result['calendar_http_status'] if result['calendar_http_status'] >= 0 else 'unavailable'}",
        f"3a. /api/calendar JSON schema observed: {'PASS' if result['calendar_json_valid'] else 'FAIL'}",
        f"3b. /api/calendar received event count: {result['calendar_api_event_count']}",
        f"3c. /api/calendar day counts: {result['calendar_api_day_counts']}",
        f"4a. providers.js -> app.js event count: {result['provider_event_count']}",
        f"4b. providers.js -> app.js day counts: {result['provider_day_counts']}",
        f"5a. renderDashboard input event count: {result['render_event_count']}",
        f"5b. renderDashboard input day counts: {result['render_day_counts']}",
        f"5c. renderDashboard observations: {result['render_snapshot_count']}",
        f"6a. rendered column heading total: {result['dom_heading_total']}",
        f"6b. rendered column heading counts: {result['dom_heading_counts']}",
        f"6c. rendered day column count: {result['dom_day_columns']}",
        f"7a. DOM event-card count: {result['dom_event_cards']}",
        f"7b. expected DOM cards after 5/3 display caps: {result['dom_expected_visible_cards']}",
        f"7c. DOM more-events indicator count: {result['dom_more_indicators']}",
        f"8a. CSS-visible event-card count: {result['css_visible_cards']}",
        f"8b. CSS-hidden event-card count: {result['css_hidden_cards']}",
        f"8c. zero-size event-card count: {result['css_zero_rect_cards']}",
        f"8d. fully clipped event-card count: {result['css_clipped_cards']}",
        f"9a. URL display=1: {'PASS' if result['display_param_is_1'] else 'FAIL'}",
        f"9b. URL calendar=google: {'PASS' if result['calendar_param_is_google'] else 'FAIL'}",
        f"9c. display-only class: {'PASS' if result['display_only_class'] else 'FAIL'}",
        f"9d. provider selector is google: {'PASS' if result['provider_select_is_google'] else 'FAIL'}",
        f"9e. app runtime mode: {result['runtime_mode']}",
        f"9f. app calendar mode: {result['calendar_mode']}",
        f"9g. app state displayOnly: {'PASS' if result['state_display_only'] else 'FAIL'}",
        f"10a. uncaught JavaScript runtime exception count: {result['runtime_exception_count']}",
    ]
    lines.extend(_counter_lines("10b. exception type", result["runtime_exception_types"]))
    lines.append(f"10c. Calendar pipeline caught exception count: {result['calendar_caught_exception_count']}")
    lines.extend(_counter_lines("10d. caught exception type", result["calendar_caught_exception_types"]))
    lines.extend([
        f"11a. app.js parsed: {'PASS' if result['app_script_parsed'] else 'FAIL'}",
        f"11b. providers.js parsed: {'PASS' if result['providers_script_parsed'] else 'FAIL'}",
        f"11c. script parse failure count: {result['script_parse_failures']}",
    ])
    for feature, supported in sorted(result["feature_support"].items()):
        lines.append(f"11d. feature {feature}: {'PASS' if supported else 'FAIL'}")
    lines.append(f"12a. console error/warning count: {result['console_error_count']}")
    lines.extend(_counter_lines("12b. console type", result["console_error_types"]))
    lines.append(f"12c. browser log error/warning count: {result['log_error_count']}")
    lines.extend(_counter_lines("12d. browser log source", result["log_error_sources"]))
    lines.extend([
        f"12e. Calendar performance resource entries: {result['calendar_resource_entries']}",
        f"temporary Edge diagnostic profile removed: {'PASS' if result['temporary_profile_removed'] else 'FAIL'}",
    ])
    return "\n".join(lines) + "\n"


def main() -> int:
    local_app_data = os.environ.get("LOCALAPPDATA")
    edge_value = os.environ.get("FAMILY_DASHBOARD_EDGE_PATH")
    if not local_app_data or not edge_value:
        print("Frontend Calendar diagnostics could not locate required local paths.")
        return 2
    data_root = Path(local_app_data) / "FamilyDashboard"
    report_path = data_root / REPORT_NAME
    try:
        result = run_frontend_diagnostics(Path(edge_value))
    except Exception:
        result = _default_result()
        result["failure_category"] = "internal"
    try:
        data_root.mkdir(parents=True, exist_ok=True)
        temporary = report_path.with_suffix(".tmp")
        temporary.write_text(render_report(result), encoding="utf-8", newline="\n")
        os.replace(temporary, report_path)
    except OSError:
        print("Frontend Calendar diagnostics could not write the sanitized report.")
        return 2
    print(f"Frontend Calendar diagnostic report: {report_path}")
    print(f"Overall result: {result['overall']}")
    return 0 if result["overall"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
