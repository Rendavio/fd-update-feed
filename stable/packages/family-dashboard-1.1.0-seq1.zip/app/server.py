import json
import platform
import sys
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

from calendar_settings import load_calendar_settings
from google_calendar_provider import GoogleCalendarProvider
from household_settings import load_household_settings
from jma_weather_provider import JmaWeatherProvider


HOST = "127.0.0.1"
PORT = 3000
ROOT = Path(__file__).resolve().parent
APP_ID = "family-dashboard"
APP_VERSION = "1.1.0"
BUILD_ID = "20260901-public-sanitized-r1"
MAX_DIAGNOSTIC_BODY_BYTES = 16_384
DIAGNOSTIC_FIELDS = {
    "screenWidth",
    "screenHeight",
    "availableWidth",
    "availableHeight",
    "viewportWidth",
    "viewportHeight",
    "outerWidth",
    "outerHeight",
    "devicePixelRatio",
    "browserZoomEstimatePercent",
    "userAgentFamily",
}


class PreviewHandler(SimpleHTTPRequestHandler):
    weather_provider = None
    calendar_provider = None
    calendar_settings = None
    household_settings = None

    def do_GET(self):
        path = urlsplit(self.path).path
        if path == "/api/weather":
            self._send_json(self.weather_provider.get_snapshot())
            return
        if path == "/api/calendar":
            snapshot = self.calendar_provider.get_snapshot()
            status = 503 if snapshot.get("cacheState") == "empty" else 200
            self._send_json(snapshot, status=status)
            return
        if path == "/api/runtime":
            self._send_json({
                "mode": self.calendar_settings.runtime_mode,
                "appVersion": APP_VERSION,
                "buildId": BUILD_ID,
                "calendar": {
                    "defaultProvider": "google" if self.calendar_settings.runtime_mode == "production" else "mock",
                    "googleConfigured": self.calendar_settings.configured,
                    "householdConfigured": bool(
                        self.household_settings and self.household_settings.configured
                    ),
                },
            })
            return
        if path == "/api/health":
            self._send_json({
                "status": "ok",
                "appId": APP_ID,
                "appVersion": APP_VERSION,
                "buildId": BUILD_ID,
                "host": HOST,
                "port": PORT,
                "mode": self.calendar_settings.runtime_mode,
            })
            return
        if path == "/api/diagnostics/system":
            self._send_json({
                "appId": APP_ID,
                "appVersion": APP_VERSION,
                "buildId": BUILD_ID,
                "host": HOST,
                "port": PORT,
                "mode": self.calendar_settings.runtime_mode,
                "pythonVersion": platform.python_version(),
                "architecture": platform.machine(),
                "platform": platform.system(),
            })
            return
        super().do_GET()

    def do_POST(self):
        path = urlsplit(self.path).path
        if path != "/api/diagnostics/display":
            self._send_json({"error": "not_found"}, status=404)
            return
        expected_origin = f"http://{HOST}:{PORT}"
        if self.headers.get("Origin") != expected_origin:
            self._send_json({"error": "origin_rejected"}, status=403)
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            length = 0
        if length <= 0 or length > MAX_DIAGNOSTIC_BODY_BYTES:
            self._send_json({"error": "invalid_length"}, status=400)
            return
        try:
            payload = json.loads(self.rfile.read(length).decode("utf-8"))
            sanitized = self._sanitize_display_diagnostics(payload)
            self._append_display_diagnostics(sanitized)
        except (OSError, UnicodeDecodeError, ValueError, json.JSONDecodeError):
            self._send_json({"error": "invalid_diagnostics"}, status=400)
            return
        self._send_json({"status": "saved"})

    @staticmethod
    def _sanitize_display_diagnostics(payload):
        if not isinstance(payload, dict) or set(payload) != DIAGNOSTIC_FIELDS:
            raise ValueError("Unexpected diagnostic field")
        sanitized = {}
        for field in DIAGNOSTIC_FIELDS:
            value = payload.get(field)
            if field == "userAgentFamily":
                if value not in {"Microsoft Edge", "Other"}:
                    raise ValueError("Unexpected browser family")
                sanitized[field] = value
                continue
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                raise ValueError("Diagnostic values must be numeric")
            if not 0 < float(value) <= 100_000:
                raise ValueError("Diagnostic value is outside the accepted range")
            sanitized[field] = round(float(value), 2)
        return sanitized

    def _append_display_diagnostics(self, payload):
        report_path = self.calendar_settings.app_data_root / "CHUWI_Dashboard_Install_Report.txt"
        report_path.parent.mkdir(parents=True, exist_ok=True)
        lines = ["", "[Browser display diagnostics]"]
        labels = {
            "screenWidth": "screen width (CSS px)",
            "screenHeight": "screen height (CSS px)",
            "availableWidth": "available width (CSS px)",
            "availableHeight": "available height (CSS px)",
            "viewportWidth": "browser viewport width (CSS px)",
            "viewportHeight": "browser viewport height (CSS px)",
            "outerWidth": "browser outer width (CSS px)",
            "outerHeight": "browser outer height (CSS px)",
            "devicePixelRatio": "devicePixelRatio",
            "browserZoomEstimatePercent": "browser zoom estimate (%)",
            "userAgentFamily": "browser family",
        }
        for field in sorted(DIAGNOSTIC_FIELDS):
            lines.append(f"{labels[field]}: {payload[field]}")
        with report_path.open("a", encoding="utf-8", newline="\n") as report:
            report.write("\n".join(lines) + "\n")

    def _send_json(self, payload, status=200):
        encoded = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(encoded)))
        self.end_headers()
        self.wfile.write(encoded)

    def end_headers(self):
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate")
        self.send_header("Pragma", "no-cache")
        self.send_header("Expires", "0")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("X-Frame-Options", "DENY")
        connect_sources = ["'self'", "wss://api.p2pquake.net"]
        if self.calendar_settings and self.calendar_settings.runtime_mode == "development":
            connect_sources.append("wss://api-realtime-sandbox.p2pquake.net")
        self.send_header(
            "Content-Security-Policy",
            "default-src 'self'; "
            "script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; "
            f"connect-src {' '.join(connect_sources)}; "
            "object-src 'none'; base-uri 'none'; frame-ancestors 'none'",
        )
        super().end_headers()

    def log_message(self, format, *args):
        return


def run_server():
    calendar_settings = load_calendar_settings(ROOT)
    household_settings = load_household_settings(
        ROOT,
        calendar_settings.app_data_root,
    )
    cache_path = calendar_settings.app_data_root / "cache" / "weather-latest.json"
    weather_provider = JmaWeatherProvider(cache_path)
    calendar_provider = GoogleCalendarProvider(
        calendar_settings,
        person_rules=household_settings.people,
    )
    weather_provider.start()
    calendar_provider.start()
    PreviewHandler.weather_provider = weather_provider
    PreviewHandler.calendar_provider = calendar_provider
    PreviewHandler.calendar_settings = calendar_settings
    PreviewHandler.household_settings = household_settings
    handler = partial(PreviewHandler, directory=str(ROOT))
    server = ThreadingHTTPServer((HOST, PORT), handler)
    server.daemon_threads = True
    print(f"Family Dashboard {APP_VERSION} ({BUILD_ID}): http://{HOST}:{PORT}", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        calendar_provider.stop()
        weather_provider.stop()
        server.server_close()


if __name__ == "__main__":
    try:
        run_server()
    except Exception as exc:
        print(f"Family Dashboard startup failed: {type(exc).__name__}: {exc}", file=sys.stderr, flush=True)
        raise
