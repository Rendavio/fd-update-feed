import { createProviders, MOCK_CALENDAR_ID } from './src/providers.js';
import { formatMinutes, getTokyoDateParts, resolveAutomaticTheme } from './src/sun-times.js';
import { makeWeatherIcon } from './src/weather-icons.js';
import { P2PEarthquakeProvider } from './src/earthquake-provider.js';
import { installEewAudioArming, playEewWarningTone } from './src/eew-audio.js';

const resolutions = {
  100: { width: 1920, height: 1200 },
  125: { width: 1536, height: 960 },
  150: { width: 1280, height: 800 },
};

const weekdayLong = ['日曜日', '月曜日', '火曜日', '水曜日', '木曜日', '金曜日', '土曜日'];
const weekdayShort = ['日', '月', '火', '水', '木', '金', '土'];
const providers = createProviders();
const params = new URLSearchParams(window.location.search);
const requestedTheme = ['auto', 'light', 'dark'].includes(params.get('theme')) ? params.get('theme') : 'auto';
const requestedCalendar = params.get('calendar') === 'google' ? 'google' : 'mock';
const requestedEewEndpoint = params.get('eew') === 'sandbox' ? 'sandbox' : 'production';
const requestedEewPreview = /^(?:[A-G]|MISSING)$/i.test(params.get('eewPreview') || '')
  ? params.get('eewPreview').toUpperCase()
  : null;

const state = {
  resolution: Object.hasOwn(resolutions, params.get('resolution')) ? params.get('resolution') : '100',
  themeMode: requestedTheme,
  resolvedTheme: 'light',
  scenario: ['normal', 'many', 'long', 'joint'].includes(params.get('scenario')) ? params.get('scenario') : 'normal',
  headerLayout: ['a', 'b', 'c', 'd', 'e'].includes(params.get('header')) ? params.get('header') : 'a',
  displayOnly: params.get('display') === '1',
  calendarMode: params.get('display') === '1' ? 'google' : requestedCalendar,
  calendarLoadedMode: null,
  weather: makePlaceholderWeather(),
  calendarDays: Array.from({ length: 7 }, () => []),
  headacheHistory: makeEmptyHeadacheHistory(),
  calendarLastSuccessAt: null,
  calendarStale: false,
  calendarError: null,
  earthquake: null,
  earthquakeStatus: { state: 'idle', endpointKind: 'production', retryInMs: null },
  earthquakeTestResult: null,
  earthquakeAudioResult: null,
  runtimeMode: 'development',
  weatherError: null,
};

let earthquakeProvider = null;

const previewApp = document.getElementById('previewApp');
const previewCanvas = document.getElementById('previewCanvas');
const deviceFrame = document.getElementById('deviceFrame');
const dashboardShell = document.getElementById('dashboardShell');
const dashboard = document.getElementById('dashboard');
const scenarioSelect = document.getElementById('scenarioSelect');
const calendarProviderSelect = document.getElementById('calendarProviderSelect');
const headerLayoutSelect = document.getElementById('headerLayoutSelect');
const previewStatus = document.getElementById('previewStatus');
const eewScenarioSelect = document.getElementById('eewScenarioSelect');

function createElement(tag, className, text) {
  const element = document.createElement(tag);
  if (className) element.className = className;
  if (text !== undefined) element.textContent = text;
  return element;
}

function tokyoIsoDate(offset = 0) {
  const parts = getTokyoDateParts();
  const date = new Date(Date.UTC(parts.year, parts.month - 1, parts.day + offset));
  return date.toISOString().slice(0, 10);
}

function addIsoDays(isoDate, offset) {
  const [year, month, day] = isoDate.split('-').map(Number);
  const date = new Date(Date.UTC(year, month - 1, day + offset));
  return date.toISOString().slice(0, 10);
}

function makeEmptyHeadacheHistory(startDate = tokyoIsoDate()) {
  return [
    [-5, '5日前'],
    [-4, '4日前'],
    [-3, '3日前'],
    [-1, '昨日'],
    [0, '本日'],
  ].map(([offset, label]) => ({ date: addIsoDays(startDate, offset), label, occurred: false }));
}

function makePlaceholderWeather() {
  return {
    schemaVersion: 1,
    fetchedAt: null,
    lastSuccessAt: null,
    observationTime: null,
    stale: true,
    cacheState: 'empty',
    currentTemperature: null,
    days: Array.from({ length: 7 }, (_, index) => ({
      date: tokyoIsoDate(index),
      weatherCode: null,
      icon: '--',
      condition: '--',
      high: null,
      low: null,
      rain: null,
    })),
  };
}

function parseIsoDate(isoDate) {
  const [year, month, day] = isoDate.split('-').map(Number);
  const weekday = new Date(Date.UTC(year, month - 1, day)).getUTCDay();
  return { year, month, day, weekday };
}

function formatMetric(value, suffix) {
  return value === null || value === undefined ? '--' : `${value}${suffix}`;
}

function makeEventCard(event) {
  const card = createElement('div', `event-card event-${event.owner}`);
  const ownerBar = createElement('span', 'owner-bar');
  ownerBar.setAttribute('aria-hidden', 'true');
  ownerBar.appendChild(createElement('span'));
  if (event.owner === 'joint') ownerBar.appendChild(createElement('span'));

  const copy = createElement('div', 'event-copy');
  const time = createElement('span', `event-time${event.allDay ? ' is-all-day' : ''}`, event.time);
  const title = createElement('span', 'event-title', event.summary);
  copy.append(time, title);
  card.append(ownerBar, copy);
  return card;
}

function makeEventsList(events, isPrimary) {
  if (!events.length) return createElement('p', 'empty-events', '予定はありません');

  const list = createElement('div', 'events-list');
  const maxVisible = isPrimary ? 5 : 3;
  events.slice(0, maxVisible).forEach((event) => list.appendChild(makeEventCard(event)));
  if (events.length > maxVisible) {
    list.appendChild(createElement('p', 'more-events', `ほか${events.length - maxVisible}件`));
  }
  return list;
}

function makeSectionHeading(count) {
  const heading = createElement('div', 'section-heading');
  heading.append(createElement('span', '', '予定'), createElement('b', '', `${count}件`));
  return heading;
}

function makeHeadacheHistory(history) {
  const section = createElement('section', 'headache-history');
  section.setAttribute('aria-label', '頭痛履歴');
  section.appendChild(createElement('h2', 'headache-history-title', '頭痛履歴'));
  const grid = createElement('div', 'headache-history-grid');
  history.forEach((item) => {
    const day = createElement('div', `headache-history-day${item.occurred ? ' is-headache' : ''}`);
    day.append(
      createElement('span', '', item.label),
      createElement('strong', '', item.occurred ? '頭痛発生' : '-'),
    );
    grid.appendChild(day);
  });
  section.appendChild(grid);
  return section;
}

function makePrimaryDay(day, events, headacheHistory) {
  const date = parseIsoDate(day.date);
  const card = createElement('article', 'day-card primary-day');
  const header = createElement('header', 'primary-header');
  const dateGroup = createElement('div');
  const dateTitle = createElement('h1', 'primary-date');
  dateTitle.append(
    createElement('span', 'date-month', `${date.month}月`),
    createElement('span', 'date-day', `${date.day}日`),
  );
  dateGroup.append(dateTitle, createElement('p', '', weekdayLong[date.weekday]));
  const time = createElement('time', '', '--:--');
  header.append(dateGroup, time);

  const currentWeather = createElement('div', 'primary-weather');
  const icon = makeWeatherIcon(day.weatherCode, { primary: true });
  const temperatureBlock = createElement('div', 'temperature-block');
  const currentValue = state.weather.currentTemperature;
  const currentTemp = createElement('p', 'current-temp', currentValue === null ? '--' : String(currentValue));
  if (currentValue !== null && currentValue !== undefined) currentTemp.appendChild(createElement('span', '', '°'));
  temperatureBlock.append(currentTemp, createElement('p', 'weather-label', day.condition || '--'));
  currentWeather.append(icon, temperatureBlock);

  const stats = createElement('div', 'weather-stats');
  [
    ['最高', formatMetric(day.high, '°'), 'temp-high'],
    ['最低', formatMetric(day.low, '°'), 'temp-low'],
    ['', formatMetric(day.rain, '%'), 'rain-stat'],
  ].forEach((item) => {
    const block = createElement('div');
    if (item[2] === 'rain-stat') block.setAttribute('aria-label', `降水確率 ${item[1]}`);
    block.append(createElement('span', '', item[0]), createElement('strong', item[2], item[1]));
    stats.appendChild(block);
  });

  const schedule = createElement('div', 'schedule-section primary-schedule');
  schedule.append(makeSectionHeading(events.length), makeEventsList(events, true));
  card.append(header, currentWeather, stats, makeHeadacheHistory(headacheHistory), schedule);
  return card;
}

function makeFutureDay(day, events) {
  const date = parseIsoDate(day.date);
  const card = createElement('article', 'day-card future-day');
  const header = createElement('header', 'future-header');
  header.append(createElement('strong', '', `${date.month}/${date.day}`), createElement('span', '', weekdayShort[date.weekday]));

  const futureWeather = createElement('div', 'future-weather');
  const icon = makeWeatherIcon(day.weatherCode);
  const temperatures = createElement('div', 'future-temperatures');
  temperatures.append(
    createElement('strong', 'temp-high', formatMetric(day.high, '°')),
    createElement('span', '', '/'),
    createElement('strong', 'temp-low', formatMetric(day.low, '°')),
  );
  const rain = createElement('p', 'rain-chance', formatMetric(day.rain, '%'));
  rain.setAttribute('aria-label', `降水確率 ${formatMetric(day.rain, '%')}`);
  futureWeather.append(icon, createElement('p', '', day.condition || '--'), temperatures, rain);

  const schedule = createElement('div', 'schedule-section');
  schedule.append(makeSectionHeading(events.length), makeEventsList(events, false));
  card.append(header, futureWeather, schedule);
  return card;
}

function renderEarthquakeOverlay() {
  if (!state.earthquake) return;
  const overlay = createElement('section', 'earthquake-overlay');
  overlay.setAttribute('role', 'alertdialog');
  overlay.setAttribute('aria-modal', 'true');
  const copy = createElement('div', 'earthquake-copy');
  if (state.earthquake.developmentTest) {
    copy.appendChild(createElement(
      'p',
      'earthquake-kicker',
      state.earthquake.sandbox ? '開発用テスト・P2P Sandbox' : '開発用テスト',
    ));
  }
  copy.append(
    createElement('h2', '', state.earthquake.headline),
    createElement('p', 'earthquake-region', state.earthquake.region),
  );
  const metrics = createElement('div', 'earthquake-metrics');
  [
    ['予想震度', state.earthquake.predictedIntensity || '--'],
    ['M', state.earthquake.magnitude || '--'],
    ['深さ', state.earthquake.depth || '--'],
  ].forEach(([label, value]) => {
    const metric = createElement('div', 'earthquake-metric');
    metric.append(
      createElement('span', 'earthquake-metric-label', label),
      createElement('b', 'earthquake-metric-value', value),
    );
    metrics.appendChild(metric);
  });
  copy.appendChild(metrics);
  const hypocenter = createElement('div', 'earthquake-hypocenter');
  hypocenter.append(
    createElement('span', 'earthquake-hypocenter-label', '震源'),
    createElement('p', 'earthquake-hypocenter-name', state.earthquake.hypocenter || '--'),
  );
  copy.appendChild(hypocenter);
  const metadata = createElement('p', 'earthquake-meta');
  const issued = createElement('span');
  issued.append(createElement('b', '', '発表時刻'), document.createTextNode(formatTokyoTimestamp(state.earthquake.issuedAt)));
  metadata.appendChild(issued);
  copy.appendChild(metadata);
  overlay.appendChild(copy);
  if (state.earthquake.developmentTest) {
    const close = createElement('button', 'earthquake-close', 'テスト表示を閉じる');
    close.type = 'button';
    close.addEventListener('click', () => earthquakeProvider?.clearDevelopmentAlert());
    overlay.appendChild(close);
  }
  dashboard.appendChild(overlay);
}

function renderDashboard() {
  const grid = createElement('div', 'week-grid');
  grid.appendChild(makePrimaryDay(state.weather.days[0], state.calendarDays[0] ?? [], state.headacheHistory));
  state.weather.days.slice(1).forEach((day, index) => {
    grid.appendChild(makeFutureDay(day, state.calendarDays[index + 1] ?? []));
  });
  dashboard.replaceChildren(grid);
  dashboard.dataset.theme = state.resolvedTheme;
  dashboard.dataset.headerLayout = state.headerLayout;
  renderEarthquakeOverlay();
  updateClock();
}

function updateScale() {
  const resolution = resolutions[state.resolution];
  const scale = state.displayOnly
    ? 1
    : Math.min((window.innerWidth - 48) / resolution.width, (window.innerHeight - 188) / resolution.height, 1);

  dashboardShell.style.width = `${resolution.width}px`;
  dashboardShell.style.height = `${resolution.height}px`;
  dashboardShell.style.transform = `scale(${scale})`;
  dashboard.style.setProperty('--u', `${resolution.width / 100}px`);
  deviceFrame.style.width = `${resolution.width * scale}px`;
  deviceFrame.style.height = `${resolution.height * scale}px`;
}

function updateControls() {
  document.querySelectorAll('[data-resolution]').forEach((button) => {
    button.classList.toggle('is-active', button.dataset.resolution === state.resolution);
  });
  document.querySelectorAll('[data-theme]').forEach((button) => {
    button.classList.toggle('is-active', button.dataset.theme === state.themeMode);
  });
  scenarioSelect.value = state.scenario;
  calendarProviderSelect.value = state.calendarMode;
  scenarioSelect.disabled = state.calendarMode === 'google';
  headerLayoutSelect.value = state.headerLayout;
  eewScenarioSelect.disabled = state.runtimeMode !== 'development';
}

function updateClock() {
  const time = dashboard.querySelector('.primary-header time');
  if (!time) return;
  const now = new Date();
  time.textContent = new Intl.DateTimeFormat('ja-JP', {
    timeZone: 'Asia/Tokyo',
    hour: '2-digit',
    minute: '2-digit',
    hourCycle: 'h23',
  }).format(now);
  time.dateTime = now.toISOString();
}

function formatTokyoTimestamp(value) {
  if (!value) return '--';
  return new Intl.DateTimeFormat('ja-JP', {
    timeZone: 'Asia/Tokyo',
    month: 'numeric',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hourCycle: 'h23',
  }).format(new Date(value));
}

function updateTheme(now = new Date()) {
  const automatic = resolveAutomaticTheme(now);
  state.resolvedTheme = state.themeMode === 'auto' ? automatic.theme : state.themeMode;
  dashboard.dataset.theme = state.resolvedTheme;
  updateControls();
  updateDevelopmentStatus(automatic);
}

function updateDevelopmentStatus(automatic = resolveAutomaticTheme()) {
  if (!previewStatus) return;
  const fetched = state.weather.lastSuccessAt
    ? formatTokyoTimestamp(state.weather.lastSuccessAt)
    : '未取得';
  const weatherState = state.weather.stale || state.weatherError
    ? `気象更新待ち・最終取得 ${fetched}`
    : `気象取得 ${fetched}`;
  const autoState = `Auto 日の出 ${formatMinutes(automatic.sunriseMinutes)} / 日没 ${formatMinutes(automatic.sunsetMinutes)}`;
  let calendarState = '予定 Mock';
  if (state.calendarMode === 'google') {
    if (state.calendarError) {
      const labels = {
        configuration: '設定待ち',
        authentication: '認証エラー',
        permission: '共有権限エラー',
        network: '更新待ち',
      };
      calendarState = `予定 Google ${labels[state.calendarError] || '取得エラー'}`;
    } else {
      const calendarFetched = state.calendarLastSuccessAt
        ? formatTokyoTimestamp(state.calendarLastSuccessAt)
        : '未取得';
      calendarState = `予定 Google${state.calendarStale ? ' 更新待ち' : ''} ${calendarFetched}`;
    }
  }
  const eewLabels = {
    idle: '待機',
    connecting: '接続中',
    connected: '接続済み',
    reconnecting: `再接続待ち ${Math.ceil((state.earthquakeStatus.retryInMs || 0) / 1000)}秒`,
    connection_error: '接続エラー',
    stopped: '停止',
  };
  const endpointLabel = state.earthquakeStatus.endpointKind === 'sandbox' ? 'Sandbox' : '本番556';
  const testState = state.earthquakeTestResult ? `・テスト${state.earthquakeTestResult}` : '';
  const audioState = state.earthquakeAudioResult === 'autoplay_blocked' ? '・音声許可待ち' : '';
  const earthquakeState = `地震速報 ${endpointLabel} ${eewLabels[state.earthquakeStatus.state] || state.earthquakeStatus.state}${testState}${audioState}`;
  previewStatus.textContent = `${weatherState}｜${calendarState}｜${autoState}｜${earthquakeState}`;
}

async function loadCalendar() {
  const provider = providers.calendars[state.calendarMode];
  const options = state.calendarMode === 'mock'
    ? {
        calendarId: MOCK_CALENDAR_ID,
        startDate: state.weather.days[0].date,
        days: 7,
        scenario: state.scenario,
      }
    : {};
  const result = await provider.getEvents(options);
  state.calendarDays = state.weather.days.map((weatherDay) => (
    result.days.find((calendarDay) => calendarDay.date === weatherDay.date)?.events ?? []
  ));
  state.headacheHistory = result.headacheHistory ?? makeEmptyHeadacheHistory(state.weather.days[0].date);
  state.calendarLastSuccessAt = result.lastSuccessAt ?? null;
  state.calendarStale = Boolean(result.stale);
  state.calendarError = result.errorType ?? null;
  state.calendarLoadedMode = state.calendarMode;
}

async function refreshCalendar() {
  try {
    await loadCalendar();
  } catch (error) {
    state.calendarError = error?.kind || 'unknown';
  }
  renderDashboard();
  updateDevelopmentStatus();
}

async function refreshWeather() {
  try {
    const weather = await providers.weather.getWeather();
    state.weather = weather;
    state.weatherError = null;
    renderDashboard();
    updateDevelopmentStatus();
    if (weather.cacheState === 'empty') window.setTimeout(refreshWeather, 5000);
  } catch (error) {
    state.weatherError = error instanceof Error ? error.message : 'Weather refresh failed';
    updateDevelopmentStatus();
  }
}

document.querySelectorAll('[data-resolution]').forEach((button) => {
  button.addEventListener('click', () => {
    state.resolution = button.dataset.resolution;
    updateControls();
    updateScale();
  });
});

document.querySelectorAll('[data-theme]').forEach((button) => {
  button.addEventListener('click', () => {
    state.themeMode = button.dataset.theme;
    updateTheme();
  });
});

scenarioSelect.addEventListener('change', async () => {
  state.scenario = scenarioSelect.value;
  await refreshCalendar();
});

calendarProviderSelect.addEventListener('change', async () => {
  state.calendarMode = calendarProviderSelect.value;
  state.calendarError = null;
  if (state.calendarLoadedMode !== state.calendarMode) {
    state.calendarDays = Array.from({ length: 7 }, () => []);
    state.headacheHistory = makeEmptyHeadacheHistory(state.weather.days[0].date);
    state.calendarLastSuccessAt = null;
    state.calendarStale = false;
  }
  updateControls();
  await refreshCalendar();
});

headerLayoutSelect.addEventListener('change', () => {
  state.headerLayout = headerLayoutSelect.value;
  dashboard.dataset.headerLayout = state.headerLayout;
});

eewScenarioSelect.addEventListener('change', () => {
  const scenario = eewScenarioSelect.value;
  eewScenarioSelect.value = '';
  if (!scenario || !earthquakeProvider || state.runtimeMode !== 'development') return;
  const results = earthquakeProvider.runDevelopmentScenario(scenario);
  state.earthquakeTestResult = `${scenario}:${results.map((result) => result.status).join('→')}`;
  updateDevelopmentStatus();
});

if (state.displayOnly) {
  previewApp.classList.add('display-only');
  previewCanvas.setAttribute('aria-label', '全画面表示');
}

window.addEventListener('resize', updateScale);
window.setInterval(refreshWeather, 60 * 1000);
window.setInterval(refreshCalendar, 60 * 1000);
window.setInterval(() => {
  updateClock();
  updateTheme();
}, 30 * 1000);

async function initialize() {
  try {
    const response = await fetch('/api/runtime', { cache: 'no-store' });
    const runtime = await response.json();
    if (runtime?.mode === 'production') {
      state.runtimeMode = 'production';
      state.themeMode = 'auto';
      state.calendarMode = 'google';
      state.displayOnly = true;
      previewApp.classList.add('display-only');
      previewCanvas.setAttribute('aria-label', '全画面表示');
    }
  } catch {
    // Development defaults remain active if the local runtime status is unavailable.
  }
  const endpointKind = state.runtimeMode === 'development' ? requestedEewEndpoint : 'production';
  earthquakeProvider = new P2PEarthquakeProvider({
    endpointKind,
    environment: state.runtimeMode,
    onSound: (alert) => {
      void playEewWarningTone({ developmentTest: alert.developmentTest }).then((result) => {
        state.earthquakeAudioResult = result.played ? 'played' : result.reason;
        updateDevelopmentStatus();
      });
    },
  });
  earthquakeProvider.subscribe((event) => {
    state.earthquake = event;
    renderDashboard();
  });
  earthquakeProvider.subscribeStatus((status) => {
    state.earthquakeStatus = status;
    updateDevelopmentStatus();
  });
  installEewAudioArming();
  earthquakeProvider.connect();
  updateTheme();
  updateControls();
  renderDashboard();
  updateScale();
  Promise.all([providers.battery.getBattery(), providers.powerPlug.getState()]).catch(() => {});
  refreshWeather();
  refreshCalendar();
  if (requestedEewPreview && state.runtimeMode === 'development') {
    const results = earthquakeProvider.runDevelopmentScenario(requestedEewPreview, { suppressSound: true });
    state.earthquakeTestResult = `${requestedEewPreview}:${results.map((result) => result.status).join('→')}・音なしプレビュー`;
    updateDevelopmentStatus();
  }
}

initialize();
