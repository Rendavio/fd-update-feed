. (Join-Path $PSScriptRoot "FamilyDashboard.Common.ps1")

if (-not $env:LOCALAPPDATA) {
    throw "LOCALAPPDATA is unavailable for the current user."
}

function Test-TlsPort {
    param([Parameter(Mandatory = $true)][string]$HostName)
    $client = New-Object System.Net.Sockets.TcpClient
    try {
        $async = $client.BeginConnect($HostName, 443, $null, $null)
        if (-not $async.AsyncWaitHandle.WaitOne(5000)) { return $false }
        $client.EndConnect($async)
        return $true
    } catch {
        return $false
    } finally {
        $client.Dispose()
    }
}

$health = Get-FamilyDashboardHealth
if (-not $health -or $health.appId -ne "family-dashboard") {
    throw "Family Dashboard is not responding at 127.0.0.1:3000. Start it first."
}

$dataRoot = if ($health.mode -eq "production") {
    Join-Path $env:LOCALAPPDATA "FamilyDashboard"
} else {
    Join-Path $env:LOCALAPPDATA "FamilyDashboard-Maintenance"
}
New-Item -ItemType Directory -Path $dataRoot -Force | Out-Null
$reportPath = Join-Path $dataRoot "CHUWI_Dashboard_Install_Report.txt"
$phaseAReport = Join-Path $script:InstallRoot "CHUWI_Dashboard_Install_Report.txt"

$lines = New-Object System.Collections.Generic.List[string]
if (Test-Path -LiteralPath $phaseAReport -PathType Leaf) {
    foreach ($line in [IO.File]::ReadAllLines($phaseAReport)) { $lines.Add($line) }
}
$lines.Add("")
$lines.Add("[Phase B / Runtime diagnostics]")
$lines.Add("timestamp: $([DateTimeOffset]::Now.ToString('o'))")
$lines.Add("app version: $($health.appVersion)")
$lines.Add("build ID: $($health.buildId)")
$lines.Add("runtime mode: $($health.mode)")
$lines.Add("install path: $script:InstallRoot")

$os = Get-CimInstance Win32_OperatingSystem
$lines.Add("Windows: $($os.Caption) $($os.Version)")
$lines.Add("architecture: $($os.OSArchitecture)")

$pythonVersion = (& $script:PythonPath --version 2>&1 | Out-String).Trim()
$lines.Add("runtime version: $pythonVersion")

$edgePath = Get-FamilyDashboardEdgePath
if ($edgePath) {
    $edgeVersion = (Get-Item -LiteralPath $edgePath).VersionInfo.ProductVersion
    $lines.Add("Microsoft Edge Chromium: found ($edgeVersion)")
} else {
    $lines.Add("Microsoft Edge Chromium: NOT FOUND")
}

$listeners = @(Get-NetTCPConnection -State Listen -LocalPort 3000 -ErrorAction SilentlyContinue)
$listenAddresses = @($listeners | ForEach-Object { $_.LocalAddress } | Sort-Object -Unique)
$listenText = if ($listenAddresses.Count -gt 0) { $listenAddresses -join ", " } else { "none" }
$localhostOnly = $listenAddresses.Count -eq 1 -and $listenAddresses[0] -eq "127.0.0.1"
$lines.Add("port 3000 listeners: $listenText")
$lines.Add("localhost-only listen: $(if ($localhostOnly) { 'PASS' } else { 'FAIL' })")

$video = Get-CimInstance Win32_VideoController | Where-Object {
    $_.CurrentHorizontalResolution -and $_.CurrentVerticalResolution
} | Select-Object -First 1
if ($video) {
    $lines.Add("physical/current display resolution: $($video.CurrentHorizontalResolution) x $($video.CurrentVerticalResolution)")
} else {
    $lines.Add("physical/current display resolution: unavailable")
}

$appliedDpi = $null
try {
    $appliedDpi = (Get-ItemProperty -LiteralPath "HKCU:\Control Panel\Desktop\WindowMetrics" -Name AppliedDPI -ErrorAction Stop).AppliedDPI
} catch {}
if ($appliedDpi) {
    $scalingPercent = [Math]::Round(($appliedDpi / 96.0) * 100)
    $lines.Add("Windows scaling: $scalingPercent% (AppliedDPI=$appliedDpi)")
} else {
    $lines.Add("Windows scaling: unavailable")
}
$lines.Add("browser viewport / devicePixelRatio / browser zoom: open diagnostics page and press the report button")

$allowedHosts = @(
    "www.jma.go.jp",
    "oauth2.googleapis.com",
    "www.googleapis.com",
    "api.p2pquake.net"
)
foreach ($hostName in $allowedHosts) {
    $result = if (Test-TlsPort -HostName $hostName) { "PASS" } else { "FAIL" }
    $lines.Add("external TCP 443 $($hostName): $result")
}
$lines.Add("new external destinations: none")

[IO.File]::WriteAllLines($reportPath, $lines, (New-Object Text.UTF8Encoding($false)))
Write-Host "Diagnostic report: $reportPath"

if (-not $localhostOnly) {
    throw "Port 3000 is not listening exclusively on 127.0.0.1. The diagnostics page was not opened."
}
if (-not $edgePath) {
    throw "Microsoft Edge Chromium is missing. No fallback browser was opened."
}
Open-FamilyDashboardEdge -Url $script:DiagnosticsUrl
