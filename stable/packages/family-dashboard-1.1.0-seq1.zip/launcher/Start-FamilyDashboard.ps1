param(
    [ValidateSet("production", "development")]
    [string]$Mode = "production",
    [ValidateSet("dashboard", "diagnostics")]
    [string]$Page = "dashboard"
)

. (Join-Path $PSScriptRoot "FamilyDashboard.Common.ps1")

if (-not (Test-Path -LiteralPath $script:PythonPath -PathType Leaf)) {
    throw "Bundled Python runtime is missing: $script:PythonPath"
}
if (-not (Test-Path -LiteralPath $script:ServerPath -PathType Leaf)) {
    throw "Family Dashboard app is missing: $script:ServerPath"
}
if (-not (Get-FamilyDashboardEdgePath)) {
    throw "Microsoft Edge Chromium was not found. Installation of another browser is intentionally disabled."
}
if (-not $env:LOCALAPPDATA) {
    throw "LOCALAPPDATA is unavailable for the current user."
}

if ($Mode -eq "production") {
    if ([Environment]::UserName -ne "Dashboard") {
        throw "Production mode must be started while signed in as the Dashboard user."
    }
    $dataRoot = Join-Path $env:LOCALAPPDATA "FamilyDashboard"
    $settingsPath = Join-Path $dataRoot "settings.json"
    $secretPath = Join-Path $dataRoot "secrets\service-account.json"
    $householdConfigPath = Join-Path $dataRoot "household-config.json"
    if (-not (Test-Path -LiteralPath $settingsPath -PathType Leaf)) {
        throw "settings.json is missing. Run Phase-B-Import-PrivateConfig.cmd as Dashboard."
    }
    if (-not (Test-Path -LiteralPath $secretPath -PathType Leaf)) {
        throw "service-account.json is missing. Run Phase-B-Import-PrivateConfig.cmd as Dashboard."
    }
    if (-not (Test-Path -LiteralPath $householdConfigPath -PathType Leaf)) {
        throw "household-config.json is missing. Run the private household migration as Dashboard."
    }
} else {
    if ([Environment]::UserName -ne "DashboardAdmin") {
        throw "Development maintenance mode must be started while signed in as DashboardAdmin."
    }
    $dataRoot = Join-Path $env:LOCALAPPDATA "FamilyDashboard-Maintenance"
}

$existing = Get-FamilyDashboardHealth
if ($existing) {
    if ($existing.appId -ne "family-dashboard") {
        throw "Port 3000 responded, but it is not Family Dashboard."
    }
    if ($existing.mode -ne $Mode) {
        throw "Family Dashboard is already running in $($existing.mode) mode. Stop it before switching modes."
    }
    $targetUrl = if ($Page -eq "diagnostics") { $script:DiagnosticsUrl } else { $script:ProductionUrl }
    if ($Mode -eq "development" -and $Page -eq "dashboard") {
        $targetUrl = "http://127.0.0.1:3000/?theme=auto&calendar=mock&eew=production"
    }
    Open-FamilyDashboardEdge -Url $targetUrl
    exit 0
}
if (Test-Port3000Listening) {
    throw "Port 3000 is already in use by another process. No alternate port will be selected."
}

$logRoot = Join-Path $dataRoot "logs"
New-Item -ItemType Directory -Path $logRoot -Force | Out-Null
$stdoutPath = Join-Path $logRoot "server-output.log"
$stderrPath = Join-Path $logRoot "server-error.log"
$pidPath = Join-Path $dataRoot "server.pid"

$previousMode = $env:FAMILY_DASHBOARD_MODE
$previousHome = $env:FAMILY_DASHBOARD_HOME
$previousUtf8 = $env:PYTHONUTF8
$previousNoBytecode = $env:PYTHONDONTWRITEBYTECODE
try {
    Set-ChildEnvironment -Mode $Mode -DataRoot $dataRoot
    $startOptions = @{
        FilePath = $script:PythonPath
        ArgumentList = @("-B", $script:ServerPath)
        WorkingDirectory = $script:AppRoot
        WindowStyle = "Hidden"
        RedirectStandardOutput = $stdoutPath
        RedirectStandardError = $stderrPath
        PassThru = $true
    }
    $process = Start-Process @startOptions
} finally {
    $env:FAMILY_DASHBOARD_MODE = $previousMode
    $env:FAMILY_DASHBOARD_HOME = $previousHome
    $env:PYTHONUTF8 = $previousUtf8
    $env:PYTHONDONTWRITEBYTECODE = $previousNoBytecode
}
[IO.File]::WriteAllText($pidPath, [string]$process.Id, (New-Object Text.UTF8Encoding($false)))

$health = $null
for ($attempt = 0; $attempt -lt 60; $attempt++) {
    Start-Sleep -Milliseconds 500
    if ($process.HasExited) { break }
    $health = Get-FamilyDashboardHealth
    if ($health) { break }
}
if (-not $health -or $health.appId -ne "family-dashboard" -or $health.mode -ne $Mode) {
    if (-not $process.HasExited) { Stop-Process -Id $process.Id -Force -ErrorAction SilentlyContinue }
    throw "Family Dashboard server did not become ready. Review $stderrPath. No fallback mode was attempted."
}

$targetUrl = if ($Page -eq "diagnostics") { $script:DiagnosticsUrl } else { $script:ProductionUrl }
if ($Mode -eq "development" -and $Page -eq "dashboard") {
    $targetUrl = "http://127.0.0.1:3000/?theme=auto&calendar=mock&eew=production"
}
Open-FamilyDashboardEdge -Url $targetUrl
Write-Host "Family Dashboard started: $($health.host):$($health.port) [$($health.mode)]"
